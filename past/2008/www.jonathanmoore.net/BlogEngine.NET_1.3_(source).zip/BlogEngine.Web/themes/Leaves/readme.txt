BlogEngine Leaves Theme Configuration Notes

Site.Master

<navlist>: Be sure to change the email address
<sidebar>: You may remove authors, tags, categories, Blogroll easily if you don't want them.

