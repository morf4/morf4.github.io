BlogEngine Terrafirma Theme Configuration Notes

Site.Master

<sidebar>: You may remove tags, categories, Blogroll easily if you don't want them.
<blogroll>: Set max length of items to 23