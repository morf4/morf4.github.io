By default, nothing special is needed to setup BlogEngine.NET.  

However, if you wish to use the SQL Server provider (instead of the default XML provider) for data storage
you will need a little instruction.

The instructions can be found on our wiki:
http://www.dotnetblogengine.net/wiki/SQLServerBlogProvider.ashx

The latest version of the SQL installation script is located in this folder.  

You should use that file to create your database tables.