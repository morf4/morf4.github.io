<?php
/**
 *
 * Theme Hook Functions
 *
 */

function decode_header_image() {
	do_action( 'decode_header_image' );
}

function decode_social_icons_first() {
	do_action( 'decode_social_icons_first' );
}

function decode_social_icons_last() {
	do_action( 'decode_social_icons_last' );
}