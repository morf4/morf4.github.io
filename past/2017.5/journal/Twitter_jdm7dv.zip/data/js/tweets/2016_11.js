Grailbird.data.tweets_2016_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804156537799372800",
  "text" : "Zuckerberg when I get all of my feeds and a bot I'm gone nobody loves me either. This will never be tv.",
  "id" : 804156537799372800,
  "created_at" : "2016-12-01 02:53:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "indices" : [ 81, 89 ],
      "id_str" : "1652541",
      "id" : 1652541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/jClFgYqr72",
      "expanded_url" : "http:\/\/reut.rs\/2eNfiH1",
      "display_url" : "reut.rs\/2eNfiH1"
    } ]
  },
  "geo" : { },
  "id_str" : "804050301556838404",
  "text" : "House Republicans test Trump on his U.S.-Mexico wall https:\/\/t.co\/jClFgYqr72 via @Reuters",
  "id" : 804050301556838404,
  "created_at" : "2016-11-30 19:51:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804037973167767552",
  "text" : "trump you do have mafia ties and I really don't like you I may want security.",
  "id" : 804037973167767552,
  "created_at" : "2016-11-30 19:02:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803922660631736320",
  "text" : "Internationally it ias called a joint venture too.",
  "id" : 803922660631736320,
  "created_at" : "2016-11-30 11:24:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803922639374925824",
  "text" : "Microsoft I could have registered with the IRS on the old partnership but never did. I am this time.",
  "id" : 803922639374925824,
  "created_at" : "2016-11-30 11:24:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/bEQGrUoDqx",
      "expanded_url" : "https:\/\/framework.gusto.com\/the-different-ways-business-owners-can-pay-themselves\/",
      "display_url" : "framework.gusto.com\/the-different-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803921473920466944",
  "text" : "https:\/\/t.co\/bEQGrUoDqx Whoever I talked to an lied about the W-2 and owners draw my hear it from me too Abingdon. Pay yourself.",
  "id" : 803921473920466944,
  "created_at" : "2016-11-30 11:19:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803848406628233216",
  "text" : "This area wants me to go to jail Goodnight fucking SWVA.",
  "id" : 803848406628233216,
  "created_at" : "2016-11-30 06:29:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803848239715909634",
  "text" : "Maybe deposit the shareholders distribution sometime after I call the bank. I just don't have all of the law document s no lawyer wouldhelp.",
  "id" : 803848239715909634,
  "created_at" : "2016-11-30 06:28:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803845910702780416",
  "text" : "That is erp5 too and you can have the bank.",
  "id" : 803845910702780416,
  "created_at" : "2016-11-30 06:19:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803845337546977280",
  "text" : "If it's just a check programmer and I don't even want to be on your team I'm mad.",
  "id" : 803845337546977280,
  "created_at" : "2016-11-30 06:17:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803844304439570434",
  "text" : "That is ugene to Russia thank you I do remember blast.",
  "id" : 803844304439570434,
  "created_at" : "2016-11-30 06:13:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803843466442764288",
  "text" : "I did think of buying checks online at they always ask for a rounding number and account maybe if I don't have to start a bank.",
  "id" : 803843466442764288,
  "created_at" : "2016-11-30 06:09:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803841550597898241",
  "text" : "When it threatens my food accountant I do get mad. And that is a free App Store mostly too Goodnight.",
  "id" : 803841550597898241,
  "created_at" : "2016-11-30 06:02:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803840565452374016",
  "text" : "storming goodnight.",
  "id" : 803840565452374016,
  "created_at" : "2016-11-30 05:58:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803840359080095744",
  "text" : "All it is accountant in a damn transaction too.",
  "id" : 803840359080095744,
  "created_at" : "2016-11-30 05:57:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803839927859445760",
  "text" : "It would have to be an s corp and a shareholders distribution..",
  "id" : 803839927859445760,
  "created_at" : "2016-11-30 05:55:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803839749370814465",
  "text" : "see sole proprietors can't pay themselves and you can't deposit equity into the bank I don't think either.",
  "id" : 803839749370814465,
  "created_at" : "2016-11-30 05:55:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/shX6jrSQYT",
      "expanded_url" : "http:\/\/www.timetrex.com\/",
      "display_url" : "timetrex.com"
    } ]
  },
  "geo" : { },
  "id_str" : "803839313779757058",
  "text" : "https:\/\/t.co\/shX6jrSQYT My Dad used Oracles ebusness suite and thought it was complicated. It is just time payroll and human resources.",
  "id" : 803839313779757058,
  "created_at" : "2016-11-30 05:53:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Ec1rws5OzV",
      "expanded_url" : "http:\/\/blog.capterra.com\/top-8-freeopen-source-lmss\/",
      "display_url" : "blog.capterra.com\/top-8-freeopen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803838359034544128",
  "text" : "https:\/\/t.co\/Ec1rws5OzV LMS",
  "id" : 803838359034544128,
  "created_at" : "2016-11-30 05:49:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803837031180894208",
  "text" : "See smart home the HomeOs just isn't organized well.",
  "id" : 803837031180894208,
  "created_at" : "2016-11-30 05:44:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803836213807513601",
  "text" : "I've seen those million dollar homes on Discovery too. Just not interested.Unmaintaible. They so just make them and sell them.",
  "id" : 803836213807513601,
  "created_at" : "2016-11-30 05:41:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803834996003893250",
  "text" : "I like some javascript HomeOS but it is for the web.",
  "id" : 803834996003893250,
  "created_at" : "2016-11-30 05:36:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/xEzNwpn9L6",
      "expanded_url" : "http:\/\/www.cam.ac.uk\/research\/news\/mathematical-breakthrough-sets-out-rules-for-more-effective-teleportation",
      "display_url" : "cam.ac.uk\/research\/news\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803833260375732224",
  "text" : "Mathematical breakthrough sets out rules for more effective teleportation  https:\/\/t.co\/xEzNwpn9L6",
  "id" : 803833260375732224,
  "created_at" : "2016-11-30 05:29:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803833094012866560",
  "text" : "Microsoft if I lived in Redmond I would just say I don't want to come to the Office either cars are just inefficient too.",
  "id" : 803833094012866560,
  "created_at" : "2016-11-30 05:28:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803832134213439488",
  "text" : "While I've waiting on my bed linen to dry I'll work with HomeOS.",
  "id" : 803832134213439488,
  "created_at" : "2016-11-30 05:24:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803831592317755392",
  "text" : "I've have HomeOS since 2011.",
  "id" : 803831592317755392,
  "created_at" : "2016-11-30 05:22:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/dKC8gIOxiM",
      "expanded_url" : "http:\/\/www.ibm.com\/smarterplanet\/us\/en\/smarter_cities\/overview\/",
      "display_url" : "ibm.com\/smarterplanet\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803830898986774528",
  "text" : "https:\/\/t.co\/dKC8gIOxiM Smart Cities IBM and I live in a town. I don't want to live in a city.",
  "id" : 803830898986774528,
  "created_at" : "2016-11-30 05:19:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803828734751076352",
  "text" : "And all Of this is already backed up up in the bank vault ETSU men. Now 10 Terabytes I'm done.",
  "id" : 803828734751076352,
  "created_at" : "2016-11-30 05:11:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/P1qaNKR6lH",
      "expanded_url" : "https:\/\/twitter.com\/guardian\/status\/803817875945517057",
      "display_url" : "twitter.com\/guardian\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803828036370104321",
  "text" : "Hi Trump. https:\/\/t.co\/P1qaNKR6lH",
  "id" : 803828036370104321,
  "created_at" : "2016-11-30 05:08:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Z4afOzdbS9",
      "expanded_url" : "https:\/\/www.microsoft.com\/en-us\/research\/project\/homeos-enabling-smarter-homes-for-everyone\/",
      "display_url" : "microsoft.com\/en-us\/research\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803826926565687296",
  "text" : "https:\/\/t.co\/Z4afOzdbS9 Home OS is open too. At Microsoft Research",
  "id" : 803826926565687296,
  "created_at" : "2016-11-30 05:04:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803825581490110464",
  "text" : "ttps:\/\/www.amazon.com\/IBM-Home-Director-Starter-Kit\/dp\/B004GVN63M IBM home director C.",
  "id" : 803825581490110464,
  "created_at" : "2016-11-30 04:58:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803825238182154241",
  "text" : "I had a smart home in 1998 with IBM.",
  "id" : 803825238182154241,
  "created_at" : "2016-11-30 04:57:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/dr5IgJ9JZY",
      "expanded_url" : "http:\/\/www.eclipse.org\/smarthome\/",
      "display_url" : "eclipse.org\/smarthome\/"
    } ]
  },
  "geo" : { },
  "id_str" : "803825132628246528",
  "text" : "https:\/\/t.co\/dr5IgJ9JZY Open Hab",
  "id" : 803825132628246528,
  "created_at" : "2016-11-30 04:57:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/NwC0yDHZ4u",
      "expanded_url" : "http:\/\/www.zdnet.com\/article\/why-microsoft-is-turning-into-an-open-source-company\/",
      "display_url" : "zdnet.com\/article\/why-mi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803823948702027776",
  "text" : "https:\/\/t.co\/NwC0yDHZ4u Microsoft is turning into an open source company. Adobe.",
  "id" : 803823948702027776,
  "created_at" : "2016-11-30 04:52:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803823067973742592",
  "text" : "With the hot girl maybe.",
  "id" : 803823067973742592,
  "created_at" : "2016-11-30 04:48:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803822985358483456",
  "text" : "When this area Acknowledges that I've worked and gotten a check from Adobe and treats me like the tech experience that I have.",
  "id" : 803822985358483456,
  "created_at" : "2016-11-30 04:48:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803821444518002688",
  "text" : "I'm just not connecting to a local startup datacenter either that is Azure and at least Google's Cloud I pay $1.99 a month for my GDrive.",
  "id" : 803821444518002688,
  "created_at" : "2016-11-30 04:42:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/vuoTOvpi9E",
      "expanded_url" : "http:\/\/chapel.cray.com\/docs\/1.12\/platforms\/cygwin.html",
      "display_url" : "chapel.cray.com\/docs\/1.12\/plat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803820281043132416",
  "text" : "https:\/\/t.co\/vuoTOvpi9E Chap[el will just build on Windows 10 Pro too.",
  "id" : 803820281043132416,
  "created_at" : "2016-11-30 04:37:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803819201358073856",
  "text" : "I had the Dell Optiplex and it latest for 9 years. With me taking it apart and was still going before it was attacked.",
  "id" : 803819201358073856,
  "created_at" : "2016-11-30 04:33:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/6LGtHgMWab",
      "expanded_url" : "http:\/\/www.dell.com\/us\/business\/p\/poweredge-r410\/pd",
      "display_url" : "dell.com\/us\/business\/p\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803818437336305664",
  "text" : "https:\/\/t.co\/6LGtHgMWab It 3 years old and I bought it for $400.00 I already have a touchscreen and a 3 tb drive to put in it.",
  "id" : 803818437336305664,
  "created_at" : "2016-11-30 04:30:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/gW9CFgMrdl",
      "expanded_url" : "http:\/\/www.laptopmag.com\/articles\/icloud-email-calendars-windows",
      "display_url" : "laptopmag.com\/articles\/iclou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803815997237055488",
  "text" : "https:\/\/t.co\/gW9CFgMrdl icloud mail for windows 10.",
  "id" : 803815997237055488,
  "created_at" : "2016-11-30 04:20:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/sPDzfoxkkM",
      "expanded_url" : "https:\/\/exchangeserverstips.wordpress.com\/2013\/12\/24\/steps-to-convert-mbox-file-to-pst-file-manually\/",
      "display_url" : "exchangeserverstips.wordpress.com\/2013\/12\/24\/ste\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803814880981745664",
  "text" : "https:\/\/t.co\/sPDzfoxkkM Apple mail For Windows?",
  "id" : 803814880981745664,
  "created_at" : "2016-11-30 04:16:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803813641984372736",
  "text" : "looking for an excel or outlook add=in.",
  "id" : 803813641984372736,
  "created_at" : "2016-11-30 04:11:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803812933407019008",
  "text" : "it is mbox Avid and Apple and Google. But I need a free Mbox to CSV email converter.",
  "id" : 803812933407019008,
  "created_at" : "2016-11-30 04:08:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803812272326004736",
  "text" : "I kinda like Pocket too If it would import all of my bookmarks into a nice website.",
  "id" : 803812272326004736,
  "created_at" : "2016-11-30 04:05:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803811665292693508",
  "text" : "Did it ship servermokey? You've had three days I'll call tomorrow.",
  "id" : 803811665292693508,
  "created_at" : "2016-11-30 04:03:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/KcJ4lGeLTR",
      "expanded_url" : "https:\/\/www.ncbi.nlm.nih.gov\/pmc\/articles\/PMC4799706\/",
      "display_url" : "ncbi.nlm.nih.gov\/pmc\/articles\/P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803810056605204480",
  "text" : "https:\/\/t.co\/KcJ4lGeLTR Education platform on NCBI.",
  "id" : 803810056605204480,
  "created_at" : "2016-11-30 03:57:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/7VyooJ0P7l",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Rosalind_(education_platform)",
      "display_url" : "en.wikipedia.org\/wiki\/Rosalind_\u2026"
    }, {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/IXvDaMGn3s",
      "expanded_url" : "http:\/\/Moore.com",
      "display_url" : "Moore.com"
    } ]
  },
  "geo" : { },
  "id_str" : "803809335482716160",
  "text" : "https:\/\/t.co\/7VyooJ0P7l Looking I would say .net or .org too Jonathan https:\/\/t.co\/IXvDaMGn3s.",
  "id" : 803809335482716160,
  "created_at" : "2016-11-30 03:54:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/057dEWbV4m",
      "expanded_url" : "http:\/\/smarteducationplatform.com\/",
      "display_url" : "smarteducationplatform.com"
    } ]
  },
  "geo" : { },
  "id_str" : "803808406322769920",
  "text" : "https:\/\/t.co\/057dEWbV4m this is better.",
  "id" : 803808406322769920,
  "created_at" : "2016-11-30 03:50:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803807281129332737",
  "text" : "BedWetter if I hear you say you have something \"special\" I am letting you have it with Nirvana.",
  "id" : 803807281129332737,
  "created_at" : "2016-11-30 03:46:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 3, 16 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/Mdrc0QWPQo",
      "expanded_url" : "http:\/\/econ.st\/2fWfCS8",
      "display_url" : "econ.st\/2fWfCS8"
    } ]
  },
  "geo" : { },
  "id_str" : "803806597763964928",
  "text" : "RT @TheEconomist: Is the \u201Cimpossible\u201D rocket engine a physics-altering breakthrough or an experimental error? https:\/\/t.co\/Mdrc0QWPQo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/Mdrc0QWPQo",
        "expanded_url" : "http:\/\/econ.st\/2fWfCS8",
        "display_url" : "econ.st\/2fWfCS8"
      } ]
    },
    "geo" : { },
    "id_str" : "803794066072858625",
    "text" : "Is the \u201Cimpossible\u201D rocket engine a physics-altering breakthrough or an experimental error? https:\/\/t.co\/Mdrc0QWPQo",
    "id" : 803794066072858625,
    "created_at" : "2016-11-30 02:53:33 +0000",
    "user" : {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "protected" : false,
      "id_str" : "5988062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461499742950678528\/2JnpHjUo_normal.png",
      "id" : 5988062,
      "verified" : true
    }
  },
  "id" : 803806597763964928,
  "created_at" : "2016-11-30 03:43:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/nSAw6vMLj6",
      "expanded_url" : "https:\/\/cloud.google.com\/",
      "display_url" : "cloud.google.com"
    } ]
  },
  "geo" : { },
  "id_str" : "803805565747130368",
  "text" : "https:\/\/t.co\/nSAw6vMLj6 I like Phillips Google but that's it.",
  "id" : 803805565747130368,
  "created_at" : "2016-11-30 03:39:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/EHtq6CMbu9",
      "expanded_url" : "http:\/\/tutorial.programming4.us\/windows_server\/sharepoint-2010-search---relevancy-algorithms.aspx",
      "display_url" : "tutorial.programming4.us\/windows_server\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803804549639274496",
  "text" : "https:\/\/t.co\/EHtq6CMbu9 See What Bing uses They use Sharepoint 2016 now probably.",
  "id" : 803804549639274496,
  "created_at" : "2016-11-30 03:35:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803803328438292480",
  "text" : "It was search server which probably contains parts of Stanford's Webbase maybe. Google I do get it.",
  "id" : 803803328438292480,
  "created_at" : "2016-11-30 03:30:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803802447848361984",
  "text" : "Google it is a Federated Search in Sharepont too.",
  "id" : 803802447848361984,
  "created_at" : "2016-11-30 03:26:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803800790502666240",
  "text" : "The form just doesn't work Microsoft I'll bookmark and search for reconnect.",
  "id" : 803800790502666240,
  "created_at" : "2016-11-30 03:20:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/uPFtvOKzC4",
      "expanded_url" : "https:\/\/twitter.com\/MVPAward\/status\/803798711268741121",
      "display_url" : "twitter.com\/MVPAward\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803799648800489473",
  "text" : "I'm trying to fill out this form but the design is terrible. https:\/\/t.co\/uPFtvOKzC4",
  "id" : 803799648800489473,
  "created_at" : "2016-11-30 03:15:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803799057407807489",
  "text" : "My yogurt is light without aspartame.",
  "id" : 803799057407807489,
  "created_at" : "2016-11-30 03:13:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803797186618265600",
  "text" : "You are Conductor but I have all I probably need from Microsoft.",
  "id" : 803797186618265600,
  "created_at" : "2016-11-30 03:05:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803796759520673792",
  "text" : "Microsoft Identity Manager 2016. I think.",
  "id" : 803796759520673792,
  "created_at" : "2016-11-30 03:04:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/AfT6Wy8zHL",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Forefront_Identity_Manager",
      "display_url" : "en.wikipedia.org\/wiki\/Forefront\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803796269290426369",
  "text" : "https:\/\/t.co\/AfT6Wy8zHL It was FIM in 2012.",
  "id" : 803796269290426369,
  "created_at" : "2016-11-30 03:02:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803795337408380929",
  "text" : "Probably in system center.",
  "id" : 803795337408380929,
  "created_at" : "2016-11-30 02:58:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803795273067757568",
  "text" : "It is Project 2016 and there hasn't been a release of Project Server since 2016 and I can't find any security for the server yet.",
  "id" : 803795273067757568,
  "created_at" : "2016-11-30 02:58:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803793192999153664",
  "text" : "Edx is open and on github but not a degree.",
  "id" : 803793192999153664,
  "created_at" : "2016-11-30 02:50:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/f8oT2hpYhp",
      "expanded_url" : "https:\/\/mail.python.org\/pipermail\/mailman-users\/2011-August\/072150.html",
      "display_url" : "mail.python.org\/pipermail\/mail\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803791809633800192",
  "text" : "https:\/\/t.co\/f8oT2hpYhp Mailman on Windows it is possible but not easy he said.",
  "id" : 803791809633800192,
  "created_at" : "2016-11-30 02:44:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 0, 6 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/tNZmhuCZ0w",
      "expanded_url" : "http:\/\/www.groom.com\/media\/publication\/1260_Paying_Employee_Benefit_Plan_Expenses.pdf",
      "display_url" : "groom.com\/media\/publicat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803791303217651712",
  "in_reply_to_user_id" : 1536791610,
  "text" : "@POTUS https:\/\/t.co\/tNZmhuCZ0w Hope this helps everyone on the money.",
  "id" : 803791303217651712,
  "created_at" : "2016-11-30 02:42:35 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/oECdzEz0fS",
      "expanded_url" : "https:\/\/blogs.technet.microsoft.com\/exchange\/2013\/11\/13\/exchange-server-the-road-ahead\/",
      "display_url" : "blogs.technet.microsoft.com\/exchange\/2013\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803790611740553217",
  "text" : "Exchange Server: The Road Ahead https:\/\/t.co\/oECdzEz0fS",
  "id" : 803790611740553217,
  "created_at" : "2016-11-30 02:39:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803789239020294145",
  "text" : "Skype for Business Server 2015",
  "id" : 803789239020294145,
  "created_at" : "2016-11-30 02:34:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803788891274772480",
  "text" : "I would say Forefront Security for Office Communications Server too but last release was in 2009.",
  "id" : 803788891274772480,
  "created_at" : "2016-11-30 02:33:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/6AEd7ZRkRJ",
      "expanded_url" : "https:\/\/twitter.com\/BBCWorld\/status\/803785413966069760",
      "display_url" : "twitter.com\/BBCWorld\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803786968245141504",
  "text" : "I really do hate to say it everyone but no sometimes means yes another double standard. https:\/\/t.co\/6AEd7ZRkRJ",
  "id" : 803786968245141504,
  "created_at" : "2016-11-30 02:25:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803786235579920385",
  "text" : "I really like mailman and don't need Exchange Server that much",
  "id" : 803786235579920385,
  "created_at" : "2016-11-30 02:22:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803783971200974848",
  "text" : "Windows Server 2016 Essentials is out and in you bizspark subscription.",
  "id" : 803783971200974848,
  "created_at" : "2016-11-30 02:13:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803781914972876800",
  "text" : "I do see a Windows Server Essentials 2012 R2 just not 2016.",
  "id" : 803781914972876800,
  "created_at" : "2016-11-30 02:05:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/mud3BvOWSG",
      "expanded_url" : "https:\/\/blogs.office.com\/2016\/05\/04\/office-online-server-now-available\/",
      "display_url" : "blogs.office.com\/2016\/05\/04\/off\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803780821597454337",
  "text" : "https:\/\/t.co\/mud3BvOWSG Try Office Online Server.",
  "id" : 803780821597454337,
  "created_at" : "2016-11-30 02:00:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803779403696263168",
  "text" : "It might not be sharepoint I'll look in my MSDN subscription.",
  "id" : 803779403696263168,
  "created_at" : "2016-11-30 01:55:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803778078337970177",
  "text" : "I am on Comcast and just don't like that coaxial.",
  "id" : 803778078337970177,
  "created_at" : "2016-11-30 01:50:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/1b96IP9Se9",
      "expanded_url" : "https:\/\/technet.microsoft.com\/en-us\/library\/bb457037.aspx",
      "display_url" : "technet.microsoft.com\/en-us\/library\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803777551072165889",
  "text" : "https:\/\/t.co\/1b96IP9Se9 It is a star topology, but home or small business too.",
  "id" : 803777551072165889,
  "created_at" : "2016-11-30 01:47:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn SlideShare",
      "screen_name" : "SlideShare",
      "indices" : [ 123, 134 ],
      "id_str" : "9676152",
      "id" : 9676152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "architecture",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/P5Q3RUbFvR",
      "expanded_url" : "http:\/\/www.slideshare.net\/kmdfaizal\/deep-dive-into-sharepoint-topologies-and-server-architecture-for-sharepoint-2013",
      "display_url" : "slideshare.net\/kmdfaizal\/deep\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803775814814859264",
  "text" : "Deep Dive into SharePoint Topologies and Server Architecture for SharePoint 2013 #architecture https:\/\/t.co\/P5Q3RUbFvR via @SlideShare",
  "id" : 803775814814859264,
  "created_at" : "2016-11-30 01:41:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/38gCfn5zQ8",
      "expanded_url" : "http:\/\/www.learningsharepoint.com\/2015\/08\/24\/things-you-need-to-know-before-you-install-sharepoint-2016-preview\/",
      "display_url" : "learningsharepoint.com\/2015\/08\/24\/thi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803774759729119233",
  "text" : "https:\/\/t.co\/38gCfn5zQ8 It is a star topology Microsoft could I connect the laptop to a farm?",
  "id" : 803774759729119233,
  "created_at" : "2016-11-30 01:36:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bloomberg",
      "screen_name" : "business",
      "indices" : [ 3, 12 ],
      "id_str" : "34713362",
      "id" : 34713362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Pzm89ZEIja",
      "expanded_url" : "http:\/\/bloom.bg\/2fAz4rs",
      "display_url" : "bloom.bg\/2fAz4rs"
    } ]
  },
  "geo" : { },
  "id_str" : "803773157584891905",
  "text" : "RT @business: Carrier reaches deal with Trump to keep about 1,000 U.S. jobs that had been set to move to Mexico https:\/\/t.co\/Pzm89ZEIja htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/business\/status\/803772989221109760\/photo\/1",
        "indices" : [ 122, 145 ],
        "url" : "https:\/\/t.co\/n90DUw2jkX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CyeTRcsXAAAMxik.jpg",
        "id_str" : "803772986478231552",
        "id" : 803772986478231552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyeTRcsXAAAMxik.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 2200
        } ],
        "display_url" : "pic.twitter.com\/n90DUw2jkX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/Pzm89ZEIja",
        "expanded_url" : "http:\/\/bloom.bg\/2fAz4rs",
        "display_url" : "bloom.bg\/2fAz4rs"
      } ]
    },
    "geo" : { },
    "id_str" : "803772989221109760",
    "text" : "Carrier reaches deal with Trump to keep about 1,000 U.S. jobs that had been set to move to Mexico https:\/\/t.co\/Pzm89ZEIja https:\/\/t.co\/n90DUw2jkX",
    "id" : 803772989221109760,
    "created_at" : "2016-11-30 01:29:48 +0000",
    "user" : {
      "name" : "Bloomberg",
      "screen_name" : "business",
      "protected" : false,
      "id_str" : "34713362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714946924105883648\/4fgNVF4H_normal.jpg",
      "id" : 34713362,
      "verified" : true
    }
  },
  "id" : 803773157584891905,
  "created_at" : "2016-11-30 01:30:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803773089616162816",
  "text" : "I bookmarked that book I'll by it used in the new year after I deploy my poweredge.Hopefully.",
  "id" : 803773089616162816,
  "created_at" : "2016-11-30 01:30:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803772217309925376",
  "text" : "Microsoft Gayler did tell me I won my MVP a long time ago find Jason Gayler Microsoft I really don't remember much nobody talks to me.",
  "id" : 803772217309925376,
  "created_at" : "2016-11-30 01:26:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803770996771749888",
  "text" : "Visual Powershell editor probably.",
  "id" : 803770996771749888,
  "created_at" : "2016-11-30 01:21:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/spsENVdZNS",
      "expanded_url" : "https:\/\/absolute-sharepoint.com\/",
      "display_url" : "absolute-sharepoint.com"
    } ]
  },
  "geo" : { },
  "id_str" : "803770620605513729",
  "text" : "https:\/\/t.co\/spsENVdZNS I just don't Steal code MVP. Thanks for the book.",
  "id" : 803770620605513729,
  "created_at" : "2016-11-30 01:20:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 109, 116 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/CFwybDlVrI",
      "expanded_url" : "https:\/\/www.amazon.com\/dp\/1484219988\/ref=cm_sw_r_tw_dp_x_1JIpybQWW3SSB",
      "display_url" : "amazon.com\/dp\/1484219988\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803770294028607488",
  "text" : "Deploying SharePoint 2016: Best Practices for Installing, Configuring, and Ma... https:\/\/t.co\/CFwybDlVrI via @amazon",
  "id" : 803770294028607488,
  "created_at" : "2016-11-30 01:19:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "listly",
      "indices" : [ 41, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/aGty3ebV1a",
      "expanded_url" : "http:\/\/list.ly\/list\/2yJ-sharepoint-blogs",
      "display_url" : "list.ly\/list\/2yJ-share\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803769381092212736",
  "text" : "SharePoint Blogs https:\/\/t.co\/aGty3ebV1a #listly",
  "id" : 803769381092212736,
  "created_at" : "2016-11-30 01:15:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/J6DkrasMGZ",
      "expanded_url" : "http:\/\/superuser.com\/questions\/664890\/deployment-fail-during-generate-star-schema",
      "display_url" : "superuser.com\/questions\/6648\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803768248944693248",
  "text" : "https:\/\/t.co\/J6DkrasMGZ Deployment with a Star schema.",
  "id" : 803768248944693248,
  "created_at" : "2016-11-30 01:10:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/PmWNSzHQWj",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Star_network",
      "display_url" : "en.wikipedia.org\/wiki\/Star_netw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803766293782495234",
  "text" : "https:\/\/t.co\/PmWNSzHQWj Star network or topology.",
  "id" : 803766293782495234,
  "created_at" : "2016-11-30 01:03:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ySaUYIElsv",
      "expanded_url" : "https:\/\/technet.microsoft.com\/en-us\/library\/bb905541(v=office.12).aspx",
      "display_url" : "technet.microsoft.com\/en-us\/library\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803765723168407552",
  "text" : "https:\/\/t.co\/ySaUYIElsv Thinking about my topology and is is a Star topology I forgot about or a client server topology.",
  "id" : 803765723168407552,
  "created_at" : "2016-11-30 01:00:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/v0OnoYdUY1",
      "expanded_url" : "http:\/\/www.disruptivei.com\/Blogg\/Inl%C3%A4gg\/6\/Install-SharePoint-2013-on-Windows-7-8-8-1",
      "display_url" : "disruptivei.com\/Blogg\/Inl%C3%A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803764621110902785",
  "text" : "https:\/\/t.co\/v0OnoYdUY1 I really don't want to do this Hawking.",
  "id" : 803764621110902785,
  "created_at" : "2016-11-30 00:56:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/iRWfljw6Ak",
      "expanded_url" : "http:\/\/sharepoint.stackexchange.com\/",
      "display_url" : "sharepoint.stackexchange.com"
    } ]
  },
  "geo" : { },
  "id_str" : "803764072160313345",
  "text" : "https:\/\/t.co\/iRWfljw6Ak I'm thinking.",
  "id" : 803764072160313345,
  "created_at" : "2016-11-30 00:54:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 3, 16 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/wTGwYQFfxa",
      "expanded_url" : "http:\/\/econ.st\/2geJtIk",
      "display_url" : "econ.st\/2geJtIk"
    } ]
  },
  "geo" : { },
  "id_str" : "803762816016465920",
  "text" : "RT @TheEconomist: Expect more high profile Chinese success stories in business and society in years to come https:\/\/t.co\/wTGwYQFfxa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/wTGwYQFfxa",
        "expanded_url" : "http:\/\/econ.st\/2geJtIk",
        "display_url" : "econ.st\/2geJtIk"
      } ]
    },
    "geo" : { },
    "id_str" : "803762005752459264",
    "text" : "Expect more high profile Chinese success stories in business and society in years to come https:\/\/t.co\/wTGwYQFfxa",
    "id" : 803762005752459264,
    "created_at" : "2016-11-30 00:46:10 +0000",
    "user" : {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "protected" : false,
      "id_str" : "5988062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461499742950678528\/2JnpHjUo_normal.png",
      "id" : 5988062,
      "verified" : true
    }
  },
  "id" : 803762816016465920,
  "created_at" : "2016-11-30 00:49:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open at Microsoft",
      "screen_name" : "OpenAtMicrosoft",
      "indices" : [ 3, 19 ],
      "id_str" : "45036289",
      "id" : 45036289
    }, {
      "name" : "Josh Gavant",
      "screen_name" : "joshugav",
      "indices" : [ 92, 101 ],
      "id_str" : "80172772",
      "id" : 80172772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803762795170893824",
  "text" : "RT @OpenAtMicrosoft: Turn system inside out so you understand how it's *supposed* to work w\/@joshugav tomorrow 11:20 https:\/\/t.co\/bRheQLPm4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Gavant",
        "screen_name" : "joshugav",
        "indices" : [ 71, 80 ],
        "id_str" : "80172772",
        "id" : 80172772
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OpenAtMicrosoft\/status\/803761717272399872\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/Z4NuwCoBzH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CyeJBVOWQAAipAP.jpg",
        "id_str" : "803761714479120384",
        "id" : 803761714479120384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyeJBVOWQAAipAP.jpg",
        "sizes" : [ {
          "h" : 144,
          "resize" : "fit",
          "w" : 144
        }, {
          "h" : 144,
          "resize" : "fit",
          "w" : 144
        }, {
          "h" : 144,
          "resize" : "fit",
          "w" : 144
        }, {
          "h" : 144,
          "resize" : "fit",
          "w" : 144
        }, {
          "h" : 144,
          "resize" : "crop",
          "w" : 144
        } ],
        "display_url" : "pic.twitter.com\/Z4NuwCoBzH"
      } ],
      "hashtags" : [ {
        "text" : "NodeInteractive",
        "indices" : [ 120, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/bRheQLPm4V",
        "expanded_url" : "http:\/\/sched.co\/8H7J",
        "display_url" : "sched.co\/8H7J"
      } ]
    },
    "geo" : { },
    "id_str" : "803761717272399872",
    "text" : "Turn system inside out so you understand how it's *supposed* to work w\/@joshugav tomorrow 11:20 https:\/\/t.co\/bRheQLPm4V #NodeInteractive https:\/\/t.co\/Z4NuwCoBzH",
    "id" : 803761717272399872,
    "created_at" : "2016-11-30 00:45:01 +0000",
    "user" : {
      "name" : "Open at Microsoft",
      "screen_name" : "OpenAtMicrosoft",
      "protected" : false,
      "id_str" : "45036289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623264825465040896\/aUzLHrCL_normal.png",
      "id" : 45036289,
      "verified" : true
    }
  },
  "id" : 803762795170893824,
  "created_at" : "2016-11-30 00:49:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803762616950624257",
  "text" : "I forgot most of my math is there a Rosetta Stone for Math. The Stanford background refresh might be enough.",
  "id" : 803762616950624257,
  "created_at" : "2016-11-30 00:48:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803759289730875393",
  "text" : "Is anyone on anybody's payroll anymore? Talk financial advisor. In January.",
  "id" : 803759289730875393,
  "created_at" : "2016-11-30 00:35:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/tNZmhuCZ0w",
      "expanded_url" : "http:\/\/www.groom.com\/media\/publication\/1260_Paying_Employee_Benefit_Plan_Expenses.pdf",
      "display_url" : "groom.com\/media\/publicat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803757571706388480",
  "text" : "https:\/\/t.co\/tNZmhuCZ0w Here's the money I hope everyone tweeted this to Obama and Trump.",
  "id" : 803757571706388480,
  "created_at" : "2016-11-30 00:28:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/hZjd8UmuS1",
      "expanded_url" : "http:\/\/lifehacker.com\/5793427\/how-to-create-a-custom-windows-installation-dvd-or-usb-install?utm_medium=sharefromsite&utm_source=Lifehacker_twitter",
      "display_url" : "lifehacker.com\/5793427\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803756673626087424",
  "text" : "How to Create a Custom Windows Installation DVD or USB Install https:\/\/t.co\/hZjd8UmuS1",
  "id" : 803756673626087424,
  "created_at" : "2016-11-30 00:24:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faithful Thinkers",
      "screen_name" : "FaithfulThinker",
      "indices" : [ 3, 19 ],
      "id_str" : "181962146",
      "id" : 181962146
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BookReview",
      "indices" : [ 21, 32 ]
    }, {
      "text" : "science",
      "indices" : [ 72, 80 ]
    }, {
      "text" : "biochemistry",
      "indices" : [ 81, 94 ]
    }, {
      "text" : "information",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/zyrvvyWCOp",
      "expanded_url" : "http:\/\/owl.li\/XgPf301DcLP",
      "display_url" : "owl.li\/XgPf301DcLP"
    } ]
  },
  "geo" : { },
  "id_str" : "803756197723705344",
  "text" : "RT @FaithfulThinker: #BookReview: Programming of Life by Donald Johnson #science #biochemistry #information https:\/\/t.co\/zyrvvyWCOp https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FaithfulThinker\/status\/803750729013809152\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/migoq9OQUm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cyd_Bw2VEAAd4qC.jpg",
        "id_str" : "803750726778294272",
        "id" : 803750726778294272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cyd_Bw2VEAAd4qC.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/migoq9OQUm"
      } ],
      "hashtags" : [ {
        "text" : "BookReview",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "science",
        "indices" : [ 51, 59 ]
      }, {
        "text" : "biochemistry",
        "indices" : [ 60, 73 ]
      }, {
        "text" : "information",
        "indices" : [ 74, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/zyrvvyWCOp",
        "expanded_url" : "http:\/\/owl.li\/XgPf301DcLP",
        "display_url" : "owl.li\/XgPf301DcLP"
      } ]
    },
    "geo" : { },
    "id_str" : "803750729013809152",
    "text" : "#BookReview: Programming of Life by Donald Johnson #science #biochemistry #information https:\/\/t.co\/zyrvvyWCOp https:\/\/t.co\/migoq9OQUm",
    "id" : 803750729013809152,
    "created_at" : "2016-11-30 00:01:21 +0000",
    "user" : {
      "name" : "Faithful Thinkers",
      "screen_name" : "FaithfulThinker",
      "protected" : false,
      "id_str" : "181962146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1109164267\/Faithful_Thinkers_Logo-_Small_Icon_normal.jpg",
      "id" : 181962146,
      "verified" : false
    }
  },
  "id" : 803756197723705344,
  "created_at" : "2016-11-30 00:23:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803754319199825920",
  "text" : "Wanna hear me cuss in Britain this is probably the last version of Windows until you can call it what every you like.",
  "id" : 803754319199825920,
  "created_at" : "2016-11-30 00:15:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBTimes UK",
      "screen_name" : "IBTimesUK",
      "indices" : [ 100, 110 ],
      "id_str" : "47916714",
      "id" : 47916714
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/zjMYTBDoQx",
      "expanded_url" : "http:\/\/ibt.uk\/A6ffK?utm_source=social&utm_medium=twitter&utm_campaign=\/microsoft-details-unified-update-platform-windows-10-creators-update-1590134",
      "display_url" : "ibt.uk\/A6ffK?utm_sour\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803753919402872832",
  "text" : "Microsoft details Unified Update Platform in Windows 10 Creators Update https:\/\/t.co\/zjMYTBDoQx via @IBTimesUK",
  "id" : 803753919402872832,
  "created_at" : "2016-11-30 00:14:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/2yM7UMvogX",
      "expanded_url" : "http:\/\/www.microsoft.com\/windowsembedded\/en-us\/windows-embedded-automotive-7.aspx",
      "display_url" : "microsoft.com\/windowsembedde\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803753096140689410",
  "text" : "https:\/\/t.co\/2yM7UMvogX Windows Embedded Automotive. Was Ford Sync.",
  "id" : 803753096140689410,
  "created_at" : "2016-11-30 00:10:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803751621205389312",
  "text" : "late dinner for me.",
  "id" : 803751621205389312,
  "created_at" : "2016-11-30 00:04:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803751293340688384",
  "text" : "That is Microsoft isn't it? You will like that car won't you?",
  "id" : 803751293340688384,
  "created_at" : "2016-11-30 00:03:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803750250670342144",
  "text" : "No plagiarism all of the copyright are in place.I just haven't coded in about 8 months I want to learn my patterns that UVa didn't teach me.",
  "id" : 803750250670342144,
  "created_at" : "2016-11-29 23:59:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803747433952018432",
  "text" : "Every universe being parallel or not has a Higgs field. And I am really done female that justs want to live forever.",
  "id" : 803747433952018432,
  "created_at" : "2016-11-29 23:48:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803746553533960192",
  "text" : "\"Stabilizing the Higgs potential with a Z'\" Thank You Bill Gates I emailed you this.",
  "id" : 803746553533960192,
  "created_at" : "2016-11-29 23:44:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803745632594915328",
  "text" : "Does EVERYONE wanna play the fucking immortality games still If had it.",
  "id" : 803745632594915328,
  "created_at" : "2016-11-29 23:41:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/X5auhJjn2L",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/SPIM",
      "display_url" : "en.wikipedia.org\/wiki\/SPIM"
    } ]
  },
  "geo" : { },
  "id_str" : "803744563898613760",
  "text" : "https:\/\/t.co\/X5auhJjn2L Hi James.",
  "id" : 803744563898613760,
  "created_at" : "2016-11-29 23:36:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stanford University",
      "screen_name" : "Stanford",
      "indices" : [ 3, 12 ],
      "id_str" : "18036441",
      "id" : 18036441
    }, {
      "name" : "Stanford Medicine",
      "screen_name" : "StanfordMed",
      "indices" : [ 15, 27 ],
      "id_str" : "56879674",
      "id" : 56879674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803743489380990976",
  "text" : "RT @Stanford: .@StanfordMed researchers have created a new cell surface receptor that inhibits cancer growth in mice. https:\/\/t.co\/xwAT9272\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stanford Medicine",
        "screen_name" : "StanfordMed",
        "indices" : [ 1, 13 ],
        "id_str" : "56879674",
        "id" : 56879674
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/xwAT9272x8",
        "expanded_url" : "http:\/\/stanford.io\/2g2rkua",
        "display_url" : "stanford.io\/2g2rkua"
      } ]
    },
    "geo" : { },
    "id_str" : "803742908365111296",
    "text" : ".@StanfordMed researchers have created a new cell surface receptor that inhibits cancer growth in mice. https:\/\/t.co\/xwAT9272x8",
    "id" : 803742908365111296,
    "created_at" : "2016-11-29 23:30:16 +0000",
    "user" : {
      "name" : "Stanford University",
      "screen_name" : "Stanford",
      "protected" : false,
      "id_str" : "18036441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520246535632592896\/N2cIW5h2_normal.png",
      "id" : 18036441,
      "verified" : true
    }
  },
  "id" : 803743489380990976,
  "created_at" : "2016-11-29 23:32:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/AlsUA21zqr",
      "expanded_url" : "https:\/\/www.encodeproject.org\/software\/star\/",
      "display_url" : "encodeproject.org\/software\/star\/"
    } ]
  },
  "geo" : { },
  "id_str" : "803743433898729472",
  "text" : "https:\/\/t.co\/AlsUA21zqr STAR",
  "id" : 803743433898729472,
  "created_at" : "2016-11-29 23:32:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803741764305752070",
  "text" : "I would pay if I didn't have to worry about treasury bills. Or at least numbers in my bank account.",
  "id" : 803741764305752070,
  "created_at" : "2016-11-29 23:25:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/5h5EHF9bX5",
      "expanded_url" : "https:\/\/vspartner.com\/",
      "display_url" : "vspartner.com"
    } ]
  },
  "geo" : { },
  "id_str" : "803741022169825281",
  "text" : "https:\/\/t.co\/5h5EHF9bX5 Free Level and Paid level. I may release the song \" Can I do it too?\" Tri-Cities.",
  "id" : 803741022169825281,
  "created_at" : "2016-11-29 23:22:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803739414199435264",
  "text" : "building clang 3.6 or 9 I just don't like the \"kill to doctor\" Tool.",
  "id" : 803739414199435264,
  "created_at" : "2016-11-29 23:16:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803738385458335745",
  "text" : "I AM WORKING IN C, C++, C# and F# in research and I do have more to push to my github and go through my files.",
  "id" : 803738385458335745,
  "created_at" : "2016-11-29 23:12:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Computerworld",
      "screen_name" : "Computerworld",
      "indices" : [ 87, 101 ],
      "id_str" : "14539324",
      "id" : 14539324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/FWyUkDhfV3",
      "expanded_url" : "http:\/\/www.computerworld.com\/article\/2528330\/app-development\/nanotech-could-make-humans-immortal-by-2040--futurist-says.html",
      "display_url" : "computerworld.com\/article\/252833\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803737860692148224",
  "text" : "Nanotech could make humans immortal by 2040, futurist says https:\/\/t.co\/FWyUkDhfV3 via @computerworld",
  "id" : 803737860692148224,
  "created_at" : "2016-11-29 23:10:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803737181479194625",
  "text" : "Ladies you may be able to replace the Windows theme again we hope.",
  "id" : 803737181479194625,
  "created_at" : "2016-11-29 23:07:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/o5fXyRURCl",
      "expanded_url" : "https:\/\/linustechtips.com\/main\/topic\/323265-why-isnt-it-possible-to-bios-hack-a-cpu\/",
      "display_url" : "linustechtips.com\/main\/topic\/323\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803734062661849090",
  "text" : "https:\/\/t.co\/o5fXyRURCl All I know it That I got a POST 3 and 4.",
  "id" : 803734062661849090,
  "created_at" : "2016-11-29 22:55:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803733156243402752",
  "text" : "I have never attacked by computer I don't hack. I do just talk on social media.",
  "id" : 803733156243402752,
  "created_at" : "2016-11-29 22:51:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803732217939841024",
  "text" : "There is only one person on my Linked in that talks to me and that is the person who built the Windows kernel for15 years.And Mensa.",
  "id" : 803732217939841024,
  "created_at" : "2016-11-29 22:47:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803730737446973445",
  "text" : "Hi Lieutenant Snodgrass where is the magistrate office over my Dell I really don't use instant checkmate but you can.",
  "id" : 803730737446973445,
  "created_at" : "2016-11-29 22:41:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803728404113670146",
  "text" : "It is my heart and CPU they attacked of the Dell and I've had it. Over one hot women.",
  "id" : 803728404113670146,
  "created_at" : "2016-11-29 22:32:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803727612174594048",
  "text" : "I forgot to reset the router. No attack this time it was just a power outage. For 10 min. In the area.",
  "id" : 803727612174594048,
  "created_at" : "2016-11-29 22:29:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803716029096595456",
  "text" : "I was getting ready to download visual stupid 2017 rc too.",
  "id" : 803716029096595456,
  "created_at" : "2016-11-29 21:43:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803712571752599552",
  "text" : "The internet is still down work bitch.",
  "id" : 803712571752599552,
  "created_at" : "2016-11-29 21:29:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803711697815044096",
  "text" : "If I could take a daily backup off just my updated files that would be better.",
  "id" : 803711697815044096,
  "created_at" : "2016-11-29 21:26:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803710624605814785",
  "text" : "The power was off for about 5 minutes. Johnson the web app was just a bad idea.",
  "id" : 803710624605814785,
  "created_at" : "2016-11-29 21:21:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803707677780086788",
  "text" : "I just don't like everything running in a browser.",
  "id" : 803707677780086788,
  "created_at" : "2016-11-29 21:10:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/q9XQidoT8C",
      "expanded_url" : "https:\/\/www.visualstudio.com\/team-services\/",
      "display_url" : "visualstudio.com\/team-services\/"
    } ]
  },
  "geo" : { },
  "id_str" : "803704558463631360",
  "text" : "https:\/\/t.co\/q9XQidoT8C You can, I'm going back to Beta Archive. And trying to find the feature build labs.",
  "id" : 803704558463631360,
  "created_at" : "2016-11-29 20:57:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803703160774819840",
  "text" : "I do have IronScheme and just don't really know if it is any good.",
  "id" : 803703160774819840,
  "created_at" : "2016-11-29 20:52:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803702594178863108",
  "text" : "I'll try a sell something I really don't want too. But I'll try.",
  "id" : 803702594178863108,
  "created_at" : "2016-11-29 20:50:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/UvjKyjcwvg",
      "expanded_url" : "https:\/\/twitter.com\/TheEconomist\/status\/803700077021818880",
      "display_url" : "twitter.com\/TheEconomist\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803701871277850624",
  "text" : "I know \"know better\" https:\/\/t.co\/UvjKyjcwvg",
  "id" : 803701871277850624,
  "created_at" : "2016-11-29 20:47:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803700986648948740",
  "text" : "You can search the LOC and the British Library with Citavi",
  "id" : 803700986648948740,
  "created_at" : "2016-11-29 20:43:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/QjCZMgOtwv",
      "expanded_url" : "https:\/\/www.citavi.com\/",
      "display_url" : "citavi.com"
    } ]
  },
  "geo" : { },
  "id_str" : "803700440617521152",
  "text" : "https:\/\/t.co\/QjCZMgOtwv a Reference manager but keep your eye on Wikipedia..",
  "id" : 803700440617521152,
  "created_at" : "2016-11-29 20:41:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803698658008891392",
  "text" : "IEEE when you get your email to forward I'll use it more.",
  "id" : 803698658008891392,
  "created_at" : "2016-11-29 20:34:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/D83zRLseZY",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Corpus_manager",
      "display_url" : "en.wikipedia.org\/wiki\/Corpus_ma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803698194429464576",
  "text" : "https:\/\/t.co\/D83zRLseZY They are Corpus Managers Microsoft. Wordsmith is one of the oldest.",
  "id" : 803698194429464576,
  "created_at" : "2016-11-29 20:32:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803697479543730176",
  "text" : "Google I am on your damn filtered search results.",
  "id" : 803697479543730176,
  "created_at" : "2016-11-29 20:29:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/dj75QpbykW",
      "expanded_url" : "http:\/\/starrobotics.tk\/software\/robot-application-software\/",
      "display_url" : "starrobotics.tk\/software\/robot\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803696968660844544",
  "text" : "Robot application software https:\/\/t.co\/dj75QpbykW Not sure this is it.",
  "id" : 803696968660844544,
  "created_at" : "2016-11-29 20:27:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Verge",
      "screen_name" : "verge",
      "indices" : [ 94, 100 ],
      "id_str" : "275686563",
      "id" : 275686563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/l87DLx1DWS",
      "expanded_url" : "http:\/\/www.theverge.com\/2016\/5\/4\/11591024\/robot-surgery-autonomous-smart-tissue-star-system?utm_campaign=theverge&utm_content=entry&utm_medium=social&utm_source=twitter",
      "display_url" : "theverge.com\/2016\/5\/4\/11591\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803696127908397056",
  "text" : "A robot surgeon has passed a major milestone \u2014 sewing up pig guts https:\/\/t.co\/l87DLx1DWS via @Verge",
  "id" : 803696127908397056,
  "created_at" : "2016-11-29 20:24:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/rp2VX7CwWk",
      "expanded_url" : "http:\/\/spectrum.ieee.org\/the-human-os\/robotics\/medical-robots\/autonomous-robot-surgeon-bests-human-surgeons-in-world-first",
      "display_url" : "spectrum.ieee.org\/the-human-os\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803695307905265664",
  "text" : "https:\/\/t.co\/rp2VX7CwWk Autonomous Robot Surgeon Bests Humans in World First.",
  "id" : 803695307905265664,
  "created_at" : "2016-11-29 20:21:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803694475818258433",
  "text" : "I like AlphaGo but it's Python if we could make I would really want to use cTakes and AI in surgery.And get it perfect Microsoft.",
  "id" : 803694475818258433,
  "created_at" : "2016-11-29 20:17:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 86, 94 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/kHbwavagx6",
      "expanded_url" : "https:\/\/youtu.be\/B9i9SKgWWGY",
      "display_url" : "youtu.be\/B9i9SKgWWGY"
    } ]
  },
  "geo" : { },
  "id_str" : "803692835228831744",
  "text" : "ASUS ROG G752 Gaming Laptop - World Domination.  Evolved. https:\/\/t.co\/kHbwavagx6 via @YouTube",
  "id" : 803692835228831744,
  "created_at" : "2016-11-29 20:11:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803690339458420736",
  "text" : "I'm having some marshmallow coco and taking a break.",
  "id" : 803690339458420736,
  "created_at" : "2016-11-29 20:01:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/lklVmumFYY",
      "expanded_url" : "https:\/\/developer.nvidia.com\/deep-learning-frameworks",
      "display_url" : "developer.nvidia.com\/deep-learning-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803689548345655296",
  "text" : "https:\/\/t.co\/lklVmumFYY deep leaning frameworks.",
  "id" : 803689548345655296,
  "created_at" : "2016-11-29 19:58:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803688186107101184",
  "text" : "Never call me Digital Research again Abingdon and shrink I did just link my Github to Microsoft Research.",
  "id" : 803688186107101184,
  "created_at" : "2016-11-29 19:52:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/gAjQfokzl6",
      "expanded_url" : "http:\/\/www.innovativeretailtechnologies.com\/doc\/zara-adding-ipads-to-dressing-rooms-as-fashion-meets-technology-0001",
      "display_url" : "innovativeretailtechnologies.com\/doc\/zara-addin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803685979194167296",
  "text" : "https:\/\/t.co\/gAjQfokzl6 the iPad is dead.",
  "id" : 803685979194167296,
  "created_at" : "2016-11-29 19:44:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/EcdMoiXmca",
      "expanded_url" : "https:\/\/hbr.org\/2015\/10\/technology-is-not-threatening-our-humanity-we-are#",
      "display_url" : "hbr.org\/2015\/10\/techno\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803684997290926081",
  "text" : "https:\/\/t.co\/EcdMoiXmca \nTechnology Is Not Threatening Our Humanity \u2014 We Are",
  "id" : 803684997290926081,
  "created_at" : "2016-11-29 19:40:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "indices" : [ 78, 86 ],
      "id_str" : "1652541",
      "id" : 1652541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/EQOUbr72ND",
      "expanded_url" : "http:\/\/www.reuters.com\/article\/us-inditex-shares-idUSL1366183920071213",
      "display_url" : "reuters.com\/article\/us-ind\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803683824626438145",
  "text" : "Inditex falls again on sales, JP Morgan downgrade https:\/\/t.co\/EQOUbr72ND via @Reuters",
  "id" : 803683824626438145,
  "created_at" : "2016-11-29 19:35:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "indices" : [ 71, 79 ],
      "id_str" : "1652541",
      "id" : 1652541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/SBInfMqpee",
      "expanded_url" : "http:\/\/reut.rs\/1jB8FBC",
      "display_url" : "reut.rs\/1jB8FBC"
    } ]
  },
  "geo" : { },
  "id_str" : "803683674759827456",
  "text" : "Spain's Inditex falls on currency concerns https:\/\/t.co\/SBInfMqpee via @Reuters",
  "id" : 803683674759827456,
  "created_at" : "2016-11-29 19:34:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/PS5RJReZ7l",
      "expanded_url" : "https:\/\/www.the-pool.com\/archive\/news-views\/fashion-news\/2015\/19\/zara-accused-of-failing-to-tackle-poor-working-standards-in-brazil",
      "display_url" : "the-pool.com\/archive\/news-v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803683135871283200",
  "text" : "https:\/\/t.co\/PS5RJReZ7l Zara Failing.",
  "id" : 803683135871283200,
  "created_at" : "2016-11-29 19:32:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/J7c1qeE4sk",
      "expanded_url" : "http:\/\/searchsdn.techtarget.com\/news\/4500272539\/Microsoft-SDN-stack-to-challenge-Cisco-VMware",
      "display_url" : "searchsdn.techtarget.com\/news\/450027253\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803681287655538688",
  "text" : "https:\/\/t.co\/J7c1qeE4sk Microsoft SDN.",
  "id" : 803681287655538688,
  "created_at" : "2016-11-29 19:25:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/veDE0nuKKE",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/OpenFlow",
      "display_url" : "en.wikipedia.org\/wiki\/OpenFlow"
    } ]
  },
  "geo" : { },
  "id_str" : "803680220305903617",
  "text" : "https:\/\/t.co\/veDE0nuKKE Open Flow.",
  "id" : 803680220305903617,
  "created_at" : "2016-11-29 19:21:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/eANWYtd4ec",
      "expanded_url" : "https:\/\/github.com\/OpenNetworkingFoundation",
      "display_url" : "github.com\/OpenNetworking\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803679193141772288",
  "text" : "https:\/\/t.co\/eANWYtd4ec I found it Lauren",
  "id" : 803679193141772288,
  "created_at" : "2016-11-29 19:17:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/1TJ1sdbRtl",
      "expanded_url" : "https:\/\/www.opennetworking.org\/",
      "display_url" : "opennetworking.org"
    } ]
  },
  "geo" : { },
  "id_str" : "803678635337142272",
  "text" : "https:\/\/t.co\/1TJ1sdbRtl",
  "id" : 803678635337142272,
  "created_at" : "2016-11-29 19:14:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/1vUXDaDEkp",
      "expanded_url" : "http:\/\/www.thenetworkencyclopedia.com\/entry\/open-network-environment\/",
      "display_url" : "thenetworkencyclopedia.com\/entry\/open-net\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803678018015088640",
  "text" : "https:\/\/t.co\/1vUXDaDEkp Open Network Environment.",
  "id" : 803678018015088640,
  "created_at" : "2016-11-29 19:12:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Register",
      "screen_name" : "TheRegister",
      "indices" : [ 88, 100 ],
      "id_str" : "78012548",
      "id" : 78012548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/d5jHqs7Nlz",
      "expanded_url" : "http:\/\/www.theregister.co.uk\/2012\/06\/14\/cisco_one_sdn_openflow_openstack\/",
      "display_url" : "theregister.co.uk\/2012\/06\/14\/cis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803677305725976577",
  "text" : "Cisco + OpenFlow + OpenStack = ONE software-defined network https:\/\/t.co\/d5jHqs7Nlz via @theregister",
  "id" : 803677305725976577,
  "created_at" : "2016-11-29 19:09:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 90, 98 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/xzfPN7V8DM",
      "expanded_url" : "https:\/\/youtu.be\/McpaUKEKhXk",
      "display_url" : "youtu.be\/McpaUKEKhXk"
    } ]
  },
  "geo" : { },
  "id_str" : "803676805400002561",
  "text" : "Deploying OpenStack with Cisco Networking Compute and Storage https:\/\/t.co\/xzfPN7V8DM via @YouTube",
  "id" : 803676805400002561,
  "created_at" : "2016-11-29 19:07:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/p1UejD71z8",
      "expanded_url" : "https:\/\/mip.codeplex.com\/",
      "display_url" : "mip.codeplex.com"
    } ]
  },
  "geo" : { },
  "id_str" : "803675392146112512",
  "text" : "https:\/\/t.co\/p1UejD71z8 Micro framework",
  "id" : 803675392146112512,
  "created_at" : "2016-11-29 19:01:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803675022338314240",
  "text" : "Just download the nuget package you can extract the source if you want I may want to make a nuget package.",
  "id" : 803675022338314240,
  "created_at" : "2016-11-29 19:00:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/P2MwCrsJlf",
      "expanded_url" : "https:\/\/code.google.com\/archive\/p\/lidgren-network-gen3\/",
      "display_url" : "code.google.com\/archive\/p\/lidg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803673663539179520",
  "text" : "https:\/\/t.co\/P2MwCrsJlf C# bigger network stack.",
  "id" : 803673663539179520,
  "created_at" : "2016-11-29 18:55:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/hcUe7RwD4E",
      "expanded_url" : "http:\/\/www.mentalis.org\/soft\/class.qpx?id=9",
      "display_url" : "mentalis.org\/soft\/class.qpx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803672840587264001",
  "text" : "https:\/\/t.co\/hcUe7RwD4E Proxy Socket in C# a dependency",
  "id" : 803672840587264001,
  "created_at" : "2016-11-29 18:51:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803671436980264960",
  "text" : "If I see some education and compatibility. I'll talk more.",
  "id" : 803671436980264960,
  "created_at" : "2016-11-29 18:46:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/XdsnCOahi5",
      "expanded_url" : "https:\/\/hardforum.com\/threads\/how-much-500watts-power-supply-cost-you-monthly-in-electric-bill.1013384\/",
      "display_url" : "hardforum.com\/threads\/how-mu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803669153383120896",
  "text" : "https:\/\/t.co\/XdsnCOahi5 550 wats that might be an extra $50 a month.If I use Active Directory.",
  "id" : 803669153383120896,
  "created_at" : "2016-11-29 18:37:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803667270685851648",
  "text" : "I'm just not sure about my home server's uptime and the power bill Azure.",
  "id" : 803667270685851648,
  "created_at" : "2016-11-29 18:29:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803666677485355008",
  "text" : "When I get all of my feeds I will just say do I need to request for you to talk.",
  "id" : 803666677485355008,
  "created_at" : "2016-11-29 18:27:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803665459610550273",
  "text" : "It is just active directory and IIS or Apache too.",
  "id" : 803665459610550273,
  "created_at" : "2016-11-29 18:22:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yogi Products",
      "screen_name" : "YogiProducts",
      "indices" : [ 3, 16 ],
      "id_str" : "1909489135",
      "id" : 1909489135
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/YogiProducts\/status\/803664489765883905\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/lYysAkPDAq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cycwl7SXgAAFERW.jpg",
      "id_str" : "803664486636945408",
      "id" : 803664486636945408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cycwl7SXgAAFERW.jpg",
      "sizes" : [ {
        "h" : 1420,
        "resize" : "fit",
        "w" : 1420
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1420,
        "resize" : "fit",
        "w" : 1420
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/lYysAkPDAq"
    } ],
    "hashtags" : [ {
      "text" : "yogitea",
      "indices" : [ 66, 74 ]
    }, {
      "text" : "teatagtuesday",
      "indices" : [ 75, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803664877172703232",
  "text" : "RT @YogiProducts: \"The purpose of life is to enjoy every moment.\" #yogitea #teatagtuesday https:\/\/t.co\/lYysAkPDAq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.falcon.io\" rel=\"nofollow\"\u003EFalcon Social Media Management \u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/YogiProducts\/status\/803664489765883905\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/lYysAkPDAq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cycwl7SXgAAFERW.jpg",
        "id_str" : "803664486636945408",
        "id" : 803664486636945408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cycwl7SXgAAFERW.jpg",
        "sizes" : [ {
          "h" : 1420,
          "resize" : "fit",
          "w" : 1420
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1420,
          "resize" : "fit",
          "w" : 1420
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/lYysAkPDAq"
      } ],
      "hashtags" : [ {
        "text" : "yogitea",
        "indices" : [ 48, 56 ]
      }, {
        "text" : "teatagtuesday",
        "indices" : [ 57, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "803664489765883905",
    "text" : "\"The purpose of life is to enjoy every moment.\" #yogitea #teatagtuesday https:\/\/t.co\/lYysAkPDAq",
    "id" : 803664489765883905,
    "created_at" : "2016-11-29 18:18:40 +0000",
    "user" : {
      "name" : "Yogi Products",
      "screen_name" : "YogiProducts",
      "protected" : false,
      "id_str" : "1909489135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/492021771709591552\/SgXf4y5k_normal.jpeg",
      "id" : 1909489135,
      "verified" : false
    }
  },
  "id" : 803664877172703232,
  "created_at" : "2016-11-29 18:20:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/EIMIoU1Duz",
      "expanded_url" : "https:\/\/github.com\/Microsoft\/nodejstools\/wiki\/Publish-to-Azure-Website-using-Git",
      "display_url" : "github.com\/Microsoft\/node\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803664844326981632",
  "text" : "https:\/\/t.co\/EIMIoU1Duz Publish to Microsoft Azure Website using Git. If hosting the domain costs I'll do that sometime.",
  "id" : 803664844326981632,
  "created_at" : "2016-11-29 18:20:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBM Research",
      "screen_name" : "IBMResearch",
      "indices" : [ 3, 15 ],
      "id_str" : "16319797",
      "id" : 16319797
    }, {
      "name" : "Guruduth Banavar",
      "screen_name" : "banavar",
      "indices" : [ 23, 31 ],
      "id_str" : "151303711",
      "id" : 151303711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803663727090245632",
  "text" : "RT @IBMResearch: IBM's @banavar: \"AI systems must be built from the get-go to operate in trust-based partnerships with people.\" #IBMResearc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Guruduth Banavar",
        "screen_name" : "banavar",
        "indices" : [ 6, 14 ],
        "id_str" : "151303711",
        "id" : 151303711
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IBMResearch",
        "indices" : [ 111, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/1DnaWCRxaX",
        "expanded_url" : "https:\/\/twitter.com\/HarvardBiz\/status\/803631580916883456",
        "display_url" : "twitter.com\/HarvardBiz\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "803663282502504448",
    "text" : "IBM's @banavar: \"AI systems must be built from the get-go to operate in trust-based partnerships with people.\" #IBMResearch https:\/\/t.co\/1DnaWCRxaX",
    "id" : 803663282502504448,
    "created_at" : "2016-11-29 18:13:52 +0000",
    "user" : {
      "name" : "IBM Research",
      "screen_name" : "IBMResearch",
      "protected" : false,
      "id_str" : "16319797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2453018418\/fn1i02hac59i02ccd9c1_normal.jpeg",
      "id" : 16319797,
      "verified" : true
    }
  },
  "id" : 803663727090245632,
  "created_at" : "2016-11-29 18:15:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803663539068108801",
  "text" : "I also talked to my cognitive therapist about how old old men use the middle aged to teach the kids then use the information to get laid.",
  "id" : 803663539068108801,
  "created_at" : "2016-11-29 18:14:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803661406658854913",
  "text" : "Abingdon try to carry some non carcinogenic soap and shampoo in your stores.",
  "id" : 803661406658854913,
  "created_at" : "2016-11-29 18:06:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803660439024332800",
  "text" : "I just may not get along with the web app teams that might be it.",
  "id" : 803660439024332800,
  "created_at" : "2016-11-29 18:02:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/fU8N5zILyW",
      "expanded_url" : "https:\/\/twitter.com\/FT\/status\/803524114380189696",
      "display_url" : "twitter.com\/FT\/status\/8035\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803659826261803010",
  "text" : "OpenCyc https:\/\/t.co\/fU8N5zILyW",
  "id" : 803659826261803010,
  "created_at" : "2016-11-29 18:00:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 3, 16 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AndAScientist",
      "indices" : [ 85, 99 ]
    }, {
      "text" : "womeninSTEM",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/0g9sitNTlQ",
      "expanded_url" : "http:\/\/ow.ly\/B6Cj303Yo1Y",
      "display_url" : "ow.ly\/B6Cj303Yo1Y"
    } ]
  },
  "geo" : { },
  "id_str" : "803659734817513472",
  "text" : "RT @royalsociety: Dr Fiona Polack on career luck, rowing, &amp; software engineering #AndAScientist #womeninSTEM https:\/\/t.co\/0g9sitNTlQ https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/royalsociety\/status\/803646769003278336\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/5rUJPg4HIX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CycddodXcAAbjZX.jpg",
        "id_str" : "803643453422923776",
        "id" : 803643453422923776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CycddodXcAAbjZX.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 2133
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/5rUJPg4HIX"
      } ],
      "hashtags" : [ {
        "text" : "AndAScientist",
        "indices" : [ 67, 81 ]
      }, {
        "text" : "womeninSTEM",
        "indices" : [ 82, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/0g9sitNTlQ",
        "expanded_url" : "http:\/\/ow.ly\/B6Cj303Yo1Y",
        "display_url" : "ow.ly\/B6Cj303Yo1Y"
      } ]
    },
    "geo" : { },
    "id_str" : "803646769003278336",
    "text" : "Dr Fiona Polack on career luck, rowing, &amp; software engineering #AndAScientist #womeninSTEM https:\/\/t.co\/0g9sitNTlQ https:\/\/t.co\/5rUJPg4HIX",
    "id" : 803646769003278336,
    "created_at" : "2016-11-29 17:08:15 +0000",
    "user" : {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "protected" : false,
      "id_str" : "28567809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672098584372846592\/wxJ8nlnH_normal.jpg",
      "id" : 28567809,
      "verified" : true
    }
  },
  "id" : 803659734817513472,
  "created_at" : "2016-11-29 17:59:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open at Microsoft",
      "screen_name" : "OpenAtMicrosoft",
      "indices" : [ 3, 19 ],
      "id_str" : "45036289",
      "id" : 45036289
    }, {
      "name" : "Sara Itani",
      "screen_name" : "mousetraps",
      "indices" : [ 43, 54 ],
      "id_str" : "12483622",
      "id" : 12483622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/BLESoQ5Oh7",
      "expanded_url" : "http:\/\/sched.co\/8xb4",
      "display_url" : "sched.co\/8xb4"
    } ]
  },
  "geo" : { },
  "id_str" : "803659525303582720",
  "text" : "RT @OpenAtMicrosoft: Ready to launch? Join @mousetraps for The Diversity Experiment v0.0.1, TODAY Salon 1 5:30 PM https:\/\/t.co\/BLESoQ5Oh7 #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sara Itani",
        "screen_name" : "mousetraps",
        "indices" : [ 22, 33 ],
        "id_str" : "12483622",
        "id" : 12483622
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NodeInteractive",
        "indices" : [ 117, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/BLESoQ5Oh7",
        "expanded_url" : "http:\/\/sched.co\/8xb4",
        "display_url" : "sched.co\/8xb4"
      } ]
    },
    "geo" : { },
    "id_str" : "803648519630262274",
    "text" : "Ready to launch? Join @mousetraps for The Diversity Experiment v0.0.1, TODAY Salon 1 5:30 PM https:\/\/t.co\/BLESoQ5Oh7 #NodeInteractive",
    "id" : 803648519630262274,
    "created_at" : "2016-11-29 17:15:12 +0000",
    "user" : {
      "name" : "Open at Microsoft",
      "screen_name" : "OpenAtMicrosoft",
      "protected" : false,
      "id_str" : "45036289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623264825465040896\/aUzLHrCL_normal.png",
      "id" : 45036289,
      "verified" : true
    }
  },
  "id" : 803659525303582720,
  "created_at" : "2016-11-29 17:58:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chapel Language",
      "screen_name" : "ChapelLanguage",
      "indices" : [ 3, 18 ],
      "id_str" : "704474630116012032",
      "id" : 704474630116012032
    }, {
      "name" : "ACCU Conference",
      "screen_name" : "ACCUConf",
      "indices" : [ 54, 63 ],
      "id_str" : "3226443425",
      "id" : 3226443425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/Ip7XkcJm3T",
      "expanded_url" : "https:\/\/conference.accu.org\/site\/index.html",
      "display_url" : "conference.accu.org\/site\/index.html"
    } ]
  },
  "geo" : { },
  "id_str" : "803659403815776256",
  "text" : "RT @ChapelLanguage: Interested in attending ACCU2017 (@ACCUConf) to hear about Chapel or otherwise? See: https:\/\/t.co\/Ip7XkcJm3T https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ACCU Conference",
        "screen_name" : "ACCUConf",
        "indices" : [ 34, 43 ],
        "id_str" : "3226443425",
        "id" : 3226443425
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/Ip7XkcJm3T",
        "expanded_url" : "https:\/\/conference.accu.org\/site\/index.html",
        "display_url" : "conference.accu.org\/site\/index.html"
      }, {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/SKgCEl0sO0",
        "expanded_url" : "https:\/\/twitter.com\/ACCUConf\/status\/803620032106217472",
        "display_url" : "twitter.com\/ACCUConf\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "803650277525962752",
    "text" : "Interested in attending ACCU2017 (@ACCUConf) to hear about Chapel or otherwise? See: https:\/\/t.co\/Ip7XkcJm3T https:\/\/t.co\/SKgCEl0sO0",
    "id" : 803650277525962752,
    "created_at" : "2016-11-29 17:22:11 +0000",
    "user" : {
      "name" : "Chapel Language",
      "screen_name" : "ChapelLanguage",
      "protected" : false,
      "id_str" : "704474630116012032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704475691383857153\/jC_wkEkv_normal.jpg",
      "id" : 704474630116012032,
      "verified" : false
    }
  },
  "id" : 803659403815776256,
  "created_at" : "2016-11-29 17:58:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803658943478333444",
  "text" : "I'm not forcing anything either it is just a computer command. I really don't have to.",
  "id" : 803658943478333444,
  "created_at" : "2016-11-29 17:56:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803658620244291584",
  "text" : "git reset origin\/master",
  "id" : 803658620244291584,
  "created_at" : "2016-11-29 17:55:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803658349548081152",
  "text" : "I might put some real estate into someone soon. And I'm really not in a hurry.",
  "id" : 803658349548081152,
  "created_at" : "2016-11-29 17:54:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803657029407494144",
  "text" : "I did mention to my cognitive therapist that women use double standards they like the ego but then they want sensitivity too.",
  "id" : 803657029407494144,
  "created_at" : "2016-11-29 17:49:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803655536843423744",
  "text" : "git reset.",
  "id" : 803655536843423744,
  "created_at" : "2016-11-29 17:43:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803652509969416193",
  "text" : "git clean -f",
  "id" : 803652509969416193,
  "created_at" : "2016-11-29 17:31:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/CVl92u5Q50",
      "expanded_url" : "https:\/\/twitter.com\/Davos\/status\/803648604787318786",
      "display_url" : "twitter.com\/Davos\/status\/8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803649893457743872",
  "text" : "Sexual Harassment money and the game. https:\/\/t.co\/CVl92u5Q50",
  "id" : 803649893457743872,
  "created_at" : "2016-11-29 17:20:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803648792557826048",
  "text" : "trying to push opencyc Microsoft it is to large for github.",
  "id" : 803648792557826048,
  "created_at" : "2016-11-29 17:16:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803643455444369408",
  "text" : "I'll talk to Amy in January Microsoft is anyone on payroll?",
  "id" : 803643455444369408,
  "created_at" : "2016-11-29 16:55:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803641535229136897",
  "text" : "She's pretty she got the job. Good day everyone.",
  "id" : 803641535229136897,
  "created_at" : "2016-11-29 16:47:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/nbHt6BpCg4",
      "expanded_url" : "http:\/\/www.wbir.com\/news\/local\/how-to-help-gatlinburg-pigeon-forge-fire-evacuees\/357810685",
      "display_url" : "wbir.com\/news\/local\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803641275559723008",
  "text" : "How to help Gatlinburg, Pigeon Forge fire evacuees https:\/\/t.co\/nbHt6BpCg4 via @@WBIRNews",
  "id" : 803641275559723008,
  "created_at" : "2016-11-29 16:46:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803640187502792705",
  "text" : "There is an re implementation of uxtheme in wine.",
  "id" : 803640187502792705,
  "created_at" : "2016-11-29 16:42:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803636057728126978",
  "text" : "household chores",
  "id" : 803636057728126978,
  "created_at" : "2016-11-29 16:25:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803630392980873216",
  "text" : "Take your trash out Tri-Cities.",
  "id" : 803630392980873216,
  "created_at" : "2016-11-29 16:03:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803629756461658112",
  "text" : "4.0GPA and help with the Higgs Boson Nobel Prize Tri-Cities Me first.",
  "id" : 803629756461658112,
  "created_at" : "2016-11-29 16:00:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803626977840115713",
  "text" : "I may remove that theme patchier too.",
  "id" : 803626977840115713,
  "created_at" : "2016-11-29 15:49:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803625730567327748",
  "text" : "Microsoft keep the utilities paid, car and equipment. I'm working.",
  "id" : 803625730567327748,
  "created_at" : "2016-11-29 15:44:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803621542705831936",
  "text" : "I pay $2000 dollars semi anully for 9GB of storage at my domain and email really not worth it I have a Google Drive and 1 GB ofspaceonAzure.",
  "id" : 803621542705831936,
  "created_at" : "2016-11-29 15:28:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803620713663868929",
  "text" : "I just can't push my books and I might I might need a small pdf search.",
  "id" : 803620713663868929,
  "created_at" : "2016-11-29 15:24:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803617151957405696",
  "text" : "Visual Studio Team Services accounts. Signing up soon.",
  "id" : 803617151957405696,
  "created_at" : "2016-11-29 15:10:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/aSkyg2Olc1",
      "expanded_url" : "https:\/\/www.codeproject.com\/kb\/ip\/tracert-ping.aspx",
      "display_url" : "codeproject.com\/kb\/ip\/tracert-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803615807506817024",
  "text" : "https:\/\/t.co\/aSkyg2Olc1 better.",
  "id" : 803615807506817024,
  "created_at" : "2016-11-29 15:05:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/AOr5Q5nGCe",
      "expanded_url" : "http:\/\/www.fluxbytes.com\/csharp\/tracert-implementation-in-c\/",
      "display_url" : "fluxbytes.com\/csharp\/tracert\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803615561989005312",
  "text" : "https:\/\/t.co\/AOr5Q5nGCe I really don't like it.",
  "id" : 803615561989005312,
  "created_at" : "2016-11-29 15:04:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803614023044464640",
  "text" : "You can make money in academia too. Just not corporate I think or commercial.",
  "id" : 803614023044464640,
  "created_at" : "2016-11-29 14:58:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803613103355105284",
  "text" : "A dollar Edward Jones is simple a \"note\" by definition. And the dictionary doesn't say anything about a promissory one either.",
  "id" : 803613103355105284,
  "created_at" : "2016-11-29 14:54:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 74, 82 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/oM4s6htl4D",
      "expanded_url" : "https:\/\/youtu.be\/tnAbKuGss4Y",
      "display_url" : "youtu.be\/tnAbKuGss4Y"
    } ]
  },
  "geo" : { },
  "id_str" : "803611484337082368",
  "text" : "Akon - I'm So Paid ft. Lil Wayne, Young Jeezy https:\/\/t.co\/oM4s6htl4D via @YouTube",
  "id" : 803611484337082368,
  "created_at" : "2016-11-29 14:48:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803610658835152896",
  "text" : "I just want some damn love too. From this fucking area before I behave.",
  "id" : 803610658835152896,
  "created_at" : "2016-11-29 14:44:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Y2YusQPgNa",
      "expanded_url" : "http:\/\/www.economist.com\/node\/11622119",
      "display_url" : "economist.com\/node\/11622119"
    } ]
  },
  "geo" : { },
  "id_str" : "803609453165760512",
  "text" : "https:\/\/t.co\/Y2YusQPgNa The meaning of Bill Gates. Bill I may just join too.",
  "id" : 803609453165760512,
  "created_at" : "2016-11-29 14:39:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803607773019832320",
  "text" : "Hi Erica Dell that wants to be a Visual Studio Industry Partner now too. And everyone at CGI.",
  "id" : 803607773019832320,
  "created_at" : "2016-11-29 14:33:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803605738618814464",
  "text" : "Downloaded all of my Visual Studio Source. CGI buy me a new car too.",
  "id" : 803605738618814464,
  "created_at" : "2016-11-29 14:25:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803600496732749824",
  "text" : "Mads are you even on the Microsoft payroll? I could say the same thing.",
  "id" : 803600496732749824,
  "created_at" : "2016-11-29 14:04:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803599606529531904",
  "text" : "I do have the Roslyn extensions too.",
  "id" : 803599606529531904,
  "created_at" : "2016-11-29 14:00:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/0eaTfFH63R",
      "expanded_url" : "https:\/\/buildazure.com\/2016\/08\/25\/free-website-hosting-in-microsoft-azure\/",
      "display_url" : "buildazure.com\/2016\/08\/25\/fre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803597917055516672",
  "text" : "https:\/\/t.co\/0eaTfFH63R I might just move to Azure too and only pay for the domains.",
  "id" : 803597917055516672,
  "created_at" : "2016-11-29 13:54:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/4sxJRNZQTX",
      "expanded_url" : "https:\/\/github.com\/madskristensen",
      "display_url" : "github.com\/madskristensen"
    } ]
  },
  "geo" : { },
  "id_str" : "803595935771226112",
  "text" : "https:\/\/t.co\/4sxJRNZQTX Hi Mads.",
  "id" : 803595935771226112,
  "created_at" : "2016-11-29 13:46:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/d0WBrmuupT",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/16587291\/extracting-nupkg-files-using-command-line",
      "display_url" : "stackoverflow.com\/questions\/1658\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803594341306535936",
  "text" : "https:\/\/t.co\/d0WBrmuupT extracting the nuget package.",
  "id" : 803594341306535936,
  "created_at" : "2016-11-29 13:39:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/n9FYUE8eD0",
      "expanded_url" : "https:\/\/talkingbollocks.net\/2016\/10\/21\/social-media-virtual-telepathy\/",
      "display_url" : "talkingbollocks.net\/2016\/10\/21\/soc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803593556267008000",
  "text" : "https:\/\/t.co\/n9FYUE8eD0 \nsocial media \u2013 virtual telepathy kinda crazy but worth a look at.",
  "id" : 803593556267008000,
  "created_at" : "2016-11-29 13:36:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Hr0j0mnrz4",
      "expanded_url" : "https:\/\/www.nuget.org\/profiles\/VisualStudioExtensibility",
      "display_url" : "nuget.org\/profiles\/Visua\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803592863657377792",
  "text" : "https:\/\/t.co\/Hr0j0mnrz4 VS Extensibility.",
  "id" : 803592863657377792,
  "created_at" : "2016-11-29 13:34:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/nIjYHdKVNl",
      "expanded_url" : "http:\/\/go.shr.lc\/2gEg5Iq",
      "display_url" : "go.shr.lc\/2gEg5Iq"
    } ]
  },
  "geo" : { },
  "id_str" : "803592166274715648",
  "text" : "What's the \"Best\" Whole-House Surge Protection? - https:\/\/t.co\/nIjYHdKVNl",
  "id" : 803592166274715648,
  "created_at" : "2016-11-29 13:31:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/fIZgEJ6BWQ",
      "expanded_url" : "https:\/\/www.nuget.org\/packages\/Microsoft.VisualStudio.Shell.14.0\/",
      "display_url" : "nuget.org\/packages\/Micro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803591107892350976",
  "text" : "https:\/\/t.co\/fIZgEJ6BWQ The Visual Studio shell is in Nuget.",
  "id" : 803591107892350976,
  "created_at" : "2016-11-29 13:27:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803590416578781185",
  "text" : "My anxiety got so bad last night I couldn't keep my dinner down. If people would stop networking around be in this damn town.And competing.",
  "id" : 803590416578781185,
  "created_at" : "2016-11-29 13:24:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 3, 12 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/D0JVsS5TRM",
      "expanded_url" : "http:\/\/trib.al\/xINlir4",
      "display_url" : "trib.al\/xINlir4"
    } ]
  },
  "geo" : { },
  "id_str" : "803589449787600896",
  "text" : "RT @guardian: The 50 best UK films of 2016: the full list https:\/\/t.co\/D0JVsS5TRM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/D0JVsS5TRM",
        "expanded_url" : "http:\/\/trib.al\/xINlir4",
        "display_url" : "trib.al\/xINlir4"
      } ]
    },
    "geo" : { },
    "id_str" : "803584806084812800",
    "text" : "The 50 best UK films of 2016: the full list https:\/\/t.co\/D0JVsS5TRM",
    "id" : 803584806084812800,
    "created_at" : "2016-11-29 13:02:02 +0000",
    "user" : {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "protected" : false,
      "id_str" : "87818409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774191274391965696\/Tulf7lwN_normal.jpg",
      "id" : 87818409,
      "verified" : true
    }
  },
  "id" : 803589449787600896,
  "created_at" : "2016-11-29 13:20:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803589051202740225",
  "text" : "The only drugs I''ve done are LSD and pot in high school and that was a 20 years ago.",
  "id" : 803589051202740225,
  "created_at" : "2016-11-29 13:18:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/QbUJqGY4lI",
      "expanded_url" : "http:\/\/www.hg.org\/xa31158",
      "display_url" : "hg.org\/xa31158"
    } ]
  },
  "geo" : { },
  "id_str" : "803587563898503168",
  "text" : "Why is Physician Assisted Suicide Illegal https:\/\/t.co\/QbUJqGY4lI",
  "id" : 803587563898503168,
  "created_at" : "2016-11-29 13:12:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cobain Case",
      "screen_name" : "cobaincase",
      "indices" : [ 3, 14 ],
      "id_str" : "298880378",
      "id" : 298880378
    }, {
      "name" : "Kurt Fraser",
      "screen_name" : "cobainevidence",
      "indices" : [ 40, 55 ],
      "id_str" : "3256070810",
      "id" : 3256070810
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KurtCobain",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/USIyTSNTJQ",
      "expanded_url" : "http:\/\/cobainevidence.com",
      "display_url" : "cobainevidence.com"
    } ]
  },
  "geo" : { },
  "id_str" : "803587096946544640",
  "text" : "RT @cobaincase: Everybody please follow @cobainevidence - He is an attorney and the author of http:\/\/t.co\/USIyTSNTJQ #KurtCobain #SoakedInB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kurt Fraser",
        "screen_name" : "cobainevidence",
        "indices" : [ 24, 39 ],
        "id_str" : "3256070810",
        "id" : 3256070810
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KurtCobain",
        "indices" : [ 101, 112 ]
      }, {
        "text" : "SoakedInBleach",
        "indices" : [ 113, 128 ]
      }, {
        "text" : "CobainCase",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/USIyTSNTJQ",
        "expanded_url" : "http:\/\/cobainevidence.com",
        "display_url" : "cobainevidence.com"
      } ]
    },
    "geo" : { },
    "id_str" : "621227415482814464",
    "text" : "Everybody please follow @cobainevidence - He is an attorney and the author of http:\/\/t.co\/USIyTSNTJQ #KurtCobain #SoakedInBleach #CobainCase",
    "id" : 621227415482814464,
    "created_at" : "2015-07-15 07:58:52 +0000",
    "user" : {
      "name" : "The Cobain Case",
      "screen_name" : "cobaincase",
      "protected" : false,
      "id_str" : "298880378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606358721564954624\/cke78ras_normal.jpg",
      "id" : 298880378,
      "verified" : false
    }
  },
  "id" : 803587096946544640,
  "created_at" : "2016-11-29 13:11:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803585272441139201",
  "text" : "If these local women would acknowledge me instead of this shrink telling me to broaden my topics I might not be that mad.",
  "id" : 803585272441139201,
  "created_at" : "2016-11-29 13:03:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/hOfOXxXKqc",
      "expanded_url" : "https:\/\/bingphp.codeplex.com\/",
      "display_url" : "bingphp.codeplex.com"
    } ]
  },
  "geo" : { },
  "id_str" : "803583668262293504",
  "text" : "https:\/\/t.co\/hOfOXxXKqc I like Arachnode Microsoft but this is Bing Search in PHP.",
  "id" : 803583668262293504,
  "created_at" : "2016-11-29 12:57:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/CUwDWQONBR",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Chicago_Loop",
      "display_url" : "en.wikipedia.org\/wiki\/Chicago_L\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803581322870591489",
  "text" : "https:\/\/t.co\/CUwDWQONBR East of the Loop Chicago.",
  "id" : 803581322870591489,
  "created_at" : "2016-11-29 12:48:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803580301519843328",
  "text" : "That hacker is east of Loop County in Chicago.",
  "id" : 803580301519843328,
  "created_at" : "2016-11-29 12:44:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803579051642408960",
  "text" : "I also have dissecting a C# program too.",
  "id" : 803579051642408960,
  "created_at" : "2016-11-29 12:39:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803578815003947008",
  "text" : "I built the ook language extension for Visual Studio. I know it was made just for fun too. I might try to write a .NET language.",
  "id" : 803578815003947008,
  "created_at" : "2016-11-29 12:38:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803577825009815552",
  "text" : "it costs $5.00 Magistrate to find out who in Chicago killed my Dell. I may call you.",
  "id" : 803577825009815552,
  "created_at" : "2016-11-29 12:34:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803576984597102597",
  "text" : "Performing a reverse phone lookup on instant checkmate on the Chicago number.",
  "id" : 803576984597102597,
  "created_at" : "2016-11-29 12:30:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "British Mensa",
      "screen_name" : "BritishMensa",
      "indices" : [ 3, 16 ],
      "id_str" : "21389945",
      "id" : 21389945
    }, {
      "name" : "Potential Plus UK",
      "screen_name" : "PPUK_",
      "indices" : [ 21, 27 ],
      "id_str" : "135918819",
      "id" : 135918819
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gifted",
      "indices" : [ 70, 77 ]
    }, {
      "text" : "gtvoice",
      "indices" : [ 87, 95 ]
    }, {
      "text" : "gtparent",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/kfJNBsflKw",
      "expanded_url" : "http:\/\/ow.ly\/9yV4306nBbg",
      "display_url" : "ow.ly\/9yV4306nBbg"
    } ]
  },
  "geo" : { },
  "id_str" : "803575517349720064",
  "text" : "RT @BritishMensa: RT @PPUK_: 9 Things I Wish People Knew About Highly #Gifted Children #gtvoice #gtparent https:\/\/t.co\/kfJNBsflKw https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Potential Plus UK",
        "screen_name" : "PPUK_",
        "indices" : [ 3, 9 ],
        "id_str" : "135918819",
        "id" : 135918819
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gifted",
        "indices" : [ 52, 59 ]
      }, {
        "text" : "gtvoice",
        "indices" : [ 69, 77 ]
      }, {
        "text" : "gtparent",
        "indices" : [ 78, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/kfJNBsflKw",
        "expanded_url" : "http:\/\/ow.ly\/9yV4306nBbg",
        "display_url" : "ow.ly\/9yV4306nBbg"
      }, {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/sQJ91oHX28",
        "expanded_url" : "http:\/\/fb.me\/UhU1VH6q",
        "display_url" : "fb.me\/UhU1VH6q"
      } ]
    },
    "geo" : { },
    "id_str" : "803573413285462016",
    "text" : "RT @PPUK_: 9 Things I Wish People Knew About Highly #Gifted Children #gtvoice #gtparent https:\/\/t.co\/kfJNBsflKw https:\/\/t.co\/sQJ91oHX28",
    "id" : 803573413285462016,
    "created_at" : "2016-11-29 12:16:46 +0000",
    "user" : {
      "name" : "British Mensa",
      "screen_name" : "BritishMensa",
      "protected" : false,
      "id_str" : "21389945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486496615838932992\/9q9rnXl__normal.jpeg",
      "id" : 21389945,
      "verified" : false
    }
  },
  "id" : 803575517349720064,
  "created_at" : "2016-11-29 12:25:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/EL9kfAph98",
      "expanded_url" : "http:\/\/lifeboat.com\/ex\/whats.new",
      "display_url" : "lifeboat.com\/ex\/whats.new"
    } ]
  },
  "geo" : { },
  "id_str" : "803574543113715712",
  "text" : "Visit the Lifeboat Foundation What&amp;rsquo;s New page and learn &amp;ldquo;what&amp;rsquo;s new&amp;rdquo; at Lifeboat! https:\/\/t.co\/EL9kfAph98",
  "id" : 803574543113715712,
  "created_at" : "2016-11-29 12:21:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803573973112000512",
  "text" : "I might added nanobot C# code when I find it after I get married of course and some of .NET. I've already asked to become a contributor.",
  "id" : 803573973112000512,
  "created_at" : "2016-11-29 12:18:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803568597285171200",
  "text" : "I do have the source to slivOS just don't like a Cloud OS.",
  "id" : 803568597285171200,
  "created_at" : "2016-11-29 11:57:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803564452461367296",
  "text" : "I emailed Chris.",
  "id" : 803564452461367296,
  "created_at" : "2016-11-29 11:41:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803563287493410816",
  "text" : "Don't steal my work do you and your family can have something to work on World and the Tri-Cities.",
  "id" : 803563287493410816,
  "created_at" : "2016-11-29 11:36:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803562965555363840",
  "text" : "Abingdon I don't want to be treated like Digital Research or Kurt Cobain. And I want to get my work done without you stealing my work.",
  "id" : 803562965555363840,
  "created_at" : "2016-11-29 11:35:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803406802759118850",
  "text" : "Storm coming I don't feel to good.",
  "id" : 803406802759118850,
  "created_at" : "2016-11-29 01:14:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803390191532732416",
  "text" : "That is why Microsoft is in Redmond not Seattle the noise.",
  "id" : 803390191532732416,
  "created_at" : "2016-11-29 00:08:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803388238585073669",
  "text" : "GitHub I really don't like social coding.",
  "id" : 803388238585073669,
  "created_at" : "2016-11-29 00:00:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803387493181751296",
  "text" : "Engineers are the real stars world not the front man.",
  "id" : 803387493181751296,
  "created_at" : "2016-11-28 23:57:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803386630996447232",
  "text" : "Leave me be area go to hell.",
  "id" : 803386630996447232,
  "created_at" : "2016-11-28 23:54:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803385885035204608",
  "text" : "I may leave highland community services and just go out patient if I don't get what I want out of this town. Fuck you abaletta",
  "id" : 803385885035204608,
  "created_at" : "2016-11-28 23:51:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803384887361343488",
  "text" : "Pushing and built the file manager and window manager and cleaned. Tomorrow please be quit area.",
  "id" : 803384887361343488,
  "created_at" : "2016-11-28 23:47:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803363830655045632",
  "text" : "I did like my Microsoft Freedom to innovate T-shirts. My dad through them out. It was of an American flag with the stars replacedbycomputer.",
  "id" : 803363830655045632,
  "created_at" : "2016-11-28 22:23:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenPOWER Foundation",
      "screen_name" : "OpenPOWERorg",
      "indices" : [ 3, 16 ],
      "id_str" : "2342138203",
      "id" : 2342138203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803362332231483392",
  "text" : "RT @OpenPOWERorg: Tencent has a need for speed! See how China's largest internet service provider is reaching benchmarks in big data | http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/percolate.com\" rel=\"nofollow\"\u003EPercolate\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OpenPOWERorg\/status\/803357108167065600\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/1oYAzWkjQ1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CyYZB_sUkAArdFJ.jpg",
        "id_str" : "803357105600106496",
        "id" : 803357105600106496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyYZB_sUkAArdFJ.jpg",
        "sizes" : [ {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/1oYAzWkjQ1"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/mIpgHw1H7v",
        "expanded_url" : "http:\/\/ibm.co\/2fpwHTi",
        "display_url" : "ibm.co\/2fpwHTi"
      } ]
    },
    "geo" : { },
    "id_str" : "803357108167065600",
    "text" : "Tencent has a need for speed! See how China's largest internet service provider is reaching benchmarks in big data | https:\/\/t.co\/mIpgHw1H7v https:\/\/t.co\/1oYAzWkjQ1",
    "id" : 803357108167065600,
    "created_at" : "2016-11-28 21:57:14 +0000",
    "user" : {
      "name" : "OpenPOWER Foundation",
      "screen_name" : "OpenPOWERorg",
      "protected" : false,
      "id_str" : "2342138203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644251922841538566\/--0eCLI8_normal.jpg",
      "id" : 2342138203,
      "verified" : false
    }
  },
  "id" : 803362332231483392,
  "created_at" : "2016-11-28 22:18:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803360397701107712",
  "text" : "I really don't like marketing NLP. I do just like science an computer programming. And I'm working on improvements.",
  "id" : 803360397701107712,
  "created_at" : "2016-11-28 22:10:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 73, 81 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/PCzXn4WhV5",
      "expanded_url" : "https:\/\/youtu.be\/iOzCn7hEtrs",
      "display_url" : "youtu.be\/iOzCn7hEtrs"
    } ]
  },
  "geo" : { },
  "id_str" : "803357584656896000",
  "text" : "Pearl Jam - Fuck Me In The Brain - Indio '93 https:\/\/t.co\/PCzXn4WhV5 via @YouTube",
  "id" : 803357584656896000,
  "created_at" : "2016-11-28 21:59:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803357293274394625",
  "text" : "I'm sick of being mind fucked everyone.",
  "id" : 803357293274394625,
  "created_at" : "2016-11-28 21:57:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803353415233507328",
  "text" : "You really don't have to use the big oven much. I use a small toaster oven and microwave some.",
  "id" : 803353415233507328,
  "created_at" : "2016-11-28 21:42:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roosh",
      "screen_name" : "rooshv",
      "indices" : [ 82, 89 ],
      "id_str" : "14458643",
      "id" : 14458643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/BH7raUC8W4",
      "expanded_url" : "http:\/\/www.rooshv.com\/rich-guys-who-still-dont-get-laid",
      "display_url" : "rooshv.com\/rich-guys-who-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803352003854352384",
  "text" : "Guys Who Make A Lot Of Money But Still Don\u2019t Get Laid https:\/\/t.co\/BH7raUC8W4 via @rooshv        engineers.",
  "id" : 803352003854352384,
  "created_at" : "2016-11-28 21:36:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803350049396760577",
  "text" : "See everyone Abingdon and culture I told my cognitive therapist I had all of Carl Sagan's videos and Hawkins. Plus a cache of Wikipedia.",
  "id" : 803350049396760577,
  "created_at" : "2016-11-28 21:29:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803348015771746305",
  "text" : "I did just give BOINC 15 percent of my CPU time to work on tasks and suspend if all apps go over 50% and use while the computer is in use.",
  "id" : 803348015771746305,
  "created_at" : "2016-11-28 21:21:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803345805960761347",
  "text" : "It is just BOINC that is giving me a lot of tasks and using more of my memory. Pay me damn it.",
  "id" : 803345805960761347,
  "created_at" : "2016-11-28 21:12:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803345031365005312",
  "text" : "I have to go through cognitive therapy. Just to broaden my scientific  mind so women will like me.",
  "id" : 803345031365005312,
  "created_at" : "2016-11-28 21:09:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803343442302615553",
  "text" : "She is kinda pretty and why was my browser just attacked.",
  "id" : 803343442302615553,
  "created_at" : "2016-11-28 21:02:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803329309272371201",
  "text" : "Just got an email for the new Star Wars too. I'm not fucking around.",
  "id" : 803329309272371201,
  "created_at" : "2016-11-28 20:06:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803284685677727744",
  "text" : "Went to court over somebody hacking me they told me to see the magistrate.",
  "id" : 803284685677727744,
  "created_at" : "2016-11-28 17:09:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803282039638265856",
  "text" : "I really haven't showed you anything yet.",
  "id" : 803282039638265856,
  "created_at" : "2016-11-28 16:58:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 28, 36 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/xDtzHAUQDL",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=UtoXvSglz80&sns=tw",
      "display_url" : "youtube.com\/watch?v=UtoXvS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803281579711860736",
  "text" : "https:\/\/t.co\/xDtzHAUQDL via @youtube",
  "id" : 803281579711860736,
  "created_at" : "2016-11-28 16:57:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803281416620490752",
  "text" : "And I'm not giving you my extension book either.",
  "id" : 803281416620490752,
  "created_at" : "2016-11-28 16:56:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803280784568229888",
  "text" : "Everyone stop trying to make her a damn phone.",
  "id" : 803280784568229888,
  "created_at" : "2016-11-28 16:53:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803277546880204800",
  "text" : "The jocks are dead the is an Visual studio wizard in MFC.",
  "id" : 803277546880204800,
  "created_at" : "2016-11-28 16:41:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803276658484465664",
  "text" : "Now you want visual studio source No! No marriage no class.",
  "id" : 803276658484465664,
  "created_at" : "2016-11-28 16:37:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803247374340456448",
  "text" : "C# is faster than C and safer.",
  "id" : 803247374340456448,
  "created_at" : "2016-11-28 14:41:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803227106368897024",
  "text" : "And UVa and M.I.T I do have the grades for an online independent study which is all I've been doing without your support.",
  "id" : 803227106368897024,
  "created_at" : "2016-11-28 13:20:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803225917455613952",
  "text" : "Kid it does probably take college too for that MVP stay in school kid.",
  "id" : 803225917455613952,
  "created_at" : "2016-11-28 13:15:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803224445833854976",
  "text" : "Flip them off Bower.",
  "id" : 803224445833854976,
  "created_at" : "2016-11-28 13:10:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803223420217552897",
  "text" : "I have my new MVP managers number and email.",
  "id" : 803223420217552897,
  "created_at" : "2016-11-28 13:06:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803222194138423296",
  "text" : "I never listed to Pearl Jam that much that is probably all my friends know about my music I read magazines . I was never influenced by them.",
  "id" : 803222194138423296,
  "created_at" : "2016-11-28 13:01:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803221073831620608",
  "text" : "Just received an Microsoft MVP email and my nomination will be reviewed next cycle as the January one has closed. And I have a new manager.",
  "id" : 803221073831620608,
  "created_at" : "2016-11-28 12:56:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/PZzPcOwYu4",
      "expanded_url" : "https:\/\/www.quora.com\/What-is-the-evolutionary-advantage-of-marriage",
      "display_url" : "quora.com\/What-is-the-ev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803216811034546176",
  "text" : "https:\/\/t.co\/PZzPcOwYu4 See parties and unevolved people.",
  "id" : 803216811034546176,
  "created_at" : "2016-11-28 12:39:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803213018205224960",
  "text" : "I joined GitHub's pre release mentor program.",
  "id" : 803213018205224960,
  "created_at" : "2016-11-28 12:24:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/V1mQeIs5wa",
      "expanded_url" : "https:\/\/blogs.msdn.microsoft.com\/fsharpteam\/2015\/01\/13\/visual-f-has-moved-to-github\/",
      "display_url" : "blogs.msdn.microsoft.com\/fsharpteam\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803210492043005952",
  "text" : "Visual F# has moved to GitHub https:\/\/t.co\/V1mQeIs5wa Microsoft is migrating to GitHub.",
  "id" : 803210492043005952,
  "created_at" : "2016-11-28 12:14:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 50, 58 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/vwftiG7JKP",
      "expanded_url" : "https:\/\/youtu.be\/FhKobpwhnhI",
      "display_url" : "youtu.be\/FhKobpwhnhI"
    } ]
  },
  "geo" : { },
  "id_str" : "803203441589972993",
  "text" : "Aphex  Twin live 2013 https:\/\/t.co\/vwftiG7JKP via @YouTube I hate folk and the public too now.",
  "id" : 803203441589972993,
  "created_at" : "2016-11-28 11:46:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803201868830822400",
  "text" : "Vanover what was your grade in Sofware engineering I got a B and I was lead programmer on my team in C#.",
  "id" : 803201868830822400,
  "created_at" : "2016-11-28 11:40:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803201037490421760",
  "text" : "And I'm really not giving you Deitel either.",
  "id" : 803201037490421760,
  "created_at" : "2016-11-28 11:37:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/pqy0zxwUXz",
      "expanded_url" : "http:\/\/jdm7dv.bandcamp.com\/track\/02008",
      "display_url" : "jdm7dv.bandcamp.com\/track\/02008"
    } ]
  },
  "geo" : { },
  "id_str" : "803195976253054976",
  "text" : "omg best track ever:  https:\/\/t.co\/pqy0zxwUXz",
  "id" : 803195976253054976,
  "created_at" : "2016-11-28 11:16:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 80, 88 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/7GIPs4ehZG",
      "expanded_url" : "https:\/\/youtu.be\/8-r-V0uK4u0",
      "display_url" : "youtu.be\/8-r-V0uK4u0"
    } ]
  },
  "geo" : { },
  "id_str" : "803193938941247489",
  "text" : "The Smashing Pumpkins - Bullet with Butterfly Wings https:\/\/t.co\/7GIPs4ehZG via @YouTube",
  "id" : 803193938941247489,
  "created_at" : "2016-11-28 11:08:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803191763628335104",
  "text" : "Upperclass I'm just not telling you how Riven ends or how to solve any of it's puzzles find a guide if you can.",
  "id" : 803191763628335104,
  "created_at" : "2016-11-28 11:00:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803188684640161792",
  "text" : "It was just the students that didn't included me at UVA wise.",
  "id" : 803188684640161792,
  "created_at" : "2016-11-28 10:47:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803166452807180288",
  "text" : "And don't treat me like digital research either.",
  "id" : 803166452807180288,
  "created_at" : "2016-11-28 09:19:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803165705701117952",
  "text" : "Microsoft never betray someone that has been with you since Windows 1.0 me.",
  "id" : 803165705701117952,
  "created_at" : "2016-11-28 09:16:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803157935538876416",
  "text" : "And II don't have a country accent or any country music.",
  "id" : 803157935538876416,
  "created_at" : "2016-11-28 08:45:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803157375167381504",
  "text" : "I don't even use any access any features any don't even stutter with b1 doctor. Bring up disability I dare you.",
  "id" : 803157375167381504,
  "created_at" : "2016-11-28 08:43:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803070790644088834",
  "text" : "Doctor you won't change my diagnosis until you get all of my source will you? I might fight you in court.",
  "id" : 803070790644088834,
  "created_at" : "2016-11-28 02:59:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803049383675785216",
  "text" : "I'm not impotent, but still that is Alan Turning isn't it?",
  "id" : 803049383675785216,
  "created_at" : "2016-11-28 01:34:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803049225592438784",
  "text" : "When I do get married I'm not getting back by putting my wedding photos on the internet to the one thing an impotent man can't have, a kid.",
  "id" : 803049225592438784,
  "created_at" : "2016-11-28 01:33:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803047127127453696",
  "text" : "Everyone say hi tomorrow with your pretty white teeth.On social media and the Today show show me that baby.",
  "id" : 803047127127453696,
  "created_at" : "2016-11-28 01:25:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803045320091439106",
  "text" : "I would just sell you my maintained version of Flash for 50 billion too Goodnight.",
  "id" : 803045320091439106,
  "created_at" : "2016-11-28 01:18:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803044376721100800",
  "text" : "And I really don't want to talk to anyone that has copied me or used me in the world ever. Goodnight.",
  "id" : 803044376721100800,
  "created_at" : "2016-11-28 01:14:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bloomberg",
      "screen_name" : "business",
      "indices" : [ 111, 120 ],
      "id_str" : "34713362",
      "id" : 34713362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/pDF1jajLIw",
      "expanded_url" : "http:\/\/bloom.bg\/2fFVKov",
      "display_url" : "bloom.bg\/2fFVKov"
    } ]
  },
  "geo" : { },
  "id_str" : "803043222935207936",
  "text" : "India's Modi has surprisingly strong rural support - but maybe not for much longer https:\/\/t.co\/pDF1jajLIw via @business See I've had it.",
  "id" : 803043222935207936,
  "created_at" : "2016-11-28 01:09:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803038164344537090",
  "text" : "The suit isn't sexy anymore everyone it's old money.",
  "id" : 803038164344537090,
  "created_at" : "2016-11-28 00:49:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 90, 96 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/NN43TVpeZG",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/life\/doonan\/2015\/11\/tight_fitted_men_s_clothing_how_male_fashion_went_from_drapey_to_taut.html?wpsrc=sh_all_dt_tw_top",
      "display_url" : "slate.com\/articles\/life\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803037925214601221",
  "text" : "Fitted men\u2019s clothing can\u2019t possibly get any tighter, can it? https:\/\/t.co\/NN43TVpeZG via @slate",
  "id" : 803037925214601221,
  "created_at" : "2016-11-28 00:48:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 28, 36 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Ez6dugUU14",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Fv05EmuDjsY&sns=tw",
      "display_url" : "youtube.com\/watch?v=Fv05Em\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803034130929819649",
  "text" : "https:\/\/t.co\/Ez6dugUU14 via @youtube won a Grammy.",
  "id" : 803034130929819649,
  "created_at" : "2016-11-28 00:33:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803033601726103552",
  "text" : "Virginia you aren't evolved for marriage yet.",
  "id" : 803033601726103552,
  "created_at" : "2016-11-28 00:31:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803032918918594560",
  "text" : "My wife would just fight over the server in court too if she ever committed adultery.",
  "id" : 803032918918594560,
  "created_at" : "2016-11-28 00:29:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803030605642350593",
  "text" : "And it is a damn law document too everyone.",
  "id" : 803030605642350593,
  "created_at" : "2016-11-28 00:19:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803030030523793410",
  "text" : "I don't lie or scam people everyone. I don't get paid.",
  "id" : 803030030523793410,
  "created_at" : "2016-11-28 00:17:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803028975538860032",
  "text" : "The justice dept hacking mailbox is full local judge. I've already tried that.",
  "id" : 803028975538860032,
  "created_at" : "2016-11-28 00:13:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 83, 89 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/v8Cpdbz2Hm",
      "expanded_url" : "https:\/\/www.wired.com\/2015\/03\/researchers-uncover-way-hack-bios-undermine-secure-operating-systems\/",
      "display_url" : "wired.com\/2015\/03\/resear\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803027676734730240",
  "text" : "Hacking BIOS Chips Isn\u2019t Just the NSA\u2019s Domain Anymore https:\/\/t.co\/v8Cpdbz2Hm via @WIRED",
  "id" : 803027676734730240,
  "created_at" : "2016-11-28 00:08:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803026552741068800",
  "text" : "After I do get my compensation for this Dell I may play a Tom Petty song.",
  "id" : 803026552741068800,
  "created_at" : "2016-11-28 00:03:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802966399996006400",
  "text" : "I am telling my manager I need some security because of who I am stop using so much computer memory trash. And I didn't even install.",
  "id" : 802966399996006400,
  "created_at" : "2016-11-27 20:04:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nidhi Subbaraman",
      "screen_name" : "NidhiSubs",
      "indices" : [ 64, 74 ],
      "id_str" : "18393501",
      "id" : 18393501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/tKueAbRjab",
      "expanded_url" : "https:\/\/www.buzzfeed.com\/nidhisubbaraman\/age-no-more?utm_term=.aqWwWnnLL",
      "display_url" : "buzzfeed.com\/nidhisubbarama\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "802595649115951108",
  "text" : "The Anti-Aging Supplement Gold Mine https:\/\/t.co\/tKueAbRjab via @nidhisubs",
  "id" : 802595649115951108,
  "created_at" : "2016-11-26 19:31:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "indices" : [ 63, 74 ],
      "id_str" : "15438913",
      "id" : 15438913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/RfvbIh0AlT",
      "expanded_url" : "http:\/\/dailym.ai\/22BNNRz",
      "display_url" : "dailym.ai\/22BNNRz"
    } ]
  },
  "geo" : { },
  "id_str" : "802591813785833472",
  "text" : "Why smart people tend to be loners https:\/\/t.co\/RfvbIh0AlT via @MailOnline",
  "id" : 802591813785833472,
  "created_at" : "2016-11-26 19:16:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 0, 6 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/0YLZlvDCs1",
      "expanded_url" : "https:\/\/github.com\/mehikmat\/CoderAcademy",
      "display_url" : "github.com\/mehikmat\/Coder\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "802547194234605568",
  "in_reply_to_user_id" : 1536791610,
  "text" : "@POTUS https:\/\/t.co\/0YLZlvDCs1 Mr. President PLEASE REMOVE THIS REPO ON ATOM BOMBS. Not mine.",
  "id" : 802547194234605568,
  "created_at" : "2016-11-26 16:18:56 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802530067947499520",
  "text" : "Trauma and able to see evil is what I'm going through. I need to do something about the career, retirement and education.",
  "id" : 802530067947499520,
  "created_at" : "2016-11-26 15:10:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mayo Clinic",
      "screen_name" : "MayoClinic",
      "indices" : [ 3, 14 ],
      "id_str" : "14592723",
      "id" : 14592723
    }, {
      "name" : "Thomas Shives M.D.",
      "screen_name" : "DrTomShives",
      "indices" : [ 85, 97 ],
      "id_str" : "2398411634",
      "id" : 2398411634
    }, {
      "name" : "Tracy McCray",
      "screen_name" : "TracyMcCray",
      "indices" : [ 102, 114 ],
      "id_str" : "86334169",
      "id" : 86334169
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MayoClinic\/status\/802528592827740160\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/oJgb9AG5Cg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CyMngDsWgAA2x2T.jpg",
      "id_str" : "802528590302707712",
      "id" : 802528590302707712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyMngDsWgAA2x2T.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/oJgb9AG5Cg"
    } ],
    "hashtags" : [ {
      "text" : "MayoClinicRadio",
      "indices" : [ 54, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/tEgLMkaEfa",
      "expanded_url" : "http:\/\/mayocl.in\/1z06Da3",
      "display_url" : "mayocl.in\/1z06Da3"
    } ]
  },
  "geo" : { },
  "id_str" : "802529281549008896",
  "text" : "RT @MayoClinic: Listen NOW https:\/\/t.co\/tEgLMkaEfa to #MayoClinicRadio with co-hosts @DrTomShives and @TracyMcCray. https:\/\/t.co\/oJgb9AG5Cg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Thomas Shives M.D.",
        "screen_name" : "DrTomShives",
        "indices" : [ 69, 81 ],
        "id_str" : "2398411634",
        "id" : 2398411634
      }, {
        "name" : "Tracy McCray",
        "screen_name" : "TracyMcCray",
        "indices" : [ 86, 98 ],
        "id_str" : "86334169",
        "id" : 86334169
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MayoClinic\/status\/802528592827740160\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/oJgb9AG5Cg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CyMngDsWgAA2x2T.jpg",
        "id_str" : "802528590302707712",
        "id" : 802528590302707712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyMngDsWgAA2x2T.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/oJgb9AG5Cg"
      } ],
      "hashtags" : [ {
        "text" : "MayoClinicRadio",
        "indices" : [ 38, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/tEgLMkaEfa",
        "expanded_url" : "http:\/\/mayocl.in\/1z06Da3",
        "display_url" : "mayocl.in\/1z06Da3"
      } ]
    },
    "geo" : { },
    "id_str" : "802528592827740160",
    "text" : "Listen NOW https:\/\/t.co\/tEgLMkaEfa to #MayoClinicRadio with co-hosts @DrTomShives and @TracyMcCray. https:\/\/t.co\/oJgb9AG5Cg",
    "id" : 802528592827740160,
    "created_at" : "2016-11-26 15:05:01 +0000",
    "user" : {
      "name" : "Mayo Clinic",
      "screen_name" : "MayoClinic",
      "protected" : false,
      "id_str" : "14592723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760454818422857728\/2WFm5vUI_normal.jpg",
      "id" : 14592723,
      "verified" : true
    }
  },
  "id" : 802529281549008896,
  "created_at" : "2016-11-26 15:07:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802528680769626113",
  "text" : "Bush it was your faith or lack of in Microsoft and a 20 year old with FreeBSD that sent me to treatment. In 2001.",
  "id" : 802528680769626113,
  "created_at" : "2016-11-26 15:05:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802527461493903360",
  "text" : "With the antipsychotics that I'm on I'm not really calling it mind control just able to see evil and the natural psychotic world.",
  "id" : 802527461493903360,
  "created_at" : "2016-11-26 15:00:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802514955131973634",
  "text" : "I was just trying to impress women with my brain too. And I really didn't mean to blown there minds.",
  "id" : 802514955131973634,
  "created_at" : "2016-11-26 14:10:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "indices" : [ 97, 108 ],
      "id_str" : "15438913",
      "id" : 15438913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/iUuG7nmj4j",
      "expanded_url" : "http:\/\/dailym.ai\/1oPVyi4",
      "display_url" : "dailym.ai\/1oPVyi4"
    } ]
  },
  "geo" : { },
  "id_str" : "802514240095387648",
  "text" : "Going through a rough time? Think about yourself in the third person https:\/\/t.co\/iUuG7nmj4j via @MailOnline Social media I've had it.",
  "id" : 802514240095387648,
  "created_at" : "2016-11-26 14:07:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802504427731034112",
  "text" : "Know I am watching who I drive with and where we go I don't want to to be put down.",
  "id" : 802504427731034112,
  "created_at" : "2016-11-26 13:29:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802502610670522369",
  "text" : "I do have a C# DICOM viewer doctor that isn't EvilDICOM no matter how much you compete with me on technology. And you can't have it.",
  "id" : 802502610670522369,
  "created_at" : "2016-11-26 13:21:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/2YCZA2xs6Y",
      "expanded_url" : "https:\/\/academic.microsoft.com\/#\/detail\/2408351025",
      "display_url" : "academic.microsoft.com\/#\/detail\/24083\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "802488378432385025",
  "text" : "https:\/\/t.co\/2YCZA2xs6Y Modelling operations and security of cloud systems using Z-notation and Chinese Wall security policy.",
  "id" : 802488378432385025,
  "created_at" : "2016-11-26 12:25:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 68, 76 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/zHnLG53lCq",
      "expanded_url" : "https:\/\/youtu.be\/377W0Fya3Xs",
      "display_url" : "youtu.be\/377W0Fya3Xs"
    } ]
  },
  "geo" : { },
  "id_str" : "802487615832391680",
  "text" : "R.E.M. - Hope (Featuring Leonard Cohen) https:\/\/t.co\/zHnLG53lCq via @YouTube",
  "id" : 802487615832391680,
  "created_at" : "2016-11-26 12:22:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802486034684583936",
  "text" : "I hope these women feel guilty.",
  "id" : 802486034684583936,
  "created_at" : "2016-11-26 12:15:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802485881370214400",
  "text" : "And every hot women in America should to the right thing and choose me as there husband for showing them the CIA's black vault.",
  "id" : 802485881370214400,
  "created_at" : "2016-11-26 12:15:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802484856915640321",
  "text" : "I do have a Seagate 5 TB black vault too.",
  "id" : 802484856915640321,
  "created_at" : "2016-11-26 12:11:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/dcAMLAmRJj",
      "expanded_url" : "http:\/\/www.theblackvault.com\/documentarchive\/cia-mkultra-collection\/",
      "display_url" : "theblackvault.com\/documentarchiv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "802484056898281472",
  "text" : "https:\/\/t.co\/dcAMLAmRJj It is declassified and I'm downloading the documents.",
  "id" : 802484056898281472,
  "created_at" : "2016-11-26 12:08:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802483063305420800",
  "text" : "Everyone turn off your Wifi and some wirelessin my area if you want and let's try something. And see if you can control your own mind today.",
  "id" : 802483063305420800,
  "created_at" : "2016-11-26 12:04:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802480629677957120",
  "text" : "I will testify Snowden I might have to bring my notes and might be nervous.",
  "id" : 802480629677957120,
  "created_at" : "2016-11-26 11:54:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/QasENM00Up",
      "expanded_url" : "http:\/\/www.pbs.org\/newshour\/rundown\/hurricane-otto-makes-landfall-nicaraguas-caribbean-coast\/?utm_source=facebook&utm_medium=pbsofficial&utm_campaign=newshour",
      "display_url" : "pbs.org\/newshour\/rundo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "802479179052838912",
  "text" : "https:\/\/t.co\/QasENM00Up It might be the weather too.",
  "id" : 802479179052838912,
  "created_at" : "2016-11-26 11:48:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802478127255429120",
  "text" : "It is the media too.maybe not fixed media and you do know media I'm talking about.",
  "id" : 802478127255429120,
  "created_at" : "2016-11-26 11:44:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802477335035269120",
  "text" : "I can even beat the doctor on the definition of liquidity. I hate you doctor.",
  "id" : 802477335035269120,
  "created_at" : "2016-11-26 11:41:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/lNB9jLSNDQ",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Wireless_electronic_devices_and_health",
      "display_url" : "en.wikipedia.org\/wiki\/Wireless_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "802475347086311424",
  "text" : "https:\/\/t.co\/lNB9jLSNDQ \nWireless electronic devices and health",
  "id" : 802475347086311424,
  "created_at" : "2016-11-26 11:33:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802473734401564672",
  "text" : "I really don't want to party I would just like to have fun with what's left of my family. And hopefully future wife if she can be trusted.",
  "id" : 802473734401564672,
  "created_at" : "2016-11-26 11:27:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802471996277854208",
  "text" : "Now I am saying discography torrent and that is all I have really done plus 4 cracks.",
  "id" : 802471996277854208,
  "created_at" : "2016-11-26 11:20:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/X7bIwpTfrs",
      "expanded_url" : "https:\/\/vimeo.com\/78548198",
      "display_url" : "vimeo.com\/78548198"
    } ]
  },
  "geo" : { },
  "id_str" : "802470784673476612",
  "text" : "https:\/\/t.co\/X7bIwpTfrs EMF the band and 'Unbelievable'",
  "id" : 802470784673476612,
  "created_at" : "2016-11-26 11:15:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802470240026144768",
  "text" : "I want all of the EMF code out. It there is any.",
  "id" : 802470240026144768,
  "created_at" : "2016-11-26 11:13:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802470204999606272",
  "text" : "Microsoft took out media center in 10 and soon I will only have a Cisco router without Xfinity. I can turn off the Cisco Wifi.",
  "id" : 802470204999606272,
  "created_at" : "2016-11-26 11:13:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802468012402102272",
  "text" : "I really am not taking it it from women about talent, intelligence, sex, or making fun of others either.",
  "id" : 802468012402102272,
  "created_at" : "2016-11-26 11:04:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/1jJL92iYCt",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/TargetedEnergyWeapons\/comments\/44j5ud\/neural_monitoring_nsa_nsa_signals_intelligence\/",
      "display_url" : "reddit.com\/r\/TargetedEner\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "802466972667670532",
  "text" : "https:\/\/t.co\/1jJL92iYCt EMF and remote signals intelligence.",
  "id" : 802466972667670532,
  "created_at" : "2016-11-26 11:00:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/SDMVSCHCqS",
      "expanded_url" : "https:\/\/www.safespaceprotection.com\/emf-health-risks\/emf-health-effects\/wi-fi-router-dangers\/",
      "display_url" : "safespaceprotection.com\/emf-health-ris\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "802466556122906624",
  "text" : "https:\/\/t.co\/SDMVSCHCqS Wi-Fi and EMF.",
  "id" : 802466556122906624,
  "created_at" : "2016-11-26 10:58:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 42, 50 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/GnfKLAj4QX",
      "expanded_url" : "https:\/\/youtu.be\/nKhKBNS1fPc",
      "display_url" : "youtu.be\/nKhKBNS1fPc"
    } ]
  },
  "geo" : { },
  "id_str" : "802464418642554880",
  "text" : "KMFDM - Dogma https:\/\/t.co\/GnfKLAj4QX via @YouTube",
  "id" : 802464418642554880,
  "created_at" : "2016-11-26 10:50:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802463106886606849",
  "text" : "Stop calling me a girl when I talk about a guy doctor. Build Clang 3.6 there is a tool called \"kill the doctor'.",
  "id" : 802463106886606849,
  "created_at" : "2016-11-26 10:44:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802458660492279811",
  "text" : "Bush you know the C programming language is dangerous and we ore trying to keep the Cyclomatic Complexity down in C#.",
  "id" : 802458660492279811,
  "created_at" : "2016-11-26 10:27:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/5A9CxMH1rt",
      "expanded_url" : "http:\/\/arstechnica.com\/tech-policy\/2016\/11\/obama-says-he-cant-pardon-snowden\/",
      "display_url" : "arstechnica.com\/tech-policy\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "802457440826617856",
  "text" : "https:\/\/t.co\/5A9CxMH1rt Snowden you are loved in my homeland.",
  "id" : 802457440826617856,
  "created_at" : "2016-11-26 10:22:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ZilT0aG3cx",
      "expanded_url" : "https:\/\/pardonsnowden.org\/",
      "display_url" : "pardonsnowden.org"
    } ]
  },
  "geo" : { },
  "id_str" : "802455852632264706",
  "text" : "https:\/\/t.co\/ZilT0aG3cx Stand up for Snowden.",
  "id" : 802455852632264706,
  "created_at" : "2016-11-26 10:15:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/9lZAlAF6CP",
      "expanded_url" : "https:\/\/www.quora.com\/How-valid-are-the-claims-of-people-being-victims-of-remote-neural-monitoring-if-at-all",
      "display_url" : "quora.com\/How-valid-are-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "802454976886964224",
  "text" : "https:\/\/t.co\/9lZAlAF6CP we are arguing still about remote neural monitoring. They will just say I have schizophrenia.",
  "id" : 802454976886964224,
  "created_at" : "2016-11-26 10:12:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802453263790600192",
  "text" : "\"clandestine operations to control human behavior\"",
  "id" : 802453263790600192,
  "created_at" : "2016-11-26 10:05:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/dKVPEhTQnx",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Project_MKUltra",
      "display_url" : "en.wikipedia.org\/wiki\/Project_M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "802452786340368384",
  "text" : "https:\/\/t.co\/dKVPEhTQnx  Project_MKUltra. CIA I want this out the every Republican presidency I feel a little unstable.",
  "id" : 802452786340368384,
  "created_at" : "2016-11-26 10:03:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 63, 71 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/aNRUg07nuX",
      "expanded_url" : "https:\/\/youtu.be\/hzf3hTUKk8U",
      "display_url" : "youtu.be\/hzf3hTUKk8U"
    } ]
  },
  "geo" : { },
  "id_str" : "801471487488258048",
  "text" : "Functional Programming is Terrible https:\/\/t.co\/aNRUg07nuX via @YouTube",
  "id" : 801471487488258048,
  "created_at" : "2016-11-23 17:04:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "801142294934130688",
  "text" : "New knew spin it media.",
  "id" : 801142294934130688,
  "created_at" : "2016-11-22 19:16:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "801142037106016256",
  "text" : "And if people keep calling and hanging up I'm calling the cops. Stop the character assignation.",
  "id" : 801142037106016256,
  "created_at" : "2016-11-22 19:15:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "801121581833551872",
  "text" : "That swarm.",
  "id" : 801121581833551872,
  "created_at" : "2016-11-22 17:54:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "801118042134482944",
  "text" : "My 1500 page Princeton math book came.",
  "id" : 801118042134482944,
  "created_at" : "2016-11-22 17:39:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SlashGear",
      "screen_name" : "slashgear",
      "indices" : [ 79, 89 ],
      "id_str" : "10685262",
      "id" : 10685262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/CUx71eaTNe",
      "expanded_url" : "https:\/\/www.slashgear.com\/why-i-refuse-to-believe-vr-is-the-future-of-gaming-08372592\/",
      "display_url" : "slashgear.com\/why-i-refuse-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "801044177849094144",
  "text" : "Why I refuse to believe VR is the future of gaming https:\/\/t.co\/CUx71eaTNe via @slashgear",
  "id" : 801044177849094144,
  "created_at" : "2016-11-22 12:46:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/mfezMWG0kJ",
      "expanded_url" : "https:\/\/ines.io\/blog\/switching-to-desktop-apps",
      "display_url" : "ines.io\/blog\/switching\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "800815414997647361",
  "text" : "https:\/\/t.co\/mfezMWG0kJ I switched from web apps to desktop apps and it's amazing.",
  "id" : 800815414997647361,
  "created_at" : "2016-11-21 21:37:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800809984661590016",
  "text" : "The area will just be stealing my culture and have other men's children and I'm telling my manager.",
  "id" : 800809984661590016,
  "created_at" : "2016-11-21 21:15:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800798785316143107",
  "text" : "I really don't like what America does to you just to get a good looking women either, spin depression etc.Then use all of your intelligence.",
  "id" : 800798785316143107,
  "created_at" : "2016-11-21 20:31:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC Copywriting",
      "screen_name" : "ABC_Copywriting",
      "indices" : [ 68, 84 ],
      "id_str" : "524168911",
      "id" : 524168911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/0SA0AhPmbe",
      "expanded_url" : "http:\/\/www.abccopywriting.com\/2012\/02\/23\/why-marketing-is-evil",
      "display_url" : "abccopywriting.com\/2012\/02\/23\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "800791793541541888",
  "text" : "Why marketing is evil - ABC Copywriting https:\/\/t.co\/0SA0AhPmbe via @ABC_Copywriting",
  "id" : 800791793541541888,
  "created_at" : "2016-11-21 20:03:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Verizon",
      "screen_name" : "verizon",
      "indices" : [ 0, 8 ],
      "id_str" : "59889953",
      "id" : 59889953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799639433045606402",
  "in_reply_to_user_id" : 59889953,
  "text" : "@verizon What program on FreeBSD if any gets phone numbers?",
  "id" : 799639433045606402,
  "created_at" : "2016-11-18 15:44:32 +0000",
  "in_reply_to_screen_name" : "verizon",
  "in_reply_to_user_id_str" : "59889953",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 3, 12 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799635672273297410",
  "text" : "RT @LinkedIn: Top headlines for Friday, November 4, 2016, from @LinkedInPulse: https:\/\/t.co\/JgVqBDH7OG #DailyRundown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DailyRundown",
        "indices" : [ 89, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/JgVqBDH7OG",
        "expanded_url" : "http:\/\/bit.ly\/2evpB2c",
        "display_url" : "bit.ly\/2evpB2c"
      } ]
    },
    "geo" : { },
    "id_str" : "794555578383269890",
    "text" : "Top headlines for Friday, November 4, 2016, from @LinkedInPulse: https:\/\/t.co\/JgVqBDH7OG #DailyRundown",
    "id" : 794555578383269890,
    "created_at" : "2016-11-04 15:03:06 +0000",
    "user" : {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "protected" : false,
      "id_str" : "13058772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614583061448036352\/CBpFkPaz_normal.png",
      "id" : 13058772,
      "verified" : true
    }
  },
  "id" : 799635672273297410,
  "created_at" : "2016-11-18 15:29:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 3, 12 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "job",
      "indices" : [ 88, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/tiEwDKvmot",
      "expanded_url" : "http:\/\/bit.ly\/2fXDRTa",
      "display_url" : "bit.ly\/2fXDRTa"
    } ]
  },
  "geo" : { },
  "id_str" : "799635449417531392",
  "text" : "RT @LinkedIn: The most popular jobs and companies for college grads. Time to start your #job search: https:\/\/t.co\/tiEwDKvmot #LinkedInStude\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "job",
        "indices" : [ 74, 78 ]
      }, {
        "text" : "LinkedInStudents",
        "indices" : [ 111, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/tiEwDKvmot",
        "expanded_url" : "http:\/\/bit.ly\/2fXDRTa",
        "display_url" : "bit.ly\/2fXDRTa"
      } ]
    },
    "geo" : { },
    "id_str" : "798928140244426752",
    "text" : "The most popular jobs and companies for college grads. Time to start your #job search: https:\/\/t.co\/tiEwDKvmot #LinkedInStudents",
    "id" : 798928140244426752,
    "created_at" : "2016-11-16 16:38:06 +0000",
    "user" : {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "protected" : false,
      "id_str" : "13058772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614583061448036352\/CBpFkPaz_normal.png",
      "id" : 13058772,
      "verified" : true
    }
  },
  "id" : 799635449417531392,
  "created_at" : "2016-11-18 15:28:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 0, 9 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799635177689534464",
  "in_reply_to_user_id" : 13058772,
  "text" : "@LinkedIn how can I find out who has blocked or reported me?",
  "id" : 799635177689534464,
  "created_at" : "2016-11-18 15:27:37 +0000",
  "in_reply_to_screen_name" : "LinkedIn",
  "in_reply_to_user_id_str" : "13058772",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 0, 9 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799635114800070657",
  "in_reply_to_user_id" : 2425151,
  "text" : "@facebook how can I find out who has blocked or reported me?",
  "id" : 799635114800070657,
  "created_at" : "2016-11-18 15:27:22 +0000",
  "in_reply_to_screen_name" : "facebook",
  "in_reply_to_user_id_str" : "2425151",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GooglePlus",
      "screen_name" : "GooglePlus",
      "indices" : [ 0, 11 ],
      "id_str" : "327602105",
      "id" : 327602105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799635029441789953",
  "in_reply_to_user_id" : 327602105,
  "text" : "@GooglePlus how can I find out who has blocked or reported me?",
  "id" : 799635029441789953,
  "created_at" : "2016-11-18 15:27:02 +0000",
  "in_reply_to_screen_name" : "GooglePlus",
  "in_reply_to_user_id_str" : "327602105",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 0, 8 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799634869269753860",
  "in_reply_to_user_id" : 783214,
  "text" : "@twitter how can I find out who has blocked or reported me?",
  "id" : 799634869269753860,
  "created_at" : "2016-11-18 15:26:23 +0000",
  "in_reply_to_screen_name" : "twitter",
  "in_reply_to_user_id_str" : "783214",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 0, 7 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799634731969101829",
  "in_reply_to_user_id" : 13334762,
  "text" : "@github how can I find out who has blocked or reported me?",
  "id" : 799634731969101829,
  "created_at" : "2016-11-18 15:25:51 +0000",
  "in_reply_to_screen_name" : "github",
  "in_reply_to_user_id_str" : "13334762",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799348567131361281",
  "text" : "Backing up my 690gb home directory. To a one to external.",
  "id" : 799348567131361281,
  "created_at" : "2016-11-17 20:28:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799307259662766080",
  "text" : "I changed the savannah repo to jessie with no changes it's in sid and currently unstable.",
  "id" : 799307259662766080,
  "created_at" : "2016-11-17 17:44:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 81, 89 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/3G7pNFHkb3",
      "expanded_url" : "https:\/\/youtu.be\/RBkxcmyB9d4",
      "display_url" : "youtu.be\/RBkxcmyB9d4"
    } ]
  },
  "geo" : { },
  "id_str" : "799304836604952576",
  "text" : "The Smashing Pumpkins - Let Me Give the World to You https:\/\/t.co\/3G7pNFHkb3 via @YouTube",
  "id" : 799304836604952576,
  "created_at" : "2016-11-17 17:34:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799303567391784960",
  "text" : "wp-mirror works out of the box.",
  "id" : 799303567391784960,
  "created_at" : "2016-11-17 17:29:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799303207562448896",
  "text" : "It's back in sid currently unstable I'll upgrade to sid when it is released.",
  "id" : 799303207562448896,
  "created_at" : "2016-11-17 17:28:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799301416510717953",
  "text" : "one package didn't install I'm on Jessie and they are on wheezy I have unmet dependencies.",
  "id" : 799301416510717953,
  "created_at" : "2016-11-17 17:21:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799297241580244992",
  "text" : "added the savavanh the the sources.list and mirroring Wikipedia with 150G and my Dell Deep Dive might be too large.",
  "id" : 799297241580244992,
  "created_at" : "2016-11-17 17:04:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799294858888232960",
  "text" : "That is savanah isn't is stallman.",
  "id" : 799294858888232960,
  "created_at" : "2016-11-17 16:55:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799293472540917760",
  "text" : "That is a mirror and a wiki, That is Debain and GNU.",
  "id" : 799293472540917760,
  "created_at" : "2016-11-17 16:49:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cray Inc.",
      "screen_name" : "cray_inc",
      "indices" : [ 3, 12 ],
      "id_str" : "64453378",
      "id" : 64453378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SC16",
      "indices" : [ 85, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/A9WgvEiSIH",
      "expanded_url" : "http:\/\/www.cray.com\/blog\/machine-learning-haystacks-conversing-cars-sc16\/",
      "display_url" : "cray.com\/blog\/machine-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799292373343883264",
  "text" : "RT @cray_inc: SC16 Day 3 recap: Machine Learning, Haystacks and Conversing Cars \u2026 at #SC16 https:\/\/t.co\/A9WgvEiSIH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SC16",
        "indices" : [ 71, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/A9WgvEiSIH",
        "expanded_url" : "http:\/\/www.cray.com\/blog\/machine-learning-haystacks-conversing-cars-sc16\/",
        "display_url" : "cray.com\/blog\/machine-l\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "799292327667920896",
    "text" : "SC16 Day 3 recap: Machine Learning, Haystacks and Conversing Cars \u2026 at #SC16 https:\/\/t.co\/A9WgvEiSIH",
    "id" : 799292327667920896,
    "created_at" : "2016-11-17 16:45:15 +0000",
    "user" : {
      "name" : "Cray Inc.",
      "screen_name" : "cray_inc",
      "protected" : false,
      "id_str" : "64453378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800378817\/Untitled-7_normal.gif",
      "id" : 64453378,
      "verified" : true
    }
  },
  "id" : 799292373343883264,
  "created_at" : "2016-11-17 16:45:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/4yV2oK9JA2",
      "expanded_url" : "http:\/\/www.pbs.org\/newshour\/rundown\/social-media-use-linked-low-math-reading-science-performance\/",
      "display_url" : "pbs.org\/newshour\/rundo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799290824949374976",
  "text" : "https:\/\/t.co\/4yV2oK9JA2 Yea PBS if you do the math in your head.I use the best math engine in the world.",
  "id" : 799290824949374976,
  "created_at" : "2016-11-17 16:39:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799288571802845184",
  "text" : "I would help a elementary school kid with there math but I do want my own damn kid. I'm not ending up like Sally Ride. And Wolfram bye.",
  "id" : 799288571802845184,
  "created_at" : "2016-11-17 16:30:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799286130592124929",
  "text" : "I'm in studying today doing a math review from Stanford. For my quantum course and making VM's.",
  "id" : 799286130592124929,
  "created_at" : "2016-11-17 16:20:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 85, 93 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/r0ajsMtYLs",
      "expanded_url" : "https:\/\/youtu.be\/BJysUmttrRI",
      "display_url" : "youtu.be\/BJysUmttrRI"
    } ]
  },
  "geo" : { },
  "id_str" : "799283552395427840",
  "text" : "Oasis - Put Yer Money Where Yer Mouth Is (album version) https:\/\/t.co\/r0ajsMtYLs via @YouTube",
  "id" : 799283552395427840,
  "created_at" : "2016-11-17 16:10:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechRadar India",
      "screen_name" : "TechRadarIndia",
      "indices" : [ 74, 89 ],
      "id_str" : "2549534851",
      "id" : 2549534851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/uKbeFoCpVP",
      "expanded_url" : "http:\/\/www.in.techradar.com\/news\/mobile-computing\/5-ways-PCs-are-set-to-make-a-comeback-in-2016\/articleshow\/48375580.cms",
      "display_url" : "in.techradar.com\/news\/mobile-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799276618908913664",
  "text" : "5 ways PCs are set to make a comeback in 2016 https:\/\/t.co\/uKbeFoCpVP via @TechRadarIndia",
  "id" : 799276618908913664,
  "created_at" : "2016-11-17 15:42:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 60, 68 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/3URHDQEjYc",
      "expanded_url" : "https:\/\/youtu.be\/8FbQoI8P7c4",
      "display_url" : "youtu.be\/8FbQoI8P7c4"
    } ]
  },
  "geo" : { },
  "id_str" : "799275088872931328",
  "text" : "THE THINNING - Official Trailer https:\/\/t.co\/3URHDQEjYc via @YouTube",
  "id" : 799275088872931328,
  "created_at" : "2016-11-17 15:36:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/lkzOShZBdg",
      "expanded_url" : "http:\/\/rich.st\/AfzGNiR",
      "display_url" : "rich.st\/AfzGNiR"
    } ]
  },
  "geo" : { },
  "id_str" : "799272638237446148",
  "text" : "10 Differences Between Old Money Vs. New Money - TheRichest\nhttps:\/\/t.co\/lkzOShZBdg",
  "id" : 799272638237446148,
  "created_at" : "2016-11-17 15:27:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cointelegraph",
      "screen_name" : "CoinTelegraph",
      "indices" : [ 68, 82 ],
      "id_str" : "2207129125",
      "id" : 2207129125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/TlTm1yeH6R",
      "expanded_url" : "https:\/\/cointelegraph.com\/news\/the-open-source-world-is-worth-billions",
      "display_url" : "cointelegraph.com\/news\/the-open-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799268053443903489",
  "text" : "The Open Source World Is Worth Billions https:\/\/t.co\/TlTm1yeH6R via @Cointelegraph Get it Jared.",
  "id" : 799268053443903489,
  "created_at" : "2016-11-17 15:08:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT OpenCourseWare",
      "screen_name" : "MITOCW",
      "indices" : [ 3, 10 ],
      "id_str" : "19540483",
      "id" : 19540483
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OLCAccelerate",
      "indices" : [ 49, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799264184915595264",
  "text" : "RT @MITOCW: TODAY!\nOCW Educator is presenting at #OLCAccelerate! Visit us @ Northern Hemisphere A1-A2 @ 1:30!  We'll share our resource for\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MITOCW\/status\/799240813481984000\/photo\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/I7s7A996Bl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cxd5SE-UAAAE-tJ.jpg",
        "id_str" : "799240810361257984",
        "id" : 799240810361257984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cxd5SE-UAAAE-tJ.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/I7s7A996Bl"
      } ],
      "hashtags" : [ {
        "text" : "OLCAccelerate",
        "indices" : [ 37, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "799240813481984000",
    "text" : "TODAY!\nOCW Educator is presenting at #OLCAccelerate! Visit us @ Northern Hemisphere A1-A2 @ 1:30!  We'll share our resource for educators https:\/\/t.co\/I7s7A996Bl",
    "id" : 799240813481984000,
    "created_at" : "2016-11-17 13:20:33 +0000",
    "user" : {
      "name" : "MIT OpenCourseWare",
      "screen_name" : "MITOCW",
      "protected" : false,
      "id_str" : "19540483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568117575792336896\/IAullcXh_normal.png",
      "id" : 19540483,
      "verified" : false
    }
  },
  "id" : 799264184915595264,
  "created_at" : "2016-11-17 14:53:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 3, 16 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RSMilner16",
      "indices" : [ 27, 38 ]
    }, {
      "text" : "RSMedals",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/4NgwGEQIkF",
      "expanded_url" : "http:\/\/ow.ly\/FTJ530604kQ",
      "display_url" : "ow.ly\/FTJ530604kQ"
    } ]
  },
  "geo" : { },
  "id_str" : "799262963001495552",
  "text" : "RT @royalsociety: Our free #RSMilner16 Award Lecture: In search of software perfection - 24 Nov https:\/\/t.co\/4NgwGEQIkF #RSMedals https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/royalsociety\/status\/799253396557479936\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/O1hRDYHL9H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CxeEufmXAAAAOUe.jpg",
        "id_str" : "799253393172791296",
        "id" : 799253393172791296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxeEufmXAAAAOUe.jpg",
        "sizes" : [ {
          "h" : 874,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 874,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 874,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 482
        } ],
        "display_url" : "pic.twitter.com\/O1hRDYHL9H"
      } ],
      "hashtags" : [ {
        "text" : "RSMilner16",
        "indices" : [ 9, 20 ]
      }, {
        "text" : "RSMedals",
        "indices" : [ 102, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/4NgwGEQIkF",
        "expanded_url" : "http:\/\/ow.ly\/FTJ530604kQ",
        "display_url" : "ow.ly\/FTJ530604kQ"
      } ]
    },
    "geo" : { },
    "id_str" : "799253396557479936",
    "text" : "Our free #RSMilner16 Award Lecture: In search of software perfection - 24 Nov https:\/\/t.co\/4NgwGEQIkF #RSMedals https:\/\/t.co\/O1hRDYHL9H",
    "id" : 799253396557479936,
    "created_at" : "2016-11-17 14:10:33 +0000",
    "user" : {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "protected" : false,
      "id_str" : "28567809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672098584372846592\/wxJ8nlnH_normal.jpg",
      "id" : 28567809,
      "verified" : true
    }
  },
  "id" : 799262963001495552,
  "created_at" : "2016-11-17 14:48:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "London Symphony Orch",
      "screen_name" : "londonsymphony",
      "indices" : [ 3, 18 ],
      "id_str" : "19209076",
      "id" : 19209076
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dfcc2016",
      "indices" : [ 63, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799262930952810496",
  "text" : "RT @londonsymphony: The Orchestra gets a vote during tonight's #dfcc2016 final, as they'll work with the winner for the next 2 years. Here'\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/londonsymphony\/status\/799253726556864512\/video\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/LrpAjIXuh4",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/799249726298263553\/pu\/img\/BQ71U7QGTIwWvhXk.jpg",
        "id_str" : "799249726298263553",
        "id" : 799249726298263553,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/799249726298263553\/pu\/img\/BQ71U7QGTIwWvhXk.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/LrpAjIXuh4"
      } ],
      "hashtags" : [ {
        "text" : "dfcc2016",
        "indices" : [ 43, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "799253726556864512",
    "text" : "The Orchestra gets a vote during tonight's #dfcc2016 final, as they'll work with the winner for the next 2 years. Here's a few opinions... https:\/\/t.co\/LrpAjIXuh4",
    "id" : 799253726556864512,
    "created_at" : "2016-11-17 14:11:52 +0000",
    "user" : {
      "name" : "London Symphony Orch",
      "screen_name" : "londonsymphony",
      "protected" : false,
      "id_str" : "19209076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422013452\/Lso_logo_crimson_RGB_medium_normal.jpg",
      "id" : 19209076,
      "verified" : true
    }
  },
  "id" : 799262930952810496,
  "created_at" : "2016-11-17 14:48:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "British Mensa",
      "screen_name" : "BritishMensa",
      "indices" : [ 3, 16 ],
      "id_str" : "21389945",
      "id" : 21389945
    }, {
      "name" : "The British Library",
      "screen_name" : "britishlibrary",
      "indices" : [ 21, 36 ],
      "id_str" : "21744554",
      "id" : 21744554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "otd",
      "indices" : [ 56, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799262876401864704",
  "text" : "RT @BritishMensa: RT @britishlibrary: Suez Canal opened #otd in 1869, reducing distance between Britain &amp; India by 4500 miles. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The British Library",
        "screen_name" : "britishlibrary",
        "indices" : [ 3, 18 ],
        "id_str" : "21744554",
        "id" : 21744554
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/britishlibrary\/status\/799245758696460288\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/jQJgcW4LVd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cxd9x6xUAAAL8qz.jpg",
        "id_str" : "799245755424702464",
        "id" : 799245755424702464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cxd9x6xUAAAL8qz.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1683,
          "resize" : "fit",
          "w" : 1115
        }, {
          "h" : 1683,
          "resize" : "fit",
          "w" : 1115
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 795
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 451
        } ],
        "display_url" : "pic.twitter.com\/jQJgcW4LVd"
      } ],
      "hashtags" : [ {
        "text" : "otd",
        "indices" : [ 38, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "799254371045240832",
    "text" : "RT @britishlibrary: Suez Canal opened #otd in 1869, reducing distance between Britain &amp; India by 4500 miles. https:\/\/t.co\/jQJgcW4LVd",
    "id" : 799254371045240832,
    "created_at" : "2016-11-17 14:14:26 +0000",
    "user" : {
      "name" : "British Mensa",
      "screen_name" : "BritishMensa",
      "protected" : false,
      "id_str" : "21389945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486496615838932992\/9q9rnXl__normal.jpeg",
      "id" : 21389945,
      "verified" : false
    }
  },
  "id" : 799262876401864704,
  "created_at" : "2016-11-17 14:48:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Princeton Univ Press",
      "screen_name" : "PrincetonUPress",
      "indices" : [ 3, 19 ],
      "id_str" : "20715956",
      "id" : 20715956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799262827991171072",
  "text" : "RT @PrincetonUPress: \"Welcome to the Universe\"\n\nA fun chat with Neil deGrasse Tyson, Michael A. Strauss,  &amp; J. Richard Gott  https:\/\/t.co\/u\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vimeo",
        "screen_name" : "Vimeo",
        "indices" : [ 136, 142 ],
        "id_str" : "14718218",
        "id" : 14718218
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/uizxqQbfyo",
        "expanded_url" : "https:\/\/vimeo.com\/190306104",
        "display_url" : "vimeo.com\/190306104"
      } ]
    },
    "geo" : { },
    "id_str" : "799255463468601344",
    "text" : "\"Welcome to the Universe\"\n\nA fun chat with Neil deGrasse Tyson, Michael A. Strauss,  &amp; J. Richard Gott  https:\/\/t.co\/uizxqQbfyo\nvia @Vimeo",
    "id" : 799255463468601344,
    "created_at" : "2016-11-17 14:18:46 +0000",
    "user" : {
      "name" : "Princeton Univ Press",
      "screen_name" : "PrincetonUPress",
      "protected" : false,
      "id_str" : "20715956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/803244887160274944\/XbBkRNnl_normal.jpg",
      "id" : 20715956,
      "verified" : true
    }
  },
  "id" : 799262827991171072,
  "created_at" : "2016-11-17 14:48:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799262327728050176",
  "text" : "I've  always hated the geek republican image of a guy in glasses and I'm not taking it from this administration.",
  "id" : 799262327728050176,
  "created_at" : "2016-11-17 14:46:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard Med School",
      "screen_name" : "harvardmed",
      "indices" : [ 3, 14 ],
      "id_str" : "30862829",
      "id" : 30862829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/PjrzFmBZNl",
      "expanded_url" : "http:\/\/hvrd.me\/4Ei6306eWs9",
      "display_url" : "hvrd.me\/4Ei6306eWs9"
    } ]
  },
  "geo" : { },
  "id_str" : "799261892082597888",
  "text" : "RT @harvardmed: The origin of human consciousness may lie in a newly pinpointed brain network https:\/\/t.co\/PjrzFmBZNl https:\/\/t.co\/p2HnR5vt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/harvardmed\/status\/799009326878904330\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/p2HnR5vt8Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cxamv1aUUAEsZ1I.jpg",
        "id_str" : "799009324626366465",
        "id" : 799009324626366465,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cxamv1aUUAEsZ1I.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/p2HnR5vt8Y"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/PjrzFmBZNl",
        "expanded_url" : "http:\/\/hvrd.me\/4Ei6306eWs9",
        "display_url" : "hvrd.me\/4Ei6306eWs9"
      } ]
    },
    "geo" : { },
    "id_str" : "799009326878904330",
    "text" : "The origin of human consciousness may lie in a newly pinpointed brain network https:\/\/t.co\/PjrzFmBZNl https:\/\/t.co\/p2HnR5vt8Y",
    "id" : 799009326878904330,
    "created_at" : "2016-11-16 22:00:43 +0000",
    "user" : {
      "name" : "Harvard Med School",
      "screen_name" : "harvardmed",
      "protected" : false,
      "id_str" : "30862829",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737626984990314497\/IeHkfA6C_normal.jpg",
      "id" : 30862829,
      "verified" : true
    }
  },
  "id" : 799261892082597888,
  "created_at" : "2016-11-17 14:44:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "British Mensa",
      "screen_name" : "BritishMensa",
      "indices" : [ 3, 16 ],
      "id_str" : "21389945",
      "id" : 21389945
    }, {
      "name" : "BBC Science News",
      "screen_name" : "BBCScienceNews",
      "indices" : [ 21, 36 ],
      "id_str" : "621573",
      "id" : 621573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/e8MyrI5Q33",
      "expanded_url" : "http:\/\/bbc.in\/2g1LaHn",
      "display_url" : "bbc.in\/2g1LaHn"
    } ]
  },
  "geo" : { },
  "id_str" : "799261821651787776",
  "text" : "RT @BritishMensa: RT @BBCScienceNews: 'Roundest known space object' identified https:\/\/t.co\/e8MyrI5Q33",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC Science News",
        "screen_name" : "BBCScienceNews",
        "indices" : [ 3, 18 ],
        "id_str" : "621573",
        "id" : 621573
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/e8MyrI5Q33",
        "expanded_url" : "http:\/\/bbc.in\/2g1LaHn",
        "display_url" : "bbc.in\/2g1LaHn"
      } ]
    },
    "geo" : { },
    "id_str" : "799251929226477568",
    "text" : "RT @BBCScienceNews: 'Roundest known space object' identified https:\/\/t.co\/e8MyrI5Q33",
    "id" : 799251929226477568,
    "created_at" : "2016-11-17 14:04:43 +0000",
    "user" : {
      "name" : "British Mensa",
      "screen_name" : "BritishMensa",
      "protected" : false,
      "id_str" : "21389945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486496615838932992\/9q9rnXl__normal.jpeg",
      "id" : 21389945,
      "verified" : false
    }
  },
  "id" : 799261821651787776,
  "created_at" : "2016-11-17 14:44:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/CLATBPiwx4",
      "expanded_url" : "https:\/\/www.theguardian.com\/us-news\/video\/2016\/nov\/17\/trumps-coming-the-new-social-media-challenge-video?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/us-news\/video\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799261306121572352",
  "text" : "Trump\u2019s coming! The new social media challenge \u2013 video https:\/\/t.co\/CLATBPiwx4",
  "id" : 799261306121572352,
  "created_at" : "2016-11-17 14:41:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noodle",
      "screen_name" : "NoodleEducation",
      "indices" : [ 68, 84 ],
      "id_str" : "158084514",
      "id" : 158084514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/lNbGmCALQZ",
      "expanded_url" : "https:\/\/www.noodle.com\/articles\/best-in-the-world-how-the-us-is-getting-gifted-education-wrong167",
      "display_url" : "noodle.com\/articles\/best-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799260189966868481",
  "text" : "Best in the World? How the US Is Getting Gifted Education Wrong via @NoodleEducation https:\/\/t.co\/lNbGmCALQZ",
  "id" : 799260189966868481,
  "created_at" : "2016-11-17 14:37:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/XZr4gk97ZM",
      "expanded_url" : "https:\/\/www.nagc.org\/resources-publications\/resources\/timely-topics\/stem-meeting-critical-demand-excellence",
      "display_url" : "nagc.org\/resources-publ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799260030017093632",
  "text" : "https:\/\/t.co\/XZr4gk97ZM STEM: Meeting a Critical Demand for Excellence.",
  "id" : 799260030017093632,
  "created_at" : "2016-11-17 14:36:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RobotLab",
      "screen_name" : "RobotLABInc",
      "indices" : [ 3, 15 ],
      "id_str" : "1128756116",
      "id" : 1128756116
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 36, 41 ]
    }, {
      "text" : "NAGC16",
      "indices" : [ 119, 126 ]
    }, {
      "text" : "Gifted",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/VRoeNAPOZh",
      "expanded_url" : "http:\/\/hubs.ly\/H05398M0",
      "display_url" : "hubs.ly\/H05398M0"
    } ]
  },
  "geo" : { },
  "id_str" : "799258429126770693",
  "text" : "RT @RobotLABInc: America's untapped #STEM potential | National Association for Gifted Children https:\/\/t.co\/VRoeNAPOZh #NAGC16 #Gifted by @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hubspot.com\/\" rel=\"nofollow\"\u003EHubSpot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NAGC",
        "screen_name" : "NAGCGIFTED",
        "indices" : [ 121, 132 ],
        "id_str" : "52407188",
        "id" : 52407188
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RobotLABInc\/status\/794240012372082688\/photo\/1",
        "indices" : [ 133, 156 ],
        "url" : "https:\/\/t.co\/K3bKo673Dy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwW1FOPWQAAYWgz.png",
        "id_str" : "794240010627203072",
        "id" : 794240010627203072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwW1FOPWQAAYWgz.png",
        "sizes" : [ {
          "h" : 84,
          "resize" : "fit",
          "w" : 310
        }, {
          "h" : 84,
          "resize" : "crop",
          "w" : 84
        }, {
          "h" : 84,
          "resize" : "fit",
          "w" : 310
        }, {
          "h" : 84,
          "resize" : "fit",
          "w" : 310
        }, {
          "h" : 84,
          "resize" : "fit",
          "w" : 310
        } ],
        "display_url" : "pic.twitter.com\/K3bKo673Dy"
      } ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 19, 24 ]
      }, {
        "text" : "NAGC16",
        "indices" : [ 102, 109 ]
      }, {
        "text" : "Gifted",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/VRoeNAPOZh",
        "expanded_url" : "http:\/\/hubs.ly\/H05398M0",
        "display_url" : "hubs.ly\/H05398M0"
      } ]
    },
    "geo" : { },
    "id_str" : "794240012372082688",
    "text" : "America's untapped #STEM potential | National Association for Gifted Children https:\/\/t.co\/VRoeNAPOZh #NAGC16 #Gifted by @NAGCGIFTED https:\/\/t.co\/K3bKo673Dy",
    "id" : 794240012372082688,
    "created_at" : "2016-11-03 18:09:09 +0000",
    "user" : {
      "name" : "RobotLab",
      "screen_name" : "RobotLABInc",
      "protected" : false,
      "id_str" : "1128756116",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691751306021752832\/1gTV-K6m_normal.jpg",
      "id" : 1128756116,
      "verified" : false
    }
  },
  "id" : 799258429126770693,
  "created_at" : "2016-11-17 14:30:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nature News&Comment",
      "screen_name" : "NatureNews",
      "indices" : [ 3, 14 ],
      "id_str" : "15862891",
      "id" : 15862891
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CRISPR",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799251346331471872",
  "text" : "RT @NatureNews: Chinese trial of #CRISPR modified cells in a cancer patient could spark a biomedical duel with the United States https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NatureNews\/status\/799251147726782464\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/jWxUCJg5zP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CxeCrlpWQAETxCF.jpg",
        "id_str" : "799251144233074689",
        "id" : 799251144233074689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxeCrlpWQAETxCF.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1600
        } ],
        "display_url" : "pic.twitter.com\/jWxUCJg5zP"
      } ],
      "hashtags" : [ {
        "text" : "CRISPR",
        "indices" : [ 17, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/si3dvnC8HY",
        "expanded_url" : "http:\/\/go.nature.com\/2fVNlMv",
        "display_url" : "go.nature.com\/2fVNlMv"
      } ]
    },
    "geo" : { },
    "id_str" : "799251147726782464",
    "text" : "Chinese trial of #CRISPR modified cells in a cancer patient could spark a biomedical duel with the United States https:\/\/t.co\/si3dvnC8HY https:\/\/t.co\/jWxUCJg5zP",
    "id" : 799251147726782464,
    "created_at" : "2016-11-17 14:01:37 +0000",
    "user" : {
      "name" : "Nature News&Comment",
      "screen_name" : "NatureNews",
      "protected" : false,
      "id_str" : "15862891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1158019862\/nature-header.ed_normal.png",
      "id" : 15862891,
      "verified" : true
    }
  },
  "id" : 799251346331471872,
  "created_at" : "2016-11-17 14:02:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799251271823691776",
  "text" : "Trump your old money big houses big planes big America I like living small the environment just can't sustain a Trump presidency",
  "id" : 799251271823691776,
  "created_at" : "2016-11-17 14:02:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799242609768206336",
  "text" : "I'm competing against you Jarred for my right is the gene pool I'm not threatening you. Bring all you got for four years.",
  "id" : 799242609768206336,
  "created_at" : "2016-11-17 13:27:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBC Bay Area",
      "screen_name" : "nbcbayarea",
      "indices" : [ 128, 139 ],
      "id_str" : "20097362",
      "id" : 20097362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/YA1mjH9XQ9",
      "expanded_url" : "http:\/\/www.nbcbayarea.com\/news\/local\/Protests-Erupt-in-Bay-Area-After-Trumps-Presidential-Victory-400509211.html",
      "display_url" : "nbcbayarea.com\/news\/local\/Pro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799240742627471361",
  "text" : "'Not Our President': Protests Erupt Across the Bay Area After Trump's Stunning Presidential Victory https:\/\/t.co\/YA1mjH9XQ9 via @nbcbayarea",
  "id" : 799240742627471361,
  "created_at" : "2016-11-17 13:20:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC7 News",
      "screen_name" : "abc7newsbayarea",
      "indices" : [ 80, 96 ],
      "id_str" : "18993395",
      "id" : 18993395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/ARZg2BRBdZ",
      "expanded_url" : "http:\/\/abc7news.com\/1604336\/",
      "display_url" : "abc7news.com\/1604336\/"
    } ]
  },
  "geo" : { },
  "id_str" : "799240522464305152",
  "text" : "Anti-Trump protesters fill streets of San Francisco https:\/\/t.co\/ARZg2BRBdZ via @abc7newsbayarea",
  "id" : 799240522464305152,
  "created_at" : "2016-11-17 13:19:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 82, 90 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/xwtV6aVW8D",
      "expanded_url" : "https:\/\/youtu.be\/uWgBHomh7fQ",
      "display_url" : "youtu.be\/uWgBHomh7fQ"
    } ]
  },
  "geo" : { },
  "id_str" : "799238685233451008",
  "text" : "Street Sweeper Social Club - The Oath (Album version) https:\/\/t.co\/xwtV6aVW8D via @YouTube",
  "id" : 799238685233451008,
  "created_at" : "2016-11-17 13:12:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799238101038235648",
  "text" : "I'm pumping iron Jared wanna take it to the streets?",
  "id" : 799238101038235648,
  "created_at" : "2016-11-17 13:09:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799233161787936768",
  "text" : "That is nanotechnology isn't is that medicine isn't is Jared. I'm not telling you what software I have.",
  "id" : 799233161787936768,
  "created_at" : "2016-11-17 12:50:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799231747200270336",
  "text" : "I'm parsing that HTML on my own in C# Jared not putting my bookmarks into Pocket I might use Onenote.",
  "id" : 799231747200270336,
  "created_at" : "2016-11-17 12:44:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/J9BVRc9dvL",
      "expanded_url" : "http:\/\/people.idsia.ch\/~juergen\/zuse.html",
      "display_url" : "people.idsia.ch\/~juergen\/zuse.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799230831747301376",
  "text" : "https:\/\/t.co\/J9BVRc9dvL This is Zuse isn't isn't Jared you Jew all of that technology is German. Quantum is German isn't is Jared.",
  "id" : 799230831747301376,
  "created_at" : "2016-11-17 12:40:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799223803385643008",
  "text" : "Creating a web page out of my 20 years worth of bookmarks Jared.",
  "id" : 799223803385643008,
  "created_at" : "2016-11-17 12:12:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799220380036644864",
  "text" : "I'm not telling you about those bots either Jared.",
  "id" : 799220380036644864,
  "created_at" : "2016-11-17 11:59:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/NQEHgX5C6K",
      "expanded_url" : "http:\/\/observer.com\/",
      "display_url" : "observer.com"
    } ]
  },
  "geo" : { },
  "id_str" : "799218245303697408",
  "text" : "https:\/\/t.co\/NQEHgX5C6K Know I'm just working on my news news Jared.",
  "id" : 799218245303697408,
  "created_at" : "2016-11-17 11:50:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Berlin Philharmonic",
      "screen_name" : "BerlinPhil",
      "indices" : [ 3, 14 ],
      "id_str" : "43298395",
      "id" : 43298395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/tzfa3x3nJ8",
      "expanded_url" : "http:\/\/blog.berliner-philharmoniker.de\/",
      "display_url" : "blog.berliner-philharmoniker.de"
    } ]
  },
  "geo" : { },
  "id_str" : "799218113988493313",
  "text" : "RT @BerlinPhil: Markus Weidmann, bassoon, caught spectacular views of the Niagara Falls and more.\nFollow our tour @ https:\/\/t.co\/tzfa3x3nJ8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BerlinPhil\/status\/799217884912320512\/photo\/1",
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/rWXXn9YsuB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CxdkZnlWEAA0W73.jpg",
        "id_str" : "799217850166677504",
        "id" : 799217850166677504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxdkZnlWEAA0W73.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 853,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 853,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/rWXXn9YsuB"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/BerlinPhil\/status\/799217884912320512\/photo\/1",
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/rWXXn9YsuB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CxdkaTzW8AQOoc-.jpg",
        "id_str" : "799217862036615172",
        "id" : 799217862036615172,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxdkaTzW8AQOoc-.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 853,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 853,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/rWXXn9YsuB"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/tzfa3x3nJ8",
        "expanded_url" : "http:\/\/blog.berliner-philharmoniker.de\/",
        "display_url" : "blog.berliner-philharmoniker.de"
      } ]
    },
    "geo" : { },
    "id_str" : "799217884912320512",
    "text" : "Markus Weidmann, bassoon, caught spectacular views of the Niagara Falls and more.\nFollow our tour @ https:\/\/t.co\/tzfa3x3nJ8 https:\/\/t.co\/rWXXn9YsuB",
    "id" : 799217884912320512,
    "created_at" : "2016-11-17 11:49:27 +0000",
    "user" : {
      "name" : "Berlin Philharmonic",
      "screen_name" : "BerlinPhil",
      "protected" : false,
      "id_str" : "43298395",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459001538065600512\/FOttw8Gb_normal.png",
      "id" : 43298395,
      "verified" : true
    }
  },
  "id" : 799218113988493313,
  "created_at" : "2016-11-17 11:50:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/RWgyG0IV7c",
      "expanded_url" : "http:\/\/www.inquisitr.com\/3703433\/michael-moore-calls-for-president-elect-donald-trumps-immediate-impeachment-americans-prepare-to-impeach-trump\/",
      "display_url" : "inquisitr.com\/3703433\/michae\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799216945409232896",
  "text" : "Michael Moore Calls For President-Elect Donald Trump\u2019s Immediate Impeachment: \u2018Americans Prepare To Impeach Trump\u2019 https:\/\/t.co\/RWgyG0IV7c",
  "id" : 799216945409232896,
  "created_at" : "2016-11-17 11:45:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/pBhs2IyDlD",
      "expanded_url" : "http:\/\/www.truthrevolt.org\/news\/michael-moores-do-list-take-over-occupy-impeach-trump",
      "display_url" : "truthrevolt.org\/news\/michael-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799216647403958272",
  "text" : "https:\/\/t.co\/pBhs2IyDlD Impeach Trump.",
  "id" : 799216647403958272,
  "created_at" : "2016-11-17 11:44:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/ulEqGrGsP3",
      "expanded_url" : "http:\/\/townhall.com\/tipsheet\/erikahaas\/2016\/11\/12\/lichtman-predicts-trump-will-be-impeached-n2244775",
      "display_url" : "townhall.com\/tipsheet\/erika\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799216207660457984",
  "text" : "The Professor Who Foresaw Trump\u2019s Win Has Made Another Big Prediction https:\/\/t.co\/ulEqGrGsP3",
  "id" : 799216207660457984,
  "created_at" : "2016-11-17 11:42:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/hzajSHRqWN",
      "expanded_url" : "http:\/\/www.vanityfair.com\/news\/2016\/11\/will-trump-be-impeached",
      "display_url" : "vanityfair.com\/news\/2016\/11\/w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799215919121711104",
  "text" : "Will Trump Be Impeached? https:\/\/t.co\/hzajSHRqWN",
  "id" : 799215919121711104,
  "created_at" : "2016-11-17 11:41:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 0, 6 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798655985858408448",
  "in_reply_to_user_id" : 1536791610,
  "text" : "@POTUS Mr. President I cannot find a lawyer in my area they all have a conflict of interest against me. Please help. All it is business law.",
  "id" : 798655985858408448,
  "created_at" : "2016-11-15 22:36:39 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/zapier.com\/\" rel=\"nofollow\"\u003EZapier.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797457557333872640",
  "text" : "New commits to my Operating System Engieering repo.",
  "id" : 797457557333872640,
  "created_at" : "2016-11-12 15:14:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/zapier.com\/\" rel=\"nofollow\"\u003EZapier.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797109345867759616",
  "text" : "New commits to my Operating System Engieering repo.",
  "id" : 797109345867759616,
  "created_at" : "2016-11-11 16:10:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/zapier.com\/\" rel=\"nofollow\"\u003EZapier.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797108879968636928",
  "text" : "Commitied new commits to my Operating System Engieering repo.",
  "id" : 797108879968636928,
  "created_at" : "2016-11-11 16:09:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796815801823232000",
  "text" : "I've known about that law document you see since 2013 just either nobody wanted to help or money meant nothing to me without her.",
  "id" : 796815801823232000,
  "created_at" : "2016-11-10 20:44:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ETSU",
      "screen_name" : "etsu",
      "indices" : [ 0, 5 ],
      "id_str" : "39405688",
      "id" : 39405688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796796698597163009",
  "in_reply_to_user_id" : 39405688,
  "text" : "@etsu ETSU who are you to me I am Jonathan Moore give me some credit you aren't even nationally ranked I've had it with yourfemale students.",
  "id" : 796796698597163009,
  "created_at" : "2016-11-10 19:28:31 +0000",
  "in_reply_to_screen_name" : "etsu",
  "in_reply_to_user_id_str" : "39405688",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796560929001504769",
  "text" : "I am famous aren't I? And you will say I am too won't you?",
  "id" : 796560929001504769,
  "created_at" : "2016-11-10 03:51:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 0, 16 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/tNZmhuCZ0w",
      "expanded_url" : "http:\/\/www.groom.com\/media\/publication\/1260_Paying_Employee_Benefit_Plan_Expenses.pdf",
      "display_url" : "groom.com\/media\/publicat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "796485758144102405",
  "in_reply_to_user_id" : 25073877,
  "text" : "@realDonaldTrump https:\/\/t.co\/tNZmhuCZ0w Paying with plan assets. Tell them when you are is office if it works. Congrats.",
  "id" : 796485758144102405,
  "created_at" : "2016-11-09 22:52:57 +0000",
  "in_reply_to_screen_name" : "realDonaldTrump",
  "in_reply_to_user_id_str" : "25073877",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796170004240732160",
  "text" : "I am one click away from depositing me equity again on windows 10 into the bank but nobody will let me.",
  "id" : 796170004240732160,
  "created_at" : "2016-11-09 01:58:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796168085296283656",
  "text" : "How high do you want to go Bill Gates?",
  "id" : 796168085296283656,
  "created_at" : "2016-11-09 01:50:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796144069919576065",
  "text" : "See what I had to go through to get a hot girl break the news about stabilizing the higgs filed with Z bosons.",
  "id" : 796144069919576065,
  "created_at" : "2016-11-09 00:15:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 28, 36 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/mIF5Hdlo8q",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=4oPXtdA8o3Y&sns=tw",
      "display_url" : "youtube.com\/watch?v=4oPXtd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "795741301555732482",
  "text" : "https:\/\/t.co\/mIF5Hdlo8q via @youtube",
  "id" : 795741301555732482,
  "created_at" : "2016-11-07 21:34:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795739917255053312",
  "text" : "Show a little admiration for your peers I do.",
  "id" : 795739917255053312,
  "created_at" : "2016-11-07 21:29:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795719971888369664",
  "text" : "Bill Clinton throw your bass around like in 92'",
  "id" : 795719971888369664,
  "created_at" : "2016-11-07 20:09:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795714857698033664",
  "text" : "I'm not teaching anymore. No pussy no class.",
  "id" : 795714857698033664,
  "created_at" : "2016-11-07 19:49:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/795683273334784000\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/t1KNP2g4Do",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwrVuFLWgAA92KX.jpg",
      "id_str" : "795683271824801792",
      "id" : 795683271824801792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwrVuFLWgAA92KX.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/t1KNP2g4Do"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795683273334784000",
  "text" : "https:\/\/t.co\/t1KNP2g4Do",
  "id" : 795683273334784000,
  "created_at" : "2016-11-07 17:44:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/795642350441811969\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/XWHf9c3TM6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwqwgCNXEAAEwHs.jpg",
      "id_str" : "795642348579524608",
      "id" : 795642348579524608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwqwgCNXEAAEwHs.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/XWHf9c3TM6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795642350441811969",
  "text" : "https:\/\/t.co\/XWHf9c3TM6",
  "id" : 795642350441811969,
  "created_at" : "2016-11-07 15:01:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/795636924224573440\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/YWcW4O1sKe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwqrkAcXUAAhveB.jpg",
      "id_str" : "795636919266922496",
      "id" : 795636919266922496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwqrkAcXUAAhveB.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/YWcW4O1sKe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795636924224573440",
  "text" : "https:\/\/t.co\/YWcW4O1sKe",
  "id" : 795636924224573440,
  "created_at" : "2016-11-07 14:39:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/795633083156406273\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Ro65deCCgq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwqoEO3W8AAWM3G.jpg",
      "id_str" : "795633074847543296",
      "id" : 795633074847543296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwqoEO3W8AAWM3G.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/Ro65deCCgq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795633083156406273",
  "text" : "https:\/\/t.co\/Ro65deCCgq",
  "id" : 795633083156406273,
  "created_at" : "2016-11-07 14:24:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/vwNptZWQte",
      "expanded_url" : "https:\/\/openvpn.net\/",
      "display_url" : "openvpn.net"
    } ]
  },
  "geo" : { },
  "id_str" : "795630244657033216",
  "text" : "https:\/\/t.co\/vwNptZWQte Free Internet. Stop playing players.",
  "id" : 795630244657033216,
  "created_at" : "2016-11-07 14:13:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/zt3yIIDCBf",
      "expanded_url" : "https:\/\/www.openshift.com\/",
      "display_url" : "openshift.com"
    } ]
  },
  "geo" : { },
  "id_str" : "795627892570877953",
  "text" : "https:\/\/t.co\/zt3yIIDCBf I forgot about my opeshift account I would but it's not Debian.",
  "id" : 795627892570877953,
  "created_at" : "2016-11-07 14:04:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/RQSedUlWG2",
      "expanded_url" : "https:\/\/azure.microsoft.com\/en-us\/develop\/nodejs\/",
      "display_url" : "azure.microsoft.com\/en-us\/develop\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "795626458613972993",
  "text" : "https:\/\/t.co\/RQSedUlWG2  Maybe if domain and site are free.",
  "id" : 795626458613972993,
  "created_at" : "2016-11-07 13:58:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/0nlfoat607",
      "expanded_url" : "https:\/\/jaxbot.me\/articles\/benchmarks_nodejs_vs_go_vs_php_3_14_2013",
      "display_url" : "jaxbot.me\/articles\/bench\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "795625200981340160",
  "text" : "https:\/\/t.co\/0nlfoat607 Node vs PHP vs Go.",
  "id" : 795625200981340160,
  "created_at" : "2016-11-07 13:53:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "InfoWorld",
      "screen_name" : "infoworld",
      "indices" : [ 85, 95 ],
      "id_str" : "15426758",
      "id" : 15426758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/3EwOweUaiy",
      "expanded_url" : "http:\/\/www.infoworld.com\/article\/2866712\/php\/php-vs-node-js-an-epic-battle-for-developer-mind-share.html",
      "display_url" : "infoworld.com\/article\/286671\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "795624243920826368",
  "text" : "PHP vs. Node.js: An epic battle for developer mind share https:\/\/t.co\/3EwOweUaiy via @infoworld",
  "id" : 795624243920826368,
  "created_at" : "2016-11-07 13:49:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fortune",
      "screen_name" : "FortuneMagazine",
      "indices" : [ 72, 88 ],
      "id_str" : "25053299",
      "id" : 25053299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/AUWsE6Nots",
      "expanded_url" : "http:\/\/for.tn\/1I9yvYv?xid=for_tw_sh",
      "display_url" : "for.tn\/1I9yvYv?xid=fo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "795615473077485568",
  "text" : "GitHub raises $250 million in new funding, now valued at $2 billion via @FortuneMagazine https:\/\/t.co\/AUWsE6Nots",
  "id" : 795615473077485568,
  "created_at" : "2016-11-07 13:14:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vrushali dandawate",
      "screen_name" : "vrushalisainath",
      "indices" : [ 3, 19 ],
      "id_str" : "142252251",
      "id" : 142252251
    }, {
      "name" : "DOAJ",
      "screen_name" : "DOAJplus",
      "indices" : [ 21, 30 ],
      "id_str" : "1017429942",
      "id" : 1017429942
    }, {
      "name" : "INASP",
      "screen_name" : "INASPinfo",
      "indices" : [ 31, 41 ],
      "id_str" : "404710459",
      "id" : 404710459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/wukOnPLbeG",
      "expanded_url" : "http:\/\/www.slideshare.net\/openaccessindia\/know-about-doaj-67615921",
      "display_url" : "slideshare.net\/openaccessindi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "795336690202267650",
  "text" : "RT @vrushalisainath: @DOAJplus @INASPinfo Presentation on DOAJ  \nhttps:\/\/t.co\/wukOnPLbeG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DOAJ",
        "screen_name" : "DOAJplus",
        "indices" : [ 0, 9 ],
        "id_str" : "1017429942",
        "id" : 1017429942
      }, {
        "name" : "INASP",
        "screen_name" : "INASPinfo",
        "indices" : [ 10, 20 ],
        "id_str" : "404710459",
        "id" : 404710459
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/wukOnPLbeG",
        "expanded_url" : "http:\/\/www.slideshare.net\/openaccessindia\/know-about-doaj-67615921",
        "display_url" : "slideshare.net\/openaccessindi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "791603520352858112",
    "in_reply_to_user_id" : 1017429942,
    "text" : "@DOAJplus @INASPinfo Presentation on DOAJ  \nhttps:\/\/t.co\/wukOnPLbeG",
    "id" : 791603520352858112,
    "created_at" : "2016-10-27 11:32:41 +0000",
    "in_reply_to_screen_name" : "DOAJplus",
    "in_reply_to_user_id_str" : "1017429942",
    "user" : {
      "name" : "vrushali dandawate",
      "screen_name" : "vrushalisainath",
      "protected" : false,
      "id_str" : "142252251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697028727562072067\/5GgDzluA_normal.jpg",
      "id" : 142252251,
      "verified" : false
    }
  },
  "id" : 795336690202267650,
  "created_at" : "2016-11-06 18:46:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 0, 6 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794941108157616128",
  "in_reply_to_user_id" : 1536791610,
  "text" : "@POTUS It has been just jealous men and egotistical women that won't submit keeping me from a relationship for 20 years. Mr. President",
  "id" : 794941108157616128,
  "created_at" : "2016-11-05 16:35:04 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amin Kadah",
      "screen_name" : "Aminkadah",
      "indices" : [ 0, 10 ],
      "id_str" : "415211659",
      "id" : 415211659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/7XLHoo0SmU",
      "expanded_url" : "https:\/\/github.com\/jdm7dv",
      "display_url" : "github.com\/jdm7dv"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/HxVK7SYn84",
      "expanded_url" : "http:\/\/www.jonathanmoore.net",
      "display_url" : "jonathanmoore.net"
    } ]
  },
  "geo" : { },
  "id_str" : "794928208634384384",
  "in_reply_to_user_id" : 415211659,
  "text" : "@Aminkadah https:\/\/t.co\/7XLHoo0SmU https:\/\/t.co\/HxVK7SYn84",
  "id" : 794928208634384384,
  "created_at" : "2016-11-05 15:43:48 +0000",
  "in_reply_to_screen_name" : "Aminkadah",
  "in_reply_to_user_id_str" : "415211659",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/QRz4Wfd7E7",
      "expanded_url" : "https:\/\/www.microsoft.com\/en-us\/sam\/",
      "display_url" : "microsoft.com\/en-us\/sam\/"
    } ]
  },
  "geo" : { },
  "id_str" : "794620454111678464",
  "text" : "https:\/\/t.co\/QRz4Wfd7E7 Microsoft Software Asset Management.",
  "id" : 794620454111678464,
  "created_at" : "2016-11-04 19:20:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/PJ7xIKP3Vo",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "794619297565933569",
  "text" : "RT @POTUS: It's pretty simple: Find a plan, get covered, earn some peace of mind. Start today: https:\/\/t.co\/PJ7xIKP3Vo https:\/\/t.co\/ZBQdNz8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/794322003754790913\/video\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/ZBQdNz8s80",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwX_GEnUkAEyLS6.jpg",
        "id_str" : "794299143942344704",
        "id" : 794299143942344704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwX_GEnUkAEyLS6.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 668,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 379,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 798,
          "resize" : "fit",
          "w" : 1433
        } ],
        "display_url" : "pic.twitter.com\/ZBQdNz8s80"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/PJ7xIKP3Vo",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "794322003754790913",
    "text" : "It's pretty simple: Find a plan, get covered, earn some peace of mind. Start today: https:\/\/t.co\/PJ7xIKP3Vo https:\/\/t.co\/ZBQdNz8s80",
    "id" : 794322003754790913,
    "created_at" : "2016-11-03 23:34:58 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 794619297565933569,
  "created_at" : "2016-11-04 19:16:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/tNZmhuCZ0w",
      "expanded_url" : "http:\/\/www.groom.com\/media\/publication\/1260_Paying_Employee_Benefit_Plan_Expenses.pdf",
      "display_url" : "groom.com\/media\/publicat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "794618976886288384",
  "text" : "https:\/\/t.co\/tNZmhuCZ0w Paying with plan assets.",
  "id" : 794618976886288384,
  "created_at" : "2016-11-04 19:15:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 0, 6 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794598596066889728",
  "in_reply_to_user_id" : 1536791610,
  "text" : "@POTUS Nobody confronts me to my face. They do just network around me and make me hear voices to think I'm crazy.",
  "id" : 794598596066889728,
  "created_at" : "2016-11-04 17:54:02 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBM Watson",
      "screen_name" : "IBMWatson",
      "indices" : [ 3, 13 ],
      "id_str" : "29735775",
      "id" : 29735775
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cognitive",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/pxBWvzakhO",
      "expanded_url" : "http:\/\/ibm.co\/2fk7Sw4",
      "display_url" : "ibm.co\/2fk7Sw4"
    } ]
  },
  "geo" : { },
  "id_str" : "794571025090486272",
  "text" : "RT @IBMWatson: How to test a #cognitive system with natural language processing unit tests. Part 4 of 7: https:\/\/t.co\/pxBWvzakhO via @andre\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew R Freed",
        "screen_name" : "andrewrfreed",
        "indices" : [ 118, 131 ],
        "id_str" : "59225033",
        "id" : 59225033
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IBMWatson\/status\/794570912423034880\/photo\/1",
        "indices" : [ 132, 155 ],
        "url" : "https:\/\/t.co\/HHBEpHOxtG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwbiAbcUUAAO-gq.jpg",
        "id_str" : "794570881271877632",
        "id" : 794570881271877632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwbiAbcUUAAO-gq.jpg",
        "sizes" : [ {
          "h" : 374,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 830
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 830
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 830
        } ],
        "display_url" : "pic.twitter.com\/HHBEpHOxtG"
      } ],
      "hashtags" : [ {
        "text" : "cognitive",
        "indices" : [ 14, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/pxBWvzakhO",
        "expanded_url" : "http:\/\/ibm.co\/2fk7Sw4",
        "display_url" : "ibm.co\/2fk7Sw4"
      } ]
    },
    "geo" : { },
    "id_str" : "794570912423034880",
    "text" : "How to test a #cognitive system with natural language processing unit tests. Part 4 of 7: https:\/\/t.co\/pxBWvzakhO via @andrewrfreed https:\/\/t.co\/HHBEpHOxtG",
    "id" : 794570912423034880,
    "created_at" : "2016-11-04 16:04:02 +0000",
    "user" : {
      "name" : "IBM Watson",
      "screen_name" : "IBMWatson",
      "protected" : false,
      "id_str" : "29735775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799709755623309312\/VieAIRsg_normal.jpg",
      "id" : 29735775,
      "verified" : true
    }
  },
  "id" : 794571025090486272,
  "created_at" : "2016-11-04 16:04:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 0, 6 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794563925555740673",
  "in_reply_to_user_id" : 1536791610,
  "text" : "@POTUS All I want it to be incorporated.",
  "id" : 794563925555740673,
  "created_at" : "2016-11-04 15:36:16 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 0, 6 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794563880882151424",
  "in_reply_to_user_id" : 1536791610,
  "text" : "@POTUS I can't find a lawyer in SWVA to help me they all shun me like the time I called 911 and nobody even showed.",
  "id" : 794563880882151424,
  "created_at" : "2016-11-04 15:36:06 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 0, 6 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794541755777609734",
  "in_reply_to_user_id" : 1536791610,
  "text" : "@POTUS All I wanted was a educated good looking wife POTUS. After all I've accomplished. You have let me down in thatregardMaybe Hilarywon't",
  "id" : 794541755777609734,
  "created_at" : "2016-11-04 14:08:11 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/FMdSfh99To",
      "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/nov\/02\/big-business-surveillance-admiral-insurance-facebook?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "793796998327570432",
  "text" : "Social media has us under surveillance \u2013 big business is the new Big Brother | Jonathan Freedland https:\/\/t.co\/FMdSfh99To",
  "id" : 793796998327570432,
  "created_at" : "2016-11-02 12:48:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]