Grailbird.data.tweets_2014_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Moore",
      "screen_name" : "Moore",
      "indices" : [ 0, 6 ],
      "id_str" : "9632752",
      "id" : 9632752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "550370915058733057",
  "in_reply_to_user_id" : 9632752,
  "text" : "@Moore I want your domain. I passed my Mensa test. Now",
  "id" : 550370915058733057,
  "created_at" : "2014-12-31 19:20:26 +0000",
  "in_reply_to_screen_name" : "Moore",
  "in_reply_to_user_id_str" : "9632752",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "indices" : [ 3, 17 ],
      "id_str" : "34554134",
      "id" : 34554134
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SETIInstitute\/status\/546440204316598272\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/Hk3oOfv8JP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5VYeGQIMAAmiS8.jpg",
      "id_str" : "546440203892961280",
      "id" : 546440203892961280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5VYeGQIMAAmiS8.jpg",
      "sizes" : [ {
        "h" : 673,
        "resize" : "fit",
        "w" : 673
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 673,
        "resize" : "fit",
        "w" : 673
      } ],
      "display_url" : "pic.twitter.com\/Hk3oOfv8JP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/4AVIruHo1Y",
      "expanded_url" : "http:\/\/buff.ly\/1APywhb",
      "display_url" : "buff.ly\/1APywhb"
    } ]
  },
  "geo" : { },
  "id_str" : "546440427944288257",
  "text" : "RT @SETIInstitute: Earth From Space: 15 Amazing Things in 15 Years: http:\/\/t.co\/4AVIruHo1Y http:\/\/t.co\/Hk3oOfv8JP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SETIInstitute\/status\/546440204316598272\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/Hk3oOfv8JP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B5VYeGQIMAAmiS8.jpg",
        "id_str" : "546440203892961280",
        "id" : 546440203892961280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5VYeGQIMAAmiS8.jpg",
        "sizes" : [ {
          "h" : 673,
          "resize" : "fit",
          "w" : 673
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 673,
          "resize" : "fit",
          "w" : 673
        } ],
        "display_url" : "pic.twitter.com\/Hk3oOfv8JP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/4AVIruHo1Y",
        "expanded_url" : "http:\/\/buff.ly\/1APywhb",
        "display_url" : "buff.ly\/1APywhb"
      } ]
    },
    "geo" : { },
    "id_str" : "546440204316598272",
    "text" : "Earth From Space: 15 Amazing Things in 15 Years: http:\/\/t.co\/4AVIruHo1Y http:\/\/t.co\/Hk3oOfv8JP",
    "id" : 546440204316598272,
    "created_at" : "2014-12-20 23:01:11 +0000",
    "user" : {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "protected" : false,
      "id_str" : "34554134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758705567556743168\/TGjZ9Uwf_normal.jpg",
      "id" : 34554134,
      "verified" : true
    }
  },
  "id" : 546440427944288257,
  "created_at" : "2014-12-20 23:02:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]