Grailbird.data.tweets_2016_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/Dsxe0AUiRN",
      "expanded_url" : "https:\/\/www.ncbi.nlm.nih.gov\/pubmed\/3493534",
      "display_url" : "ncbi.nlm.nih.gov\/pubmed\/3493534"
    } ]
  },
  "geo" : { },
  "id_str" : "781992496519847936",
  "text" : "Disease competition as a factor in ecological studies of mortality: the case of urban centers. - PubMed - NCBI https:\/\/t.co\/Dsxe0AUiRN",
  "id" : 781992496519847936,
  "created_at" : "2016-09-30 23:01:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/bnohBFFh5T",
      "expanded_url" : "http:\/\/fw.to\/6P10gCk",
      "display_url" : "fw.to\/6P10gCk"
    } ]
  },
  "geo" : { },
  "id_str" : "781987273978081280",
  "text" : "Introducing Intel\u00AE Optane\u2122 Technology \u2013 Bringing 3D XPoint\u2122 Memory to Storage and Memory Products https:\/\/t.co\/bnohBFFh5T",
  "id" : 781987273978081280,
  "created_at" : "2016-09-30 22:41:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Beast",
      "screen_name" : "thedailybeast",
      "indices" : [ 67, 81 ],
      "id_str" : "16012783",
      "id" : 16012783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/OtTG0DAia2",
      "expanded_url" : "http:\/\/thebea.st\/1xWF7t0",
      "display_url" : "thebea.st\/1xWF7t0"
    } ]
  },
  "geo" : { },
  "id_str" : "781981411502948352",
  "text" : "Why It's Time to Legalize Prostitution https:\/\/t.co\/OtTG0DAia2 via @thedailybeast",
  "id" : 781981411502948352,
  "created_at" : "2016-09-30 22:17:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 104, 112 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/nVf7QnHNQH",
      "expanded_url" : "https:\/\/youtu.be\/Yvs7f4UaKLo",
      "display_url" : "youtu.be\/Yvs7f4UaKLo"
    } ]
  },
  "geo" : { },
  "id_str" : "781966098321276929",
  "text" : "The last job on Earth: imagining a fully automated world | Guardian Anim... https:\/\/t.co\/nVf7QnHNQH via @YouTube",
  "id" : 781966098321276929,
  "created_at" : "2016-09-30 21:17:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/pXrEazB7Eo",
      "expanded_url" : "http:\/\/nation.foxnews.com\/economy\/2012\/04\/24\/jobless-underemployed-and-deep-debt-welcome-your-future-class-2012",
      "display_url" : "nation.foxnews.com\/economy\/2012\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781965592865738752",
  "text" : "Jobless, Underemployed and Deep in Debt ... Welcome to Your Future, Class of 2012 |  https:\/\/t.co\/pXrEazB7Eo I am just overqualified.",
  "id" : 781965592865738752,
  "created_at" : "2016-09-30 21:15:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Health Care Blog",
      "screen_name" : "THCBstaff",
      "indices" : [ 120, 130 ],
      "id_str" : "18248403",
      "id" : 18248403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/tpA4OZAWYE",
      "expanded_url" : "http:\/\/thehealthcareblog.com\/blog\/2015\/06\/23\/is-natural-language-processing-the-digital-breakthrough-weve-been-waiting-for\/",
      "display_url" : "thehealthcareblog.com\/blog\/2015\/06\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781964279486570496",
  "text" : "The Digital Doctor: Is Natural Language Processing the Breakthrough We\u2019ve Been Waiting For? https:\/\/t.co\/tpA4OZAWYE via @THCBstaff",
  "id" : 781964279486570496,
  "created_at" : "2016-09-30 21:09:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 63, 70 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/2QwDw5FmfK",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/georgeleef\/2013\/10\/29\/will-online-education-render-traditional-college-obsolete\/#2fe3ab212497",
      "display_url" : "forbes.com\/sites\/georgele\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781956935251787780",
  "text" : "Will Online Education Render Traditional College Obsolete? via @forbes https:\/\/t.co\/2QwDw5FmfK",
  "id" : 781956935251787780,
  "created_at" : "2016-09-30 20:40:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETSU",
      "indices" : [ 78, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781833660408487940",
  "text" : "I how she can live with herself by possibly hurting one of the top percentile #ETSU.",
  "id" : 781833660408487940,
  "created_at" : "2016-09-30 12:30:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781829535318802432",
  "text" : "Have fun at medical school humans and killing people and taking kickbacks.",
  "id" : 781829535318802432,
  "created_at" : "2016-09-30 12:14:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/Ejgv9oewp8",
      "expanded_url" : "https:\/\/www.theguardian.com\/global-development\/2016\/sep\/28\/destruction-of-heritage-weapon-of-war-timbuktu-shrines-irina-bokova?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/global-develop\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781827198797934592",
  "text" : "At last, the destruction of heritage has been recognised as a weapon of war | Irina Bokova https:\/\/t.co\/Ejgv9oewp8",
  "id" : 781827198797934592,
  "created_at" : "2016-09-30 12:05:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/vFzA6dwVeR",
      "expanded_url" : "https:\/\/goo.gl\/5g26fX",
      "display_url" : "goo.gl\/5g26fX"
    } ]
  },
  "geo" : { },
  "id_str" : "781826781225558016",
  "text" : "Perceptions of Unfair Marketing Practices: Consumerism Implications\nhttps:\/\/t.co\/vFzA6dwVeR",
  "id" : 781826781225558016,
  "created_at" : "2016-09-30 12:03:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/LJDiNEsVi2",
      "expanded_url" : "https:\/\/www.marketingevolution.com\/",
      "display_url" : "marketingevolution.com"
    } ]
  },
  "geo" : { },
  "id_str" : "781826287493115904",
  "text" : "https:\/\/t.co\/LJDiNEsVi2 Know your enemy.",
  "id" : 781826287493115904,
  "created_at" : "2016-09-30 12:01:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781821041186312192",
  "text" : "Everyone do be good. I'm not getting married. Or having kids either, natural selection has just failed in SWVA.",
  "id" : 781821041186312192,
  "created_at" : "2016-09-30 11:40:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "ESA Rosetta Mission",
      "screen_name" : "ESA_Rosetta",
      "indices" : [ 75, 87 ],
      "id_str" : "253536357",
      "id" : 253536357
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CometLanding",
      "indices" : [ 19, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781820241915633664",
  "text" : "RT @NASA: Ahead of #CometLanding, learn all about the amazing science that @ESA_Rosetta has accomplished. Watch on NASA TV: https:\/\/t.co\/KX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ESA Rosetta Mission",
        "screen_name" : "ESA_Rosetta",
        "indices" : [ 65, 77 ],
        "id_str" : "253536357",
        "id" : 253536357
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/781809849759739908\/video\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/MstKOHIUG5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtmL6P3UMAIK3XU.jpg",
        "id_str" : "781809496930693121",
        "id" : 781809496930693121,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtmL6P3UMAIK3XU.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/MstKOHIUG5"
      } ],
      "hashtags" : [ {
        "text" : "CometLanding",
        "indices" : [ 9, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/KX5g7zfYQe",
        "expanded_url" : "http:\/\/www.nasa.gov\/nasatv",
        "display_url" : "nasa.gov\/nasatv"
      } ]
    },
    "geo" : { },
    "id_str" : "781809849759739908",
    "text" : "Ahead of #CometLanding, learn all about the amazing science that @ESA_Rosetta has accomplished. Watch on NASA TV: https:\/\/t.co\/KX5g7zfYQe https:\/\/t.co\/MstKOHIUG5",
    "id" : 781809849759739908,
    "created_at" : "2016-09-30 10:56:08 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 781820241915633664,
  "created_at" : "2016-09-30 11:37:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Amos",
      "screen_name" : "BBCAmos",
      "indices" : [ 3, 11 ],
      "id_str" : "104585489",
      "id" : 104585489
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BBCAmos\/status\/781816629063716864\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/BqQmgLcfWM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtmSD9JWcAA6sVw.jpg",
      "id_str" : "781816606976536576",
      "id" : 781816606976536576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtmSD9JWcAA6sVw.jpg",
      "sizes" : [ {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 923
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 923
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 923
      } ],
      "display_url" : "pic.twitter.com\/BqQmgLcfWM"
    } ],
    "hashtags" : [ {
      "text" : "Rosetta",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781820014978535424",
  "text" : "RT @BBCAmos: It's all over. #Rosetta is gone. Flight controllers Sylvain Lodiot and Andrea Accomazzo embrace. https:\/\/t.co\/BqQmgLcfWM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BBCAmos\/status\/781816629063716864\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/BqQmgLcfWM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtmSD9JWcAA6sVw.jpg",
        "id_str" : "781816606976536576",
        "id" : 781816606976536576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtmSD9JWcAA6sVw.jpg",
        "sizes" : [ {
          "h" : 376,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 923
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 923
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 923
        } ],
        "display_url" : "pic.twitter.com\/BqQmgLcfWM"
      } ],
      "hashtags" : [ {
        "text" : "Rosetta",
        "indices" : [ 15, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "781816629063716864",
    "text" : "It's all over. #Rosetta is gone. Flight controllers Sylvain Lodiot and Andrea Accomazzo embrace. https:\/\/t.co\/BqQmgLcfWM",
    "id" : 781816629063716864,
    "created_at" : "2016-09-30 11:23:04 +0000",
    "user" : {
      "name" : "Jonathan Amos",
      "screen_name" : "BBCAmos",
      "protected" : false,
      "id_str" : "104585489",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593104934415028225\/IqEQm7bC_normal.jpg",
      "id" : 104585489,
      "verified" : false
    }
  },
  "id" : 781820014978535424,
  "created_at" : "2016-09-30 11:36:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781819886720933888",
  "text" : "Microsoft I may just call sometime. I have paid. When all SWVA does is download torrents. I still have some of your executives numbers.",
  "id" : 781819886720933888,
  "created_at" : "2016-09-30 11:36:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 66, 74 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/fxQY7mgaRx",
      "expanded_url" : "https:\/\/youtu.be\/6ADTPb2f_44",
      "display_url" : "youtu.be\/6ADTPb2f_44"
    } ]
  },
  "geo" : { },
  "id_str" : "781818181744783360",
  "text" : "Red Hot Chili Peppers - Higher Ground https:\/\/t.co\/fxQY7mgaRx via @YouTube",
  "id" : 781818181744783360,
  "created_at" : "2016-09-30 11:29:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781817253180370944",
  "text" : "I just invited a former Microsoft Home employee to my LinkedIn.",
  "id" : 781817253180370944,
  "created_at" : "2016-09-30 11:25:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781807315460718592",
  "text" : "Hi \"Jonathan \" on HGTV.",
  "id" : 781807315460718592,
  "created_at" : "2016-09-30 10:46:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "indices" : [ 3, 9 ],
      "id_str" : "3819701",
      "id" : 3819701
    }, {
      "name" : "Mary Jo Foley",
      "screen_name" : "maryjofoley",
      "indices" : [ 109, 121 ],
      "id_str" : "49465463",
      "id" : 49465463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/ECim3H6eGC",
      "expanded_url" : "http:\/\/zd.net\/2dokjWA",
      "display_url" : "zd.net\/2dokjWA"
    } ]
  },
  "geo" : { },
  "id_str" : "781806358492569600",
  "text" : "RT @ZDNet: Microsoft and Salesforce: How the former suitors are once again disputers https:\/\/t.co\/ECim3H6eGC @maryjofoley https:\/\/t.co\/l24c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mary Jo Foley",
        "screen_name" : "maryjofoley",
        "indices" : [ 98, 110 ],
        "id_str" : "49465463",
        "id" : 49465463
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ZDNet\/status\/781805321262104576\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/l24c4bz8Yw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtmHyNcWAAEXsOL.jpg",
        "id_str" : "781805306997243905",
        "id" : 781805306997243905,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtmHyNcWAAEXsOL.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 594,
          "resize" : "fit",
          "w" : 930
        }, {
          "h" : 594,
          "resize" : "fit",
          "w" : 930
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 594,
          "resize" : "fit",
          "w" : 930
        } ],
        "display_url" : "pic.twitter.com\/l24c4bz8Yw"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/ECim3H6eGC",
        "expanded_url" : "http:\/\/zd.net\/2dokjWA",
        "display_url" : "zd.net\/2dokjWA"
      } ]
    },
    "geo" : { },
    "id_str" : "781805321262104576",
    "text" : "Microsoft and Salesforce: How the former suitors are once again disputers https:\/\/t.co\/ECim3H6eGC @maryjofoley https:\/\/t.co\/l24c4bz8Yw",
    "id" : 781805321262104576,
    "created_at" : "2016-09-30 10:38:08 +0000",
    "user" : {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "protected" : false,
      "id_str" : "3819701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706961982545473536\/Ibj46-DX_normal.jpg",
      "id" : 3819701,
      "verified" : true
    }
  },
  "id" : 781806358492569600,
  "created_at" : "2016-09-30 10:42:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781806321570045952",
  "text" : "It was PixelSense now it's just a Surface book and I don't want it. See what your \"Help us improve\" has done to the future ladies.",
  "id" : 781806321570045952,
  "created_at" : "2016-09-30 10:42:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/AKhnL91vxl",
      "expanded_url" : "https:\/\/channel9.msdn.com\/Series\/CampusTours\/Microsoft-Campus-Tours-The-Microsoft-Home",
      "display_url" : "channel9.msdn.com\/Series\/CampusT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781801944419540992",
  "text" : "https:\/\/t.co\/AKhnL91vxl Channel 9 Microsoft Home.",
  "id" : 781801944419540992,
  "created_at" : "2016-09-30 10:24:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781800377469562880",
  "text" : "I really don't want anything on my walls until I get small projectors and have video wallpaper like the Microsoft home.",
  "id" : 781800377469562880,
  "created_at" : "2016-09-30 10:18:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781798430893015041",
  "text" : "Mensa should be enough you would think if the U.S. was good that the money would start coming in. See natural selection failed in SWVA.",
  "id" : 781798430893015041,
  "created_at" : "2016-09-30 10:10:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/hsItsO87Ja",
      "expanded_url" : "https:\/\/goo.gl\/4FLM2s",
      "display_url" : "goo.gl\/4FLM2s"
    } ]
  },
  "geo" : { },
  "id_str" : "781797516681613312",
  "text" : "https:\/\/t.co\/hsItsO87Ja Evolution's Next Stage And I am 38 long enough to live and to prove myself to natural selection.",
  "id" : 781797516681613312,
  "created_at" : "2016-09-30 10:07:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/nQeJnmCQK0",
      "expanded_url" : "http:\/\/www.juancole.com\/2013\/12\/corrupt-country-world.html",
      "display_url" : "juancole.com\/2013\/12\/corrup\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781794991165345792",
  "text" : "Top 10 Ways the US is the Most Corrupt Country in the World https:\/\/t.co\/nQeJnmCQK0",
  "id" : 781794991165345792,
  "created_at" : "2016-09-30 09:57:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/JgyVYaVyfI",
      "expanded_url" : "https:\/\/goo.gl\/jlBswr",
      "display_url" : "goo.gl\/jlBswr"
    } ]
  },
  "geo" : { },
  "id_str" : "781794350191767552",
  "text" : "Dutch experts say schizophrenia does not exist, but psychosis does, and is very treatable. https:\/\/t.co\/JgyVYaVyfI",
  "id" : 781794350191767552,
  "created_at" : "2016-09-30 09:54:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/3kQ05rHYEA",
      "expanded_url" : "http:\/\/www.evolution.berkeley.edu\/evosite\/evo101\/IIIE6aFitenough.shtml",
      "display_url" : "evolution.berkeley.edu\/evosite\/evo101\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781792832357076992",
  "text" : "https:\/\/t.co\/3kQ05rHYEA Natural selection does not produce perfection like I would want. We have lost too much.Ever watch 'Alien'.",
  "id" : 781792832357076992,
  "created_at" : "2016-09-30 09:48:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781790865568239616",
  "text" : "World Community Grid is running right now. Until natural selection works for me I'm just not telling people much.",
  "id" : 781790865568239616,
  "created_at" : "2016-09-30 09:40:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Einstein@Home",
      "screen_name" : "EinsteinAtHome",
      "indices" : [ 3, 18 ],
      "id_str" : "357399084",
      "id" : 357399084
    }, {
      "name" : "Einstein@Home",
      "screen_name" : "EinsteinAtHome",
      "indices" : [ 50, 65 ],
      "id_str" : "357399084",
      "id" : 357399084
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gravitationalwave",
      "indices" : [ 103, 121 ]
    }, {
      "text" : "science",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/4vfjyAuogv",
      "expanded_url" : "http:\/\/www.cafepress.com\/ligosc\/11573295",
      "display_url" : "cafepress.com\/ligosc\/11573295"
    } ]
  },
  "geo" : { },
  "id_str" : "781790314541510656",
  "text" : "RT @EinsteinAtHome: Enjoy your coffee or tea from @EinsteinAtHome project mugs https:\/\/t.co\/4vfjyAuogv #gravitationalwave #science https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Einstein@Home",
        "screen_name" : "EinsteinAtHome",
        "indices" : [ 30, 45 ],
        "id_str" : "357399084",
        "id" : 357399084
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EinsteinAtHome\/status\/781780202795958272\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/uXPoncqjjs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ctlw8zuWAAAgtSX.png",
        "id_str" : "781780200304541696",
        "id" : 781780200304541696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ctlw8zuWAAAgtSX.png",
        "sizes" : [ {
          "h" : 350,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 350
        } ],
        "display_url" : "pic.twitter.com\/uXPoncqjjs"
      } ],
      "hashtags" : [ {
        "text" : "gravitationalwave",
        "indices" : [ 83, 101 ]
      }, {
        "text" : "science",
        "indices" : [ 102, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/4vfjyAuogv",
        "expanded_url" : "http:\/\/www.cafepress.com\/ligosc\/11573295",
        "display_url" : "cafepress.com\/ligosc\/11573295"
      } ]
    },
    "geo" : { },
    "id_str" : "781780202795958272",
    "text" : "Enjoy your coffee or tea from @EinsteinAtHome project mugs https:\/\/t.co\/4vfjyAuogv #gravitationalwave #science https:\/\/t.co\/uXPoncqjjs",
    "id" : 781780202795958272,
    "created_at" : "2016-09-30 08:58:19 +0000",
    "user" : {
      "name" : "Einstein@Home",
      "screen_name" : "EinsteinAtHome",
      "protected" : false,
      "id_str" : "357399084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1501716579\/E_H_head_normal.png",
      "id" : 357399084,
      "verified" : false
    }
  },
  "id" : 781790314541510656,
  "created_at" : "2016-09-30 09:38:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC News (World)",
      "screen_name" : "BBCWorld",
      "indices" : [ 3, 12 ],
      "id_str" : "742143",
      "id" : 742143
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 59, 71 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/oecnPxhOE4",
      "expanded_url" : "http:\/\/bbc.in\/2dqTw8H",
      "display_url" : "bbc.in\/2dqTw8H"
    } ]
  },
  "geo" : { },
  "id_str" : "781790251878678528",
  "text" : "RT @BBCWorld: \"He never saw his dream of peace fulfilled,\" @BarackObama pays tribute to Shimon Peres https:\/\/t.co\/oecnPxhOE4 https:\/\/t.co\/n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 45, 57 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/oecnPxhOE4",
        "expanded_url" : "http:\/\/bbc.in\/2dqTw8H",
        "display_url" : "bbc.in\/2dqTw8H"
      }, {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/nU2VDcoKFV",
        "expanded_url" : "http:\/\/snpy.tv\/2dg57ZJ",
        "display_url" : "snpy.tv\/2dg57ZJ"
      } ]
    },
    "geo" : { },
    "id_str" : "781780482094604288",
    "text" : "\"He never saw his dream of peace fulfilled,\" @BarackObama pays tribute to Shimon Peres https:\/\/t.co\/oecnPxhOE4 https:\/\/t.co\/nU2VDcoKFV",
    "id" : 781780482094604288,
    "created_at" : "2016-09-30 08:59:26 +0000",
    "user" : {
      "name" : "BBC News (World)",
      "screen_name" : "BBCWorld",
      "protected" : false,
      "id_str" : "742143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694449140269518848\/57ZmXva0_normal.jpg",
      "id" : 742143,
      "verified" : true
    }
  },
  "id" : 781790251878678528,
  "created_at" : "2016-09-30 09:38:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781788592884580352",
  "text" : "I watched module 2 of my quantum course. Math background. Before Adobe I worked for 'For Kids' in Greenville TN. developing Flash for kids.",
  "id" : 781788592884580352,
  "created_at" : "2016-09-30 09:31:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stanford Cultural",
      "screen_name" : "Stanford_CinC",
      "indices" : [ 0, 14 ],
      "id_str" : "3242795869",
      "id" : 3242795869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781787103600447488",
  "in_reply_to_user_id" : 3242795869,
  "text" : "@Stanford_CinC Thanks for the follow.",
  "id" : 781787103600447488,
  "created_at" : "2016-09-30 09:25:45 +0000",
  "in_reply_to_screen_name" : "Stanford_CinC",
  "in_reply_to_user_id_str" : "3242795869",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/wPmXhqIpeI",
      "expanded_url" : "http:\/\/pleiotropy.fieldofscience.com\/2008\/10\/natural-selection-fails-to-optimize.html?spref=tw",
      "display_url" : "pleiotropy.fieldofscience.com\/2008\/10\/natura\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781784778878099456",
  "text" : "Pleiotropy: Natural Selection Fails to Optimize Mutation Rates... https:\/\/t.co\/wPmXhqIpeI Originally we had brown eyes.",
  "id" : 781784778878099456,
  "created_at" : "2016-09-30 09:16:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 79, 87 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/qGyNPVCc73",
      "expanded_url" : "https:\/\/youtu.be\/tcHz3o4t6Rk",
      "display_url" : "youtu.be\/tcHz3o4t6Rk"
    } ]
  },
  "geo" : { },
  "id_str" : "781775117810413568",
  "text" : "Higgs Boson Discovery Wins Nobel Prize for Physics https:\/\/t.co\/qGyNPVCc73 via @YouTube",
  "id" : 781775117810413568,
  "created_at" : "2016-09-30 08:38:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/mbFEV6E3K3",
      "expanded_url" : "http:\/\/www.healyourlife.com\/have-we-met-in-a-past-life",
      "display_url" : "healyourlife.com\/have-we-met-in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781754648273170432",
  "text" : "https:\/\/t.co\/mbFEV6E3K3 Have we met in a past life?",
  "id" : 781754648273170432,
  "created_at" : "2016-09-30 07:16:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/Xk31G7AYP7",
      "expanded_url" : "https:\/\/g.co\/kgs\/8gK2nv",
      "display_url" : "g.co\/kgs\/8gK2nv"
    } ]
  },
  "geo" : { },
  "id_str" : "781640193271037952",
  "text" : "The World We Live In https:\/\/t.co\/Xk31G7AYP7",
  "id" : 781640193271037952,
  "created_at" : "2016-09-29 23:41:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781631685007900672",
  "text" : "Until we all are happy in the marriage we want and away from each other it won't get better.",
  "id" : 781631685007900672,
  "created_at" : "2016-09-29 23:08:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/GXvF624Ji5",
      "expanded_url" : "http:\/\/www.newsweek.com\/america-hates-its-gifted-kids-226327",
      "display_url" : "newsweek.com\/america-hates-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781629073990774785",
  "text" : "America Hates Its Gifted Kids https:\/\/t.co\/GXvF624Ji5",
  "id" : 781629073990774785,
  "created_at" : "2016-09-29 22:57:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newsweek Europe",
      "screen_name" : "NewsweekEurope",
      "indices" : [ 70, 85 ],
      "id_str" : "237851661",
      "id" : 237851661
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "music",
      "indices" : [ 13, 19 ]
    }, {
      "text" : "Musichealthbenefits",
      "indices" : [ 86, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/xVkiDy5Vbg",
      "expanded_url" : "http:\/\/europe.newsweek.com\/music-can-heal-your-pain-new-study-says-331525?utm_source=social&utm_medium=twitter&utm_campaign=\/music-can-heal-your-pain-new-study-says-331525",
      "display_url" : "europe.newsweek.com\/music-can-heal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781628617713483776",
  "text" : "Listening to #music makes you feel better https:\/\/t.co\/xVkiDy5Vbg via @NewsweekEurope #Musichealthbenefits",
  "id" : 781628617713483776,
  "created_at" : "2016-09-29 22:55:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IEEE Spectrum",
      "screen_name" : "IEEESpectrum",
      "indices" : [ 3, 16 ],
      "id_str" : "15825547",
      "id" : 15825547
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/IEEESpectrum\/status\/781588646310936576\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/0uLH52FYOr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtjCuuHWAAALgWv.jpg",
      "id_str" : "781588643257384960",
      "id" : 781588643257384960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtjCuuHWAAALgWv.jpg",
      "sizes" : [ {
        "h" : 373,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/0uLH52FYOr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/0pNNwb5RIJ",
      "expanded_url" : "http:\/\/trib.al\/LKKsXyx",
      "display_url" : "trib.al\/LKKsXyx"
    } ]
  },
  "geo" : { },
  "id_str" : "781628050492366848",
  "text" : "RT @IEEESpectrum: New Memristor Circuit Mimicks Synapses in the Brain https:\/\/t.co\/0pNNwb5RIJ https:\/\/t.co\/0uLH52FYOr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IEEESpectrum\/status\/781588646310936576\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/0uLH52FYOr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtjCuuHWAAALgWv.jpg",
        "id_str" : "781588643257384960",
        "id" : 781588643257384960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtjCuuHWAAALgWv.jpg",
        "sizes" : [ {
          "h" : 373,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/0uLH52FYOr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/0pNNwb5RIJ",
        "expanded_url" : "http:\/\/trib.al\/LKKsXyx",
        "display_url" : "trib.al\/LKKsXyx"
      } ]
    },
    "geo" : { },
    "id_str" : "781588646310936576",
    "text" : "New Memristor Circuit Mimicks Synapses in the Brain https:\/\/t.co\/0pNNwb5RIJ https:\/\/t.co\/0uLH52FYOr",
    "id" : 781588646310936576,
    "created_at" : "2016-09-29 20:17:09 +0000",
    "user" : {
      "name" : "IEEE Spectrum",
      "screen_name" : "IEEESpectrum",
      "protected" : false,
      "id_str" : "15825547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489425137884618752\/J0_eul7G_normal.jpeg",
      "id" : 15825547,
      "verified" : false
    }
  },
  "id" : 781628050492366848,
  "created_at" : "2016-09-29 22:53:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "indices" : [ 3, 17 ],
      "id_str" : "34554134",
      "id" : 34554134
    }, {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 82, 94 ],
      "id_str" : "17248121",
      "id" : 17248121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/8SLC2ErZYN",
      "expanded_url" : "http:\/\/buff.ly\/2cEC8MU",
      "display_url" : "buff.ly\/2cEC8MU"
    } ]
  },
  "geo" : { },
  "id_str" : "781627928589262848",
  "text" : "RT @SETIInstitute: Rosetta measures production of water at comet over two years | @physorg_com https:\/\/t.co\/8SLC2ErZYN https:\/\/t.co\/UpyUJ8a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Phys.org",
        "screen_name" : "physorg_com",
        "indices" : [ 63, 75 ],
        "id_str" : "17248121",
        "id" : 17248121
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SETIInstitute\/status\/781591134116143104\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/UpyUJ8ahe7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtjE_iNWgAAzRus.jpg",
        "id_str" : "781591131142389760",
        "id" : 781591131142389760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtjE_iNWgAAzRus.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/UpyUJ8ahe7"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SETIInstitute\/status\/781591134116143104\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/UpyUJ8ahe7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtjE_i0WIAEAgk_.jpg",
        "id_str" : "781591131305943041",
        "id" : 781591131305943041,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtjE_i0WIAEAgk_.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/UpyUJ8ahe7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/8SLC2ErZYN",
        "expanded_url" : "http:\/\/buff.ly\/2cEC8MU",
        "display_url" : "buff.ly\/2cEC8MU"
      } ]
    },
    "geo" : { },
    "id_str" : "781591134116143104",
    "text" : "Rosetta measures production of water at comet over two years | @physorg_com https:\/\/t.co\/8SLC2ErZYN https:\/\/t.co\/UpyUJ8ahe7",
    "id" : 781591134116143104,
    "created_at" : "2016-09-29 20:27:02 +0000",
    "user" : {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "protected" : false,
      "id_str" : "34554134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758705567556743168\/TGjZ9Uwf_normal.jpg",
      "id" : 34554134,
      "verified" : true
    }
  },
  "id" : 781627928589262848,
  "created_at" : "2016-09-29 22:53:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "indices" : [ 3, 10 ],
      "id_str" : "17471979",
      "id" : 17471979
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photography",
      "indices" : [ 68, 80 ]
    }, {
      "text" : "pod",
      "indices" : [ 81, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/6b3m5KD3kp",
      "expanded_url" : "http:\/\/on.natgeo.com\/2dv6mmX",
      "display_url" : "on.natgeo.com\/2dv6mmX"
    } ]
  },
  "geo" : { },
  "id_str" : "781627815305371649",
  "text" : "RT @NatGeo: Photo of the Day: Winter Wonder\nhttps:\/\/t.co\/6b3m5KD3kp #photography #pod",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "photography",
        "indices" : [ 56, 68 ]
      }, {
        "text" : "pod",
        "indices" : [ 69, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/6b3m5KD3kp",
        "expanded_url" : "http:\/\/on.natgeo.com\/2dv6mmX",
        "display_url" : "on.natgeo.com\/2dv6mmX"
      } ]
    },
    "geo" : { },
    "id_str" : "781595681177931777",
    "text" : "Photo of the Day: Winter Wonder\nhttps:\/\/t.co\/6b3m5KD3kp #photography #pod",
    "id" : 781595681177931777,
    "created_at" : "2016-09-29 20:45:06 +0000",
    "user" : {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "protected" : false,
      "id_str" : "17471979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798181194202566656\/U8QbCBdH_normal.jpg",
      "id" : 17471979,
      "verified" : true
    }
  },
  "id" : 781627815305371649,
  "created_at" : "2016-09-29 22:52:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBM",
      "screen_name" : "IBM",
      "indices" : [ 3, 7 ],
      "id_str" : "18994444",
      "id" : 18994444
    }, {
      "name" : "IBM Watson",
      "screen_name" : "IBMWatson",
      "indices" : [ 29, 39 ],
      "id_str" : "29735775",
      "id" : 29735775
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OmniEarth",
      "indices" : [ 9, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781627312521547776",
  "text" : "RT @IBM: #OmniEarth is using @IBMWatson's visual recognition capabilities to help manage water during California's drought: https:\/\/t.co\/Nt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/percolate.com\" rel=\"nofollow\"\u003EPercolate\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IBM Watson",
        "screen_name" : "IBMWatson",
        "indices" : [ 20, 30 ],
        "id_str" : "29735775",
        "id" : 29735775
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IBM\/status\/781619345700950016\/photo\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/BGIKiQ0OkJ",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CtjepmpUIAAlc9w.jpg",
        "id_str" : "781619341678616576",
        "id" : 781619341678616576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CtjepmpUIAAlc9w.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/BGIKiQ0OkJ"
      } ],
      "hashtags" : [ {
        "text" : "OmniEarth",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/NthykPE9Gk",
        "expanded_url" : "http:\/\/bit.ly\/2duH5xV",
        "display_url" : "bit.ly\/2duH5xV"
      } ]
    },
    "geo" : { },
    "id_str" : "781619345700950016",
    "text" : "#OmniEarth is using @IBMWatson's visual recognition capabilities to help manage water during California's drought: https:\/\/t.co\/NthykPE9Gk https:\/\/t.co\/BGIKiQ0OkJ",
    "id" : 781619345700950016,
    "created_at" : "2016-09-29 22:19:08 +0000",
    "user" : {
      "name" : "IBM",
      "screen_name" : "IBM",
      "protected" : false,
      "id_str" : "18994444",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614802024832610304\/_CZY2puL_normal.jpg",
      "id" : 18994444,
      "verified" : true
    }
  },
  "id" : 781627312521547776,
  "created_at" : "2016-09-29 22:50:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/0KbNqiOk8p",
      "expanded_url" : "http:\/\/www.hippiessavedphysics.com\/",
      "display_url" : "hippiessavedphysics.com"
    } ]
  },
  "geo" : { },
  "id_str" : "781626968387223552",
  "text" : "https:\/\/t.co\/0KbNqiOk8p How the hippies saved physics. I bet you don't like my long hair do you father.",
  "id" : 781626968387223552,
  "created_at" : "2016-09-29 22:49:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781625653145825280",
  "text" : "I'm just not following \"us\" I will follow however just her.",
  "id" : 781625653145825280,
  "created_at" : "2016-09-29 22:44:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/6WRLLO4N7y",
      "expanded_url" : "https:\/\/www.top500.org\/lists\/2016\/06\/",
      "display_url" : "top500.org\/lists\/2016\/06\/"
    } ]
  },
  "geo" : { },
  "id_str" : "781623993119961088",
  "text" : "https:\/\/t.co\/6WRLLO4N7y June 2016 guess what I was doing while you where by the pool?",
  "id" : 781623993119961088,
  "created_at" : "2016-09-29 22:37:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781621384892018688",
  "text" : "Reading my Google alerts Who? I'm just not telling you.",
  "id" : 781621384892018688,
  "created_at" : "2016-09-29 22:27:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 95, 102 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/LZeFOyUWGY",
      "expanded_url" : "https:\/\/www.amazon.com\/dp\/0310327792\/ref=cm_sw_r_tw_dp_x_3gz7xbQ0MVVT2",
      "display_url" : "amazon.com\/dp\/0310327792\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781618191051137024",
  "text" : "Trading Places: The Secret to the Marriage You Want by Les Parrott https:\/\/t.co\/LZeFOyUWGY via @amazon just bought it.",
  "id" : 781618191051137024,
  "created_at" : "2016-09-29 22:14:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/W3BG6Sivui",
      "expanded_url" : "http:\/\/thechart.blogs.cnn.com\/2011\/05\/23\/thats-dr-watson-to-you\/",
      "display_url" : "thechart.blogs.cnn.com\/2011\/05\/23\/tha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781612232136335367",
  "text" : "https:\/\/t.co\/W3BG6Sivui That's Dr. Watson to you. And I do know how Watson is built Trade Secret.",
  "id" : 781612232136335367,
  "created_at" : "2016-09-29 21:50:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 55, 63 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/DQJo2zvpS1",
      "expanded_url" : "https:\/\/youtu.be\/-Dd28nxUpLY",
      "display_url" : "youtu.be\/-Dd28nxUpLY"
    } ]
  },
  "geo" : { },
  "id_str" : "781608973745160193",
  "text" : "Getting nailed by the King https:\/\/t.co\/DQJo2zvpS1 via @YouTube",
  "id" : 781608973745160193,
  "created_at" : "2016-09-29 21:37:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781527638556958720",
  "text" : "If it's a no she just killed my kid.",
  "id" : 781527638556958720,
  "created_at" : "2016-09-29 16:14:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781527528452288512",
  "text" : "I'm not coming on the anymore women I told her about klotho and spoke then forever holding my peace.",
  "id" : 781527528452288512,
  "created_at" : "2016-09-29 16:14:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/nRgk1r5psu",
      "expanded_url" : "https:\/\/www.sciencedaily.com\/releases\/2008\/01\/080130170343.htm",
      "display_url" : "sciencedaily.com\/releases\/2008\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781503058320756736",
  "text" : "https:\/\/t.co\/nRgk1r5psu Originally we all had brown eyes until the Neanderthal mutation.",
  "id" : 781503058320756736,
  "created_at" : "2016-09-29 14:37:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781502211251724289",
  "text" : "Doctor feeling like a little homo sapien by shaving? Liar.",
  "id" : 781502211251724289,
  "created_at" : "2016-09-29 14:33:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/OkvMxRQnAF",
      "expanded_url" : "https:\/\/goo.gl\/IIbA3T",
      "display_url" : "goo.gl\/IIbA3T"
    } ]
  },
  "geo" : { },
  "id_str" : "781493632020975616",
  "text" : "The downside of sex with Neanderthals. I am well below the national average. https:\/\/t.co\/OkvMxRQnAF",
  "id" : 781493632020975616,
  "created_at" : "2016-09-29 13:59:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 63, 71 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/TPogjKpSZh",
      "expanded_url" : "https:\/\/youtu.be\/YEe4fZnJJVs",
      "display_url" : "youtu.be\/YEe4fZnJJVs"
    } ]
  },
  "geo" : { },
  "id_str" : "781430827196506114",
  "text" : "David Bowie   Something In The Air https:\/\/t.co\/TPogjKpSZh via @YouTube",
  "id" : 781430827196506114,
  "created_at" : "2016-09-29 09:50:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781425652180344832",
  "text" : "And finished Day 1 of of the Quantum course. Back to bed.",
  "id" : 781425652180344832,
  "created_at" : "2016-09-29 09:29:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781425476208295937",
  "text" : "Downloaded all 9 weeks of my Stanford Quantum Course. I would give them to a kid if they wanted them .Also submitted an asteroid task.",
  "id" : 781425476208295937,
  "created_at" : "2016-09-29 09:28:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "indices" : [ 3, 10 ],
      "id_str" : "17471979",
      "id" : 17471979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/lD0fa0z2yG",
      "expanded_url" : "http:\/\/on.natgeo.com\/2d8dVVw",
      "display_url" : "on.natgeo.com\/2d8dVVw"
    } ]
  },
  "geo" : { },
  "id_str" : "781407170940243968",
  "text" : "RT @NatGeo: What exactly is a black moon? https:\/\/t.co\/lD0fa0z2yG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/lD0fa0z2yG",
        "expanded_url" : "http:\/\/on.natgeo.com\/2d8dVVw",
        "display_url" : "on.natgeo.com\/2d8dVVw"
      } ]
    },
    "geo" : { },
    "id_str" : "781305512960876544",
    "text" : "What exactly is a black moon? https:\/\/t.co\/lD0fa0z2yG",
    "id" : 781305512960876544,
    "created_at" : "2016-09-29 01:32:04 +0000",
    "user" : {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "protected" : false,
      "id_str" : "17471979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798181194202566656\/U8QbCBdH_normal.jpg",
      "id" : 17471979,
      "verified" : true
    }
  },
  "id" : 781407170940243968,
  "created_at" : "2016-09-29 08:16:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 3, 11 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781406921148497920",
  "text" : "RT @Harvard: The Moise Y. Safra Welcome Pavilion at the entrance of the Campus Center will make the facility a valuable resource https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/pzTwwmcnjT",
        "expanded_url" : "http:\/\/hvrd.me\/OQlB304BJiO",
        "display_url" : "hvrd.me\/OQlB304BJiO"
      } ]
    },
    "geo" : { },
    "id_str" : "781312038010257408",
    "text" : "The Moise Y. Safra Welcome Pavilion at the entrance of the Campus Center will make the facility a valuable resource https:\/\/t.co\/pzTwwmcnjT",
    "id" : 781312038010257408,
    "created_at" : "2016-09-29 01:58:00 +0000",
    "user" : {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "protected" : false,
      "id_str" : "39585367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466953024271679488\/3rftwYWT_normal.jpeg",
      "id" : 39585367,
      "verified" : true
    }
  },
  "id" : 781406921148497920,
  "created_at" : "2016-09-29 08:15:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "indices" : [ 3, 10 ],
      "id_str" : "17471979",
      "id" : 17471979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/krrjuZABNC",
      "expanded_url" : "http:\/\/on.natgeo.com\/2dsVwxK",
      "display_url" : "on.natgeo.com\/2dsVwxK"
    } ]
  },
  "geo" : { },
  "id_str" : "781406548543344640",
  "text" : "RT @NatGeo: Sylvia Earle, an unstoppable force at 81, wants 20% of Earth's oceans protected by 2020. https:\/\/t.co\/krrjuZABNC #ExplorerMomen\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ExplorerMoments",
        "indices" : [ 113, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/krrjuZABNC",
        "expanded_url" : "http:\/\/on.natgeo.com\/2dsVwxK",
        "display_url" : "on.natgeo.com\/2dsVwxK"
      } ]
    },
    "geo" : { },
    "id_str" : "781320117766479872",
    "text" : "Sylvia Earle, an unstoppable force at 81, wants 20% of Earth's oceans protected by 2020. https:\/\/t.co\/krrjuZABNC #ExplorerMoments",
    "id" : 781320117766479872,
    "created_at" : "2016-09-29 02:30:06 +0000",
    "user" : {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "protected" : false,
      "id_str" : "17471979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798181194202566656\/U8QbCBdH_normal.jpg",
      "id" : 17471979,
      "verified" : true
    }
  },
  "id" : 781406548543344640,
  "created_at" : "2016-09-29 08:13:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Princeton Univ Press",
      "screen_name" : "PrincetonUPress",
      "indices" : [ 3, 19 ],
      "id_str" : "20715956",
      "id" : 20715956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781406307572211712",
  "text" : "RT @PrincetonUPress: NEW\n\nPhotography Reinvented:\nThe Collection of Robert E. Meyerhoff and Rheda Becker\nby Sarah Greenough\nhttps:\/\/t.co\/oQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dashboard.twitter.com\" rel=\"nofollow\"\u003ETwitter Business Experience\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PrincetonUPress\/status\/781327642217807872\/photo\/1",
        "indices" : [ 127, 150 ],
        "url" : "https:\/\/t.co\/VlfaC8qosk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtdqIULWcAE7Xcl.jpg",
        "id_str" : "781209751459885057",
        "id" : 781209751459885057,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtdqIULWcAE7Xcl.jpg",
        "sizes" : [ {
          "h" : 370,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/VlfaC8qosk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/oQyCOCQAYI",
        "expanded_url" : "http:\/\/press.princeton.edu\/titles\/10814.html",
        "display_url" : "press.princeton.edu\/titles\/10814.h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781327642217807872",
    "text" : "NEW\n\nPhotography Reinvented:\nThe Collection of Robert E. Meyerhoff and Rheda Becker\nby Sarah Greenough\nhttps:\/\/t.co\/oQyCOCQAYI https:\/\/t.co\/VlfaC8qosk",
    "id" : 781327642217807872,
    "created_at" : "2016-09-29 03:00:00 +0000",
    "user" : {
      "name" : "Princeton Univ Press",
      "screen_name" : "PrincetonUPress",
      "protected" : false,
      "id_str" : "20715956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/803244887160274944\/XbBkRNnl_normal.jpg",
      "id" : 20715956,
      "verified" : true
    }
  },
  "id" : 781406307572211712,
  "created_at" : "2016-09-29 08:12:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Google Car",
      "screen_name" : "thegooglecar",
      "indices" : [ 3, 16 ],
      "id_str" : "575310592",
      "id" : 575310592
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Environment",
      "indices" : [ 109, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/iSyIUFDeHp",
      "expanded_url" : "http:\/\/dlvr.it\/MM6JWT",
      "display_url" : "dlvr.it\/MM6JWT"
    } ]
  },
  "geo" : { },
  "id_str" : "781406153460879361",
  "text" : "RT @thegooglecar: Hundreds brought down from slopes of erupting volcano in Indonesia https:\/\/t.co\/iSyIUFDeHp #Environment",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Environment",
        "indices" : [ 91, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/iSyIUFDeHp",
        "expanded_url" : "http:\/\/dlvr.it\/MM6JWT",
        "display_url" : "dlvr.it\/MM6JWT"
      } ]
    },
    "geo" : { },
    "id_str" : "781332068517031936",
    "text" : "Hundreds brought down from slopes of erupting volcano in Indonesia https:\/\/t.co\/iSyIUFDeHp #Environment",
    "id" : 781332068517031936,
    "created_at" : "2016-09-29 03:17:36 +0000",
    "user" : {
      "name" : "The Google Car",
      "screen_name" : "thegooglecar",
      "protected" : false,
      "id_str" : "575310592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2211469309\/OhKoo_hroBK-MC9LHPQ2vTl72eJkfbmt4t8yenImKBVaiQDB_Rd1H6kmuBWtceBJ_normal.jpg",
      "id" : 575310592,
      "verified" : false
    }
  },
  "id" : 781406153460879361,
  "created_at" : "2016-09-29 08:11:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Bass",
      "screen_name" : "bass_analytics",
      "indices" : [ 3, 18 ],
      "id_str" : "4686586766",
      "id" : 4686586766
    }, {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "indices" : [ 102, 118 ],
      "id_str" : "393033324",
      "id" : 393033324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DeepLearning",
      "indices" : [ 70, 83 ]
    }, {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781405802515095552",
  "text" : "RT @bass_analytics: A primer on universal function approximation with #DeepLearning \n(in Torch and R)\n@DataScienceCtrl #rstats \nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Data Science Central",
        "screen_name" : "DataScienceCtrl",
        "indices" : [ 82, 98 ],
        "id_str" : "393033324",
        "id" : 393033324
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bass_analytics\/status\/781313232942292992\/photo\/1",
        "indices" : [ 132, 155 ],
        "url" : "https:\/\/t.co\/z7ipgh6JKN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtfIC87WcAAmhA1.jpg",
        "id_str" : "781313013412425728",
        "id" : 781313013412425728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtfIC87WcAAmhA1.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/z7ipgh6JKN"
      } ],
      "hashtags" : [ {
        "text" : "DeepLearning",
        "indices" : [ 50, 63 ]
      }, {
        "text" : "rstats",
        "indices" : [ 99, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/7lNVxBP7nz",
        "expanded_url" : "http:\/\/www.datasciencecentral.com\/profiles\/blogs\/a-primer-on-universal-function-approximation-with-deep-learning",
        "display_url" : "datasciencecentral.com\/profiles\/blogs\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781313232942292992",
    "text" : "A primer on universal function approximation with #DeepLearning \n(in Torch and R)\n@DataScienceCtrl #rstats \nhttps:\/\/t.co\/7lNVxBP7nz https:\/\/t.co\/z7ipgh6JKN",
    "id" : 781313232942292992,
    "created_at" : "2016-09-29 02:02:45 +0000",
    "user" : {
      "name" : "Kevin Bass",
      "screen_name" : "bass_analytics",
      "protected" : false,
      "id_str" : "4686586766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682757887261818880\/Q5--Prn6_normal.jpg",
      "id" : 4686586766,
      "verified" : false
    }
  },
  "id" : 781405802515095552,
  "created_at" : "2016-09-29 08:10:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Datio Engineering",
      "screen_name" : "datiobd",
      "indices" : [ 3, 11 ],
      "id_str" : "2837967381",
      "id" : 2837967381
    }, {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "indices" : [ 103, 119 ],
      "id_str" : "393033324",
      "id" : 393033324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deeplearning",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/Twaql5ffku",
      "expanded_url" : "http:\/\/ow.ly\/c0Zk303Y2mh",
      "display_url" : "ow.ly\/c0Zk303Y2mh"
    } ]
  },
  "geo" : { },
  "id_str" : "781405484309897216",
  "text" : "RT @datiobd: Urban Sound Classification using Neural Network https:\/\/t.co\/Twaql5ffku #deeplearning via @DataScienceCtrl https:\/\/t.co\/GuvIa7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Data Science Central",
        "screen_name" : "DataScienceCtrl",
        "indices" : [ 90, 106 ],
        "id_str" : "393033324",
        "id" : 393033324
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/datiobd\/status\/781192623805562880\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/GuvIa7iLKc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtdajHbWYAA9RtX.jpg",
        "id_str" : "781192619707752448",
        "id" : 781192619707752448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtdajHbWYAA9RtX.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 507
        }, {
          "h" : 1776,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 287
        }, {
          "h" : 1776,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/GuvIa7iLKc"
      } ],
      "hashtags" : [ {
        "text" : "deeplearning",
        "indices" : [ 72, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/Twaql5ffku",
        "expanded_url" : "http:\/\/ow.ly\/c0Zk303Y2mh",
        "display_url" : "ow.ly\/c0Zk303Y2mh"
      } ]
    },
    "geo" : { },
    "id_str" : "781192623805562880",
    "text" : "Urban Sound Classification using Neural Network https:\/\/t.co\/Twaql5ffku #deeplearning via @DataScienceCtrl https:\/\/t.co\/GuvIa7iLKc",
    "id" : 781192623805562880,
    "created_at" : "2016-09-28 18:03:30 +0000",
    "user" : {
      "name" : "Datio Engineering",
      "screen_name" : "datiobd",
      "protected" : false,
      "id_str" : "2837967381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731029562474278912\/TQW_ZJML_normal.jpg",
      "id" : 2837967381,
      "verified" : false
    }
  },
  "id" : 781405484309897216,
  "created_at" : "2016-09-29 08:09:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Polecat",
      "screen_name" : "PolecatMM",
      "indices" : [ 3, 13 ],
      "id_str" : "6889182",
      "id" : 6889182
    }, {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "indices" : [ 99, 115 ],
      "id_str" : "393033324",
      "id" : 393033324
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PolecatMM\/status\/781152657822146560\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/FhTMFWScyN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ctc2M3XW8AIJBAi.jpg",
      "id_str" : "781152655020322818",
      "id" : 781152655020322818,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ctc2M3XW8AIJBAi.jpg",
      "sizes" : [ {
        "h" : 335,
        "resize" : "fit",
        "w" : 530
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 530
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 530
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 530
      } ],
      "display_url" : "pic.twitter.com\/FhTMFWScyN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/RdivQxxPFn",
      "expanded_url" : "http:\/\/hubs.ly\/H04tws40",
      "display_url" : "hubs.ly\/H04tws40"
    } ]
  },
  "geo" : { },
  "id_str" : "781405392257581056",
  "text" : "RT @PolecatMM: Real Time Digital Image Processing of Agricultural Data https:\/\/t.co\/RdivQxxPFn via @DataScienceCtrl https:\/\/t.co\/FhTMFWScyN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hubspot.com\/\" rel=\"nofollow\"\u003EHubSpot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Data Science Central",
        "screen_name" : "DataScienceCtrl",
        "indices" : [ 84, 100 ],
        "id_str" : "393033324",
        "id" : 393033324
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PolecatMM\/status\/781152657822146560\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/FhTMFWScyN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ctc2M3XW8AIJBAi.jpg",
        "id_str" : "781152655020322818",
        "id" : 781152655020322818,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ctc2M3XW8AIJBAi.jpg",
        "sizes" : [ {
          "h" : 335,
          "resize" : "fit",
          "w" : 530
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 530
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 530
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 530
        } ],
        "display_url" : "pic.twitter.com\/FhTMFWScyN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/RdivQxxPFn",
        "expanded_url" : "http:\/\/hubs.ly\/H04tws40",
        "display_url" : "hubs.ly\/H04tws40"
      } ]
    },
    "geo" : { },
    "id_str" : "781152657822146560",
    "text" : "Real Time Digital Image Processing of Agricultural Data https:\/\/t.co\/RdivQxxPFn via @DataScienceCtrl https:\/\/t.co\/FhTMFWScyN",
    "id" : 781152657822146560,
    "created_at" : "2016-09-28 15:24:41 +0000",
    "user" : {
      "name" : "Polecat",
      "screen_name" : "PolecatMM",
      "protected" : false,
      "id_str" : "6889182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705309848423014400\/5VTbwWIL_normal.jpg",
      "id" : 6889182,
      "verified" : false
    }
  },
  "id" : 781405392257581056,
  "created_at" : "2016-09-29 08:08:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life Extension",
      "screen_name" : "LifeExtension",
      "indices" : [ 3, 17 ],
      "id_str" : "27188645",
      "id" : 27188645
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vitamins",
      "indices" : [ 86, 95 ]
    }, {
      "text" : "vitamind",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/8fAGFzzOnD",
      "expanded_url" : "http:\/\/trib.al\/ExqKNFC",
      "display_url" : "trib.al\/ExqKNFC"
    } ]
  },
  "geo" : { },
  "id_str" : "781404817272909824",
  "text" : "RT @LifeExtension: Are you taking the best form of vitamin D? https:\/\/t.co\/8fAGFzzOnD #vitamins #vitamind",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "vitamins",
        "indices" : [ 67, 76 ]
      }, {
        "text" : "vitamind",
        "indices" : [ 77, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/8fAGFzzOnD",
        "expanded_url" : "http:\/\/trib.al\/ExqKNFC",
        "display_url" : "trib.al\/ExqKNFC"
      } ]
    },
    "geo" : { },
    "id_str" : "781401581627596800",
    "text" : "Are you taking the best form of vitamin D? https:\/\/t.co\/8fAGFzzOnD #vitamins #vitamind",
    "id" : 781401581627596800,
    "created_at" : "2016-09-29 07:53:49 +0000",
    "user" : {
      "name" : "Life Extension",
      "screen_name" : "LifeExtension",
      "protected" : false,
      "id_str" : "27188645",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466584195842592768\/C9ajd_Y__normal.jpeg",
      "id" : 27188645,
      "verified" : false
    }
  },
  "id" : 781404817272909824,
  "created_at" : "2016-09-29 08:06:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moog Synthesizers",
      "screen_name" : "moogmusicinc",
      "indices" : [ 3, 16 ],
      "id_str" : "26779967",
      "id" : 26779967
    }, {
      "name" : "Official",
      "screen_name" : "Portisheadinfo",
      "indices" : [ 47, 62 ],
      "id_str" : "218446185",
      "id" : 218446185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moogmusicinc\/status\/779347055382827008\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/3r9KM104N2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtDMAt-UAAAHsyM.jpg",
      "id_str" : "779347048248115200",
      "id" : 779347048248115200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtDMAt-UAAAHsyM.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/3r9KM104N2"
    } ],
    "hashtags" : [ {
      "text" : "Minimoog",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/oBkGV5RnM5",
      "expanded_url" : "https:\/\/ask.audio\/articles\/synth-stories-portisheads-adrian-utley-on-minimoog-sos",
      "display_url" : "ask.audio\/articles\/synth\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781404533843001344",
  "text" : "RT @moogmusicinc: Synth master Adrian Utley of @Portisheadinfo on the #Minimoog https:\/\/t.co\/oBkGV5RnM5 https:\/\/t.co\/3r9KM104N2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Official",
        "screen_name" : "Portisheadinfo",
        "indices" : [ 29, 44 ],
        "id_str" : "218446185",
        "id" : 218446185
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/moogmusicinc\/status\/779347055382827008\/photo\/1",
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/3r9KM104N2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtDMAt-UAAAHsyM.jpg",
        "id_str" : "779347048248115200",
        "id" : 779347048248115200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtDMAt-UAAAHsyM.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/3r9KM104N2"
      } ],
      "hashtags" : [ {
        "text" : "Minimoog",
        "indices" : [ 52, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/oBkGV5RnM5",
        "expanded_url" : "https:\/\/ask.audio\/articles\/synth-stories-portisheads-adrian-utley-on-minimoog-sos",
        "display_url" : "ask.audio\/articles\/synth\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779347055382827008",
    "text" : "Synth master Adrian Utley of @Portisheadinfo on the #Minimoog https:\/\/t.co\/oBkGV5RnM5 https:\/\/t.co\/3r9KM104N2",
    "id" : 779347055382827008,
    "created_at" : "2016-09-23 15:49:52 +0000",
    "user" : {
      "name" : "Moog Synthesizers",
      "screen_name" : "moogmusicinc",
      "protected" : false,
      "id_str" : "26779967",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736287958584721409\/JcZWLecp_normal.jpg",
      "id" : 26779967,
      "verified" : true
    }
  },
  "id" : 781404533843001344,
  "created_at" : "2016-09-29 08:05:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Propellerhead",
      "screen_name" : "PropellerheadSW",
      "indices" : [ 3, 19 ],
      "id_str" : "22631376",
      "id" : 22631376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/CKOXpkxQr3",
      "expanded_url" : "https:\/\/twitter.com\/bemineaudio\/status\/781239271839637504",
      "display_url" : "twitter.com\/bemineaudio\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781403163777724416",
  "text" : "RT @PropellerheadSW: What do you think about this Reason setup? \uD83D\uDC40 https:\/\/t.co\/CKOXpkxQr3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/CKOXpkxQr3",
        "expanded_url" : "https:\/\/twitter.com\/bemineaudio\/status\/781239271839637504",
        "display_url" : "twitter.com\/bemineaudio\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781402997238759424",
    "text" : "What do you think about this Reason setup? \uD83D\uDC40 https:\/\/t.co\/CKOXpkxQr3",
    "id" : 781402997238759424,
    "created_at" : "2016-09-29 07:59:26 +0000",
    "user" : {
      "name" : "Propellerhead",
      "screen_name" : "PropellerheadSW",
      "protected" : false,
      "id_str" : "22631376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558288234363367424\/qChNU38G_normal.png",
      "id" : 22631376,
      "verified" : true
    }
  },
  "id" : 781403163777724416,
  "created_at" : "2016-09-29 08:00:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781265032306913280",
  "text" : "\"the famous Viking and founder of the Dukes of Normandy,which includes the present-day British Royal Family,have been member of this family\"",
  "id" : 781265032306913280,
  "created_at" : "2016-09-28 22:51:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781264188115128320",
  "text" : "People just won't admit what they won't say to my face you know it's been war crimes.",
  "id" : 781264188115128320,
  "created_at" : "2016-09-28 22:47:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/cb32Hdm2Yj",
      "expanded_url" : "https:\/\/twitter.com\/BBCBreaking\/status\/781245556781944832",
      "display_url" : "twitter.com\/BBCBreaking\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781262710294052873",
  "text" : "The CIA called the override \"embarrassing\" https:\/\/t.co\/cb32Hdm2Yj",
  "id" : 781262710294052873,
  "created_at" : "2016-09-28 22:41:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/MHSB96Wa41",
      "expanded_url" : "https:\/\/twitter.com\/AP\/status\/781259636624224257",
      "display_url" : "twitter.com\/AP\/status\/7812\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781261143096619012",
  "text" : "They just won't admit it will they. https:\/\/t.co\/MHSB96Wa41",
  "id" : 781261143096619012,
  "created_at" : "2016-09-28 22:35:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781259898873061377",
  "text" : "Play all in the family Google, Facebook, Amazon, and IBM it's only a breakup or divorce for the better man. Do give up.",
  "id" : 781259898873061377,
  "created_at" : "2016-09-28 22:30:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781259395397218304",
  "text" : "What are they going to use the AI for? Surveillance?",
  "id" : 781259395397218304,
  "created_at" : "2016-09-28 22:28:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/cKHgQCu9fS",
      "expanded_url" : "https:\/\/www.theguardian.com\/technology\/2016\/sep\/28\/google-facebook-amazon-ibm-microsoft-partnership-on-ai-tech-firms?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/technology\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781259185853956096",
  "text" : "'Partnership on AI' formed by Google, Facebook, Amazon, IBM and Microsoft https:\/\/t.co\/cKHgQCu9fS",
  "id" : 781259185853956096,
  "created_at" : "2016-09-28 22:27:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781258185747423232",
  "text" : "it compiles in Visual Studio 2012 for now. If they make another underscore change to the STL I'm mad.",
  "id" : 781258185747423232,
  "created_at" : "2016-09-28 22:24:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781257104996888577",
  "text" : "Reason is designed to last a long time and be compatible with version 1.x and up. The racks do compile with clang.",
  "id" : 781257104996888577,
  "created_at" : "2016-09-28 22:19:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781256451692060672",
  "text" : "I have over 2000 Reason sound libraries or refills I just haven't even used yet some I paid for some I got for free.",
  "id" : 781256451692060672,
  "created_at" : "2016-09-28 22:17:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/LLXuC7UKRt",
      "expanded_url" : "https:\/\/goo.gl\/8YhZup",
      "display_url" : "goo.gl\/8YhZup"
    } ]
  },
  "geo" : { },
  "id_str" : "781254679825088513",
  "text" : "Reason Serves as a Key Tool for Grammy Award-Winner Chris Vrenna.\nhttps:\/\/t.co\/LLXuC7UKRt",
  "id" : 781254679825088513,
  "created_at" : "2016-09-28 22:10:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781252751779065856",
  "text" : "Propellerhead's Reason is written in C++ Neanderthal.",
  "id" : 781252751779065856,
  "created_at" : "2016-09-28 22:02:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781252003167109120",
  "text" : "Just printed the entire index of all of the IRS retirement plans. I have all day banker.",
  "id" : 781252003167109120,
  "created_at" : "2016-09-28 21:59:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781250870826631168",
  "text" : "Highlands community services just called and said 'Ho' to me. Why to people continue to put me down.",
  "id" : 781250870826631168,
  "created_at" : "2016-09-28 21:54:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781239182152835072",
  "text" : "I would just stand out in her network.",
  "id" : 781239182152835072,
  "created_at" : "2016-09-28 21:08:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781238949478035456",
  "text" : "These people have just destroyed my heritage it's not about marriage it is about genetics and accomplishments.",
  "id" : 781238949478035456,
  "created_at" : "2016-09-28 21:07:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/H7N3ZltSTl",
      "expanded_url" : "https:\/\/twitter.com\/guardian\/status\/781235786075123712",
      "display_url" : "twitter.com\/guardian\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781236486364594176",
  "text" : "Get it. https:\/\/t.co\/H7N3ZltSTl",
  "id" : 781236486364594176,
  "created_at" : "2016-09-28 20:57:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781236321373347840",
  "text" : "Steinberg and Propellerhead really aren't in the \"cloud\" either.",
  "id" : 781236321373347840,
  "created_at" : "2016-09-28 20:57:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781235758598348800",
  "text" : "You can have a copy of all of that source but you only own want you maintain or write.",
  "id" : 781235758598348800,
  "created_at" : "2016-09-28 20:54:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781235463902363649",
  "text" : "\"There is a fine line between genius and insanity, and I have erased that line\" - Oscar Levant",
  "id" : 781235463902363649,
  "created_at" : "2016-09-28 20:53:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781232441885356032",
  "text" : "They did paint my railing at my apartment nice start. Not that disappointed.",
  "id" : 781232441885356032,
  "created_at" : "2016-09-28 20:41:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781227440567910400",
  "text" : "He didn't vote against guns for hunting use I think which is fine.",
  "id" : 781227440567910400,
  "created_at" : "2016-09-28 20:21:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 64, 72 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/F7wMcpZTVs",
      "expanded_url" : "https:\/\/youtu.be\/nARq6P3sm0U",
      "display_url" : "youtu.be\/nARq6P3sm0U"
    } ]
  },
  "geo" : { },
  "id_str" : "781225161609601024",
  "text" : "Neanderthal: Discovery Channel 2001 https:\/\/t.co\/F7wMcpZTVs via @YouTube D.E.K.",
  "id" : 781225161609601024,
  "created_at" : "2016-09-28 20:12:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781224515179253760",
  "text" : "Has anything changed since FDR?",
  "id" : 781224515179253760,
  "created_at" : "2016-09-28 20:10:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781223479408529408",
  "text" : "Wanna see little Raphie go off this XMas again you will. Probably on TBS. I did,it took six cops to force me to take my meds one time.",
  "id" : 781223479408529408,
  "created_at" : "2016-09-28 20:06:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781222082101309440",
  "text" : "And my father was my voting witness. Also 'Unfair to Genius' came that I want to read for the rest of the day. Quantum class tomorrow.",
  "id" : 781222082101309440,
  "created_at" : "2016-09-28 20:00:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781220860199919616",
  "text" : "I voted today by absentee for Joe Donnelly. A pro life, against guns democrat I may vote republican next time.",
  "id" : 781220860199919616,
  "created_at" : "2016-09-28 19:55:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/EGgSBGVJAs",
      "expanded_url" : "http:\/\/www.informationweek.com\/cloud\/8-reasons-it-pros-hate-the-cloud\/d\/d-id\/1320531",
      "display_url" : "informationweek.com\/cloud\/8-reason\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781220231616290816",
  "text" : "https:\/\/t.co\/EGgSBGVJAs Why IT pros hate the cloud.",
  "id" : 781220231616290816,
  "created_at" : "2016-09-28 19:53:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Verge",
      "screen_name" : "verge",
      "indices" : [ 102, 108 ],
      "id_str" : "275686563",
      "id" : 275686563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/Skiwgd3B8e",
      "expanded_url" : "http:\/\/www.theverge.com\/2014\/4\/15\/5619182\/android-design-head-matias-duarte-says-mobile-is-dead?utm_campaign=theverge&utm_content=entry&utm_medium=social&utm_source=twitter",
      "display_url" : "theverge.com\/2014\/4\/15\/5619\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781220028389744640",
  "text" : "Watch this: Android design head Matias Duarte explains why mobile is dead https:\/\/t.co\/Skiwgd3B8e via @Verge",
  "id" : 781220028389744640,
  "created_at" : "2016-09-28 19:52:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 0, 6 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781078333123616768",
  "in_reply_to_user_id" : 1536791610,
  "text" : "@POTUS Mr. President all of the local women are blocking me for using my brain. And treating me like Kurt Cobain or Aaron Schwartz.",
  "id" : 781078333123616768,
  "created_at" : "2016-09-28 10:29:21 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/CPJiOYVhRD",
      "expanded_url" : "https:\/\/twitter.com\/UVA\/status\/780844726907994112",
      "display_url" : "twitter.com\/UVA\/status\/780\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780849587871440897",
  "text" : "There is a seed in me isn't there? I can't tolerate the public or competition anymore can I? https:\/\/t.co\/CPJiOYVhRD",
  "id" : 780849587871440897,
  "created_at" : "2016-09-27 19:20:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 3, 6 ],
      "id_str" : "51241574",
      "id" : 51241574
    }, {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 29, 32 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780849098790465536",
  "text" : "RT @AP: COMING WEDNESDAY: An @AP investigation finds police misuse databases to check out women, politicians, celebrities and journalists.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Associated Press",
        "screen_name" : "AP",
        "indices" : [ 21, 24 ],
        "id_str" : "51241574",
        "id" : 51241574
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AP\/status\/780844799016435714\/video\/1",
        "indices" : [ 131, 154 ],
        "url" : "https:\/\/t.co\/LaSi0KYgDR",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/780844744083697665\/pu\/img\/6OYSRu6bgJnYjMC1.jpg",
        "id_str" : "780844744083697665",
        "id" : 780844744083697665,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/780844744083697665\/pu\/img\/6OYSRu6bgJnYjMC1.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/LaSi0KYgDR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780844799016435714",
    "text" : "COMING WEDNESDAY: An @AP investigation finds police misuse databases to check out women, politicians, celebrities and journalists. https:\/\/t.co\/LaSi0KYgDR",
    "id" : 780844799016435714,
    "created_at" : "2016-09-27 19:01:22 +0000",
    "user" : {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "protected" : false,
      "id_str" : "51241574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461964160838803457\/8z9FImcv_normal.png",
      "id" : 51241574,
      "verified" : true
    }
  },
  "id" : 780849098790465536,
  "created_at" : "2016-09-27 19:18:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruin Report Online",
      "screen_name" : "BruinReport",
      "indices" : [ 3, 15 ],
      "id_str" : "789808844",
      "id" : 789808844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCLA",
      "indices" : [ 39, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/jwkuT6q5P1",
      "expanded_url" : "http:\/\/www.scout.com\/college\/ucla\/story\/1710339-jim-mora-after-stanford-game",
      "display_url" : "scout.com\/college\/ucla\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780848503065047040",
  "text" : "RT @BruinReport: Jim Mora talked after #UCLA's heartbreaking loss to Stanford. https:\/\/t.co\/jwkuT6q5P1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UCLA",
        "indices" : [ 22, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/jwkuT6q5P1",
        "expanded_url" : "http:\/\/www.scout.com\/college\/ucla\/story\/1710339-jim-mora-after-stanford-game",
        "display_url" : "scout.com\/college\/ucla\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779894480354672641",
    "text" : "Jim Mora talked after #UCLA's heartbreaking loss to Stanford. https:\/\/t.co\/jwkuT6q5P1",
    "id" : 779894480354672641,
    "created_at" : "2016-09-25 04:05:08 +0000",
    "user" : {
      "name" : "Bruin Report Online",
      "screen_name" : "BruinReport",
      "protected" : false,
      "id_str" : "789808844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512466212874248192\/y_6tUPai_normal.jpeg",
      "id" : 789808844,
      "verified" : false
    }
  },
  "id" : 780848503065047040,
  "created_at" : "2016-09-27 19:16:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 0, 6 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780578475849711616",
  "in_reply_to_user_id" : 1536791610,
  "text" : "@POTUS I do have my money now and past and current credentials. Probably better than anyone in the area can I have Cady Forgey of ETSU?",
  "id" : 780578475849711616,
  "created_at" : "2016-09-27 01:23:05 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Warner",
      "screen_name" : "MarkWarner",
      "indices" : [ 0, 11 ],
      "id_str" : "7429102",
      "id" : 7429102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780573329308655616",
  "in_reply_to_user_id" : 7429102,
  "text" : "@MarkWarner There would be a lot less violence in America and college graduates if prostitution was legal. Can it be?",
  "id" : 780573329308655616,
  "created_at" : "2016-09-27 01:02:38 +0000",
  "in_reply_to_screen_name" : "MarkWarner",
  "in_reply_to_user_id_str" : "7429102",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780517477461753858",
  "text" : "Mensa is enough.",
  "id" : 780517477461753858,
  "created_at" : "2016-09-26 21:20:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780517419345408002",
  "text" : "Tomorrow I am telling my manager how powerful I could be if I wanted at 7 am. It is about a girl too. I might tell the bank the same.",
  "id" : 780517419345408002,
  "created_at" : "2016-09-26 21:20:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780489133068288002",
  "text" : "It is over everyone I can become the biggest name on Twitter because I'm a programmer too.",
  "id" : 780489133068288002,
  "created_at" : "2016-09-26 19:28:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780485886614048769",
  "text" : "I though Mensa was enough but now I guess I do have to take on idiots as well.",
  "id" : 780485886614048769,
  "created_at" : "2016-09-26 19:15:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780485153642733572",
  "text" : "I may just tweet 'About A Girl' and become the biggest name on Twitter. Try me.",
  "id" : 780485153642733572,
  "created_at" : "2016-09-26 19:12:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/YykdEsTBtw",
      "expanded_url" : "https:\/\/twitter.com\/guardian\/status\/780481778192683010",
      "display_url" : "twitter.com\/guardian\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780483929971257344",
  "text" : "The beauty is is food and health In America now. https:\/\/t.co\/YykdEsTBtw",
  "id" : 780483929971257344,
  "created_at" : "2016-09-26 19:07:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NFLBoycott",
      "indices" : [ 23, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780481952595976192",
  "text" : "Bring it sports fan!!! #NFLBoycott",
  "id" : 780481952595976192,
  "created_at" : "2016-09-26 18:59:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 40, 47 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/UdLhtprjot",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/carolinehoward\/2015\/07\/29\/americas-top-colleges-2015\/#193f88364eed",
      "display_url" : "forbes.com\/sites\/caroline\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780478248773881856",
  "text" : "America's Top Colleges Ranking 2015 via @forbes https:\/\/t.co\/UdLhtprjot 2nd in the country jdm7dv@virginia.edu",
  "id" : 780478248773881856,
  "created_at" : "2016-09-26 18:44:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RT\u00C9",
      "screen_name" : "rte",
      "indices" : [ 75, 79 ],
      "id_str" : "1245699895",
      "id" : 1245699895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/gy9kjtNfjO",
      "expanded_url" : "http:\/\/www.rte.ie\/news\/2016\/0923\/818777-twitter-shares\/",
      "display_url" : "rte.ie\/news\/2016\/0923\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780476876573769728",
  "text" : "Twitter shares soar on report of possible sale https:\/\/t.co\/gy9kjtNfjO via @rte",
  "id" : 780476876573769728,
  "created_at" : "2016-09-26 18:39:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETSU",
      "indices" : [ 47, 52 ]
    }, {
      "text" : "WJHL",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780475747060293632",
  "text" : "Time to compete Johnson City TN, ETSU and WJHL.#ETSU and #WJHL",
  "id" : 780475747060293632,
  "created_at" : "2016-09-26 18:34:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780474157653958656",
  "text" : "Unfair to Genius: The Strange and Litigious Career of Ira B. Arnstein by Gary... This is all I'm reading soon Tri-Cities.",
  "id" : 780474157653958656,
  "created_at" : "2016-09-26 18:28:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 75, 83 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/nRXUJ4hzvu",
      "expanded_url" : "https:\/\/youtu.be\/xz7w_Ut12fY",
      "display_url" : "youtu.be\/xz7w_Ut12fY"
    } ]
  },
  "geo" : { },
  "id_str" : "780467814117306368",
  "text" : "Nine Inch Nails - All Time Low (VEVO Presents) https:\/\/t.co\/nRXUJ4hzvu via @YouTube",
  "id" : 780467814117306368,
  "created_at" : "2016-09-26 18:03:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 79, 87 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/YllzVgN1f9",
      "expanded_url" : "https:\/\/youtu.be\/xUXVE4GEwmc",
      "display_url" : "youtu.be\/xUXVE4GEwmc"
    } ]
  },
  "geo" : { },
  "id_str" : "780462847973359617",
  "text" : "U2   Love Is Blindness (ZOO TV Live in Sydney).mp4 https:\/\/t.co\/YllzVgN1f9 via @YouTube",
  "id" : 780462847973359617,
  "created_at" : "2016-09-26 17:43:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 60, 68 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/PohGkzlpVl",
      "expanded_url" : "https:\/\/youtu.be\/AjrlWA2yWtU",
      "display_url" : "youtu.be\/AjrlWA2yWtU"
    } ]
  },
  "geo" : { },
  "id_str" : "780458287892422656",
  "text" : "Nirvana - About A Girl - Bleach https:\/\/t.co\/PohGkzlpVl via @YouTube",
  "id" : 780458287892422656,
  "created_at" : "2016-09-26 17:25:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Abend",
      "screen_name" : "AngelaAbend",
      "indices" : [ 3, 15 ],
      "id_str" : "2861829177",
      "id" : 2861829177
    }, {
      "name" : "SENG",
      "screen_name" : "SENG_Gifted",
      "indices" : [ 83, 95 ],
      "id_str" : "149552483",
      "id" : 149552483
    }, {
      "name" : "NAGC",
      "screen_name" : "NAGCGIFTED",
      "indices" : [ 96, 107 ],
      "id_str" : "52407188",
      "id" : 52407188
    }, {
      "name" : "Carol Bainbridge",
      "screen_name" : "Giftedkidsguide",
      "indices" : [ 108, 124 ],
      "id_str" : "22681573",
      "id" : 22681573
    }, {
      "name" : "Daily Gifted",
      "screen_name" : "DailyGifted",
      "indices" : [ 125, 137 ],
      "id_str" : "975506892",
      "id" : 975506892
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gtchat",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/kJdUg7wYrp",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=_kTQx93k60E",
      "display_url" : "youtube.com\/watch?v=_kTQx9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780456835513999360",
  "text" : "RT @AngelaAbend: In a nutshell ... worth the look:\nhttps:\/\/t.co\/kJdUg7wYrp\n#gtchat @SENG_Gifted @NAGCGIFTED @Giftedkidsguide @DailyGifted @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SENG",
        "screen_name" : "SENG_Gifted",
        "indices" : [ 66, 78 ],
        "id_str" : "149552483",
        "id" : 149552483
      }, {
        "name" : "NAGC",
        "screen_name" : "NAGCGIFTED",
        "indices" : [ 79, 90 ],
        "id_str" : "52407188",
        "id" : 52407188
      }, {
        "name" : "Carol Bainbridge",
        "screen_name" : "Giftedkidsguide",
        "indices" : [ 91, 107 ],
        "id_str" : "22681573",
        "id" : 22681573
      }, {
        "name" : "Daily Gifted",
        "screen_name" : "DailyGifted",
        "indices" : [ 108, 120 ],
        "id_str" : "975506892",
        "id" : 975506892
      }, {
        "name" : "Diane Provvido",
        "screen_name" : "DianeProvvido",
        "indices" : [ 121, 135 ],
        "id_str" : "58446098",
        "id" : 58446098
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gtchat",
        "indices" : [ 58, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/kJdUg7wYrp",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=_kTQx93k60E",
        "display_url" : "youtube.com\/watch?v=_kTQx9\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "767676310206513152",
    "text" : "In a nutshell ... worth the look:\nhttps:\/\/t.co\/kJdUg7wYrp\n#gtchat @SENG_Gifted @NAGCGIFTED @Giftedkidsguide @DailyGifted @DianeProvvido",
    "id" : 767676310206513152,
    "created_at" : "2016-08-22 10:54:29 +0000",
    "user" : {
      "name" : "Angela Abend",
      "screen_name" : "AngelaAbend",
      "protected" : false,
      "id_str" : "2861829177",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800056083620343808\/2_bNDm0-_normal.jpg",
      "id" : 2861829177,
      "verified" : false
    }
  },
  "id" : 780456835513999360,
  "created_at" : "2016-09-26 17:19:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/HxVK7SYn84",
      "expanded_url" : "http:\/\/www.jonathanmoore.net",
      "display_url" : "jonathanmoore.net"
    } ]
  },
  "geo" : { },
  "id_str" : "779883107637919744",
  "text" : "I am https:\/\/t.co\/HxVK7SYn84  aren't I Bing. You do just want to play big brother don't you Microsoft with Drawbridge.",
  "id" : 779883107637919744,
  "created_at" : "2016-09-25 03:19:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/5vp7GAxisD",
      "expanded_url" : "http:\/\/www.bradmagnus.com\/",
      "display_url" : "bradmagnus.com"
    } ]
  },
  "geo" : { },
  "id_str" : "779879838337425409",
  "text" : "https:\/\/t.co\/5vp7GAxisD Brad you only had a User Group. And this is sold to someone else.",
  "id" : 779879838337425409,
  "created_at" : "2016-09-25 03:06:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779877855828271104",
  "text" : "I did turn off my smart screen Microsoft.",
  "id" : 779877855828271104,
  "created_at" : "2016-09-25 02:59:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/m6GOqtwKhU",
      "expanded_url" : "https:\/\/www.gigsalad.com\/Music-Groups\/Cover-Band\/TN\/Kingsport",
      "display_url" : "gigsalad.com\/Music-Groups\/C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779873339917606912",
  "text" : "https:\/\/t.co\/m6GOqtwKhU Cover bands Tri-Cities and I'm kinda laughing at you.",
  "id" : 779873339917606912,
  "created_at" : "2016-09-25 02:41:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779872561396056064",
  "text" : "Who else is is the Tri Cities TN\/VA that is as good as me at what I do? That's right nobody.",
  "id" : 779872561396056064,
  "created_at" : "2016-09-25 02:38:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779871947853271040",
  "text" : "World I have blown your mind with what I say stop looking for someone new all the time.",
  "id" : 779871947853271040,
  "created_at" : "2016-09-25 02:35:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/q5uuT0dpK7",
      "expanded_url" : "https:\/\/youtu.be\/5R682M3ZEyk",
      "display_url" : "youtu.be\/5R682M3ZEyk"
    } ]
  },
  "geo" : { },
  "id_str" : "779870899227033600",
  "text" : "Marilyn Manson - The Dope Show https:\/\/t.co\/q5uuT0dpK7 via @YouTube Dedicated to Abingdon.",
  "id" : 779870899227033600,
  "created_at" : "2016-09-25 02:31:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/JNmZyL2vR9",
      "expanded_url" : "https:\/\/youtu.be\/Sboh-_w43W8",
      "display_url" : "youtu.be\/Sboh-_w43W8"
    } ]
  },
  "geo" : { },
  "id_str" : "779870044494950401",
  "text" : "The Secret of Oz by Bill Still https:\/\/t.co\/JNmZyL2vR9 via @YouTube\nGrant I told this to the President and a lot of other people.",
  "id" : 779870044494950401,
  "created_at" : "2016-09-25 02:28:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779868444170813440",
  "text" : "Grant they want me to file a missing person's report for Kady and I just won't do it all of these women drop me because of jealous men.",
  "id" : 779868444170813440,
  "created_at" : "2016-09-25 02:21:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 3, 6 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/HlrPJiwNyT",
      "expanded_url" : "http:\/\/apne.ws\/2cRN9gu",
      "display_url" : "apne.ws\/2cRN9gu"
    } ]
  },
  "geo" : { },
  "id_str" : "779866962889433088",
  "text" : "RT @AP: Doubts remain after Charlotte police shooting video released. https:\/\/t.co\/HlrPJiwNyT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/HlrPJiwNyT",
        "expanded_url" : "http:\/\/apne.ws\/2cRN9gu",
        "display_url" : "apne.ws\/2cRN9gu"
      } ]
    },
    "geo" : { },
    "id_str" : "779857022825226240",
    "text" : "Doubts remain after Charlotte police shooting video released. https:\/\/t.co\/HlrPJiwNyT",
    "id" : 779857022825226240,
    "created_at" : "2016-09-25 01:36:17 +0000",
    "user" : {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "protected" : false,
      "id_str" : "51241574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461964160838803457\/8z9FImcv_normal.png",
      "id" : 51241574,
      "verified" : true
    }
  },
  "id" : 779866962889433088,
  "created_at" : "2016-09-25 02:15:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779865844776132608",
  "text" : "They do just drop me and disappear too. After seeing a bunch of intelligence. They always have I can't help it.",
  "id" : 779865844776132608,
  "created_at" : "2016-09-25 02:11:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779865393582178305",
  "text" : "Grant all I'm doing is using my brain on these social networks. If these women just can't take it I can't help that..",
  "id" : 779865393582178305,
  "created_at" : "2016-09-25 02:09:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779864181138939905",
  "text" : "I may call you Grant I would like to know what happened to me.",
  "id" : 779864181138939905,
  "created_at" : "2016-09-25 02:04:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779863889475465217",
  "text" : "I'm clean Grant except maybe for some torrents. No drugs except for prescription, No alcohol no smoking. No porn No women under age.",
  "id" : 779863889475465217,
  "created_at" : "2016-09-25 02:03:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779862118610956289",
  "text" : "When you are as big as me you really can't trust the local authorities. You do have to do out of jurisdiction.",
  "id" : 779862118610956289,
  "created_at" : "2016-09-25 01:56:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779860116434784256",
  "text" : "I see these Abingdon cop cars parked at apartments probably fucking prostitutes.",
  "id" : 779860116434784256,
  "created_at" : "2016-09-25 01:48:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779859001387474945",
  "text" : "Dr. Abaletta I wanna know why you thought my next album might be like In utero and I'm kinda laughing at you",
  "id" : 779859001387474945,
  "created_at" : "2016-09-25 01:44:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Grant",
      "screen_name" : "tomgrantpi",
      "indices" : [ 3, 14 ],
      "id_str" : "30269153",
      "id" : 30269153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/s3zUsQJSCs",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=SYPx7SGUDyU",
      "display_url" : "youtube.com\/watch?v=SYPx7S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779853542781755393",
  "text" : "RT @tomgrantpi: Just posted on YouTube. Dr. Wecht's revealing television interview: https:\/\/t.co\/s3zUsQJSCs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/s3zUsQJSCs",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=SYPx7SGUDyU",
        "display_url" : "youtube.com\/watch?v=SYPx7S\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761275793150324736",
    "text" : "Just posted on YouTube. Dr. Wecht's revealing television interview: https:\/\/t.co\/s3zUsQJSCs",
    "id" : 761275793150324736,
    "created_at" : "2016-08-04 19:01:07 +0000",
    "user" : {
      "name" : "Tom Grant",
      "screen_name" : "tomgrantpi",
      "protected" : false,
      "id_str" : "30269153",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724632984196812802\/-lJ0wXio_normal.jpg",
      "id" : 30269153,
      "verified" : false
    }
  },
  "id" : 779853542781755393,
  "created_at" : "2016-09-25 01:22:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/CqXYGqLCVs",
      "expanded_url" : "http:\/\/www.cobaincase.com\/",
      "display_url" : "cobaincase.com"
    } ]
  },
  "geo" : { },
  "id_str" : "779849560243961856",
  "text" : "https:\/\/t.co\/CqXYGqLCVs I want this out.",
  "id" : 779849560243961856,
  "created_at" : "2016-09-25 01:06:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779847744512987136",
  "text" : "Courtney you did just jack up Dylan so he couldn't be questioned.",
  "id" : 779847744512987136,
  "created_at" : "2016-09-25 00:59:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779846653499039744",
  "text" : "Kurt's stomach was getting better he wasn't even suicidal.",
  "id" : 779846653499039744,
  "created_at" : "2016-09-25 00:55:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779845790084759552",
  "text" : "Wanna kill someone kill a junkie. See I am in cognitive therapy because of what America just won't do.",
  "id" : 779845790084759552,
  "created_at" : "2016-09-25 00:51:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Courtney Love Cobain",
      "screen_name" : "Courtney",
      "indices" : [ 0, 9 ],
      "id_str" : "43522180",
      "id" : 43522180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779841803348484096",
  "in_reply_to_user_id" : 43522180,
  "text" : "@Courtney Just watched 'soaked in bleach' people would like to know what happened to Kurt.",
  "id" : 779841803348484096,
  "created_at" : "2016-09-25 00:35:49 +0000",
  "in_reply_to_screen_name" : "Courtney",
  "in_reply_to_user_id_str" : "43522180",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779839435340996608",
  "text" : "BMI I really don't want to know Courtney Love right now either.",
  "id" : 779839435340996608,
  "created_at" : "2016-09-25 00:26:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779836239675621376",
  "text" : "See Abingdon explosion possibility \"Your town is next\".",
  "id" : 779836239675621376,
  "created_at" : "2016-09-25 00:13:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779835495421542401",
  "text" : "My dad sames to know a lot about Cobain too and he never told me I'm a little suspicious of him too.",
  "id" : 779835495421542401,
  "created_at" : "2016-09-25 00:10:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779834513585307648",
  "text" : "I called 911 one time and the Abingdon Police never showed.",
  "id" : 779834513585307648,
  "created_at" : "2016-09-25 00:06:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779833520378220544",
  "text" : "Open source is worth billions if you use your brain. Net Worth= equity= shares. And put it in an IRA. You can withdraw early I hope.",
  "id" : 779833520378220544,
  "created_at" : "2016-09-25 00:02:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779832264654000128",
  "text" : "I don't want a cease and desist order form Courtney Love. I can't say anything else. Ask Tom Grant.",
  "id" : 779832264654000128,
  "created_at" : "2016-09-24 23:57:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779831421737336833",
  "text" : "And Abingdon police I'm on you for almost causing a copycat suicide.",
  "id" : 779831421737336833,
  "created_at" : "2016-09-24 23:54:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779830931028844544",
  "text" : "I will say one more thing Rosemary I heard the tapes don't lie.",
  "id" : 779830931028844544,
  "created_at" : "2016-09-24 23:52:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779829976212312068",
  "text" : "Just watched 'Soaked in Bleach' Courtney Kurt was leaving you you did inherent billions and there was a motive.That's all I can say.",
  "id" : 779829976212312068,
  "created_at" : "2016-09-24 23:48:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBC News",
      "screen_name" : "NBCNews",
      "indices" : [ 94, 102 ],
      "id_str" : "14173315",
      "id" : 14173315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/8ENNZxZWyI",
      "expanded_url" : "http:\/\/nbcnews.to\/2cXyIbJ",
      "display_url" : "nbcnews.to\/2cXyIbJ"
    } ]
  },
  "geo" : { },
  "id_str" : "779427773953806336",
  "text" : "President Obama vetoes bill to let 9\/11 families sue Saudi Arabia https:\/\/t.co\/8ENNZxZWyI via @nbcnews",
  "id" : 779427773953806336,
  "created_at" : "2016-09-23 21:10:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 0, 11 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779278492479393793",
  "in_reply_to_user_id" : 30313925,
  "text" : "@WhiteHouse Everyone do watch the 'Sercet of Oz' on You Tube. I really don't know why our government is in debt.",
  "id" : 779278492479393793,
  "created_at" : "2016-09-23 11:17:25 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/pECrdgiJrJ",
      "expanded_url" : "https:\/\/www.shrm.org\/hr-today\/news\/hr-magazine\/Pages\/0412tyler2.aspx",
      "display_url" : "shrm.org\/hr-today\/news\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779022566644183041",
  "text" : "What a Corporate University Is and Is Not https:\/\/t.co\/pECrdgiJrJ",
  "id" : 779022566644183041,
  "created_at" : "2016-09-22 18:20:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779010659241590784",
  "text" : "I won't date anyone under 23-25.",
  "id" : 779010659241590784,
  "created_at" : "2016-09-22 17:33:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778750763619057664",
  "text" : "I do just get the classic story about is it legal to create an Mac OS X VM in Virtual Box it is.",
  "id" : 778750763619057664,
  "created_at" : "2016-09-22 00:20:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/OQzXbIEcMt",
      "expanded_url" : "http:\/\/www.wikihow.com\/Install-Ubuntu-on-VirtualBox",
      "display_url" : "wikihow.com\/Install-Ubuntu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778747718277619712",
  "text" : "How to Install Ubuntu on VirtualBox https:\/\/t.co\/OQzXbIEcMt",
  "id" : 778747718277619712,
  "created_at" : "2016-09-22 00:08:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 72, 80 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/QKXVznGOlG",
      "expanded_url" : "https:\/\/youtu.be\/vEcJuliraw8",
      "display_url" : "youtu.be\/vEcJuliraw8"
    } ]
  },
  "geo" : { },
  "id_str" : "778745663546732544",
  "text" : "Abstract Art | Photoshop Tutorial | click3d https:\/\/t.co\/QKXVznGOlG via @YouTube",
  "id" : 778745663546732544,
  "created_at" : "2016-09-22 00:00:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/7kj8p8mQOT",
      "expanded_url" : "http:\/\/fineartamerica.com\/shop\/canvas+prints\/digital+art",
      "display_url" : "fineartamerica.com\/shop\/canvas+pr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778745043582529536",
  "text" : "https:\/\/t.co\/7kj8p8mQOT It is Digital Art too. William King.",
  "id" : 778745043582529536,
  "created_at" : "2016-09-21 23:57:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778742683112124416",
  "text" : "Some of the different OSes have the same projects too and maintainers the Open Source world isn't as big as you thought.",
  "id" : 778742683112124416,
  "created_at" : "2016-09-21 23:48:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778741553778991104",
  "text" : "That was just 600GB I do have two 5 terabyte drives.",
  "id" : 778741553778991104,
  "created_at" : "2016-09-21 23:43:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/QyVr44Ulpa",
      "expanded_url" : "https:\/\/help.ubuntu.com\/community\/Rsyncmirror",
      "display_url" : "help.ubuntu.com\/community\/Rsyn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778740773751709696",
  "text" : "https:\/\/t.co\/QyVr44Ulpa Here everyone here is some of the Open Source world you don't own it you can have a copy.",
  "id" : 778740773751709696,
  "created_at" : "2016-09-21 23:40:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778739128154238976",
  "text" : "Dad I know you've worked hard and are retired now I do respect that but what I have is worth alot.",
  "id" : 778739128154238976,
  "created_at" : "2016-09-21 23:34:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778737372045258752",
  "text" : "When I start to say I'm worth a lot of money that's when they take me in for treatment. Or prescreened poor SWVA.",
  "id" : 778737372045258752,
  "created_at" : "2016-09-21 23:27:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778737109431496704",
  "text" : "That bank and my manager will just treat me like I'm small too And I don't like that.",
  "id" : 778737109431496704,
  "created_at" : "2016-09-21 23:26:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778735842864996352",
  "text" : "Women do just push you for immortality too. And I've had it, maybe 120 years right now.",
  "id" : 778735842864996352,
  "created_at" : "2016-09-21 23:21:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778735373480361984",
  "text" : "DSP is math and music and VST and audio effects too. I'm just not telling you THE book yet.",
  "id" : 778735373480361984,
  "created_at" : "2016-09-21 23:19:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/CC3XlxPnmO",
      "expanded_url" : "https:\/\/www.propellerheads.se\/substance\/record-u\/index.cfm?fuseaction=display_main",
      "display_url" : "propellerheads.se\/substance\/reco\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778734462762819589",
  "text" : "https:\/\/t.co\/CC3XlxPnmO Record University and Propeperhead is proprietary for now and social reproduction is academically defined.",
  "id" : 778734462762819589,
  "created_at" : "2016-09-21 23:15:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778732000932876289",
  "text" : "I don't mean to be that high as in money but I probably have as much source as Bill Gates I think of him a lot.",
  "id" : 778732000932876289,
  "created_at" : "2016-09-21 23:05:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778730913727295493",
  "text" : "If I see anymore white and blue I'll just hurl.",
  "id" : 778730913727295493,
  "created_at" : "2016-09-21 23:01:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Community Grid",
      "screen_name" : "WCGrid",
      "indices" : [ 3, 10 ],
      "id_str" : "26388412",
      "id" : 26388412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778730591361519616",
  "text" : "RT @WCGrid: \"Life gives you a test of survival, and then lets you handle it\" Volunteer shares experience w\/childhood cancer https:\/\/t.co\/sA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/sAeFvbBqTb",
        "expanded_url" : "http:\/\/ow.ly\/YHvp304rbZN",
        "display_url" : "ow.ly\/YHvp304rbZN"
      } ]
    },
    "geo" : { },
    "id_str" : "778698450263117824",
    "text" : "\"Life gives you a test of survival, and then lets you handle it\" Volunteer shares experience w\/childhood cancer https:\/\/t.co\/sAeFvbBqTb",
    "id" : 778698450263117824,
    "created_at" : "2016-09-21 20:52:32 +0000",
    "user" : {
      "name" : "World Community Grid",
      "screen_name" : "WCGrid",
      "protected" : false,
      "id_str" : "26388412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448919987281866752\/T4oA5jtc_normal.png",
      "id" : 26388412,
      "verified" : false
    }
  },
  "id" : 778730591361519616,
  "created_at" : "2016-09-21 23:00:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Propellerhead",
      "screen_name" : "PropellerheadSW",
      "indices" : [ 3, 19 ],
      "id_str" : "22631376",
      "id" : 22631376
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReasonQuickTip",
      "indices" : [ 111, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778730062484942848",
  "text" : "RT @PropellerheadSW: Here's how to quickly assign your MIDI controller to any knob in Reason! What's your best #ReasonQuickTip? https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PropellerheadSW\/status\/778706647187202052\/video\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/69izgXltxR",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/778705409498505218\/pu\/img\/EqplpF3DJ5AzRr9n.jpg",
        "id_str" : "778705409498505218",
        "id" : 778705409498505218,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/778705409498505218\/pu\/img\/EqplpF3DJ5AzRr9n.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/69izgXltxR"
      } ],
      "hashtags" : [ {
        "text" : "ReasonQuickTip",
        "indices" : [ 90, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778706647187202052",
    "text" : "Here's how to quickly assign your MIDI controller to any knob in Reason! What's your best #ReasonQuickTip? https:\/\/t.co\/69izgXltxR",
    "id" : 778706647187202052,
    "created_at" : "2016-09-21 21:25:07 +0000",
    "user" : {
      "name" : "Propellerhead",
      "screen_name" : "PropellerheadSW",
      "protected" : false,
      "id_str" : "22631376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558288234363367424\/qChNU38G_normal.png",
      "id" : 22631376,
      "verified" : true
    }
  },
  "id" : 778730062484942848,
  "created_at" : "2016-09-21 22:58:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/PGcJIELMp9",
      "expanded_url" : "https:\/\/twitter.com\/LifeExtension\/status\/778717781340499970",
      "display_url" : "twitter.com\/LifeExtension\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778729811128705024",
  "text" : "I did try these and I really couldn't tell a difference yet maybe I was too young. https:\/\/t.co\/PGcJIELMp9",
  "id" : 778729811128705024,
  "created_at" : "2016-09-21 22:57:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778728674581327872",
  "text" : "I am keeping my domain. I don't mezan to be that narcissistic. I might think of something else on my website..",
  "id" : 778728674581327872,
  "created_at" : "2016-09-21 22:52:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778727280893759488",
  "text" : "And when you follow Steinberg or Propellerhead you are following me.",
  "id" : 778727280893759488,
  "created_at" : "2016-09-21 22:47:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778727257669894144",
  "text" : "Nobody has to follow me I want to follow larges groups of people. Like Companies.",
  "id" : 778727257669894144,
  "created_at" : "2016-09-21 22:47:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adobe Open Source",
      "screen_name" : "OpenatAdobe",
      "indices" : [ 3, 15 ],
      "id_str" : "153496712",
      "id" : 153496712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/Bl7AgJ07w1",
      "expanded_url" : "http:\/\/github.com\/adobe\/node-smb-server",
      "display_url" : "github.com\/adobe\/node-smb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778725989073362949",
  "text" : "RT @OpenatAdobe: Introducing: node-smb-server, a pure JavaScript SMB server implementation.  Check it out: https:\/\/t.co\/Bl7AgJ07w1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/Bl7AgJ07w1",
        "expanded_url" : "http:\/\/github.com\/adobe\/node-smb-server",
        "display_url" : "github.com\/adobe\/node-smb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "778721459585691649",
    "text" : "Introducing: node-smb-server, a pure JavaScript SMB server implementation.  Check it out: https:\/\/t.co\/Bl7AgJ07w1",
    "id" : 778721459585691649,
    "created_at" : "2016-09-21 22:23:58 +0000",
    "user" : {
      "name" : "Adobe Open Source",
      "screen_name" : "OpenatAdobe",
      "protected" : false,
      "id_str" : "153496712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1099852711\/thumb_normal.png",
      "id" : 153496712,
      "verified" : false
    }
  },
  "id" : 778725989073362949,
  "created_at" : "2016-09-21 22:41:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778725928947945472",
  "text" : "It is time for me to just art doing my mathematics and stay off of the computer some if I can I do use Maple and Matlab.",
  "id" : 778725928947945472,
  "created_at" : "2016-09-21 22:41:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/iFiQZi4yEN",
      "expanded_url" : "http:\/\/www.innovasiancuisine.com\/",
      "display_url" : "innovasiancuisine.com"
    } ]
  },
  "geo" : { },
  "id_str" : "778724851087388672",
  "text" : "https:\/\/t.co\/iFiQZi4yEN Lowest amount of sodium of the Asian cuisines in Food City.",
  "id" : 778724851087388672,
  "created_at" : "2016-09-21 22:37:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mayo Clinic",
      "screen_name" : "MayoClinic",
      "indices" : [ 3, 14 ],
      "id_str" : "14592723",
      "id" : 14592723
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MayoClinic\/status\/778720539070255104\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/NObwXtLecN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs6SM7VVYAY_OUi.jpg",
      "id_str" : "778720536364933126",
      "id" : 778720536364933126,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs6SM7VVYAY_OUi.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/NObwXtLecN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/gjH3K2yB1d",
      "expanded_url" : "http:\/\/mayocl.in\/2d2rL8f",
      "display_url" : "mayocl.in\/2d2rL8f"
    } ]
  },
  "geo" : { },
  "id_str" : "778721673348427782",
  "text" : "RT @MayoClinic: Mayo Clinic remembers William Eugene Mayberry, M.D., former Mayo Clinic CEO https:\/\/t.co\/gjH3K2yB1d https:\/\/t.co\/NObwXtLecN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MayoClinic\/status\/778720539070255104\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/NObwXtLecN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs6SM7VVYAY_OUi.jpg",
        "id_str" : "778720536364933126",
        "id" : 778720536364933126,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs6SM7VVYAY_OUi.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/NObwXtLecN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/gjH3K2yB1d",
        "expanded_url" : "http:\/\/mayocl.in\/2d2rL8f",
        "display_url" : "mayocl.in\/2d2rL8f"
      } ]
    },
    "geo" : { },
    "id_str" : "778720539070255104",
    "text" : "Mayo Clinic remembers William Eugene Mayberry, M.D., former Mayo Clinic CEO https:\/\/t.co\/gjH3K2yB1d https:\/\/t.co\/NObwXtLecN",
    "id" : 778720539070255104,
    "created_at" : "2016-09-21 22:20:19 +0000",
    "user" : {
      "name" : "Mayo Clinic",
      "screen_name" : "MayoClinic",
      "protected" : false,
      "id_str" : "14592723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760454818422857728\/2WFm5vUI_normal.jpg",
      "id" : 14592723,
      "verified" : true
    }
  },
  "id" : 778721673348427782,
  "created_at" : "2016-09-21 22:24:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778721420285140992",
  "text" : "I just don't want to quit and say I'm retired I do like learning if I just had a wife to learn with. See she never learned with me.",
  "id" : 778721420285140992,
  "created_at" : "2016-09-21 22:23:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 3, 12 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/Qa4BTk6Yjt",
      "expanded_url" : "http:\/\/trib.al\/4hmPLm8",
      "display_url" : "trib.al\/4hmPLm8"
    } ]
  },
  "geo" : { },
  "id_str" : "778720023799926785",
  "text" : "RT @guardian: US tests reveal major TV manufacturers may be manipulating energy ratings https:\/\/t.co\/Qa4BTk6Yjt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/Qa4BTk6Yjt",
        "expanded_url" : "http:\/\/trib.al\/4hmPLm8",
        "display_url" : "trib.al\/4hmPLm8"
      } ]
    },
    "geo" : { },
    "id_str" : "778719797911531520",
    "text" : "US tests reveal major TV manufacturers may be manipulating energy ratings https:\/\/t.co\/Qa4BTk6Yjt",
    "id" : 778719797911531520,
    "created_at" : "2016-09-21 22:17:22 +0000",
    "user" : {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "protected" : false,
      "id_str" : "87818409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774191274391965696\/Tulf7lwN_normal.jpg",
      "id" : 87818409,
      "verified" : true
    }
  },
  "id" : 778720023799926785,
  "created_at" : "2016-09-21 22:18:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778719979357085696",
  "text" : "All they really have is \"screen\" not to give me what I need.",
  "id" : 778719979357085696,
  "created_at" : "2016-09-21 22:18:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778717149749587968",
  "text" : "And not just buy them a DVD player and a bunch of cartoons and leave them.",
  "id" : 778717149749587968,
  "created_at" : "2016-09-21 22:06:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778717020887977984",
  "text" : "I really don't mean to be mean to families but I do like foreign families that learn technology with their children.",
  "id" : 778717020887977984,
  "created_at" : "2016-09-21 22:06:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/vQ6jLvk4jx",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/559816\/how-to-export-and-import-environment-variables-in-windows",
      "display_url" : "stackoverflow.com\/questions\/5598\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778715320810819584",
  "text" : "https:\/\/t.co\/vQ6jLvk4jx Exporting Windows Environment variables and merge.",
  "id" : 778715320810819584,
  "created_at" : "2016-09-21 21:59:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778713639536566273",
  "text" : "I just don't want the developers Windows to die. That's not how I was brought up.",
  "id" : 778713639536566273,
  "created_at" : "2016-09-21 21:52:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778713255724191744",
  "text" : "Maybe I will like Windows 10. and the new Control Panel. I do know that the environment variables editor got an improvement.",
  "id" : 778713255724191744,
  "created_at" : "2016-09-21 21:51:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778712412174200834",
  "text" : "I had a Chili's Fajita bowl and fried rice maybe a little bit more sodium than I needed.",
  "id" : 778712412174200834,
  "created_at" : "2016-09-21 21:48:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778711560399179776",
  "text" : "See All these beauty products for women and none for men doctor.",
  "id" : 778711560399179776,
  "created_at" : "2016-09-21 21:44:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778708978658217984",
  "text" : "Bigger the castle more rooms she can cheat on you in.",
  "id" : 778708978658217984,
  "created_at" : "2016-09-21 21:34:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778708543247519745",
  "text" : "You do have to make a decision Big America and big houses that you'll never be able to maintain. Or A lot of technology and education.",
  "id" : 778708543247519745,
  "created_at" : "2016-09-21 21:32:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778707665383886848",
  "text" : "Now I know why Windows Media Center got the boot Heart Disease.",
  "id" : 778707665383886848,
  "created_at" : "2016-09-21 21:29:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Olc27okdhD",
      "expanded_url" : "http:\/\/empirenews.net\/google-to-buy-facebook-in-first-1-trillion-acquisition\/",
      "display_url" : "empirenews.net\/google-to-buy-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778700455639560192",
  "text" : "https:\/\/t.co\/Olc27okdhD Is this real?",
  "id" : 778700455639560192,
  "created_at" : "2016-09-21 21:00:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778699847884865536",
  "text" : "Google logged me in Facebook when you lost my email and password.",
  "id" : 778699847884865536,
  "created_at" : "2016-09-21 20:58:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778696550721564673",
  "text" : "It is pronounced DIE-COM isn't it.",
  "id" : 778696550721564673,
  "created_at" : "2016-09-21 20:44:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Williams-Sonoma",
      "screen_name" : "WilliamsSonoma",
      "indices" : [ 3, 18 ],
      "id_str" : "29247574",
      "id" : 29247574
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WilliamsSonoma\/status\/778685234715893761\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/r9yaXoVoT6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs5yF7eUEAAGKh6.jpg",
      "id_str" : "778685231771422720",
      "id" : 778685231771422720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs5yF7eUEAAGKh6.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 711,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 711,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 711,
        "resize" : "fit",
        "w" : 474
      } ],
      "display_url" : "pic.twitter.com\/r9yaXoVoT6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/XDdsYiCZH0",
      "expanded_url" : "http:\/\/wsono.ma\/6017B7aef",
      "display_url" : "wsono.ma\/6017B7aef"
    } ]
  },
  "geo" : { },
  "id_str" : "778695809831362560",
  "text" : "RT @WilliamsSonoma: Hellooo, apple season! \uD83C\uDF4E\uD83C\uDF4E\n\nIngredient Spotlight: Apples: https:\/\/t.co\/XDdsYiCZH0 https:\/\/t.co\/r9yaXoVoT6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WilliamsSonoma\/status\/778685234715893761\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/r9yaXoVoT6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs5yF7eUEAAGKh6.jpg",
        "id_str" : "778685231771422720",
        "id" : 778685231771422720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs5yF7eUEAAGKh6.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 711,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 711,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 711,
          "resize" : "fit",
          "w" : 474
        } ],
        "display_url" : "pic.twitter.com\/r9yaXoVoT6"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/XDdsYiCZH0",
        "expanded_url" : "http:\/\/wsono.ma\/6017B7aef",
        "display_url" : "wsono.ma\/6017B7aef"
      } ]
    },
    "geo" : { },
    "id_str" : "778685234715893761",
    "text" : "Hellooo, apple season! \uD83C\uDF4E\uD83C\uDF4E\n\nIngredient Spotlight: Apples: https:\/\/t.co\/XDdsYiCZH0 https:\/\/t.co\/r9yaXoVoT6",
    "id" : 778685234715893761,
    "created_at" : "2016-09-21 20:00:01 +0000",
    "user" : {
      "name" : "Williams-Sonoma",
      "screen_name" : "WilliamsSonoma",
      "protected" : false,
      "id_str" : "29247574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1148307110\/pineapple_normal.jpg",
      "id" : 29247574,
      "verified" : true
    }
  },
  "id" : 778695809831362560,
  "created_at" : "2016-09-21 20:42:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778694832965378049",
  "text" : "See MacOs Microsoft maybe you shouldn't have a branding number for versioning.Just NT Versioning we are still on NT 6.",
  "id" : 778694832965378049,
  "created_at" : "2016-09-21 20:38:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778693234151141376",
  "text" : "Do just buy Moore.",
  "id" : 778693234151141376,
  "created_at" : "2016-09-21 20:31:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778692678145839104",
  "text" : "Physicians always have to have the latest technology don't they? Did it get any better doctor?",
  "id" : 778692678145839104,
  "created_at" : "2016-09-21 20:29:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778691948160782336",
  "text" : "And my manager is going with me always take a witness or partner with you.",
  "id" : 778691948160782336,
  "created_at" : "2016-09-21 20:26:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778690481865621510",
  "text" : "The bank called and I have my appointment.",
  "id" : 778690481865621510,
  "created_at" : "2016-09-21 20:20:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778689041734565888",
  "text" : "Kids just don't look good when you go to the doctor.",
  "id" : 778689041734565888,
  "created_at" : "2016-09-21 20:15:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778688653484666881",
  "text" : "Kids do just replace that evil physician with a robot.",
  "id" : 778688653484666881,
  "created_at" : "2016-09-21 20:13:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778688534924320771",
  "text" : "I was listening to NPR on the way home. And I'm glad those Syrian kids are in the U.S. and want to be engineers.",
  "id" : 778688534924320771,
  "created_at" : "2016-09-21 20:13:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778686773014646784",
  "text" : "i  am my dental insurance an uping the coverage and going to my old dentist in Kingsport if I really need to up the coverage.",
  "id" : 778686773014646784,
  "created_at" : "2016-09-21 20:06:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/u1Hc8C336N",
      "expanded_url" : "https:\/\/bizspark.microsoft.com\/\/",
      "display_url" : "bizspark.microsoft.com\/\/"
    } ]
  },
  "geo" : { },
  "id_str" : "778685830374100992",
  "text" : "https:\/\/t.co\/u1Hc8C336N Take it doctor hope do don't DO engineers. This is what I have after paying for eight years.",
  "id" : 778685830374100992,
  "created_at" : "2016-09-21 20:02:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778684331464073216",
  "text" : "Doctor want the latest Windows? See 10 cavities I'm going to Kingsport.They do just see an engineer coming.",
  "id" : 778684331464073216,
  "created_at" : "2016-09-21 19:56:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778661440517468161",
  "text" : "Hi Hilary what new on TV?",
  "id" : 778661440517468161,
  "created_at" : "2016-09-21 18:25:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778660535399178240",
  "text" : "I'm so sick of these eloi big American people.",
  "id" : 778660535399178240,
  "created_at" : "2016-09-21 18:21:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/eAPMkrDKXn",
      "expanded_url" : "https:\/\/www.theguardian.com\/science\/2010\/jan\/11\/watching-television-increases-death-heart-disease?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/science\/2010\/j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778658288367960064",
  "text" : "Watching television increases risk of death from heart disease https:\/\/t.co\/eAPMkrDKXn",
  "id" : 778658288367960064,
  "created_at" : "2016-09-21 18:12:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778657662955388928",
  "text" : "The dental hygienist will probably tell you everything on her network later.",
  "id" : 778657662955388928,
  "created_at" : "2016-09-21 18:10:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/778656558687277056\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/OLaWkuUMzG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs5YA0_UkAATgim.jpg",
      "id_str" : "778656556829151232",
      "id" : 778656556829151232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs5YA0_UkAATgim.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/OLaWkuUMzG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778656558687277056",
  "text" : "https:\/\/t.co\/OLaWkuUMzG",
  "id" : 778656558687277056,
  "created_at" : "2016-09-21 18:06:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778641352070397952",
  "text" : "I'm not a homosexual NPR.",
  "id" : 778641352070397952,
  "created_at" : "2016-09-21 17:05:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "St. Louis Business",
      "screen_name" : "PostDispatchbiz",
      "indices" : [ 107, 123 ],
      "id_str" : "211654138",
      "id" : 211654138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ers53JuluV",
      "expanded_url" : "http:\/\/www.stltoday.com\/business\/local\/amazon-opening-two-fulfillment-facilities-in-edwardsville-creating-jobs\/article_5547733f-43ee-5413-ba5a-50a4dd20a987.html?utm_medium=social&utm_source=twitter&utm_campaign=user-share",
      "display_url" : "stltoday.com\/business\/local\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778639990649749504",
  "text" : "Amazon opening two fulfillment facilities in Edwardsville, creating 1,000 jobs https:\/\/t.co\/ers53JuluV via @PostDispatchbiz",
  "id" : 778639990649749504,
  "created_at" : "2016-09-21 17:00:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salon",
      "screen_name" : "Salon",
      "indices" : [ 73, 79 ],
      "id_str" : "16955991",
      "id" : 16955991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/wtoam8kV1S",
      "expanded_url" : "http:\/\/www.salon.com\/2013\/08\/16\/10_famous_geniuses_who_used_drugs_and_were_better_off_for_it_partner\/",
      "display_url" : "salon.com\/2013\/08\/16\/10_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778638487419490305",
  "text" : "10 famous geniuses and their drugs of choice https:\/\/t.co\/wtoam8kV1S via @Salon",
  "id" : 778638487419490305,
  "created_at" : "2016-09-21 16:54:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/gNzMx6cYz0",
      "expanded_url" : "https:\/\/drugs-forum.com\/forum\/showthread.php?t=70418",
      "display_url" : "drugs-forum.com\/forum\/showthre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778637677956571136",
  "text" : "https:\/\/t.co\/gNzMx6cYz0 LSD and the effects on hearing IDK yet.",
  "id" : 778637677956571136,
  "created_at" : "2016-09-21 16:51:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778634979152625665",
  "text" : "Now I am saying this to Hollywood. Was one local hot educated girl that hard when they pushed me to Mensa?",
  "id" : 778634979152625665,
  "created_at" : "2016-09-21 16:40:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778633879838130181",
  "text" : "There is something to be said for anxiety and fame too.",
  "id" : 778633879838130181,
  "created_at" : "2016-09-21 16:35:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/JXTmxE79kW",
      "expanded_url" : "http:\/\/mentalhealthtalk.info\/schizophrenia-stories",
      "display_url" : "mentalhealthtalk.info\/schizophrenia-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778632939827527682",
  "text" : "https:\/\/t.co\/JXTmxE79kW Schizophrenia: my psychic connection to the universe.",
  "id" : 778632939827527682,
  "created_at" : "2016-09-21 16:32:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 91, 99 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/PGvTTCxaaR",
      "expanded_url" : "https:\/\/youtu.be\/isQ5Ycie73U",
      "display_url" : "youtu.be\/isQ5Ycie73U"
    } ]
  },
  "geo" : { },
  "id_str" : "778632051968933888",
  "text" : "Collateral Beauty Official Trailer 1 (2016) - Will Smith Movie https:\/\/t.co\/PGvTTCxaaR via @YouTube",
  "id" : 778632051968933888,
  "created_at" : "2016-09-21 16:28:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778629415324581888",
  "text" : "Called the bank and they are still working on the appointment.",
  "id" : 778629415324581888,
  "created_at" : "2016-09-21 16:18:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 28, 36 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/S4D2JXCUri",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=MyCFi7lbw50&sns=tw",
      "display_url" : "youtube.com\/watch?v=MyCFi7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778626238827159552",
  "text" : "https:\/\/t.co\/S4D2JXCUri via @youtube",
  "id" : 778626238827159552,
  "created_at" : "2016-09-21 16:05:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778624950122979328",
  "text" : "Hipster vinyl scratches easily.",
  "id" : 778624950122979328,
  "created_at" : "2016-09-21 16:00:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778622608430469120",
  "text" : "Are they on\"scene\" now?",
  "id" : 778622608430469120,
  "created_at" : "2016-09-21 15:51:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/473hz2fCZI",
      "expanded_url" : "http:\/\/bit.ly\/cIqP3I",
      "display_url" : "bit.ly\/cIqP3I"
    } ]
  },
  "geo" : { },
  "id_str" : "778621802515955712",
  "text" : "Too much, and you'll risk skin cancer, too little and you'll lack vitamin D - so how much sun SHOULD you have? https:\/\/t.co\/473hz2fCZI",
  "id" : 778621802515955712,
  "created_at" : "2016-09-21 15:47:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778620490185191424",
  "text" : "I'll pay for new music when people buy my music I haven't made one sell.",
  "id" : 778620490185191424,
  "created_at" : "2016-09-21 15:42:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778618974951075840",
  "text" : "I'm Turing off the location platform on Windows I am global. One local girl was never to much to ask.",
  "id" : 778618974951075840,
  "created_at" : "2016-09-21 15:36:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Food.com",
      "screen_name" : "Fooddotcom",
      "indices" : [ 47, 58 ],
      "id_str" : "18913121",
      "id" : 18913121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/b53DfOLrB4",
      "expanded_url" : "http:\/\/www.food.com\/recipe\/tortilla-pinwheels-201475?soc=socialsharingtw",
      "display_url" : "food.com\/recipe\/tortill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778614484260818944",
  "text" : "Tortilla Pinwheels https:\/\/t.co\/b53DfOLrB4 via @fooddotcom",
  "id" : 778614484260818944,
  "created_at" : "2016-09-21 15:18:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 67, 75 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/ruWFXFnVrI",
      "expanded_url" : "https:\/\/youtu.be\/-ZOGNAmxVdA",
      "display_url" : "youtu.be\/-ZOGNAmxVdA"
    } ]
  },
  "geo" : { },
  "id_str" : "778614193461325825",
  "text" : "Pinwheels (fixed) by Smashing Pumpkins https:\/\/t.co\/ruWFXFnVrI via @YouTube",
  "id" : 778614193461325825,
  "created_at" : "2016-09-21 15:17:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778613171212918784",
  "text" : "If we ever get done fighting over the women everyone and who really deserves the hot women (like myself) their might be peace.",
  "id" : 778613171212918784,
  "created_at" : "2016-09-21 15:13:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/KjEvboVPq9",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pubmed\/12496735",
      "display_url" : "ncbi.nlm.nih.gov\/pubmed\/12496735"
    } ]
  },
  "geo" : { },
  "id_str" : "778608165357248512",
  "text" : "Marriage: an evolutionary perspective. - PubMed - NCBI https:\/\/t.co\/KjEvboVPq9",
  "id" : 778608165357248512,
  "created_at" : "2016-09-21 14:53:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/CH1QLMvrqx",
      "expanded_url" : "http:\/\/townhall.com\/columnists\/johnstossel\/2012\/05\/16\/making_life_fair",
      "display_url" : "townhall.com\/columnists\/joh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778606487098781700",
  "text" : "Making Life Fair  https:\/\/t.co\/CH1QLMvrqx",
  "id" : 778606487098781700,
  "created_at" : "2016-09-21 14:47:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 109, 116 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/ilKPTHIakz",
      "expanded_url" : "https:\/\/www.amazon.com\/dp\/0199733481\/ref=cm_sw_r_tw_dp_x_gUP4xb84MTX80",
      "display_url" : "amazon.com\/dp\/0199733481\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778604484918411264",
  "text" : "Unfair to Genius: The Strange and Litigious Career of Ira B. Arnstein by Gary... https:\/\/t.co\/ilKPTHIakz via @amazon",
  "id" : 778604484918411264,
  "created_at" : "2016-09-21 14:39:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/72d22IpY1a",
      "expanded_url" : "http:\/\/www.jonathanmoore.net\/",
      "display_url" : "jonathanmoore.net"
    } ]
  },
  "geo" : { },
  "id_str" : "778603878325579776",
  "text" : "https:\/\/t.co\/72d22IpY1a",
  "id" : 778603878325579776,
  "created_at" : "2016-09-21 14:36:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 65, 73 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/1vDeiCXceQ",
      "expanded_url" : "https:\/\/youtu.be\/72rWAe0pUdQ",
      "display_url" : "youtu.be\/72rWAe0pUdQ"
    } ]
  },
  "geo" : { },
  "id_str" : "778602515336196096",
  "text" : "Guns N' Roses-Bad Obsession w\/Lyrics https:\/\/t.co\/1vDeiCXceQ via @YouTube Better luck next time punk. And I don't mean Bad Religion.",
  "id" : 778602515336196096,
  "created_at" : "2016-09-21 14:31:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778600586036047872",
  "text" : "Kid after we get done if it works you won't even have your youth.",
  "id" : 778600586036047872,
  "created_at" : "2016-09-21 14:23:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778599276851134464",
  "text" : "I spent $130 dollars forgroceries and that bagger punk kid was showing off his manly watch if I could have ripped off his head I would have.",
  "id" : 778599276851134464,
  "created_at" : "2016-09-21 14:18:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778577456680865792",
  "text" : "Forgy how is you man I call him code name \" Jonathan Moore\" in progress.",
  "id" : 778577456680865792,
  "created_at" : "2016-09-21 12:51:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 109, 116 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/zH14ZEI45n",
      "expanded_url" : "https:\/\/www.amazon.com\/dp\/1590591372\/ref=cm_sw_r_tw_dp_x_OfO4xb9J87S0N",
      "display_url" : "amazon.com\/dp\/1590591372\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778576713362137088",
  "text" : "Code Generation in Microsoft .NET (Expert's Voice Books for Professionals by ... https:\/\/t.co\/zH14ZEI45n via @amazon bought this in 2013.",
  "id" : 778576713362137088,
  "created_at" : "2016-09-21 12:48:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778574999200366596",
  "text" : "I was taken to court in this area for giving a girl a flower.",
  "id" : 778574999200366596,
  "created_at" : "2016-09-21 12:41:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vimeo",
      "indices" : [ 42, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/WbiIJxGCMY",
      "expanded_url" : "https:\/\/vimeo.com\/64669655?ref=tw-share",
      "display_url" : "vimeo.com\/64669655?ref=t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778573551792168960",
  "text" : "Watch \u201CStreet of Dreams-Guns N\u2019 Roses\u201D on #Vimeo https:\/\/t.co\/WbiIJxGCMY",
  "id" : 778573551792168960,
  "created_at" : "2016-09-21 12:36:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Futurism",
      "screen_name" : "futurism",
      "indices" : [ 96, 105 ],
      "id_str" : "2557446343",
      "id" : 2557446343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/pY1z4S7JAa",
      "expanded_url" : "http:\/\/futurism.com\/vortex-laser-will-both-revolutionize-computing-and-save-moores-law\/",
      "display_url" : "futurism.com\/vortex-laser-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778572102811213824",
  "text" : "Vortex Laser Will Both Revolutionize Computing and Save Moore\u2019s Law https:\/\/t.co\/pY1z4S7JAa via @Futurism",
  "id" : 778572102811213824,
  "created_at" : "2016-09-21 12:30:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/iEObiYU94x",
      "expanded_url" : "https:\/\/twitter.com\/NatureNews\/status\/778569497103958016",
      "display_url" : "twitter.com\/NatureNews\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778571120475799552",
  "text" : "The correct English is \"anymore more\" Nature. https:\/\/t.co\/iEObiYU94x",
  "id" : 778571120475799552,
  "created_at" : "2016-09-21 12:26:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778569777614913537",
  "text" : "People shun people when they don't have any money then come after then when they do.",
  "id" : 778569777614913537,
  "created_at" : "2016-09-21 12:21:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778563260966703104",
  "text" : "Are they still talking about the band Anthrax and want local shops?",
  "id" : 778563260966703104,
  "created_at" : "2016-09-21 11:55:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778562290266275840",
  "text" : "No peace Arvil until I get the girl maybe not you but a least one I've been talking too.",
  "id" : 778562290266275840,
  "created_at" : "2016-09-21 11:51:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778559988134469633",
  "text" : "I didn't know there was a connection between intelligence and anxiety until last year I was diagnosed in 2001.",
  "id" : 778559988134469633,
  "created_at" : "2016-09-21 11:42:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778558340016332800",
  "text" : "Mensa you should have the Mensa app connect to you databases and be proprietary.",
  "id" : 778558340016332800,
  "created_at" : "2016-09-21 11:35:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 28, 36 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/fVWpAc4cXI",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=VTOrGOLkLbM&sns=tw",
      "display_url" : "youtube.com\/watch?v=VTOrGO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778556813365092352",
  "text" : "https:\/\/t.co\/fVWpAc4cXI via @youtube some change.",
  "id" : 778556813365092352,
  "created_at" : "2016-09-21 11:29:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778554348737560576",
  "text" : "The young dumb and competitive.",
  "id" : 778554348737560576,
  "created_at" : "2016-09-21 11:19:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778552047453036544",
  "text" : "All they have now is sex, hacking and \"I don't like you against me\". Men and women don't like me because they can't cheat.",
  "id" : 778552047453036544,
  "created_at" : "2016-09-21 11:10:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david wilson",
      "screen_name" : "powerpossum",
      "indices" : [ 50, 62 ],
      "id_str" : "4825021",
      "id" : 4825021
    }, {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 92, 98 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/h7k5Z0OjPp",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/health_and_science\/science\/2015\/04\/do_smart_people_worry_more_iq_is_correlated_with_anxiety.html?wpsrc=sh_all_dt_tw_top",
      "display_url" : "slate.com\/articles\/healt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778550811290963969",
  "text" : "Scary smart: Do intelligent people worry more? By @powerpossum: https:\/\/t.co\/h7k5Z0OjPp via @slate",
  "id" : 778550811290963969,
  "created_at" : "2016-09-21 11:05:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778548181156134912",
  "text" : "All they have now is hacking and sex. Still trying to hide us Google?",
  "id" : 778548181156134912,
  "created_at" : "2016-09-21 10:55:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778548033143341056",
  "text" : "Is the media going to scare a person named \"Jonathan\" with the word \"case\" today because of what you don't have?",
  "id" : 778548033143341056,
  "created_at" : "2016-09-21 10:54:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 104, 112 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/BBEebrZCz2",
      "expanded_url" : "https:\/\/youtu.be\/dpqQJfdLO14",
      "display_url" : "youtu.be\/dpqQJfdLO14"
    } ]
  },
  "geo" : { },
  "id_str" : "778545298771763200",
  "text" : "Noel Gallagher's High Flying Birds - \"Everybody's On The Run\" (Official ... https:\/\/t.co\/BBEebrZCz2 via @YouTube",
  "id" : 778545298771763200,
  "created_at" : "2016-09-21 10:43:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/ONCmkNVvIW",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pmc\/articles\/PMC3110841\/",
      "display_url" : "ncbi.nlm.nih.gov\/pmc\/articles\/P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778544310606303232",
  "text" : "Klotho and the Aging Process https:\/\/t.co\/ONCmkNVvIW",
  "id" : 778544310606303232,
  "created_at" : "2016-09-21 10:40:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778398926240092160",
  "text" : "There is an I in team isn't there? Right in the A-hole I just know how men are and how woman fantasize. Good night everyone.",
  "id" : 778398926240092160,
  "created_at" : "2016-09-21 01:02:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778397585895788544",
  "text" : "My version of Flash is being maintained. Like I've said a long time ago. It does build with Visual Studio 2015 And I left at version 4.",
  "id" : 778397585895788544,
  "created_at" : "2016-09-21 00:57:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778395331272802304",
  "text" : "I really don't want the mask of the company right now. It would be a joint venture internationally. If they have something original fine.",
  "id" : 778395331272802304,
  "created_at" : "2016-09-21 00:48:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778393576342425600",
  "text" : "You can use inkscape or Gimp too. It is SVG.",
  "id" : 778393576342425600,
  "created_at" : "2016-09-21 00:41:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778393130936721408",
  "text" : "I bought a lot of vector logos. Created a clipping mask in illustrator.Then pasted in place in Photoshop. Then Cropped.",
  "id" : 778393130936721408,
  "created_at" : "2016-09-21 00:39:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life Extension",
      "screen_name" : "LifeExtension",
      "indices" : [ 3, 17 ],
      "id_str" : "27188645",
      "id" : 27188645
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "supplements",
      "indices" : [ 80, 92 ]
    }, {
      "text" : "lycopene",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/S3k0AdgpnE",
      "expanded_url" : "http:\/\/trib.al\/GYrAu7m",
      "display_url" : "trib.al\/GYrAu7m"
    } ]
  },
  "geo" : { },
  "id_str" : "778392561044054016",
  "text" : "RT @LifeExtension: Is this why tomatoes are so healthy? https:\/\/t.co\/S3k0AdgpnE #supplements #lycopene",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "supplements",
        "indices" : [ 61, 73 ]
      }, {
        "text" : "lycopene",
        "indices" : [ 74, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/S3k0AdgpnE",
        "expanded_url" : "http:\/\/trib.al\/GYrAu7m",
        "display_url" : "trib.al\/GYrAu7m"
      } ]
    },
    "geo" : { },
    "id_str" : "778392307997564928",
    "text" : "Is this why tomatoes are so healthy? https:\/\/t.co\/S3k0AdgpnE #supplements #lycopene",
    "id" : 778392307997564928,
    "created_at" : "2016-09-21 00:36:02 +0000",
    "user" : {
      "name" : "Life Extension",
      "screen_name" : "LifeExtension",
      "protected" : false,
      "id_str" : "27188645",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466584195842592768\/C9ajd_Y__normal.jpeg",
      "id" : 27188645,
      "verified" : false
    }
  },
  "id" : 778392561044054016,
  "created_at" : "2016-09-21 00:37:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/ttRtfwAuYW",
      "expanded_url" : "https:\/\/twitter.com\/coastw\/status\/778387829370028032",
      "display_url" : "twitter.com\/coastw\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778390915408863232",
  "text" : "Hi Jon why don't you like to be called Jonathan do they question your quality like Couric. https:\/\/t.co\/ttRtfwAuYW",
  "id" : 778390915408863232,
  "created_at" : "2016-09-21 00:30:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778389880779014144",
  "text" : "Want 'it' honey? What is 'it' professor? Never want me.",
  "id" : 778389880779014144,
  "created_at" : "2016-09-21 00:26:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 39, 47 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/tuh7UZX0Xw",
      "expanded_url" : "https:\/\/youtu.be\/f2ajHEdsdU4",
      "display_url" : "youtu.be\/f2ajHEdsdU4"
    } ]
  },
  "geo" : { },
  "id_str" : "778389503702626304",
  "text" : "Cousin Itt https:\/\/t.co\/tuh7UZX0Xw via @YouTube",
  "id" : 778389503702626304,
  "created_at" : "2016-09-21 00:24:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/DSS5xMTh6Q",
      "expanded_url" : "http:\/\/www.nydailynews.com\/life-style\/health\/miracle-therapy-helps-crippled-dog-walk-article-1.1205242",
      "display_url" : "nydailynews.com\/life-style\/hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778388130328109060",
  "text" : "Miracle therapy helps crippled dog walk again https:\/\/t.co\/DSS5xMTh6Q",
  "id" : 778388130328109060,
  "created_at" : "2016-09-21 00:19:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778387435516489728",
  "text" : "Can I take a picture of me standing and running asshole so you won't show me wheelchairs. I have nobody to take my picture.",
  "id" : 778387435516489728,
  "created_at" : "2016-09-21 00:16:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/U4MEruD04S",
      "expanded_url" : "http:\/\/www.pbs.org\/wgbh\/nova\/next\/?p=13398",
      "display_url" : "pbs.org\/wgbh\/nova\/next\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778386154035044352",
  "text" : "The Virus That Could Cure Alzheimer\u2019s, Parkinson\u2019s, and More https:\/\/t.co\/U4MEruD04S via @novapbsThat democrat will say and Moore won't they",
  "id" : 778386154035044352,
  "created_at" : "2016-09-21 00:11:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/iEvdWOqktG",
      "expanded_url" : "http:\/\/www.psychguides.com\/guides\/anger-symptoms-causes-and-effects\/",
      "display_url" : "psychguides.com\/guides\/anger-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778385229270622208",
  "text" : "https:\/\/t.co\/iEvdWOqktG Anger audience over women and competition and memory loss.",
  "id" : 778385229270622208,
  "created_at" : "2016-09-21 00:07:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778382430642311169",
  "text" : "If you don't do anything dirty why cover things up?",
  "id" : 778382430642311169,
  "created_at" : "2016-09-20 23:56:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Xjwh2XCIH2",
      "expanded_url" : "https:\/\/goo.gl\/WJpDHW",
      "display_url" : "goo.gl\/WJpDHW"
    } ]
  },
  "geo" : { },
  "id_str" : "778381438718734336",
  "text" : "https:\/\/t.co\/Xjwh2XCIH2 3d X Point, if these Democrats keep covering things up I will be mad.",
  "id" : 778381438718734336,
  "created_at" : "2016-09-20 23:52:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778380114665013248",
  "text" : "Thank You JavaScript Digest for retweeting \"JavaScript is doomed\"",
  "id" : 778380114665013248,
  "created_at" : "2016-09-20 23:47:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778379214856781824",
  "text" : "I will just forget what I've done and they keep competing for the girl when I really don't need too anymore.",
  "id" : 778379214856781824,
  "created_at" : "2016-09-20 23:44:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778377980758351872",
  "text" : "I would like to go through my Facebook and Twitter and put together some of my past I'll call them social media radio shows.",
  "id" : 778377980758351872,
  "created_at" : "2016-09-20 23:39:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/d8ZpBp9dG4",
      "expanded_url" : "http:\/\/techdissected.com\/web-and-computing\/google-hangouts-on-air-a-guide-for-musicians\/",
      "display_url" : "techdissected.com\/web-and-comput\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778377224466595840",
  "text" : "Google Hangouts On Air: A Guide For Musicians https:\/\/t.co\/d8ZpBp9dG4",
  "id" : 778377224466595840,
  "created_at" : "2016-09-20 23:36:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778376720114122752",
  "text" : "I'm just not getting out the guitar and going on you tube.",
  "id" : 778376720114122752,
  "created_at" : "2016-09-20 23:34:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778376351179038720",
  "text" : "I stopped fantasizing when I was 8 years old.",
  "id" : 778376351179038720,
  "created_at" : "2016-09-20 23:32:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778375438624260096",
  "text" : "UVa Wise wanna know how long I been performing on social media live? Better than in class? 8 years maybe a little scatterbrained but good.",
  "id" : 778375438624260096,
  "created_at" : "2016-09-20 23:29:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778373348212477952",
  "text" : "You don have to accept those messages don't you?",
  "id" : 778373348212477952,
  "created_at" : "2016-09-20 23:20:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Broadcast Music Inc.",
      "screen_name" : "bmi",
      "indices" : [ 3, 7 ],
      "id_str" : "14392252",
      "id" : 14392252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/jYcORSEZEQ",
      "expanded_url" : "http:\/\/bit.ly\/2cvobXg",
      "display_url" : "bit.ly\/2cvobXg"
    } ]
  },
  "geo" : { },
  "id_str" : "778372831222632448",
  "text" : "RT @bmi: News | BMI Prevails Over DOJ in Consent Decree Dispute https:\/\/t.co\/jYcORSEZEQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/jYcORSEZEQ",
        "expanded_url" : "http:\/\/bit.ly\/2cvobXg",
        "display_url" : "bit.ly\/2cvobXg"
      } ]
    },
    "geo" : { },
    "id_str" : "776907680698863616",
    "text" : "News | BMI Prevails Over DOJ in Consent Decree Dispute https:\/\/t.co\/jYcORSEZEQ",
    "id" : 776907680698863616,
    "created_at" : "2016-09-16 22:16:39 +0000",
    "user" : {
      "name" : "Broadcast Music Inc.",
      "screen_name" : "bmi",
      "protected" : false,
      "id_str" : "14392252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560889552819060736\/FNxPI4Zz_normal.jpeg",
      "id" : 14392252,
      "verified" : false
    }
  },
  "id" : 778372831222632448,
  "created_at" : "2016-09-20 23:18:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778371200783384577",
  "text" : "PERIOD",
  "id" : 778371200783384577,
  "created_at" : "2016-09-20 23:12:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/X63pq0hLyM",
      "expanded_url" : "https:\/\/goo.gl\/hvQgkN",
      "display_url" : "goo.gl\/hvQgkN"
    } ]
  },
  "geo" : { },
  "id_str" : "778370589346172931",
  "text" : "A Scientist's Discovery about the Universe https:\/\/t.co\/X63pq0hLyM",
  "id" : 778370589346172931,
  "created_at" : "2016-09-20 23:09:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778369495920439296",
  "text" : "I will donate some money to M.I.T too.",
  "id" : 778369495920439296,
  "created_at" : "2016-09-20 23:05:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Bank",
      "screen_name" : "WorldBank",
      "indices" : [ 3, 13 ],
      "id_str" : "27860681",
      "id" : 27860681
    }, {
      "name" : "Jim Yong Kim",
      "screen_name" : "JimYongKim",
      "indices" : [ 25, 36 ],
      "id_str" : "3239192692",
      "id" : 3239192692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "refugee",
      "indices" : [ 61, 69 ]
    }, {
      "text" : "AidRefugees",
      "indices" : [ 102, 114 ]
    }, {
      "text" : "UNGA",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778368673199353856",
  "text" : "RT @WorldBank: President @JimYongKim  on 4 new approaches to #refugee challenge at Leaders\u2019 Summit to #AidRefugees. |#UNGA https:\/\/t.co\/bx5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jim Yong Kim",
        "screen_name" : "JimYongKim",
        "indices" : [ 10, 21 ],
        "id_str" : "3239192692",
        "id" : 3239192692
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WorldBank\/status\/778366547471560704\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/bx56fMB8ta",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs1QP7tXEAI4ihL.jpg",
        "id_str" : "778366545261170690",
        "id" : 778366545261170690,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs1QP7tXEAI4ihL.jpg",
        "sizes" : [ {
          "h" : 322,
          "resize" : "fit",
          "w" : 609
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 609
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 609
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 609
        } ],
        "display_url" : "pic.twitter.com\/bx56fMB8ta"
      } ],
      "hashtags" : [ {
        "text" : "refugee",
        "indices" : [ 46, 54 ]
      }, {
        "text" : "AidRefugees",
        "indices" : [ 87, 99 ]
      }, {
        "text" : "UNGA",
        "indices" : [ 102, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778366547471560704",
    "text" : "President @JimYongKim  on 4 new approaches to #refugee challenge at Leaders\u2019 Summit to #AidRefugees. |#UNGA https:\/\/t.co\/bx56fMB8ta",
    "id" : 778366547471560704,
    "created_at" : "2016-09-20 22:53:40 +0000",
    "user" : {
      "name" : "World Bank",
      "screen_name" : "WorldBank",
      "protected" : false,
      "id_str" : "27860681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725323426588688385\/elPT0mkW_normal.jpg",
      "id" : 27860681,
      "verified" : true
    }
  },
  "id" : 778368673199353856,
  "created_at" : "2016-09-20 23:02:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 70, 78 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/Pesl5Y0jIN",
      "expanded_url" : "https:\/\/youtu.be\/Gwd0O9Ca6ts",
      "display_url" : "youtu.be\/Gwd0O9Ca6ts"
    } ]
  },
  "geo" : { },
  "id_str" : "778367111949352960",
  "text" : "12 Unforgettable Axl Rose Onstage Moments https:\/\/t.co\/Pesl5Y0jIN via @YouTube",
  "id" : 778367111949352960,
  "created_at" : "2016-09-20 22:55:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778366742619910144",
  "text" : "I am buying another Rock Star drink.",
  "id" : 778366742619910144,
  "created_at" : "2016-09-20 22:54:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/fkCMiWoX47",
      "expanded_url" : "http:\/\/www.elizabethink.net\/?p=263",
      "display_url" : "elizabethink.net\/?p=263"
    } ]
  },
  "geo" : { },
  "id_str" : "778366254042210304",
  "text" : "The Social Media Stage is Yours https:\/\/t.co\/fkCMiWoX47",
  "id" : 778366254042210304,
  "created_at" : "2016-09-20 22:52:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vimeo",
      "indices" : [ 28, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/vzMLRcvTaZ",
      "expanded_url" : "https:\/\/vimeo.com\/pearljamofficial\/pearljamtwentytrailer?ref=tw-share",
      "display_url" : "vimeo.com\/pearljamoffici\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778365805520154624",
  "text" : "Watch \u201CPearl Jam Twenty\u201D on #Vimeo https:\/\/t.co\/vzMLRcvTaZ Don't call me brother I forget which concert.",
  "id" : 778365805520154624,
  "created_at" : "2016-09-20 22:50:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/hihZuN202D",
      "expanded_url" : "http:\/\/nyti.ms\/UluFtx",
      "display_url" : "nyti.ms\/UluFtx"
    } ]
  },
  "geo" : { },
  "id_str" : "778363999834480641",
  "text" : "PHYSICIST AIMS TO CREATE A UNIVERSE, LITERALLY https:\/\/t.co\/hihZuN202D Again I forgot what happened.",
  "id" : 778363999834480641,
  "created_at" : "2016-09-20 22:43:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778362809566564355",
  "text" : "I don't know if that was right.",
  "id" : 778362809566564355,
  "created_at" : "2016-09-20 22:38:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778362424382615556",
  "text" : "This is the WWW isn't it? Have I got her yet not yet? And I do believe spiders like math.",
  "id" : 778362424382615556,
  "created_at" : "2016-09-20 22:37:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778361485479276545",
  "text" : "If I remember the explosion occurred near Orion.",
  "id" : 778361485479276545,
  "created_at" : "2016-09-20 22:33:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/BLwdlT5IqR",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/History_of_supernova_observation",
      "display_url" : "en.wikipedia.org\/wiki\/History_o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778360809466527744",
  "text" : "https:\/\/t.co\/BLwdlT5IqR History of supernova observation Gen X was just a larger explosion. I forget my research on Facebook.",
  "id" : 778360809466527744,
  "created_at" : "2016-09-20 22:30:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/2E37W78HhL",
      "expanded_url" : "http:\/\/news.nationalgeographic.com\/2015\/01\/150128-big-bang-universe-supernova-astrophysics-health-space-ngbooktalk\/",
      "display_url" : "news.nationalgeographic.com\/2015\/01\/150128\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778360170833403908",
  "text" : "https:\/\/t.co\/2E37W78HhL We all are stardust found out in 2009.",
  "id" : 778360170833403908,
  "created_at" : "2016-09-20 22:28:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/lppYDuKfvZ",
      "expanded_url" : "http:\/\/www.leafscience.com\/2014\/02\/23\/5-must-know-facts-cannabidiol-cbd\/",
      "display_url" : "leafscience.com\/2014\/02\/23\/5-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778357795531976704",
  "text" : "https:\/\/t.co\/lppYDuKfvZ",
  "id" : 778357795531976704,
  "created_at" : "2016-09-20 22:18:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Living",
      "screen_name" : "HealthyLiving",
      "indices" : [ 73, 87 ],
      "id_str" : "23674342",
      "id" : 23674342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/vNQd5upymp",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/entry\/marijuana-broken-bones_us_55ad1e24e4b0d2ded39f7bef?ncid=engmodushpmg00000004",
      "display_url" : "huffingtonpost.com\/entry\/marijuan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778356867017957376",
  "text" : "Study says marijuana helps heal broken bones https:\/\/t.co\/vNQd5upymp via @HealthyLiving I'm just interested in the ingredient.",
  "id" : 778356867017957376,
  "created_at" : "2016-09-20 22:15:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/c1Cx0obwZi",
      "expanded_url" : "http:\/\/www.todayifoundout.com\/index.php\/2013\/04\/how-the-dalai-lama-is-chosen\/",
      "display_url" : "todayifoundout.com\/index.php\/2013\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778355630562217986",
  "text" : "Hey check this out https:\/\/t.co\/c1Cx0obwZi",
  "id" : 778355630562217986,
  "created_at" : "2016-09-20 22:10:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 83, 91 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/4pTet89ntS",
      "expanded_url" : "https:\/\/youtu.be\/6i_gGXDDCGE",
      "display_url" : "youtu.be\/6i_gGXDDCGE"
    } ]
  },
  "geo" : { },
  "id_str" : "778352362796777473",
  "text" : "My 30 years in the Yogi Bhajan 3HO kundalini yoga cult https:\/\/t.co\/4pTet89ntS via @YouTube",
  "id" : 778352362796777473,
  "created_at" : "2016-09-20 21:57:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/O0PMluhBY7",
      "expanded_url" : "http:\/\/www.cellbiolabs.com\/selection-guide-oxidative-stress-assays-sample-type?gclid=CJnz5u_2ns8CFUk8gQodNYcN6Q",
      "display_url" : "cellbiolabs.com\/selection-guid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778351417954279425",
  "text" : "https:\/\/t.co\/O0PMluhBY7 I've been researching oxidative stress for some time mine is just lake of collagen.",
  "id" : 778351417954279425,
  "created_at" : "2016-09-20 21:53:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yogi Products",
      "screen_name" : "YogiProducts",
      "indices" : [ 3, 16 ],
      "id_str" : "1909489135",
      "id" : 1909489135
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/YogiProducts\/status\/775744671599525892\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/klLaMcWse6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsP_qpGXYAEVeRY.jpg",
      "id_str" : "775744668889997313",
      "id" : 775744668889997313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsP_qpGXYAEVeRY.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/klLaMcWse6"
    } ],
    "hashtags" : [ {
      "text" : "TeaTagTuesday",
      "indices" : [ 24, 38 ]
    }, {
      "text" : "yogitea",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778350677332549636",
  "text" : "RT @YogiProducts: Happy #TeaTagTuesday! \"Appreciate yourself and honor your soul.\" What does your #yogitea tag say? https:\/\/t.co\/klLaMcWse6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.falcon.io\" rel=\"nofollow\"\u003EFalcon Social Media Management \u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/YogiProducts\/status\/775744671599525892\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/klLaMcWse6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsP_qpGXYAEVeRY.jpg",
        "id_str" : "775744668889997313",
        "id" : 775744668889997313,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsP_qpGXYAEVeRY.jpg",
        "sizes" : [ {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/klLaMcWse6"
      } ],
      "hashtags" : [ {
        "text" : "TeaTagTuesday",
        "indices" : [ 6, 20 ]
      }, {
        "text" : "yogitea",
        "indices" : [ 80, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775744671599525892",
    "text" : "Happy #TeaTagTuesday! \"Appreciate yourself and honor your soul.\" What does your #yogitea tag say? https:\/\/t.co\/klLaMcWse6",
    "id" : 775744671599525892,
    "created_at" : "2016-09-13 17:15:17 +0000",
    "user" : {
      "name" : "Yogi Products",
      "screen_name" : "YogiProducts",
      "protected" : false,
      "id_str" : "1909489135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/492021771709591552\/SgXf4y5k_normal.jpeg",
      "id" : 1909489135,
      "verified" : false
    }
  },
  "id" : 778350677332549636,
  "created_at" : "2016-09-20 21:50:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778349707131293696",
  "text" : "I really don't know it I should get a haircut before I go to the bank. Will they judge me?",
  "id" : 778349707131293696,
  "created_at" : "2016-09-20 21:46:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health",
      "screen_name" : "goodhealth",
      "indices" : [ 66, 77 ],
      "id_str" : "15566901",
      "id" : 15566901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/5ZqlQKAe0f",
      "expanded_url" : "http:\/\/www.health.com\/health\/gallery\/0,,20551987,00.html",
      "display_url" : "health.com\/health\/gallery\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778348784136941568",
  "text" : "14 Best and Worst Foods for Digestion https:\/\/t.co\/5ZqlQKAe0f via @goodhealth",
  "id" : 778348784136941568,
  "created_at" : "2016-09-20 21:43:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/exS9I1wYcE",
      "expanded_url" : "http:\/\/www.geappliances.com\/ge\/microwave-oven.htm?cid=901&omni_key=M4M_Brand_Microwaves_Exact_SEM-GE_Microwaves-ge_microwaves-Exact&gclid=CIK-u5_0ns8CFZI8gQodizEFLw",
      "display_url" : "geappliances.com\/ge\/microwave-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778348157956685824",
  "text" : "https:\/\/t.co\/exS9I1wYcE I do have a GE countertop. Older but it's never failed.",
  "id" : 778348157956685824,
  "created_at" : "2016-09-20 21:40:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ZjxzPbQtGT",
      "expanded_url" : "http:\/\/www.health.harvard.edu\/staying-healthy\/microwave-cooking-and-nutrition",
      "display_url" : "health.harvard.edu\/staying-health\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778347562185191424",
  "text" : "https:\/\/t.co\/ZjxzPbQtGT I do use a Microwave 5 min.",
  "id" : 778347562185191424,
  "created_at" : "2016-09-20 21:38:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778345253715804160",
  "text" : "I spend $120 on quality groceries every two to three weeks on me alone. I don't go out much so I save on fuel.",
  "id" : 778345253715804160,
  "created_at" : "2016-09-20 21:29:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778343264588038144",
  "text" : "I am eating from a can (La Coy) tonight. Eating from can can lower your sperm count. I rarely eat from them.",
  "id" : 778343264588038144,
  "created_at" : "2016-09-20 21:21:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/778341293500104704\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/myHG4uOZ1O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs05R_JWEAEas59.jpg",
      "id_str" : "778341291776151553",
      "id" : 778341291776151553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs05R_JWEAEas59.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/myHG4uOZ1O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778341293500104704",
  "text" : "Fuck off UVa you let me down. https:\/\/t.co\/myHG4uOZ1O",
  "id" : 778341293500104704,
  "created_at" : "2016-09-20 21:13:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778340425350389762",
  "text" : "Josh Moore was on my Facebook the one that worked at UVa Wise in 2013. And he is or was on my G+ too.",
  "id" : 778340425350389762,
  "created_at" : "2016-09-20 21:09:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778339215205687296",
  "text" : "Josh Moore works at DISH UVa.",
  "id" : 778339215205687296,
  "created_at" : "2016-09-20 21:05:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778338571191250944",
  "text" : "It's 5 the bank didn't call back I'll call back tomorrow.",
  "id" : 778338571191250944,
  "created_at" : "2016-09-20 21:02:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778337959296770048",
  "text" : "Non voting shares.",
  "id" : 778337959296770048,
  "created_at" : "2016-09-20 21:00:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/58pXaK043w",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Joint_venture",
      "display_url" : "en.wikipedia.org\/wiki\/Joint_ven\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778337671244550144",
  "text" : "https:\/\/t.co\/58pXaK043w Joint Venture.",
  "id" : 778337671244550144,
  "created_at" : "2016-09-20 20:58:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 84, 92 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/iJuvcpRB8x",
      "expanded_url" : "https:\/\/youtu.be\/Qm99WBQY3eA",
      "display_url" : "youtu.be\/Qm99WBQY3eA"
    } ]
  },
  "geo" : { },
  "id_str" : "778335930767777792",
  "text" : "Garbage - Show Me HD (NYKOP DELUXE EDITION BONUS TRACK) https:\/\/t.co\/iJuvcpRB8x via @YouTube Show the update law bank.",
  "id" : 778335930767777792,
  "created_at" : "2016-09-20 20:52:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778331686778073090",
  "text" : "I will just start taking inventory the first time we go to bed. I really don't know what she'll do when I'm asleep.",
  "id" : 778331686778073090,
  "created_at" : "2016-09-20 20:35:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/4iwPTrIUMq",
      "expanded_url" : "https:\/\/twitter.com\/Freeletics\/status\/705430663193690112",
      "display_url" : "twitter.com\/Freeletics\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778326162900652036",
  "text" : "I really don't care. I will just say the first time she goes out was he any good? https:\/\/t.co\/4iwPTrIUMq",
  "id" : 778326162900652036,
  "created_at" : "2016-09-20 20:13:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 3, 12 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/vnz2ZRveYo",
      "expanded_url" : "http:\/\/trib.al\/4lmjLaJ",
      "display_url" : "trib.al\/4lmjLaJ"
    } ]
  },
  "geo" : { },
  "id_str" : "778325553925459970",
  "text" : "RT @guardian: Donald Trump used $258,000 from his charity for legal settlements, reports say https:\/\/t.co\/vnz2ZRveYo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/vnz2ZRveYo",
        "expanded_url" : "http:\/\/trib.al\/4lmjLaJ",
        "display_url" : "trib.al\/4lmjLaJ"
      } ]
    },
    "geo" : { },
    "id_str" : "778317195705192448",
    "text" : "Donald Trump used $258,000 from his charity for legal settlements, reports say https:\/\/t.co\/vnz2ZRveYo",
    "id" : 778317195705192448,
    "created_at" : "2016-09-20 19:37:34 +0000",
    "user" : {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "protected" : false,
      "id_str" : "87818409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774191274391965696\/Tulf7lwN_normal.jpg",
      "id" : 87818409,
      "verified" : true
    }
  },
  "id" : 778325553925459970,
  "created_at" : "2016-09-20 20:10:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778323043148042240",
  "text" : "I did tweet you Avril Lavigne but are you really going to drop everything and marry me?Probably not. Plus you probably don't like computers.",
  "id" : 778323043148042240,
  "created_at" : "2016-09-20 20:00:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778321852196352000",
  "text" : "I am motivated to work at home but there is no love. Social media and the web has exhausted and used all I want to say.",
  "id" : 778321852196352000,
  "created_at" : "2016-09-20 19:56:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778320411201331201",
  "text" : "I just really don't feel like working that much, motivation comes with love  And not one woman has said they loved me it 20 years.",
  "id" : 778320411201331201,
  "created_at" : "2016-09-20 19:50:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778319421173534721",
  "text" : "Sometimes you can reserve the right to be hypocritical.",
  "id" : 778319421173534721,
  "created_at" : "2016-09-20 19:46:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778318467602808833",
  "text" : "People do want to be like me. They just never tell me.",
  "id" : 778318467602808833,
  "created_at" : "2016-09-20 19:42:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778316718099890176",
  "text" : "All we have now is 'get back' You'll get back at me and I'll continue to use my high IQ brain to get back at you.",
  "id" : 778316718099890176,
  "created_at" : "2016-09-20 19:35:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778314196366884864",
  "text" : "You will say God right Hilary? Just not Science so they can make fun.",
  "id" : 778314196366884864,
  "created_at" : "2016-09-20 19:25:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778313457917628417",
  "text" : "The guess who American woman anyone?",
  "id" : 778313457917628417,
  "created_at" : "2016-09-20 19:22:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778312888675172352",
  "text" : "America sex cars drugs and money.",
  "id" : 778312888675172352,
  "created_at" : "2016-09-20 19:20:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778312438374604800",
  "text" : "I really don't even no if I want a new car. Hydrogen, electric or natural gas?",
  "id" : 778312438374604800,
  "created_at" : "2016-09-20 19:18:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778309535467499526",
  "text" : "I hate fake online web app musicians Google. Quit standing on the shoulders of giants.",
  "id" : 778309535467499526,
  "created_at" : "2016-09-20 19:07:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778300377724772352",
  "text" : "All these tellers know and I did say Teller are there number keys too.",
  "id" : 778300377724772352,
  "created_at" : "2016-09-20 18:30:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778298764641636352",
  "text" : "I did say joint venture bank not company don't kill my kid.",
  "id" : 778298764641636352,
  "created_at" : "2016-09-20 18:24:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/PEbq9k0nRn",
      "expanded_url" : "https:\/\/simpleprogrammer.com\/2013\/05\/06\/why-javascript-is-doomed\/",
      "display_url" : "simpleprogrammer.com\/2013\/05\/06\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778298268224778240",
  "text" : "Why JavaScript Is Doomed: https:\/\/t.co\/PEbq9k0nRn",
  "id" : 778298268224778240,
  "created_at" : "2016-09-20 18:22:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778297214825275392",
  "text" : "See education Lori Mueller.",
  "id" : 778297214825275392,
  "created_at" : "2016-09-20 18:18:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778296699580284929",
  "text" : "And I don't mean that in a gay way either.",
  "id" : 778296699580284929,
  "created_at" : "2016-09-20 18:16:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778296278920925184",
  "text" : "This is what it would look like, the bank you be turning me down not because of credit but because of who I am.",
  "id" : 778296278920925184,
  "created_at" : "2016-09-20 18:14:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778295692582420483",
  "text" : "cool",
  "id" : 778295692582420483,
  "created_at" : "2016-09-20 18:12:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778295301266341888",
  "text" : "Net Worth = Equity = Shares and sign a share holders agreement This is my money that I've worked hard for too banker don't just say not me.",
  "id" : 778295301266341888,
  "created_at" : "2016-09-20 18:10:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/cBHqM6KjX2",
      "expanded_url" : "https:\/\/www.pensco.com\/self-directed-iras\/investing-options\/private-equity",
      "display_url" : "pensco.com\/self-directed-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778294380113330176",
  "text" : "https:\/\/t.co\/cBHqM6KjX2 private-equity investing And is really not that shady either.",
  "id" : 778294380113330176,
  "created_at" : "2016-09-20 18:06:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778293241280098304",
  "text" : "Still making the appointment with the bank had to coordinate with my manger and I need to cover my back.",
  "id" : 778293241280098304,
  "created_at" : "2016-09-20 18:02:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 84, 92 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/XM41TPc08r",
      "expanded_url" : "https:\/\/youtu.be\/d73tiBBzvFM",
      "display_url" : "youtu.be\/d73tiBBzvFM"
    } ]
  },
  "geo" : { },
  "id_str" : "778289648196022273",
  "text" : "Ace of Base - All That She Wants (Official Music Video) https:\/\/t.co\/XM41TPc08r via @YouTube",
  "id" : 778289648196022273,
  "created_at" : "2016-09-20 17:48:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778288846580641792",
  "text" : "He might say I don't need to rebuild collagen right now either.",
  "id" : 778288846580641792,
  "created_at" : "2016-09-20 17:44:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778288181884162048",
  "text" : "K K K K K K K K K K K K K K K K K K K K K K  I might get laid.",
  "id" : 778288181884162048,
  "created_at" : "2016-09-20 17:42:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 3, 12 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/MgPwZfYO6D",
      "expanded_url" : "http:\/\/trib.al\/sPzwCyj",
      "display_url" : "trib.al\/sPzwCyj"
    } ]
  },
  "geo" : { },
  "id_str" : "778286315838242816",
  "text" : "RT @guardian: The rules on questioning criminal suspects are there for a reason | Duncan Campbell https:\/\/t.co\/MgPwZfYO6D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/MgPwZfYO6D",
        "expanded_url" : "http:\/\/trib.al\/sPzwCyj",
        "display_url" : "trib.al\/sPzwCyj"
      } ]
    },
    "geo" : { },
    "id_str" : "778285205194960897",
    "text" : "The rules on questioning criminal suspects are there for a reason | Duncan Campbell https:\/\/t.co\/MgPwZfYO6D",
    "id" : 778285205194960897,
    "created_at" : "2016-09-20 17:30:27 +0000",
    "user" : {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "protected" : false,
      "id_str" : "87818409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774191274391965696\/Tulf7lwN_normal.jpg",
      "id" : 87818409,
      "verified" : true
    }
  },
  "id" : 778286315838242816,
  "created_at" : "2016-09-20 17:34:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/58sr6SYpgf",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/List_of_Major_League_Baseball_career_strikeout_leaders",
      "display_url" : "en.wikipedia.org\/wiki\/List_of_M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778285937927327744",
  "text" : "https:\/\/t.co\/58sr6SYpgf",
  "id" : 778285937927327744,
  "created_at" : "2016-09-20 17:33:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 49, 57 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/S5uPBH5iXn",
      "expanded_url" : "https:\/\/youtu.be\/5o1G0GSiNQM",
      "display_url" : "youtu.be\/5o1G0GSiNQM"
    } ]
  },
  "geo" : { },
  "id_str" : "778283536956751874",
  "text" : "Def Leppard - Rocket https:\/\/t.co\/S5uPBH5iXn via @YouTube",
  "id" : 778283536956751874,
  "created_at" : "2016-09-20 17:23:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 3, 6 ],
      "id_str" : "14159148",
      "id" : 14159148
    }, {
      "name" : "Hon. Kamina J Smith",
      "screen_name" : "kaminajsmith",
      "indices" : [ 50, 63 ],
      "id_str" : "2406303550",
      "id" : 2406303550
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/UN\/status\/778281745233879040\/video\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/SbcOexrRgd",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/778281542992953344\/pu\/img\/a9C7KdhI99mdBkBU.jpg",
      "id_str" : "778281542992953344",
      "id" : 778281542992953344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/778281542992953344\/pu\/img\/a9C7KdhI99mdBkBU.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/SbcOexrRgd"
    } ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 70, 75 ]
    }, {
      "text" : "GlobalGoals",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778282745709654017",
  "text" : "RT @UN: A year after the adoption of 2030 Agenda, @kaminajsmith is at #UNGA celebrating the #GlobalGoals https:\/\/t.co\/SbcOexrRgd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter Challenger\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hon. Kamina J Smith",
        "screen_name" : "kaminajsmith",
        "indices" : [ 42, 55 ],
        "id_str" : "2406303550",
        "id" : 2406303550
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/UN\/status\/778281745233879040\/video\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/SbcOexrRgd",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/778281542992953344\/pu\/img\/a9C7KdhI99mdBkBU.jpg",
        "id_str" : "778281542992953344",
        "id" : 778281542992953344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/778281542992953344\/pu\/img\/a9C7KdhI99mdBkBU.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/SbcOexrRgd"
      } ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 62, 67 ]
      }, {
        "text" : "GlobalGoals",
        "indices" : [ 84, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778281745233879040",
    "text" : "A year after the adoption of 2030 Agenda, @kaminajsmith is at #UNGA celebrating the #GlobalGoals https:\/\/t.co\/SbcOexrRgd",
    "id" : 778281745233879040,
    "created_at" : "2016-09-20 17:16:42 +0000",
    "user" : {
      "name" : "United Nations",
      "screen_name" : "UN",
      "protected" : false,
      "id_str" : "14159148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538328216729968642\/SdfeQXSM_normal.png",
      "id" : 14159148,
      "verified" : true
    }
  },
  "id" : 778282745709654017,
  "created_at" : "2016-09-20 17:20:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778281864717070336",
  "text" : "Not Botox or plastic surgery natural injections.",
  "id" : 778281864717070336,
  "created_at" : "2016-09-20 17:17:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/n7huxxm3re",
      "expanded_url" : "http:\/\/renovusbeauty.com\/",
      "display_url" : "renovusbeauty.com"
    } ]
  },
  "geo" : { },
  "id_str" : "778280941412356101",
  "text" : "https:\/\/t.co\/n7huxxm3re I have and appointment with Dr. Clemens in Oct. to rebuild collagen.",
  "id" : 778280941412356101,
  "created_at" : "2016-09-20 17:13:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778265628037742592",
  "text" : "Abingdon you can find me at the rejuvenation clinic. On Lee Highway today.",
  "id" : 778265628037742592,
  "created_at" : "2016-09-20 16:12:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/sLkHB7Zf0r",
      "expanded_url" : "http:\/\/www.radiancy.com\/en\/applications\/skin-rejuvenation.html",
      "display_url" : "radiancy.com\/en\/application\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778264446330372096",
  "text" : "https:\/\/t.co\/sLkHB7Zf0r Skin and collagen rejuvenation. See the German flag.",
  "id" : 778264446330372096,
  "created_at" : "2016-09-20 16:07:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778259143073431557",
  "text" : "You will just sue me over what you don't have right? Mo' Money mo' problems.",
  "id" : 778259143073431557,
  "created_at" : "2016-09-20 15:46:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/S4iAay9brT",
      "expanded_url" : "http:\/\/www.collegescholarships.org\/grants\/married.htm",
      "display_url" : "collegescholarships.org\/grants\/married\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778256924219506688",
  "text" : "https:\/\/t.co\/S4iAay9brT Grants for married students.",
  "id" : 778256924219506688,
  "created_at" : "2016-09-20 15:38:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778254829227474944",
  "text" : "Microsoft if I have to turn off the smart screen filter to kick you out I will.",
  "id" : 778254829227474944,
  "created_at" : "2016-09-20 15:29:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778254183166255104",
  "text" : "I built a VST with the Avid Audio SDK what used to be Digidesign.",
  "id" : 778254183166255104,
  "created_at" : "2016-09-20 15:27:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StyleBlazer",
      "screen_name" : "StyleBlazer",
      "indices" : [ 103, 115 ],
      "id_str" : "221788706",
      "id" : 221788706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/uikiM6TN8o",
      "expanded_url" : "http:\/\/wp.me\/p2G2v8-i6u",
      "display_url" : "wp.me\/p2G2v8-i6u"
    } ]
  },
  "geo" : { },
  "id_str" : "778252044981432320",
  "text" : "Did You Know They Had Brothers? 15 Celebs and Their Not-So-Famous Siblings https:\/\/t.co\/uikiM6TN8o via @StyleBlazer",
  "id" : 778252044981432320,
  "created_at" : "2016-09-20 15:18:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778249769458208768",
  "text" : "Women: \"No matter what happens I'll just get the money you are dumb but I don't care. You were my first\" I've had it.",
  "id" : 778249769458208768,
  "created_at" : "2016-09-20 15:09:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778246348181299200",
  "text" : "I am going to get more Twritter followers that Eastman Chemical too. Or the news.",
  "id" : 778246348181299200,
  "created_at" : "2016-09-20 14:56:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cointelegraph",
      "screen_name" : "CoinTelegraph",
      "indices" : [ 68, 82 ],
      "id_str" : "2207129125",
      "id" : 2207129125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/TlTm1yeH6R",
      "expanded_url" : "https:\/\/cointelegraph.com\/news\/the-open-source-world-is-worth-billions",
      "display_url" : "cointelegraph.com\/news\/the-open-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778245544070242304",
  "text" : "The Open Source World Is Worth Billions https:\/\/t.co\/TlTm1yeH6R via @Cointelegraph Making an appointment with the bank.",
  "id" : 778245544070242304,
  "created_at" : "2016-09-20 14:52:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778243404383870976",
  "text" : "Change your name to Moore ladies and let me die like Jack Dawson of the Titanic.",
  "id" : 778243404383870976,
  "created_at" : "2016-09-20 14:44:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778242027293204480",
  "text" : "My manager does get it now the area is in debt to me.",
  "id" : 778242027293204480,
  "created_at" : "2016-09-20 14:38:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 3, 6 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/6D65ycmO0P",
      "expanded_url" : "http:\/\/apne.ws\/2cG965w",
      "display_url" : "apne.ws\/2cG965w"
    } ]
  },
  "geo" : { },
  "id_str" : "778237590352826368",
  "text" : "RT @AP: UN chief Ban Ki-moon rails at leaders present at #UNGA who \"ignored, facilitated, funded\" Syrian conflict. https:\/\/t.co\/6D65ycmO0P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 49, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/6D65ycmO0P",
        "expanded_url" : "http:\/\/apne.ws\/2cG965w",
        "display_url" : "apne.ws\/2cG965w"
      } ]
    },
    "geo" : { },
    "id_str" : "778237459360538625",
    "text" : "UN chief Ban Ki-moon rails at leaders present at #UNGA who \"ignored, facilitated, funded\" Syrian conflict. https:\/\/t.co\/6D65ycmO0P",
    "id" : 778237459360538625,
    "created_at" : "2016-09-20 14:20:43 +0000",
    "user" : {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "protected" : false,
      "id_str" : "51241574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461964160838803457\/8z9FImcv_normal.png",
      "id" : 51241574,
      "verified" : true
    }
  },
  "id" : 778237590352826368,
  "created_at" : "2016-09-20 14:21:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778237551475916801",
  "text" : "Reading my 2007 IEEE magazine about RFID's.",
  "id" : 778237551475916801,
  "created_at" : "2016-09-20 14:21:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778214927857176576",
  "text" : "Flash isn't good for the web only for movies and presentations. People do just attack it.",
  "id" : 778214927857176576,
  "created_at" : "2016-09-20 12:51:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/778213026390429696\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/mJKWEgJAJo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CszEn1LVIAABlb3.jpg",
      "id_str" : "778213024196796416",
      "id" : 778213024196796416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CszEn1LVIAABlb3.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/mJKWEgJAJo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778213026390429696",
  "text" : "https:\/\/t.co\/mJKWEgJAJo",
  "id" : 778213026390429696,
  "created_at" : "2016-09-20 12:43:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/FivhZgob32",
      "expanded_url" : "http:\/\/gulfelitemag.com\/millennials-worst-generation-ever-live\/",
      "display_url" : "gulfelitemag.com\/millennials-wo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778210534709690368",
  "text" : "https:\/\/t.co\/FivhZgob32 millennials-worst-generation-ever-live",
  "id" : 778210534709690368,
  "created_at" : "2016-09-20 12:33:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bloomberg",
      "screen_name" : "business",
      "indices" : [ 70, 79 ],
      "id_str" : "34713362",
      "id" : 34713362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/8lJDAsfqMd",
      "expanded_url" : "http:\/\/bloom.bg\/1KUzQEA",
      "display_url" : "bloom.bg\/1KUzQEA"
    } ]
  },
  "geo" : { },
  "id_str" : "778210035033841664",
  "text" : "Gen X Was Right: Reality Really Does Bite https:\/\/t.co\/8lJDAsfqMd via @business",
  "id" : 778210035033841664,
  "created_at" : "2016-09-20 12:31:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 65, 73 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/RZQVNUTKrE",
      "expanded_url" : "https:\/\/youtu.be\/eoC82RuAxqw",
      "display_url" : "youtu.be\/eoC82RuAxqw"
    } ]
  },
  "geo" : { },
  "id_str" : "778207546792407040",
  "text" : "Pearl Jam- Not For You (with Lyrics) https:\/\/t.co\/RZQVNUTKrE via @YouTube Remember I do.",
  "id" : 778207546792407040,
  "created_at" : "2016-09-20 12:21:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/ak0Rd80kK6",
      "expanded_url" : "https:\/\/youtu.be\/c30q0gWW-fA",
      "display_url" : "youtu.be\/c30q0gWW-fA"
    } ]
  },
  "geo" : { },
  "id_str" : "778206532097933312",
  "text" : "Mudhoney-What Moves The Heart? https:\/\/t.co\/ak0Rd80kK6 via @YouTube",
  "id" : 778206532097933312,
  "created_at" : "2016-09-20 12:17:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778180272927993856",
  "text" : "I am changing my profile picture today just don't fantasize about who you aren't.",
  "id" : 778180272927993856,
  "created_at" : "2016-09-20 10:33:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 56, 64 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/9hWIhYaTLi",
      "expanded_url" : "https:\/\/youtu.be\/0K0vUpKrSw4",
      "display_url" : "youtu.be\/0K0vUpKrSw4"
    } ]
  },
  "geo" : { },
  "id_str" : "778178851369254912",
  "text" : "Bad Religion - No Substance https:\/\/t.co\/9hWIhYaTLi via @YouTube",
  "id" : 778178851369254912,
  "created_at" : "2016-09-20 10:27:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778174391502901249",
  "text" : "Using the Steinberg SDK today I'm just not using JUCE. I don't like Julian. Plus I have my own audio plug-in framework.",
  "id" : 778174391502901249,
  "created_at" : "2016-09-20 10:10:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elite Daily",
      "screen_name" : "EliteDaily",
      "indices" : [ 80, 91 ],
      "id_str" : "331057915",
      "id" : 331057915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/5mIw2iKAdX",
      "expanded_url" : "http:\/\/elitedaily.com\/?p=190172",
      "display_url" : "elitedaily.com\/?p=190172"
    } ]
  },
  "geo" : { },
  "id_str" : "778170600548433920",
  "text" : "How To Set Yourself Apart From The P*ssy Generation https:\/\/t.co\/5mIw2iKAdX via @EliteDaily",
  "id" : 778170600548433920,
  "created_at" : "2016-09-20 09:55:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778169284279361538",
  "text" : "I have over 100 demos that nobody has ever even heard.",
  "id" : 778169284279361538,
  "created_at" : "2016-09-20 09:49:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SoundCloud",
      "indices" : [ 48, 59 ]
    }, {
      "text" : "np",
      "indices" : [ 61, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/NB5ohHsHMx",
      "expanded_url" : "https:\/\/soundcloud.com\/jdm7dv\/var_string?utm_source=soundcloud&utm_campaign=share&utm_medium=twitter",
      "display_url" : "soundcloud.com\/jdm7dv\/var_str\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778024918327947264",
  "text" : "Have you heard \u2018F_Theory.\u2019 by Jonathan Moore on #SoundCloud? #np https:\/\/t.co\/NB5ohHsHMx",
  "id" : 778024918327947264,
  "created_at" : "2016-09-20 00:16:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/0USUN5YLAN",
      "expanded_url" : "http:\/\/www.physicsoverflow.org\/26941\/from-string-theory-to-m-theory-to-f-theory-what-is-the-roadmap",
      "display_url" : "physicsoverflow.org\/26941\/from-str\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778021746494541824",
  "text" : "https:\/\/t.co\/0USUN5YLAN",
  "id" : 778021746494541824,
  "created_at" : "2016-09-20 00:03:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778016227306381312",
  "text" : "\"We are the Nation's first line of defense. We accomplish what others cannot accomplish and go where others cannot go.\"",
  "id" : 778016227306381312,
  "created_at" : "2016-09-19 23:41:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778013656466554880",
  "text" : "God means the supreme reality and that is what I gave her. Goodbye for now. England you would lose again.",
  "id" : 778013656466554880,
  "created_at" : "2016-09-19 23:31:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 55, 63 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/DQJo2zvpS1",
      "expanded_url" : "https:\/\/youtu.be\/-Dd28nxUpLY",
      "display_url" : "youtu.be\/-Dd28nxUpLY"
    } ]
  },
  "geo" : { },
  "id_str" : "778012185972834304",
  "text" : "Getting nailed by the King https:\/\/t.co\/DQJo2zvpS1 via @YouTube",
  "id" : 778012185972834304,
  "created_at" : "2016-09-19 23:25:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778010724606115841",
  "text" : "No one in the area will let me be a global dominate man. The women try to keep me down.",
  "id" : 778010724606115841,
  "created_at" : "2016-09-19 23:19:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/JNmZyL2vR9",
      "expanded_url" : "https:\/\/youtu.be\/Sboh-_w43W8",
      "display_url" : "youtu.be\/Sboh-_w43W8"
    } ]
  },
  "geo" : { },
  "id_str" : "778007686034165760",
  "text" : "The Secret of Oz by Bill Still https:\/\/t.co\/JNmZyL2vR9 via @YouTube",
  "id" : 778007686034165760,
  "created_at" : "2016-09-19 23:07:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/hYkepxetMf",
      "expanded_url" : "http:\/\/JonathanMoore.com",
      "display_url" : "JonathanMoore.com"
    } ]
  },
  "geo" : { },
  "id_str" : "778007160454348800",
  "text" : "https:\/\/t.co\/hYkepxetMf I did score a 140 on my IQ test I want the domain and .org money is made up out of thin air.",
  "id" : 778007160454348800,
  "created_at" : "2016-09-19 23:05:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 80, 88 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/KAe66B1uaJ",
      "expanded_url" : "https:\/\/youtu.be\/MyjTrwOMSO4",
      "display_url" : "youtu.be\/MyjTrwOMSO4"
    } ]
  },
  "geo" : { },
  "id_str" : "778003910992822272",
  "text" : "Third Eye Blind - Semi-Charmed Life (HQ) [Official] https:\/\/t.co\/KAe66B1uaJ via @YouTube",
  "id" : 778003910992822272,
  "created_at" : "2016-09-19 22:52:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AlterNet",
      "screen_name" : "AlterNet",
      "indices" : [ 33, 42 ],
      "id_str" : "18851248",
      "id" : 18851248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/WRyYRBLWYk",
      "expanded_url" : "http:\/\/www.alternet.org\/story\/43095\/air_travel_is_killing_the_planet",
      "display_url" : "alternet.org\/story\/43095\/ai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778000987986485248",
  "text" : "Air Travel Is Killing the Planet @alternet https:\/\/t.co\/WRyYRBLWYk",
  "id" : 778000987986485248,
  "created_at" : "2016-09-19 22:41:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New Yorker",
      "screen_name" : "NewYorker",
      "indices" : [ 77, 87 ],
      "id_str" : "14677919",
      "id" : 14677919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/3aAgohDCen",
      "expanded_url" : "http:\/\/www.newyorker.com\/business\/currency\/linkedins-complicated-bet-on-the-future-of-work",
      "display_url" : "newyorker.com\/business\/curre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777999499402833920",
  "text" : "LinkedIn\u2019s Complicated Bet on the Future of Work https:\/\/t.co\/3aAgohDCen via @newyorker",
  "id" : 777999499402833920,
  "created_at" : "2016-09-19 22:35:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777998094034145281",
  "text" : "\"You thought you'd found a friend To take you out of this place. Someone you could lend a hand In return for grace.\"",
  "id" : 777998094034145281,
  "created_at" : "2016-09-19 22:29:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777997543062040576",
  "text" : "I know your plans trying to hack me world I hate you all after how evil you all really are.",
  "id" : 777997543062040576,
  "created_at" : "2016-09-19 22:27:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777994704864542720",
  "text" : "Got a trouble with me Bono? I will kick your ass.",
  "id" : 777994704864542720,
  "created_at" : "2016-09-19 22:16:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 61, 69 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/0frw6c2axz",
      "expanded_url" : "https:\/\/youtu.be\/YLhtPtR4IQk",
      "display_url" : "youtu.be\/YLhtPtR4IQk"
    } ]
  },
  "geo" : { },
  "id_str" : "777992027518763008",
  "text" : "U2 - The Troubles (Original Mix) https:\/\/t.co\/0frw6c2axz via @YouTube",
  "id" : 777992027518763008,
  "created_at" : "2016-09-19 22:05:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/017SE4W31B",
      "expanded_url" : "https:\/\/hbr.org\/2011\/11\/the-trouble-with-bright-kids",
      "display_url" : "hbr.org\/2011\/11\/the-tr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777991911802101760",
  "text" : "https:\/\/t.co\/017SE4W31B The trouble with bright kids.",
  "id" : 777991911802101760,
  "created_at" : "2016-09-19 22:05:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777989640284434432",
  "text" : "Programming with JUCE tomorrow, world and I'm not letting in my brain as to what I'm searching for or being that gullible.Web history is off",
  "id" : 777989640284434432,
  "created_at" : "2016-09-19 21:55:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/9nqFpbwQoR",
      "expanded_url" : "https:\/\/youtu.be\/afam2nIae4o",
      "display_url" : "youtu.be\/afam2nIae4o"
    } ]
  },
  "geo" : { },
  "id_str" : "777987703736528896",
  "text" : "The Who - The Kids Are Alright https:\/\/t.co\/9nqFpbwQoR via @YouTube I was going to study systems biology with her but now I don't know.",
  "id" : 777987703736528896,
  "created_at" : "2016-09-19 21:48:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 64, 72 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/6nC5OKh6jj",
      "expanded_url" : "https:\/\/youtu.be\/FRBiTbuZIGM",
      "display_url" : "youtu.be\/FRBiTbuZIGM"
    } ]
  },
  "geo" : { },
  "id_str" : "777985933002039296",
  "text" : "Bad Religion - All Fantastic Images https:\/\/t.co\/6nC5OKh6jj via @YouTube",
  "id" : 777985933002039296,
  "created_at" : "2016-09-19 21:41:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777984821830291456",
  "text" : "I'm not gay yet.",
  "id" : 777984821830291456,
  "created_at" : "2016-09-19 21:36:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/JZdD5yYQNr",
      "expanded_url" : "http:\/\/mentalfloss.com\/article\/61868\/10-exceptionally-clever-female-con-artists",
      "display_url" : "mentalfloss.com\/article\/61868\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777984577176567808",
  "text" : "https:\/\/t.co\/JZdD5yYQNr",
  "id" : 777984577176567808,
  "created_at" : "2016-09-19 21:35:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BI Tech",
      "screen_name" : "SAI",
      "indices" : [ 77, 81 ],
      "id_str" : "8841372",
      "id" : 8841372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/MzRGfkdvpo",
      "expanded_url" : "http:\/\/read.bi\/1wApwbN",
      "display_url" : "read.bi\/1wApwbN"
    } ]
  },
  "geo" : { },
  "id_str" : "777980888860729344",
  "text" : "The \"social media phase of the Internet\" is over https:\/\/t.co\/MzRGfkdvpo via @sai",
  "id" : 777980888860729344,
  "created_at" : "2016-09-19 21:21:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777973684510261248",
  "text" : "Wanna see me flip off Facebook F.I.N.E.",
  "id" : 777973684510261248,
  "created_at" : "2016-09-19 20:52:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777973007339913216",
  "text" : "Wanna play pool everyone? Side packet. I'm a man fucking know. Google I'm not using my alias so you can follow me anymore.",
  "id" : 777973007339913216,
  "created_at" : "2016-09-19 20:49:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777972215593725952",
  "text" : "Splice is new I go through older channels.",
  "id" : 777972215593725952,
  "created_at" : "2016-09-19 20:46:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777970572617719808",
  "text" : "Where did I first hear of VST's and Digidesign? Google by luck in 2003. That was obvious wasn't it?",
  "id" : 777970572617719808,
  "created_at" : "2016-09-19 20:40:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 50, 58 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/vwftiG7JKP",
      "expanded_url" : "https:\/\/youtu.be\/FhKobpwhnhI",
      "display_url" : "youtu.be\/FhKobpwhnhI"
    } ]
  },
  "geo" : { },
  "id_str" : "777968742475202560",
  "text" : "Aphex  Twin live 2013 https:\/\/t.co\/vwftiG7JKP via @YouTube",
  "id" : 777968742475202560,
  "created_at" : "2016-09-19 20:32:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777957955077537792",
  "text" : "I called my manager and she is assigning me someone new. Female for next month.",
  "id" : 777957955077537792,
  "created_at" : "2016-09-19 19:50:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 85, 89 ],
      "id_str" : "28785486",
      "id" : 28785486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/pYxx8hnzAs",
      "expanded_url" : "http:\/\/abcnews.go.com\/Technology\/story?id=4858780&page=1",
      "display_url" : "abcnews.go.com\/Technology\/sto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777956227187875840",
  "text" : "On tap in space: Urine will not go to waste - ABC News - https:\/\/t.co\/pYxx8hnzAs via @ABC",
  "id" : 777956227187875840,
  "created_at" : "2016-09-19 19:43:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777954752734846976",
  "text" : "I'm disappointed on how this area and the world keeps treating me over one hot local 25 year old. They really must want suicide???",
  "id" : 777954752734846976,
  "created_at" : "2016-09-19 19:37:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/777943451593744384\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/QqSElAQXH9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsvPcjNWIAAmEDj.jpg",
      "id_str" : "777943450046046208",
      "id" : 777943450046046208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsvPcjNWIAAmEDj.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/QqSElAQXH9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777943451593744384",
  "text" : "https:\/\/t.co\/QqSElAQXH9",
  "id" : 777943451593744384,
  "created_at" : "2016-09-19 18:52:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/777940189159227392\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/9fSe0O1Yjs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsvMemuWEAYsj-T.jpg",
      "id_str" : "777940186814615558",
      "id" : 777940186814615558,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsvMemuWEAYsj-T.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/9fSe0O1Yjs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777940189159227392",
  "text" : "https:\/\/t.co\/9fSe0O1Yjs",
  "id" : 777940189159227392,
  "created_at" : "2016-09-19 18:39:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777928514456739840",
  "text" : "Facebook still trying to win people back with fake beautiful woman and profiles? Getting off to VR? The whole world is a stage.",
  "id" : 777928514456739840,
  "created_at" : "2016-09-19 17:53:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 57, 65 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/0Lqz8QchnY",
      "expanded_url" : "https:\/\/youtu.be\/r80HF68KM8g",
      "display_url" : "youtu.be\/r80HF68KM8g"
    } ]
  },
  "geo" : { },
  "id_str" : "777925602452135936",
  "text" : "Alice In Chains - No Excuses https:\/\/t.co\/0Lqz8QchnY via @YouTube",
  "id" : 777925602452135936,
  "created_at" : "2016-09-19 17:41:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "indices" : [ 73, 84 ],
      "id_str" : "15438913",
      "id" : 15438913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/aY5s8J8Skh",
      "expanded_url" : "http:\/\/dailym.ai\/1XqoRgu",
      "display_url" : "dailym.ai\/1XqoRgu"
    } ]
  },
  "geo" : { },
  "id_str" : "777923836968853505",
  "text" : "Diabetes pill that could help us live to 120 https:\/\/t.co\/aY5s8J8Skh via @MailOnline",
  "id" : 777923836968853505,
  "created_at" : "2016-09-19 17:34:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR",
      "screen_name" : "NPR",
      "indices" : [ 4, 8 ],
      "id_str" : "5392522",
      "id" : 5392522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/TAeyYOsSRN",
      "expanded_url" : "https:\/\/n.pr\/29U0a5s",
      "display_url" : "n.pr\/29U0a5s"
    } ]
  },
  "geo" : { },
  "id_str" : "777923605443309569",
  "text" : "Via @NPR: Episode 576: When Women Stopped Coding https:\/\/t.co\/TAeyYOsSRN Thank you Cyndi Lauper. And don't fall for the cult of immortality.",
  "id" : 777923605443309569,
  "created_at" : "2016-09-19 17:33:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 67, 75 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/tJpdVhxDiJ",
      "expanded_url" : "https:\/\/youtu.be\/9U-VH9RveiA",
      "display_url" : "youtu.be\/9U-VH9RveiA"
    } ]
  },
  "geo" : { },
  "id_str" : "777920919041957888",
  "text" : "Bad Religion - Them and Us with lyrics https:\/\/t.co\/tJpdVhxDiJ via @YouTube There isn't a difference.",
  "id" : 777920919041957888,
  "created_at" : "2016-09-19 17:22:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Muse",
      "screen_name" : "dailymuse",
      "indices" : [ 90, 100 ],
      "id_str" : "334984155",
      "id" : 334984155
    }, {
      "name" : "Alex Honeysett",
      "screen_name" : "AHoneysett",
      "indices" : [ 101, 112 ],
      "id_str" : "19767679",
      "id" : 19767679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/QEn6ma5KtV",
      "expanded_url" : "https:\/\/www.themuse.com\/advice\/why-youre-losing-followers-on-social-media-and-how-to-stop",
      "display_url" : "themuse.com\/advice\/why-you\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777919773330042880",
  "text" : "Why You're Losing Followers on Social Media (and How to Stop) https:\/\/t.co\/QEn6ma5KtV via @dailymuse @AHoneysett \nI do just overwhelm.",
  "id" : 777919773330042880,
  "created_at" : "2016-09-19 17:18:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faithful Thinkers",
      "screen_name" : "FaithfulThinker",
      "indices" : [ 3, 19 ],
      "id_str" : "181962146",
      "id" : 181962146
    }, {
      "name" : "Dr. Victor S Couzens",
      "screen_name" : "drvictorcouzens",
      "indices" : [ 43, 59 ],
      "id_str" : "249305288",
      "id" : 249305288
    }, {
      "name" : "Jonathan Moore",
      "screen_name" : "jdm7dv",
      "indices" : [ 60, 67 ],
      "id_str" : "40799920",
      "id" : 40799920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777918719318253568",
  "text" : "RT @FaithfulThinker: Thanks for following, @drvictorcouzens @jdm7dv. I pray my tweets are a blessing to you and your followers! &gt;&gt; https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/commun.it\" rel=\"nofollow\"\u003ECommun.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Victor S Couzens",
        "screen_name" : "drvictorcouzens",
        "indices" : [ 22, 38 ],
        "id_str" : "249305288",
        "id" : 249305288
      }, {
        "name" : "Jonathan Moore",
        "screen_name" : "jdm7dv",
        "indices" : [ 39, 46 ],
        "id_str" : "40799920",
        "id" : 40799920
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/aGlv4perRO",
        "expanded_url" : "http:\/\/bit.ly\/_want_this_free",
        "display_url" : "bit.ly\/_want_this_free"
      } ]
    },
    "geo" : { },
    "id_str" : "777914261016186880",
    "text" : "Thanks for following, @drvictorcouzens @jdm7dv. I pray my tweets are a blessing to you and your followers! &gt;&gt; https:\/\/t.co\/aGlv4perRO",
    "id" : 777914261016186880,
    "created_at" : "2016-09-19 16:56:27 +0000",
    "user" : {
      "name" : "Faithful Thinkers",
      "screen_name" : "FaithfulThinker",
      "protected" : false,
      "id_str" : "181962146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1109164267\/Faithful_Thinkers_Logo-_Small_Icon_normal.jpg",
      "id" : 181962146,
      "verified" : false
    }
  },
  "id" : 777918719318253568,
  "created_at" : "2016-09-19 17:14:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 50, 57 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/X0c0U3yK6E",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/robertberger\/2015\/02\/09\/5-best-ira-options-for-every-type-of-investor\/#359f25885185",
      "display_url" : "forbes.com\/sites\/robertbe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777918307156561920",
  "text" : "5 Best IRA Options For Every Type Of Investor via @forbes https:\/\/t.co\/X0c0U3yK6E",
  "id" : 777918307156561920,
  "created_at" : "2016-09-19 17:12:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincent Granville",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/KSxI0lziDc",
      "expanded_url" : "http:\/\/ow.ly\/GOpC304jQ2C",
      "display_url" : "ow.ly\/GOpC304jQ2C"
    } ]
  },
  "geo" : { },
  "id_str" : "777917707253587968",
  "text" : "RT @analyticbridge: When Data Viz Trumps Statistics https:\/\/t.co\/KSxI0lziDc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/KSxI0lziDc",
        "expanded_url" : "http:\/\/ow.ly\/GOpC304jQ2C",
        "display_url" : "ow.ly\/GOpC304jQ2C"
      } ]
    },
    "geo" : { },
    "id_str" : "777915698697932801",
    "text" : "When Data Viz Trumps Statistics https:\/\/t.co\/KSxI0lziDc",
    "id" : 777915698697932801,
    "created_at" : "2016-09-19 17:02:10 +0000",
    "user" : {
      "name" : "Vincent Granville",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729843251453140992\/SPucfBPm_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 777917707253587968,
  "created_at" : "2016-09-19 17:10:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IEEE",
      "screen_name" : "IEEEorg",
      "indices" : [ 3, 11 ],
      "id_str" : "54290504",
      "id" : 54290504
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 38, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/Rg5lxuounj",
      "expanded_url" : "http:\/\/bit.ly\/2cYnchZ",
      "display_url" : "bit.ly\/2cYnchZ"
    } ]
  },
  "geo" : { },
  "id_str" : "777915992659951618",
  "text" : "RT @IEEEorg: Here are just a few high-#tech tools that have already made their way into the classroom: https:\/\/t.co\/Rg5lxuounj via @IEEEIns\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Institute",
        "screen_name" : "IEEEInstitute",
        "indices" : [ 118, 132 ],
        "id_str" : "163897617",
        "id" : 163897617
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tech",
        "indices" : [ 25, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/Rg5lxuounj",
        "expanded_url" : "http:\/\/bit.ly\/2cYnchZ",
        "display_url" : "bit.ly\/2cYnchZ"
      } ]
    },
    "geo" : { },
    "id_str" : "777911130106662913",
    "text" : "Here are just a few high-#tech tools that have already made their way into the classroom: https:\/\/t.co\/Rg5lxuounj via @IEEEInstitute",
    "id" : 777911130106662913,
    "created_at" : "2016-09-19 16:44:00 +0000",
    "user" : {
      "name" : "IEEE",
      "screen_name" : "IEEEorg",
      "protected" : false,
      "id_str" : "54290504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474591466749034496\/2-H1zqWf_normal.jpeg",
      "id" : 54290504,
      "verified" : false
    }
  },
  "id" : 777915992659951618,
  "created_at" : "2016-09-19 17:03:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moog Synthesizers",
      "screen_name" : "moogmusicinc",
      "indices" : [ 3, 16 ],
      "id_str" : "26779967",
      "id" : 26779967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777915933511806976",
  "text" : "RT @moogmusicinc: 2016 is so heavy w\/ loss. Please go make something beautiful, give it to the world &amp; dedicate it to these angels. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/moogmusicinc\/status\/777911148028887040\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/RoqeLxdBe3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsuyCuzWcAAj4QA.jpg",
        "id_str" : "777911120644435968",
        "id" : 777911120644435968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsuyCuzWcAAj4QA.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/RoqeLxdBe3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777911148028887040",
    "text" : "2016 is so heavy w\/ loss. Please go make something beautiful, give it to the world &amp; dedicate it to these angels. https:\/\/t.co\/RoqeLxdBe3",
    "id" : 777911148028887040,
    "created_at" : "2016-09-19 16:44:05 +0000",
    "user" : {
      "name" : "Moog Synthesizers",
      "screen_name" : "moogmusicinc",
      "protected" : false,
      "id_str" : "26779967",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736287958584721409\/JcZWLecp_normal.jpg",
      "id" : 26779967,
      "verified" : true
    }
  },
  "id" : 777915933511806976,
  "created_at" : "2016-09-19 17:03:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smithsonian",
      "screen_name" : "smithsonian",
      "indices" : [ 3, 15 ],
      "id_str" : "14199378",
      "id" : 14199378
    }, {
      "name" : "Smithsonian Magazine",
      "screen_name" : "SmithsonianMag",
      "indices" : [ 111, 126 ],
      "id_str" : "17998609",
      "id" : 17998609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777915765630574592",
  "text" : "RT @smithsonian: Our forensic ornithologist explained the science you might not have seen on the big screen to @SmithsonianMag https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Smithsonian Magazine",
        "screen_name" : "SmithsonianMag",
        "indices" : [ 94, 109 ],
        "id_str" : "17998609",
        "id" : 17998609
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/OVrJKAHzVv",
        "expanded_url" : "http:\/\/bit.ly\/2cyaGkE",
        "display_url" : "bit.ly\/2cyaGkE"
      } ]
    },
    "geo" : { },
    "id_str" : "777914414569623552",
    "text" : "Our forensic ornithologist explained the science you might not have seen on the big screen to @SmithsonianMag https:\/\/t.co\/OVrJKAHzVv",
    "id" : 777914414569623552,
    "created_at" : "2016-09-19 16:57:04 +0000",
    "user" : {
      "name" : "Smithsonian",
      "screen_name" : "smithsonian",
      "protected" : false,
      "id_str" : "14199378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3481246370\/466b650a1da1c9eafaadf9f3dccaa7a8_normal.png",
      "id" : 14199378,
      "verified" : true
    }
  },
  "id" : 777915765630574592,
  "created_at" : "2016-09-19 17:02:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/l9yXSRvesx",
      "expanded_url" : "https:\/\/global.oup.com\/academic\/product\/unfair-to-genius-9780199733484?cc=us&lang=en&",
      "display_url" : "global.oup.com\/academic\/produ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777915513129340928",
  "text" : "https:\/\/t.co\/l9yXSRvesx Unfair to genius.",
  "id" : 777915513129340928,
  "created_at" : "2016-09-19 17:01:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777913249174065152",
  "text" : "My Tweets earned 6.2K impressions over this 28 day period.",
  "id" : 777913249174065152,
  "created_at" : "2016-09-19 16:52:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sourceforge",
      "screen_name" : "sourceforge",
      "indices" : [ 3, 15 ],
      "id_str" : "14118534",
      "id" : 14118534
    }, {
      "name" : "Intel",
      "screen_name" : "intel",
      "indices" : [ 22, 28 ],
      "id_str" : "2803191",
      "id" : 2803191
    }, {
      "name" : "Go Parallel",
      "screen_name" : "Go_Parallel",
      "indices" : [ 79, 91 ],
      "id_str" : "1504640684",
      "id" : 1504640684
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AI",
      "indices" : [ 92, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/XW7gIm5F1l",
      "expanded_url" : "http:\/\/sdm.link\/intdom",
      "display_url" : "sdm.link\/intdom"
    } ]
  },
  "geo" : { },
  "id_str" : "777911245101993984",
  "text" : "RT @sourceforge: Will @intel dominate artificial intelligence now and forever? @Go_Parallel #AI https:\/\/t.co\/XW7gIm5F1l https:\/\/t.co\/32Sb3W\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Intel",
        "screen_name" : "intel",
        "indices" : [ 5, 11 ],
        "id_str" : "2803191",
        "id" : 2803191
      }, {
        "name" : "Go Parallel",
        "screen_name" : "Go_Parallel",
        "indices" : [ 62, 74 ],
        "id_str" : "1504640684",
        "id" : 1504640684
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sourceforge\/status\/777906646844633088\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/32Sb3WOj1A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Csut-LCWgAAdPeN.jpg",
        "id_str" : "777906644277690368",
        "id" : 777906644277690368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Csut-LCWgAAdPeN.jpg",
        "sizes" : [ {
          "h" : 482,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 709,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 709,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 709,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/32Sb3WOj1A"
      } ],
      "hashtags" : [ {
        "text" : "AI",
        "indices" : [ 75, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/XW7gIm5F1l",
        "expanded_url" : "http:\/\/sdm.link\/intdom",
        "display_url" : "sdm.link\/intdom"
      } ]
    },
    "geo" : { },
    "id_str" : "777906646844633088",
    "text" : "Will @intel dominate artificial intelligence now and forever? @Go_Parallel #AI https:\/\/t.co\/XW7gIm5F1l https:\/\/t.co\/32Sb3WOj1A",
    "id" : 777906646844633088,
    "created_at" : "2016-09-19 16:26:12 +0000",
    "user" : {
      "name" : "sourceforge",
      "screen_name" : "sourceforge",
      "protected" : false,
      "id_str" : "14118534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1101343930\/sf_badge_64s_normal.png",
      "id" : 14118534,
      "verified" : true
    }
  },
  "id" : 777911245101993984,
  "created_at" : "2016-09-19 16:44:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 73, 80 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/AV7i0CckH5",
      "expanded_url" : "https:\/\/www.amazon.com\/dp\/1783283319\/ref=cm_sw_r_tw_dp_x_Hrb4xbS8NKMGN",
      "display_url" : "amazon.com\/dp\/1783283319\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777909686393798656",
  "text" : "Getting Started with JUCE by Martin Robinson https:\/\/t.co\/AV7i0CckH5 via @amazon I just didn't like it.",
  "id" : 777909686393798656,
  "created_at" : "2016-09-19 16:38:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC Good Food",
      "screen_name" : "bbcgoodfood",
      "indices" : [ 3, 15 ],
      "id_str" : "19644356",
      "id" : 19644356
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bbcgoodfood\/status\/777135113981362176\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/KpLfJZYM60",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsjwRDxWgAA7o_y.jpg",
      "id_str" : "777135111582154752",
      "id" : 777135111582154752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsjwRDxWgAA7o_y.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/KpLfJZYM60"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/kNWlgLvmhq",
      "expanded_url" : "http:\/\/www.bbcgoodfood.com\/recipes\/peanut-butter-chicken",
      "display_url" : "bbcgoodfood.com\/recipes\/peanut\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777908244798898176",
  "text" : "RT @bbcgoodfood: Winner winner peanut butter chicken dinner... https:\/\/t.co\/kNWlgLvmhq https:\/\/t.co\/KpLfJZYM60",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bbcgoodfood\/status\/777135113981362176\/photo\/1",
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/KpLfJZYM60",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsjwRDxWgAA7o_y.jpg",
        "id_str" : "777135111582154752",
        "id" : 777135111582154752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsjwRDxWgAA7o_y.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/KpLfJZYM60"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/kNWlgLvmhq",
        "expanded_url" : "http:\/\/www.bbcgoodfood.com\/recipes\/peanut-butter-chicken",
        "display_url" : "bbcgoodfood.com\/recipes\/peanut\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "777135113981362176",
    "text" : "Winner winner peanut butter chicken dinner... https:\/\/t.co\/kNWlgLvmhq https:\/\/t.co\/KpLfJZYM60",
    "id" : 777135113981362176,
    "created_at" : "2016-09-17 13:20:24 +0000",
    "user" : {
      "name" : "BBC Good Food",
      "screen_name" : "bbcgoodfood",
      "protected" : false,
      "id_str" : "19644356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768526238482829312\/5zg18dVR_normal.jpg",
      "id" : 19644356,
      "verified" : true
    }
  },
  "id" : 777908244798898176,
  "created_at" : "2016-09-19 16:32:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/4YBqaEkvYA",
      "expanded_url" : "http:\/\/aimath.org\/textbooks\/",
      "display_url" : "aimath.org\/textbooks\/"
    } ]
  },
  "geo" : { },
  "id_str" : "777906370381287427",
  "text" : "https:\/\/t.co\/4YBqaEkvYA Open Text Books. I'm still feeling a little gullible. Still feel good be not as nice.",
  "id" : 777906370381287427,
  "created_at" : "2016-09-19 16:25:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/hfkIf2Bsfx",
      "expanded_url" : "https:\/\/www.sharecare.com\/health\/calories\/brain-calories-at-rest?cmpid=sc-tw-sm-00-up-04172015",
      "display_url" : "sharecare.com\/health\/calorie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777901860359405568",
  "text" : "Click for more information. https:\/\/t.co\/hfkIf2Bsfx The brain consumes a lot of calories when you use it. That's way I'm small.",
  "id" : 777901860359405568,
  "created_at" : "2016-09-19 16:07:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777897922121859072",
  "text" : "I don't know why a lot of doctors want men to feel bad and look ugly or get fat.",
  "id" : 777897922121859072,
  "created_at" : "2016-09-19 15:51:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 56, 64 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/vFb3og4ddq",
      "expanded_url" : "https:\/\/youtu.be\/fu2gxZDquzA",
      "display_url" : "youtu.be\/fu2gxZDquzA"
    } ]
  },
  "geo" : { },
  "id_str" : "777895682736816128",
  "text" : "Ingrid Michaelson-The Chain https:\/\/t.co\/vFb3og4ddq via @YouTube America has the chain. Depression? No. I need sex.",
  "id" : 777895682736816128,
  "created_at" : "2016-09-19 15:42:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777888611459035136",
  "text" : "Look at how good I feel today and yet I've been bombard by negative medical propaganda. Sex no longer sells.",
  "id" : 777888611459035136,
  "created_at" : "2016-09-19 15:14:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777885445577437184",
  "text" : "People unfollow when I post yet use me and just want computer scientists to \"watch\" people have get back sex.",
  "id" : 777885445577437184,
  "created_at" : "2016-09-19 15:01:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/q5uuT0dpK7",
      "expanded_url" : "https:\/\/youtu.be\/5R682M3ZEyk",
      "display_url" : "youtu.be\/5R682M3ZEyk"
    } ]
  },
  "geo" : { },
  "id_str" : "777883778236706816",
  "text" : "Marilyn Manson - The Dope Show https:\/\/t.co\/q5uuT0dpK7 via @YouTube",
  "id" : 777883778236706816,
  "created_at" : "2016-09-19 14:55:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 77, 85 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/N2MqDpHkL8",
      "expanded_url" : "https:\/\/youtu.be\/V4A0Qya23y0",
      "display_url" : "youtu.be\/V4A0Qya23y0"
    } ]
  },
  "geo" : { },
  "id_str" : "777882309936709632",
  "text" : "Rage Against The Machine: Voice Of The Voiceless https:\/\/t.co\/N2MqDpHkL8 via @YouTube",
  "id" : 777882309936709632,
  "created_at" : "2016-09-19 14:49:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/YNFi1tvqRA",
      "expanded_url" : "http:\/\/legaldictionary.net\/child-exploitation\/",
      "display_url" : "legaldictionary.net\/child-exploita\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777881333599207424",
  "text" : "https:\/\/t.co\/YNFi1tvqRA Child Exploitation Facebook.",
  "id" : 777881333599207424,
  "created_at" : "2016-09-19 14:45:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777876980444307456",
  "text" : "Doctor wants to be on Facebook doesn't he? Success it's a goddamn baby doctor.",
  "id" : 777876980444307456,
  "created_at" : "2016-09-19 14:28:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "indices" : [ 3, 17 ],
      "id_str" : "34554134",
      "id" : 34554134
    }, {
      "name" : "SwRI",
      "screen_name" : "SwRI",
      "indices" : [ 90, 95 ],
      "id_str" : "25301238",
      "id" : 25301238
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SETITalks",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/6TOxIOQrs0",
      "expanded_url" : "http:\/\/buff.ly\/2cJ7B3Z",
      "display_url" : "buff.ly\/2cJ7B3Z"
    } ]
  },
  "geo" : { },
  "id_str" : "777876536225591296",
  "text" : "RT @SETIInstitute: #SETITalks: Pluto's interacting surface and atmosphere | Leslie Young, @SwRI | Free tix: https:\/\/t.co\/6TOxIOQrs0 https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SwRI",
        "screen_name" : "SwRI",
        "indices" : [ 71, 76 ],
        "id_str" : "25301238",
        "id" : 25301238
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SETIInstitute\/status\/777873678801506304\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/xaeoXNmpX0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsuP_PbW8AApcDD.jpg",
        "id_str" : "777873677287354368",
        "id" : 777873677287354368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsuP_PbW8AApcDD.jpg",
        "sizes" : [ {
          "h" : 135,
          "resize" : "fit",
          "w" : 135
        }, {
          "h" : 135,
          "resize" : "fit",
          "w" : 135
        }, {
          "h" : 135,
          "resize" : "crop",
          "w" : 135
        }, {
          "h" : 135,
          "resize" : "fit",
          "w" : 135
        }, {
          "h" : 135,
          "resize" : "fit",
          "w" : 135
        } ],
        "display_url" : "pic.twitter.com\/xaeoXNmpX0"
      } ],
      "hashtags" : [ {
        "text" : "SETITalks",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/6TOxIOQrs0",
        "expanded_url" : "http:\/\/buff.ly\/2cJ7B3Z",
        "display_url" : "buff.ly\/2cJ7B3Z"
      } ]
    },
    "geo" : { },
    "id_str" : "777873678801506304",
    "text" : "#SETITalks: Pluto's interacting surface and atmosphere | Leslie Young, @SwRI | Free tix: https:\/\/t.co\/6TOxIOQrs0 https:\/\/t.co\/xaeoXNmpX0",
    "id" : 777873678801506304,
    "created_at" : "2016-09-19 14:15:11 +0000",
    "user" : {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "protected" : false,
      "id_str" : "34554134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758705567556743168\/TGjZ9Uwf_normal.jpg",
      "id" : 34554134,
      "verified" : true
    }
  },
  "id" : 777876536225591296,
  "created_at" : "2016-09-19 14:26:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "indices" : [ 91, 97 ],
      "id_str" : "25928253",
      "id" : 25928253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/4FWvK0vjYd",
      "expanded_url" : "http:\/\/wb.md\/1lzMiTN",
      "display_url" : "wb.md\/1lzMiTN"
    } ]
  },
  "geo" : { },
  "id_str" : "777875020462825472",
  "text" : "Taking Too Many Vitamins? Side Effects of Vitamin Overdosing https:\/\/t.co\/4FWvK0vjYd\n from @WebMD",
  "id" : 777875020462825472,
  "created_at" : "2016-09-19 14:20:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777873251687071744",
  "text" : "I'm just not taking it from that upper class doctor about heart attacks and not feeling well today.",
  "id" : 777873251687071744,
  "created_at" : "2016-09-19 14:13:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science of Us",
      "screen_name" : "thescienceofus",
      "indices" : [ 92, 107 ],
      "id_str" : "2244290719",
      "id" : 2244290719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/E7irMQu7dN",
      "expanded_url" : "http:\/\/nymag.com\/scienceofus\/2016\/08\/is-elysium-healths-basis-the-fountain-of-youth.html?mid=twitter-share-scienceofus",
      "display_url" : "nymag.com\/scienceofus\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777871745718087680",
  "text" : "An MIT Scientist Claims That This Pill Is the Fountain of Youth https:\/\/t.co\/E7irMQu7dN via @thescienceofus",
  "id" : 777871745718087680,
  "created_at" : "2016-09-19 14:07:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777869628567613440",
  "text" : "My apartment looks good on the inside after what I've done to it over the last three yearsI'm just applauded on what the outside looks like.",
  "id" : 777869628567613440,
  "created_at" : "2016-09-19 13:59:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/pCnvui3rbZ",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pubmed\/26518564",
      "display_url" : "ncbi.nlm.nih.gov\/pubmed\/26518564"
    } ]
  },
  "geo" : { },
  "id_str" : "777866992464396288",
  "text" : "Effect of SkQ1 eye drops on the rat lens metabolomic composition and the chaperone activity of \u03B1-crystallin. - NCBI https:\/\/t.co\/pCnvui3rbZ",
  "id" : 777866992464396288,
  "created_at" : "2016-09-19 13:48:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBM Accessibility",
      "screen_name" : "IBMAccess",
      "indices" : [ 3, 13 ],
      "id_str" : "29533641",
      "id" : 29533641
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aging",
      "indices" : [ 72, 78 ]
    }, {
      "text" : "ibmedge",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/7wDk6XjKMN",
      "expanded_url" : "http:\/\/ow.ly\/nyh8304l94O",
      "display_url" : "ow.ly\/nyh8304l94O"
    } ]
  },
  "geo" : { },
  "id_str" : "777865429519855616",
  "text" : "RT @IBMAccess: Explore the challenges &amp; opportunities created by an #aging society: New Report https:\/\/t.co\/7wDk6XjKMN #ibmedge https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IBMAccess\/status\/777840950798323712\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/LJAhIfSEZW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CstyOKHWEAAlmtA.jpg",
        "id_str" : "777840948210438144",
        "id" : 777840948210438144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CstyOKHWEAAlmtA.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/LJAhIfSEZW"
      } ],
      "hashtags" : [ {
        "text" : "aging",
        "indices" : [ 57, 63 ]
      }, {
        "text" : "ibmedge",
        "indices" : [ 108, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/7wDk6XjKMN",
        "expanded_url" : "http:\/\/ow.ly\/nyh8304l94O",
        "display_url" : "ow.ly\/nyh8304l94O"
      } ]
    },
    "geo" : { },
    "id_str" : "777840950798323712",
    "text" : "Explore the challenges &amp; opportunities created by an #aging society: New Report https:\/\/t.co\/7wDk6XjKMN #ibmedge https:\/\/t.co\/LJAhIfSEZW",
    "id" : 777840950798323712,
    "created_at" : "2016-09-19 12:05:08 +0000",
    "user" : {
      "name" : "IBM Accessibility",
      "screen_name" : "IBMAccess",
      "protected" : false,
      "id_str" : "29533641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687645892644593664\/Ztwq3nHR_normal.jpg",
      "id" : 29533641,
      "verified" : false
    }
  },
  "id" : 777865429519855616,
  "created_at" : "2016-09-19 13:42:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 57, 65 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/40AEoaWYqe",
      "expanded_url" : "https:\/\/youtu.be\/qN4bH8cmJpY",
      "display_url" : "youtu.be\/qN4bH8cmJpY"
    } ]
  },
  "geo" : { },
  "id_str" : "777862802102968320",
  "text" : "The Facts of Life Theme Song https:\/\/t.co\/40AEoaWYqe via @YouTube Cleaning",
  "id" : 777862802102968320,
  "created_at" : "2016-09-19 13:31:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777861877971976192",
  "text" : "Twitter must be getting rid of fake profiles.",
  "id" : 777861877971976192,
  "created_at" : "2016-09-19 13:28:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/7HBZyA6ENn",
      "expanded_url" : "http:\/\/schizophrenia.com\/?page_id=716",
      "display_url" : "schizophrenia.com\/?page_id=716"
    } ]
  },
  "geo" : { },
  "id_str" : "777858568854839296",
  "text" : "https:\/\/t.co\/7HBZyA6ENn B Vitamins for Schizophrenia",
  "id" : 777858568854839296,
  "created_at" : "2016-09-19 13:15:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SOS Magazine",
      "screen_name" : "sospublications",
      "indices" : [ 3, 19 ],
      "id_str" : "76075215",
      "id" : 76075215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/I96RXMbXnD",
      "expanded_url" : "http:\/\/sosm.ag\/sep16powell",
      "display_url" : "sosm.ag\/sep16powell"
    } ]
  },
  "geo" : { },
  "id_str" : "777833002479083520",
  "text" : "RT @sospublications: So much to learn in this rock mix breakdown from the awesome, Grammy-winning Vance Powell. https:\/\/t.co\/I96RXMbXnD htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sospublications\/status\/777825908933656576\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/STBWFGIknI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CstkAzMXYAA-wIm.jpg",
        "id_str" : "777825325556391936",
        "id" : 777825325556391936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CstkAzMXYAA-wIm.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/STBWFGIknI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/I96RXMbXnD",
        "expanded_url" : "http:\/\/sosm.ag\/sep16powell",
        "display_url" : "sosm.ag\/sep16powell"
      } ]
    },
    "geo" : { },
    "id_str" : "777825908933656576",
    "text" : "So much to learn in this rock mix breakdown from the awesome, Grammy-winning Vance Powell. https:\/\/t.co\/I96RXMbXnD https:\/\/t.co\/STBWFGIknI",
    "id" : 777825908933656576,
    "created_at" : "2016-09-19 11:05:22 +0000",
    "user" : {
      "name" : "SOS Magazine",
      "screen_name" : "sospublications",
      "protected" : false,
      "id_str" : "76075215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743144500403515392\/mZeaGITf_normal.jpg",
      "id" : 76075215,
      "verified" : false
    }
  },
  "id" : 777833002479083520,
  "created_at" : "2016-09-19 11:33:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFF",
      "screen_name" : "EFF",
      "indices" : [ 92, 96 ],
      "id_str" : "4816",
      "id" : 4816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/wRnlt4Ck7V",
      "expanded_url" : "https:\/\/www.eff.org\/deeplinks\/2013\/07\/how-opt-out-twitters-tailored-advertisements-and-more",
      "display_url" : "eff.org\/deeplinks\/2013\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777827269716869120",
  "text" : "How To Opt Out Of Twitter's Tailored Advertisements (And More!) https:\/\/t.co\/wRnlt4Ck7V via @EFF",
  "id" : 777827269716869120,
  "created_at" : "2016-09-19 11:10:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777825543978946561",
  "text" : "My Calvin Klein jeans fit again are a little ripped but lost some belly fat.",
  "id" : 777825543978946561,
  "created_at" : "2016-09-19 11:03:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777813520985579520",
  "text" : "This world is just treating me like Aaron Schwartz too because I believe in financial freedom and equality for all.",
  "id" : 777813520985579520,
  "created_at" : "2016-09-19 10:16:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/AeQ0k9BAvp",
      "expanded_url" : "http:\/\/www.omicsonline.org\/top-best-open-access-journals.php",
      "display_url" : "omicsonline.org\/top-best-open-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777812478533206016",
  "text" : "I just shared this with Mensa so now I guess I can share it with you. https:\/\/t.co\/AeQ0k9BAvp",
  "id" : 777812478533206016,
  "created_at" : "2016-09-19 10:12:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/JNmZyL2vR9",
      "expanded_url" : "https:\/\/youtu.be\/Sboh-_w43W8",
      "display_url" : "youtu.be\/Sboh-_w43W8"
    } ]
  },
  "geo" : { },
  "id_str" : "777809633088077824",
  "text" : "The Secret of Oz by Bill Still https:\/\/t.co\/JNmZyL2vR9 via @YouTube",
  "id" : 777809633088077824,
  "created_at" : "2016-09-19 10:00:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777806027840450560",
  "text" : "The guitar is merely one instrument you rock star sex bohemian.",
  "id" : 777806027840450560,
  "created_at" : "2016-09-19 09:46:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 86, 94 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/kHbwavagx6",
      "expanded_url" : "https:\/\/youtu.be\/B9i9SKgWWGY",
      "display_url" : "youtu.be\/B9i9SKgWWGY"
    } ]
  },
  "geo" : { },
  "id_str" : "777801076405854208",
  "text" : "ASUS ROG G752 Gaming Laptop - World Domination.  Evolved. https:\/\/t.co\/kHbwavagx6 via @YouTube",
  "id" : 777801076405854208,
  "created_at" : "2016-09-19 09:26:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 57, 65 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/CuEoCni4Ob",
      "expanded_url" : "https:\/\/youtu.be\/gI-Xb8iKtRc",
      "display_url" : "youtu.be\/gI-Xb8iKtRc"
    } ]
  },
  "geo" : { },
  "id_str" : "777800570027597825",
  "text" : "Soundgarden \"Boot Camp\" Live https:\/\/t.co\/CuEoCni4Ob via @YouTube",
  "id" : 777800570027597825,
  "created_at" : "2016-09-19 09:24:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777799543249375232",
  "text" : "I had to reset my Mendeley password from about five years ago.",
  "id" : 777799543249375232,
  "created_at" : "2016-09-19 09:20:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/liZPS307qS",
      "expanded_url" : "http:\/\/dev.mendeley.com\/",
      "display_url" : "dev.mendeley.com"
    } ]
  },
  "geo" : { },
  "id_str" : "777791944214937600",
  "text" : "https:\/\/t.co\/liZPS307qS Open Science for everyone.",
  "id" : 777791944214937600,
  "created_at" : "2016-09-19 08:50:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777790931399536640",
  "text" : "I just asked Mensa if we should start a Mendeley Group.",
  "id" : 777790931399536640,
  "created_at" : "2016-09-19 08:46:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/IdF18UKwf8",
      "expanded_url" : "http:\/\/www.springernature.com\/gp\/group\/media\/press-releases\/over-60-of-2015-research-articles-on-nature-com-are-open-access\/835426",
      "display_url" : "springernature.com\/gp\/group\/media\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777778896766926848",
  "text" : "https:\/\/t.co\/IdF18UKwf8",
  "id" : 777778896766926848,
  "created_at" : "2016-09-19 07:58:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gigaom",
      "screen_name" : "gigaom",
      "indices" : [ 108, 115 ],
      "id_str" : "2893971",
      "id" : 2893971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Ektdiqi6rI",
      "expanded_url" : "https:\/\/gigaom.com\/2014\/12\/02\/nature-journals-now-free-as-open-access-model-gains-steam\/",
      "display_url" : "gigaom.com\/2014\/12\/02\/nat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777778118266351616",
  "text" : "&lt;em&gt;Nature&lt;\/em&gt; journals now free, as open access model gains steam https:\/\/t.co\/Ektdiqi6rI via @Gigaom",
  "id" : 777778118266351616,
  "created_at" : "2016-09-19 07:55:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/JlbqQCw7Ou",
      "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2015\/feb\/07\/aaron-swartz-suicide-internets-own-boy?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777776645268791296",
  "text" : "Aaron Swartz stood up for freedom and fairness \u2013 and was hounded to his death https:\/\/t.co\/JlbqQCw7Ou",
  "id" : 777776645268791296,
  "created_at" : "2016-09-19 07:49:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 69, 73 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/EKOfF72gDk",
      "expanded_url" : "http:\/\/cnn.it\/1NdX5fa",
      "display_url" : "cnn.it\/1NdX5fa"
    } ]
  },
  "geo" : { },
  "id_str" : "777769553803767809",
  "text" : "Ancient teeth found in China challenge modern human migration theory @CNN https:\/\/t.co\/EKOfF72gDk",
  "id" : 777769553803767809,
  "created_at" : "2016-09-19 07:21:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777651309994446848",
  "in_reply_to_user_id" : 411185138,
  "text" : "@Mo_Mo4875 If you can find a way to force people to talk me online and quit hiding or blocking me than do it.People have used me since 2004.",
  "id" : 777651309994446848,
  "created_at" : "2016-09-18 23:31:35 +0000",
  "in_reply_to_screen_name" : "morgan_munsey",
  "in_reply_to_user_id_str" : "411185138",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/bXAiyFgmmH",
      "expanded_url" : "http:\/\/www.ted.com\/talks\/dan_dennett_on_our_consciousness?utm_source=twitter.com&utm_medium=social&utm_campaign=tedspread",
      "display_url" : "ted.com\/talks\/dan_denn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777650187078668288",
  "text" : "The illusion of consciousness https:\/\/t.co\/bXAiyFgmmH",
  "id" : 777650187078668288,
  "created_at" : "2016-09-18 23:27:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777626318057906177",
  "text" : "From now on when I talk to women I am always going to mention Mensa and what I can do on their app.",
  "id" : 777626318057906177,
  "created_at" : "2016-09-18 21:52:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777624900030857216",
  "in_reply_to_user_id" : 411185138,
  "text" : "@Mo_Mo4875 I am in the official Mensa Linked in Group. There is none higher.It is the world oldest High IQ society.",
  "id" : 777624900030857216,
  "created_at" : "2016-09-18 21:46:38 +0000",
  "in_reply_to_screen_name" : "morgan_munsey",
  "in_reply_to_user_id_str" : "411185138",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777624203189190656",
  "in_reply_to_user_id" : 411185138,
  "text" : "@Mo_Mo4875 One day you will wonder what these social networks have done to you I really don't want to be a part of it anymore.",
  "id" : 777624203189190656,
  "created_at" : "2016-09-18 21:43:52 +0000",
  "in_reply_to_screen_name" : "morgan_munsey",
  "in_reply_to_user_id_str" : "411185138",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hayes\uD83D\uDCBB\uD83C\uDFAE\uD83D\uDC4D",
      "screen_name" : "RyannosaurusRex",
      "indices" : [ 0, 16 ],
      "id_str" : "15887030",
      "id" : 15887030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777611668939542528",
  "in_reply_to_user_id" : 15887030,
  "text" : "@RyannosaurusRex Are you in a Mensa group Hayes? If not I don't want to talk to you.",
  "id" : 777611668939542528,
  "created_at" : "2016-09-18 20:54:03 +0000",
  "in_reply_to_screen_name" : "RyannosaurusRex",
  "in_reply_to_user_id_str" : "15887030",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hayes\uD83D\uDCBB\uD83C\uDFAE\uD83D\uDC4D",
      "screen_name" : "RyannosaurusRex",
      "indices" : [ 0, 16 ],
      "id_str" : "15887030",
      "id" : 15887030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777610447193272320",
  "in_reply_to_user_id" : 15887030,
  "text" : "@RyannosaurusRex Who are you to me Hayes I've helped with two almost three Nobel Prizes and I was and MVP too.",
  "id" : 777610447193272320,
  "created_at" : "2016-09-18 20:49:12 +0000",
  "in_reply_to_screen_name" : "RyannosaurusRex",
  "in_reply_to_user_id_str" : "15887030",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 66, 74 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/1NjD1GQdEk",
      "expanded_url" : "https:\/\/youtu.be\/m7TI6PtlKNY",
      "display_url" : "youtu.be\/m7TI6PtlKNY"
    } ]
  },
  "geo" : { },
  "id_str" : "777606202071126016",
  "text" : "Pearl Jam - Rearviewmirror (SNL 1994) https:\/\/t.co\/1NjD1GQdEk via @YouTube",
  "id" : 777606202071126016,
  "created_at" : "2016-09-18 20:32:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 52, 60 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/QSZ1PaY1Ru",
      "expanded_url" : "https:\/\/youtu.be\/VdFwM9tnuNE",
      "display_url" : "youtu.be\/VdFwM9tnuNE"
    } ]
  },
  "geo" : { },
  "id_str" : "777606145460563968",
  "text" : "Pearl Jam - Meaningless https:\/\/t.co\/QSZ1PaY1Ru via @YouTube",
  "id" : 777606145460563968,
  "created_at" : "2016-09-18 20:32:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 61, 69 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/ciXIaLm43m",
      "expanded_url" : "https:\/\/youtu.be\/6ZDAnrQrUWw",
      "display_url" : "youtu.be\/6ZDAnrQrUWw"
    } ]
  },
  "geo" : { },
  "id_str" : "777599068432400385",
  "text" : "U2 - Gone (Official Music Video) https:\/\/t.co\/ciXIaLm43m via @YouTube",
  "id" : 777599068432400385,
  "created_at" : "2016-09-18 20:03:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777595843822100480",
  "in_reply_to_user_id" : 411185138,
  "text" : "@Mo_Mo4875 Say hi to Forgy for me.",
  "id" : 777595843822100480,
  "created_at" : "2016-09-18 19:51:10 +0000",
  "in_reply_to_screen_name" : "morgan_munsey",
  "in_reply_to_user_id_str" : "411185138",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/W3BG6Sivui",
      "expanded_url" : "http:\/\/thechart.blogs.cnn.com\/2011\/05\/23\/thats-dr-watson-to-you\/",
      "display_url" : "thechart.blogs.cnn.com\/2011\/05\/23\/tha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777594483777175553",
  "text" : "https:\/\/t.co\/W3BG6Sivui That's Dr. Watson to you.",
  "id" : 777594483777175553,
  "created_at" : "2016-09-18 19:45:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777588432969269248",
  "text" : "Technology assets = net worth= equity = shares. Into an IRA and withdraw early maybe a tax penalty, and Open Source it worth billions.",
  "id" : 777588432969269248,
  "created_at" : "2016-09-18 19:21:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777586676138926080",
  "text" : "Shuler you are just a high school redneck. I will hang out with cops. I called 911 one time and nobody even showed.",
  "id" : 777586676138926080,
  "created_at" : "2016-09-18 19:14:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 50, 58 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/KnCXJPa05O",
      "expanded_url" : "https:\/\/youtu.be\/Lc7b3VQ-Xfw",
      "display_url" : "youtu.be\/Lc7b3VQ-Xfw"
    } ]
  },
  "geo" : { },
  "id_str" : "777574862156075009",
  "text" : "The Moore family tree https:\/\/t.co\/KnCXJPa05O via @YouTube",
  "id" : 777574862156075009,
  "created_at" : "2016-09-18 18:27:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 65, 73 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/8zyVGECYOy",
      "expanded_url" : "https:\/\/youtu.be\/j4cN_q3NX9c",
      "display_url" : "youtu.be\/j4cN_q3NX9c"
    } ]
  },
  "geo" : { },
  "id_str" : "777568377774739456",
  "text" : "Tim Berners-Lee ~ The World Wide Web https:\/\/t.co\/8zyVGECYOy via @YouTube",
  "id" : 777568377774739456,
  "created_at" : "2016-09-18 18:02:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 72, 80 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/DIer3FgWRx",
      "expanded_url" : "https:\/\/youtu.be\/yA281OuU3rk",
      "display_url" : "youtu.be\/yA281OuU3rk"
    } ]
  },
  "geo" : { },
  "id_str" : "777565095891206144",
  "text" : "Nine Inch Nails - Copy of a (VEVO Presents) https:\/\/t.co\/DIer3FgWRx via @YouTube",
  "id" : 777565095891206144,
  "created_at" : "2016-09-18 17:48:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/nMhhMkaDmN",
      "expanded_url" : "https:\/\/uxmag.com\/articles\/why-web-design-is-dead",
      "display_url" : "uxmag.com\/articles\/why-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777564602267828224",
  "text" : "https:\/\/t.co\/nMhhMkaDmN Why web design is dead. UX Magazine.",
  "id" : 777564602267828224,
  "created_at" : "2016-09-18 17:47:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777561295830876160",
  "text" : "I might tell you professor of that Black Hole written in C I have if I ever got a hot women. No hug from a women in 20 years.",
  "id" : 777561295830876160,
  "created_at" : "2016-09-18 17:33:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 64, 72 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/l0d9gsIsOT",
      "expanded_url" : "https:\/\/youtu.be\/cyOTbE1dlAA",
      "display_url" : "youtu.be\/cyOTbE1dlAA"
    } ]
  },
  "geo" : { },
  "id_str" : "777557790571237377",
  "text" : "06 - M.M.I.X. - Coldplay (Official) https:\/\/t.co\/l0d9gsIsOT via @YouTube",
  "id" : 777557790571237377,
  "created_at" : "2016-09-18 17:19:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 71, 79 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/W1g94edMAq",
      "expanded_url" : "https:\/\/youtu.be\/XvijyBIgazE",
      "display_url" : "youtu.be\/XvijyBIgazE"
    } ]
  },
  "geo" : { },
  "id_str" : "777556900749709312",
  "text" : "A Christmas Story - Ralphie Beats Up Bully https:\/\/t.co\/W1g94edMAq via @YouTube Wanna see me go off?",
  "id" : 777556900749709312,
  "created_at" : "2016-09-18 17:16:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/VO01J9sGUM",
      "expanded_url" : "https:\/\/www.cnet.com\/news\/stephen-hawking-makes-it-clear-there-is-no-god\/",
      "display_url" : "cnet.com\/news\/stephen-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777556689272864768",
  "text" : "https:\/\/t.co\/VO01J9sGUM Stephen Hawking makes it clear there is no God. I'm just saying supreme reality.Which I'm already told her.",
  "id" : 777556689272864768,
  "created_at" : "2016-09-18 17:15:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 69, 77 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/OnXLD1F9WD",
      "expanded_url" : "https:\/\/youtu.be\/-hIjgofcuWU",
      "display_url" : "youtu.be\/-hIjgofcuWU"
    } ]
  },
  "geo" : { },
  "id_str" : "777554660471214081",
  "text" : "SNOOP DOGG - WHO AM I (WHATS MY NAME) HD https:\/\/t.co\/OnXLD1F9WD via @YouTube",
  "id" : 777554660471214081,
  "created_at" : "2016-09-18 17:07:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Newman",
      "screen_name" : "OneJaredNewman",
      "indices" : [ 108, 123 ],
      "id_str" : "24724740",
      "id" : 24724740
    }, {
      "name" : "Fast Company",
      "screen_name" : "FastCompany",
      "indices" : [ 128, 140 ],
      "id_str" : "2735591",
      "id" : 2735591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/x2d3b4CGCV",
      "expanded_url" : "http:\/\/www.fastcompany.com\/3063006\/why-on-earth-is-google-building-a-new-operating-system-from-scratch",
      "display_url" : "fastcompany.com\/3063006\/why-on\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777553772381863936",
  "text" : "Google is doing one of the rarest things in tech: writing a new operating system https:\/\/t.co\/x2d3b4CGCV by @OneJaredNewman via @FastCompany",
  "id" : 777553772381863936,
  "created_at" : "2016-09-18 17:04:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Verge",
      "screen_name" : "verge",
      "indices" : [ 86, 92 ],
      "id_str" : "275686563",
      "id" : 275686563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/uZvqXJqV4y",
      "expanded_url" : "http:\/\/www.theverge.com\/2016\/8\/15\/12480566\/google-fuchsia-new-operating-system?utm_campaign=theverge&utm_content=entry&utm_medium=social&utm_source=twitter",
      "display_url" : "theverge.com\/2016\/8\/15\/1248\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777553491275440128",
  "text" : "Google is working on a new operating system named Fuchsia https:\/\/t.co\/uZvqXJqV4y via @Verge",
  "id" : 777553491275440128,
  "created_at" : "2016-09-18 17:02:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/4axgWJ7GJR",
      "expanded_url" : "http:\/\/techrights.org\/2015\/07\/11\/microsoft-is-dying-quickly-desperately-trying-to-turn-into-surveillance-behemoth\/",
      "display_url" : "techrights.org\/2015\/07\/11\/mic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777553125054017536",
  "text" : "https:\/\/t.co\/4axgWJ7GJR",
  "id" : 777553125054017536,
  "created_at" : "2016-09-18 17:01:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 52, 60 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/qhJFYhsIIB",
      "expanded_url" : "https:\/\/youtu.be\/AnJzCHkRzOQ",
      "display_url" : "youtu.be\/AnJzCHkRzOQ"
    } ]
  },
  "geo" : { },
  "id_str" : "777538063048245249",
  "text" : "Excitable - Def Leppard https:\/\/t.co\/qhJFYhsIIB via @YouTube  It's Nature.",
  "id" : 777538063048245249,
  "created_at" : "2016-09-18 16:01:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777536387981664257",
  "text" : "This morning I did just hit the M.I.T. motherload of what might not be in open courseware until 2020.",
  "id" : 777536387981664257,
  "created_at" : "2016-09-18 15:54:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777535296133013504",
  "text" : "You can go to Microsoft Research we are hiding from you like you are hiding from us.",
  "id" : 777535296133013504,
  "created_at" : "2016-09-18 15:50:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777534286660571136",
  "text" : "If these eloi or hot women are hiding from the law because I'm the better man then evolution says we have a problem.",
  "id" : 777534286660571136,
  "created_at" : "2016-09-18 15:46:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777532380772982784",
  "text" : "The Police Station is closed I will just call sometime next week and start asking questions.",
  "id" : 777532380772982784,
  "created_at" : "2016-09-18 15:39:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 98, 104 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/SHT8zBmWmL",
      "expanded_url" : "https:\/\/www.wired.com\/2016\/09\/nocturnal-animals-trailer-get-ready-go-dark-places\/",
      "display_url" : "wired.com\/2016\/09\/noctur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777530275756666880",
  "text" : "Nocturnal Animals Teaser Trailer: Get Ready to Go to Some Dark Places https:\/\/t.co\/SHT8zBmWmL via @WIRED",
  "id" : 777530275756666880,
  "created_at" : "2016-09-18 15:30:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 74, 82 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/Q3rq8frWcY",
      "expanded_url" : "https:\/\/youtu.be\/r9-wvOkSmF4",
      "display_url" : "youtu.be\/r9-wvOkSmF4"
    } ]
  },
  "geo" : { },
  "id_str" : "777529714395193344",
  "text" : "Guns N' Roses - Better (Official Music Video) https:\/\/t.co\/Q3rq8frWcY via @YouTube",
  "id" : 777529714395193344,
  "created_at" : "2016-09-18 15:28:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777528496352624644",
  "text" : "All I may ask the cop is what did these social networks do to me since 2002 or '04.",
  "id" : 777528496352624644,
  "created_at" : "2016-09-18 15:23:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 67, 75 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/CcjuenSXzT",
      "expanded_url" : "https:\/\/youtu.be\/ml6Io35s4Rk",
      "display_url" : "youtu.be\/ml6Io35s4Rk"
    } ]
  },
  "geo" : { },
  "id_str" : "777526243881353216",
  "text" : "Red Hot Chili Peppers - Police Station https:\/\/t.co\/CcjuenSXzT via @YouTube",
  "id" : 777526243881353216,
  "created_at" : "2016-09-18 15:14:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777526065380134912",
  "text" : "I will venture out into the community, but I may stop at the police station. And just hang out.",
  "id" : 777526065380134912,
  "created_at" : "2016-09-18 15:13:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777524990065405952",
  "text" : "Look me up on instant checkmate all you will find is a marijuana first offender. And 3 speeding tickets.The other people are confidential.",
  "id" : 777524990065405952,
  "created_at" : "2016-09-18 15:09:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/5xSM2gGdmv",
      "expanded_url" : "http:\/\/gizmodo.com\/5795861\/how-the-police-get-your-phone-records?utm_medium=sharefromsite&utm_source=Gizmodo_twitter",
      "display_url" : "gizmodo.com\/5795861\/how-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777521470650056704",
  "text" : "How the Police Get Your Phone Records https:\/\/t.co\/5xSM2gGdmv",
  "id" : 777521470650056704,
  "created_at" : "2016-09-18 14:55:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 49, 57 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/9167v51fOz",
      "expanded_url" : "https:\/\/youtu.be\/OjyZKfdwlng",
      "display_url" : "youtu.be\/OjyZKfdwlng"
    } ]
  },
  "geo" : { },
  "id_str" : "777519950609154048",
  "text" : "Warrant - Cherry Pie https:\/\/t.co\/9167v51fOz via @YouTube",
  "id" : 777519950609154048,
  "created_at" : "2016-09-18 14:49:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 112, 123 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/0LFngIIn7C",
      "expanded_url" : "http:\/\/tcrn.ch\/1SKJfUq",
      "display_url" : "tcrn.ch\/1SKJfUq"
    } ]
  },
  "geo" : { },
  "id_str" : "777519419387969537",
  "text" : "House unanimously passes Email Privacy Act, requiring warrants for obtaining\u00A0emails https:\/\/t.co\/0LFngIIn7C via @techcrunch",
  "id" : 777519419387969537,
  "created_at" : "2016-09-18 14:47:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IAPP Daily Dashboard",
      "screen_name" : "DailyDashboard",
      "indices" : [ 67, 82 ],
      "id_str" : "372372472",
      "id" : 372372472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/kEM3G4r6AC",
      "expanded_url" : "http:\/\/iapp.org\/news\/a\/the-privacy-act-turned-40-got-roasted\/",
      "display_url" : "iapp.org\/news\/a\/the-pri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777518867606274048",
  "text" : "The Privacy Act Turned 40, Got Roasted https:\/\/t.co\/kEM3G4r6AC via @DailyDashboard",
  "id" : 777518867606274048,
  "created_at" : "2016-09-18 14:45:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777510276031778821",
  "text" : "Microsoft you are on Genome Engineering and that is gene theft HP is really on crime.",
  "id" : 777510276031778821,
  "created_at" : "2016-09-18 14:11:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/CyfPXUKFMZ",
      "expanded_url" : "http:\/\/www.informationweek.com\/big-data\/big-data-analytics\/microsoft-launches-online-data-science-degree-program\/d\/d-id\/1326276",
      "display_url" : "informationweek.com\/big-data\/big-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777508876715524097",
  "text" : "https:\/\/t.co\/CyfPXUKFMZ",
  "id" : 777508876715524097,
  "created_at" : "2016-09-18 14:05:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/C5rP2b3yru",
      "expanded_url" : "https:\/\/ignite.microsoft.com\/",
      "display_url" : "ignite.microsoft.com"
    } ]
  },
  "geo" : { },
  "id_str" : "777507767498207232",
  "text" : "https:\/\/t.co\/C5rP2b3yru",
  "id" : 777507767498207232,
  "created_at" : "2016-09-18 14:01:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777505259283513344",
  "text" : "I might want to go back to treatment just to meet girls and groupe women in the nursing home when or if I grow old. Wanna keep this up?",
  "id" : 777505259283513344,
  "created_at" : "2016-09-18 13:51:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777501862832594945",
  "text" : "I am emailing NSA one last time for my profile if I can get through. I'm also using data science to find out what really is going on.",
  "id" : 777501862832594945,
  "created_at" : "2016-09-18 13:37:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fortune",
      "screen_name" : "FortuneMagazine",
      "indices" : [ 52, 68 ],
      "id_str" : "25053299",
      "id" : 25053299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/b1HTcBt4Za",
      "expanded_url" : "http:\/\/for.tn\/2c7NBaM?xid=for_tw_sh",
      "display_url" : "for.tn\/2c7NBaM?xid=fo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777489321846767620",
  "text" : "Most people have no interest in buying iPhone 7 via @FortuneMagazine https:\/\/t.co\/b1HTcBt4Za",
  "id" : 777489321846767620,
  "created_at" : "2016-09-18 12:47:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777488560349908992",
  "text" : "I do have Windows 10 Enterprise LTSB with a key. I'm just waiting for FF 15 to come to the PC and my PC is certified for 8 and 10.",
  "id" : 777488560349908992,
  "created_at" : "2016-09-18 12:44:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Verge",
      "screen_name" : "verge",
      "indices" : [ 94, 100 ],
      "id_str" : "275686563",
      "id" : 275686563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/d2wiHVQSEA",
      "expanded_url" : "http:\/\/www.theverge.com\/2015\/5\/7\/8568473\/windows-10-last-version-of-windows?utm_campaign=theverge&utm_content=entry&utm_medium=social&utm_source=twitter",
      "display_url" : "theverge.com\/2015\/5\/7\/85684\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777487588311633920",
  "text" : "Why Microsoft is calling Windows 10 'the last version of Windows' https:\/\/t.co\/d2wiHVQSEA via @Verge",
  "id" : 777487588311633920,
  "created_at" : "2016-09-18 12:41:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 45, 56 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/pTLseXuQdh",
      "expanded_url" : "http:\/\/tcrn.ch\/1oKBggi",
      "display_url" : "tcrn.ch\/1oKBggi"
    } ]
  },
  "geo" : { },
  "id_str" : "777487280059604992",
  "text" : "Tablets Are Dead https:\/\/t.co\/pTLseXuQdh via @techcrunch",
  "id" : 777487280059604992,
  "created_at" : "2016-09-18 12:39:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/777483693988388864\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/kImhkA0VCA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsotTILWAAAlzVc.jpg",
      "id_str" : "777483692310659072",
      "id" : 777483692310659072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsotTILWAAAlzVc.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/kImhkA0VCA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777483693988388864",
  "text" : "https:\/\/t.co\/kImhkA0VCA",
  "id" : 777483693988388864,
  "created_at" : "2016-09-18 12:25:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777448631704154112",
  "text" : "M.I.T. thank you for providing information on the genomes of species whose genomes have been completed. I could help you also.I might call.",
  "id" : 777448631704154112,
  "created_at" : "2016-09-18 10:06:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hardee's",
      "screen_name" : "Hardees",
      "indices" : [ 3, 11 ],
      "id_str" : "16101657",
      "id" : 16101657
    }, {
      "name" : "genevieve morton",
      "screen_name" : "genevievemorton",
      "indices" : [ 50, 66 ],
      "id_str" : "36182872",
      "id" : 36182872
    }, {
      "name" : "Emily Sears",
      "screen_name" : "emilysears",
      "indices" : [ 83, 94 ],
      "id_str" : "2834212357",
      "id" : 2834212357
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ElenaBelle",
      "indices" : [ 67, 78 ]
    }, {
      "text" : "Bacon3Way",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777442396816695296",
  "text" : "RT @Hardees: Tap at just the right moment to give @genevievemorton #ElenaBelle and @emilysears their #Bacon3Way back. https:\/\/t.co\/O4HBVeEF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "genevieve morton",
        "screen_name" : "genevievemorton",
        "indices" : [ 37, 53 ],
        "id_str" : "36182872",
        "id" : 36182872
      }, {
        "name" : "Emily Sears",
        "screen_name" : "emilysears",
        "indices" : [ 70, 81 ],
        "id_str" : "2834212357",
        "id" : 2834212357
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Hardees\/status\/766410088374349824\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/O4HBVeEFyv",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CqLV4gWVUAAHg4s.jpg",
        "id_str" : "766410053339402240",
        "id" : 766410053339402240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CqLV4gWVUAAHg4s.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 360
        } ],
        "display_url" : "pic.twitter.com\/O4HBVeEFyv"
      } ],
      "hashtags" : [ {
        "text" : "ElenaBelle",
        "indices" : [ 54, 65 ]
      }, {
        "text" : "Bacon3Way",
        "indices" : [ 88, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766410088374349824",
    "text" : "Tap at just the right moment to give @genevievemorton #ElenaBelle and @emilysears their #Bacon3Way back. https:\/\/t.co\/O4HBVeEFyv",
    "id" : 766410088374349824,
    "created_at" : "2016-08-18 23:02:58 +0000",
    "user" : {
      "name" : "Hardee's",
      "screen_name" : "Hardees",
      "protected" : false,
      "id_str" : "16101657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791287388630839296\/FNzEQERq_normal.jpg",
      "id" : 16101657,
      "verified" : true
    }
  },
  "id" : 777442396816695296,
  "created_at" : "2016-09-18 09:41:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/NBLcJcRDuX",
      "expanded_url" : "https:\/\/goo.gl\/9SuTBO",
      "display_url" : "goo.gl\/9SuTBO"
    } ]
  },
  "geo" : { },
  "id_str" : "777439967471628288",
  "text" : "Marriage: an evolutionary perspective. https:\/\/t.co\/NBLcJcRDuX",
  "id" : 777439967471628288,
  "created_at" : "2016-09-18 09:31:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777437961768079360",
  "text" : "M.I.T. I could really help you with the future if you wanted. Your new courses that ARE ethical are beautiful.They just aren't open yet.",
  "id" : 777437961768079360,
  "created_at" : "2016-09-18 09:23:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Friedman",
      "screen_name" : "professor",
      "indices" : [ 74, 84 ],
      "id_str" : "3339331",
      "id" : 3339331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/roN13J40I7",
      "expanded_url" : "http:\/\/www.professorshouse.com\/my-husband-is-an-idiot\/",
      "display_url" : "professorshouse.com\/my-husband-is-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777436332981444609",
  "text" : "My Husband is an Idiot \u2013 Why did I Marry Him? https:\/\/t.co\/roN13J40I7 via @Professor&amp;#039;s House",
  "id" : 777436332981444609,
  "created_at" : "2016-09-18 09:17:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777420028027232256",
  "text" : "I found a better bioinformatics or systems biology suite than UGENE. I might experiment with it today.",
  "id" : 777420028027232256,
  "created_at" : "2016-09-18 08:12:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777418367007350785",
  "text" : "I can't sleep. I am in Mensa at least on LinkedIn an G+ with the mobile app. Do have rare blood and klotho. Is that not good enough?",
  "id" : 777418367007350785,
  "created_at" : "2016-09-18 08:05:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777411328118054912",
  "text" : "Hack me. I really don't care my 10 terabyte persona and source code is already back up at the bank in my safety deposit box.",
  "id" : 777411328118054912,
  "created_at" : "2016-09-18 07:37:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "techdirt",
      "screen_name" : "techdirt",
      "indices" : [ 110, 119 ],
      "id_str" : "11382292",
      "id" : 11382292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/HhzBmGbCxk",
      "expanded_url" : "https:\/\/www.techdirt.com\/articles\/20070412\/180719.shtml",
      "display_url" : "techdirt.com\/articles\/20070\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777409209449189376",
  "text" : "If You're Going Around Forcing People To Get RFID Chips, Stay Out Of North Dakota https:\/\/t.co\/HhzBmGbCxk via @Techdirt",
  "id" : 777409209449189376,
  "created_at" : "2016-09-18 07:29:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 71, 78 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/Kwys2JkQwA",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/connieguglielmo\/2013\/10\/30\/you-wont-have-michael-dell-to-kick-around-anymore\/#431a52b24fd2",
      "display_url" : "forbes.com\/sites\/conniegu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777406874253688833",
  "text" : "Dell Officially Goes Private: Inside The Nastiest Tech Buyout Ever via @forbes https:\/\/t.co\/Kwys2JkQwA",
  "id" : 777406874253688833,
  "created_at" : "2016-09-18 07:20:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777404133301248000",
  "text" : "Socialism doesn't work, why women just don't want one man I don't know. I really don't like their lifestyle.",
  "id" : 777404133301248000,
  "created_at" : "2016-09-18 07:09:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777403595767635968",
  "text" : "However I am becoming more private online until I get married. I will keep my twitter public sometimes.",
  "id" : 777403595767635968,
  "created_at" : "2016-09-18 07:07:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777403178962841600",
  "text" : "I would like to thank the people of Mensa for letting me become a member of their LinkedIn Group.",
  "id" : 777403178962841600,
  "created_at" : "2016-09-18 07:05:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/776027795512254464\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/jxm3k1pTMz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsUA_KgW8AAKL0H.jpg",
      "id_str" : "776027595943112704",
      "id" : 776027595943112704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsUA_KgW8AAKL0H.jpg",
      "sizes" : [ {
        "h" : 330,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 1045
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 1045
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 1045
      } ],
      "display_url" : "pic.twitter.com\/jxm3k1pTMz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776027795512254464",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne Spell Check is a life saver. I hope you have a good day. https:\/\/t.co\/jxm3k1pTMz",
  "id" : 776027795512254464,
  "created_at" : "2016-09-14 12:00:19 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/775997068661972992\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/YDrxP15vnd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsTlJ9dWYAAz1vl.jpg",
      "id_str" : "775996995093815296",
      "id" : 775996995093815296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsTlJ9dWYAAz1vl.jpg",
      "sizes" : [ {
        "h" : 828,
        "resize" : "fit",
        "w" : 1059
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 828,
        "resize" : "fit",
        "w" : 1059
      }, {
        "h" : 828,
        "resize" : "fit",
        "w" : 1059
      }, {
        "h" : 532,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/YDrxP15vnd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775997068661972992",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne Avril I told my story to the President he wrote back in ink. You know I don't know who to trust. https:\/\/t.co\/YDrxP15vnd",
  "id" : 775997068661972992,
  "created_at" : "2016-09-14 09:58:13 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 0, 11 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772452249603833856",
  "in_reply_to_user_id" : 30313925,
  "text" : "@WhiteHouse Americans need universal heath care.What would it take to get it?",
  "id" : 772452249603833856,
  "created_at" : "2016-09-04 15:12:22 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]