Grailbird.data.tweets_2012_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/7KgovL36",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/science\/blog\/2012\/oct\/31\/halloween-pranks-gizmodo-health",
      "display_url" : "guardian.co.uk\/science\/blog\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "263626092450025472",
  "text" : "Happy Halloween! stay safe http:\/\/t.co\/7KgovL36",
  "id" : 263626092450025472,
  "created_at" : "2012-10-31 12:58:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/Tq0JajH3",
      "expanded_url" : "http:\/\/www.carbonfund.org\/",
      "display_url" : "carbonfund.org"
    } ]
  },
  "geo" : { },
  "id_str" : "262636967601266688",
  "text" : "reduce your carbon footprint. http:\/\/t.co\/Tq0JajH3",
  "id" : 262636967601266688,
  "created_at" : "2012-10-28 19:28:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "antiaging",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/LGOUwOML",
      "expanded_url" : "http:\/\/www.isagenix.com\/ww\/en\/product_b.html",
      "display_url" : "isagenix.com\/ww\/en\/product_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "256118588052733953",
  "text" : "Product B #antiaging http:\/\/t.co\/LGOUwOML",
  "id" : 256118588052733953,
  "created_at" : "2012-10-10 19:46:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]