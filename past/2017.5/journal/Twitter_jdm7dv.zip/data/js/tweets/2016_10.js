Grailbird.data.tweets_2016_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Outer Places",
      "screen_name" : "outerplaces",
      "indices" : [ 85, 97 ],
      "id_str" : "296890242",
      "id" : 296890242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/zYt5vkfnTu",
      "expanded_url" : "http:\/\/www.outerplaces.com\/science\/item\/4977-are-dreams-interactions-between-quantum-parallel-worlds",
      "display_url" : "outerplaces.com\/science\/item\/4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "793174387285434368",
  "text" : "Are Dreams Interactions Between Quantum Parallel Worlds? https:\/\/t.co\/zYt5vkfnTu via @outerplaces",
  "id" : 793174387285434368,
  "created_at" : "2016-10-31 19:34:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/zY0aJXNGMP",
      "expanded_url" : "http:\/\/nyti.ms\/2e32bOg",
      "display_url" : "nyti.ms\/2e32bOg"
    } ]
  },
  "geo" : { },
  "id_str" : "792933075009335296",
  "text" : "Rock and Roll Hall of Fame Inducts Guns N\u2019 Roses https:\/\/t.co\/zY0aJXNGMP",
  "id" : 792933075009335296,
  "created_at" : "2016-10-31 03:35:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 58, 66 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/6etFBlUQgM",
      "expanded_url" : "https:\/\/youtu.be\/SXhreAiCFXI",
      "display_url" : "youtu.be\/SXhreAiCFXI"
    } ]
  },
  "geo" : { },
  "id_str" : "792931055422627840",
  "text" : "Guns N' Roses - Shotgun Blues https:\/\/t.co\/6etFBlUQgM via @YouTube",
  "id" : 792931055422627840,
  "created_at" : "2016-10-31 03:27:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 100, 108 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/6Na33mP0GC",
      "expanded_url" : "https:\/\/youtu.be\/8DuNERt6AD4",
      "display_url" : "youtu.be\/8DuNERt6AD4"
    } ]
  },
  "geo" : { },
  "id_str" : "792927571046494208",
  "text" : "Garbage - \"Not Your Kind of People\"(2012) (Deluxe Version) (Full Album) https:\/\/t.co\/6Na33mP0GC via @YouTube",
  "id" : 792927571046494208,
  "created_at" : "2016-10-31 03:13:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/po6nuEQhr9",
      "expanded_url" : "http:\/\/www.ww.idebate.org\/debatabase\/debates\/environment-animal-welfare\/house-believes-people-should-not-keep-pets",
      "display_url" : "ww.idebate.org\/debatabase\/deb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792925892620193793",
  "text" : "https:\/\/t.co\/po6nuEQhr9",
  "id" : 792925892620193793,
  "created_at" : "2016-10-31 03:07:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792923447110369280",
  "text" : "Oh you have my heart Amin fucking pussy. They do just want to call the cops on you for spreading intelligence.too.",
  "id" : 792923447110369280,
  "created_at" : "2016-10-31 02:57:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/0bfd1JhReZ",
      "expanded_url" : "http:\/\/wpo.st\/Gbo92",
      "display_url" : "wpo.st\/Gbo92"
    } ]
  },
  "geo" : { },
  "id_str" : "792921597216714752",
  "text" : "Why smart people are better off with fewer friends https:\/\/t.co\/0bfd1JhReZ",
  "id" : 792921597216714752,
  "created_at" : "2016-10-31 02:50:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792918875205726209",
  "text" : "And I just emailed Perose my theory.",
  "id" : 792918875205726209,
  "created_at" : "2016-10-31 02:39:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792916358593933312",
  "text" : "My theory is being human on earth is merely a stage of consciousness IDK yet.",
  "id" : 792916358593933312,
  "created_at" : "2016-10-31 02:29:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 75, 83 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/YPrQqldAeQ",
      "expanded_url" : "https:\/\/youtu.be\/yp1muwMcBzs",
      "display_url" : "youtu.be\/yp1muwMcBzs"
    } ]
  },
  "geo" : { },
  "id_str" : "792914067249831936",
  "text" : "Green Day - Horseshoes and Handgrenades lyrics https:\/\/t.co\/YPrQqldAeQ via @YouTube",
  "id" : 792914067249831936,
  "created_at" : "2016-10-31 02:20:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/lMB5nS36At",
      "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S1571064513001188",
      "display_url" : "sciencedirect.com\/science\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792913919786582016",
  "text" : "https:\/\/t.co\/lMB5nS36At \nConsciousness in the universe: A review of the \u2018Orch OR\u2019 theory.",
  "id" : 792913919786582016,
  "created_at" : "2016-10-31 02:19:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 28, 34 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/XGL5MZELJA",
      "expanded_url" : "https:\/\/www.wired.com\/2007\/03\/robert_lanza_do\/",
      "display_url" : "wired.com\/2007\/03\/robert\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792910523100721152",
  "text" : "https:\/\/t.co\/XGL5MZELJA via @WIRED But if you\u2019re going to play, you have to bring your A-game. Lanza does not.",
  "id" : 792910523100721152,
  "created_at" : "2016-10-31 02:06:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/bp87x1eTbL",
      "expanded_url" : "http:\/\/shr.gs\/IORihrL",
      "display_url" : "shr.gs\/IORihrL"
    } ]
  },
  "geo" : { },
  "id_str" : "792909122949746688",
  "text" : "Time runs like cine film and YOU are trapped FOREVER in each moment, physicists say https:\/\/t.co\/bp87x1eTbL",
  "id" : 792909122949746688,
  "created_at" : "2016-10-31 02:00:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "indices" : [ 74, 85 ],
      "id_str" : "15438913",
      "id" : 15438913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/R6Nve2gbvG",
      "expanded_url" : "http:\/\/dailym.ai\/1QQpLQE",
      "display_url" : "dailym.ai\/1QQpLQE"
    } ]
  },
  "geo" : { },
  "id_str" : "792908618907672576",
  "text" : "Physicists say time travel could be a reality https:\/\/t.co\/R6Nve2gbvG via @MailOnline",
  "id" : 792908618907672576,
  "created_at" : "2016-10-31 01:58:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/GPQqjedHFK",
      "expanded_url" : "https:\/\/arxiv.org\/abs\/1501.03111",
      "display_url" : "arxiv.org\/abs\/1501.03111"
    } ]
  },
  "geo" : { },
  "id_str" : "792908458261635072",
  "text" : "https:\/\/t.co\/GPQqjedHFK Time Crystals from Minimum Time Uncertainty",
  "id" : 792908458261635072,
  "created_at" : "2016-10-31 01:58:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/J6ORtJL5cN",
      "expanded_url" : "http:\/\/www.independent.co.uk\/news\/uk\/politics\/you-are-living-like-an-adult-way-before-your-time-and-its-very-difficult-108922.html",
      "display_url" : "independent.co.uk\/news\/uk\/politi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792867663622107136",
  "text" : "'You are living like an adult way before your time, and it's very https:\/\/t.co\/J6ORtJL5cN",
  "id" : 792867663622107136,
  "created_at" : "2016-10-30 23:15:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Borowitz",
      "screen_name" : "BorowitzReport",
      "indices" : [ 84, 99 ],
      "id_str" : "17293897",
      "id" : 17293897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/7tJlNNHDkK",
      "expanded_url" : "http:\/\/www.newyorker.com\/humor\/borowitz-report\/queen-offers-to-restore-british-rule-over-united-states",
      "display_url" : "newyorker.com\/humor\/borowitz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792551778608881665",
  "text" : "Queen Offers to Restore British Rule Over United States https:\/\/t.co\/7tJlNNHDkK via @BorowitzReport",
  "id" : 792551778608881665,
  "created_at" : "2016-10-30 02:20:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFLScience",
      "screen_name" : "IFLScience",
      "indices" : [ 69, 80 ],
      "id_str" : "838464523",
      "id" : 838464523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/QKk4d9ArWJ",
      "expanded_url" : "http:\/\/www.iflscience.com\/health-and-medicine\/dna-nanobots-will-seek-and-destroy-cancer-cells\/",
      "display_url" : "iflscience.com\/health-and-med\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790930819804229633",
  "text" : "DNA Nanobots Set To Seek and Destroy Cancer Cells In Human Trial via @IFLScience: https:\/\/t.co\/QKk4d9ArWJ",
  "id" : 790930819804229633,
  "created_at" : "2016-10-25 14:59:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/790260248204480512\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/WsrJO55CMv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CveRgcwWAAEnxWR.jpg",
      "id_str" : "790260246287613953",
      "id" : 790260246287613953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CveRgcwWAAEnxWR.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/WsrJO55CMv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790260248204480512",
  "text" : "https:\/\/t.co\/WsrJO55CMv",
  "id" : 790260248204480512,
  "created_at" : "2016-10-23 18:35:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 3, 10 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/amazon\/status\/790228040831922176\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/2tlOfOli14",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvd0NtkWEAENe8k.jpg",
      "id_str" : "790228038545969153",
      "id" : 790228038545969153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvd0NtkWEAENe8k.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/2tlOfOli14"
    } ],
    "hashtags" : [ {
      "text" : "AmazonPrime",
      "indices" : [ 46, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/lNsdYjyeuh",
      "expanded_url" : "http:\/\/amzn.to\/2due5Ft",
      "display_url" : "amzn.to\/2due5Ft"
    } ]
  },
  "geo" : { },
  "id_str" : "790237283924471808",
  "text" : "RT @amazon: Just some light Sunday reading... #AmazonPrime https:\/\/t.co\/lNsdYjyeuh https:\/\/t.co\/2tlOfOli14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/amazon\/status\/790228040831922176\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/2tlOfOli14",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvd0NtkWEAENe8k.jpg",
        "id_str" : "790228038545969153",
        "id" : 790228038545969153,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvd0NtkWEAENe8k.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/2tlOfOli14"
      } ],
      "hashtags" : [ {
        "text" : "AmazonPrime",
        "indices" : [ 34, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/lNsdYjyeuh",
        "expanded_url" : "http:\/\/amzn.to\/2due5Ft",
        "display_url" : "amzn.to\/2due5Ft"
      } ]
    },
    "geo" : { },
    "id_str" : "790228040831922176",
    "text" : "Just some light Sunday reading... #AmazonPrime https:\/\/t.co\/lNsdYjyeuh https:\/\/t.co\/2tlOfOli14",
    "id" : 790228040831922176,
    "created_at" : "2016-10-23 16:27:01 +0000",
    "user" : {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "protected" : false,
      "id_str" : "20793816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786252488223580160\/9-Lwv1sI_normal.jpg",
      "id" : 20793816,
      "verified" : true
    }
  },
  "id" : 790237283924471808,
  "created_at" : "2016-10-23 17:03:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790229783883948033",
  "text" : "These nurses need to stop trying to think of what everyone can get for free and give the people that have earned it their just dues.",
  "id" : 790229783883948033,
  "created_at" : "2016-10-23 16:33:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/yOw55fZSbT",
      "expanded_url" : "http:\/\/lifehacker.com\/note-taking-showdown-evernote-vs-onenote-2016-editio-1765707423?utm_medium=sharefromsite&utm_source=Lifehacker_twitter",
      "display_url" : "lifehacker.com\/note-taking-sh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790228658103455749",
  "text" : "Note-Taking Showdown: Evernote vs. OneNote (2016 Edition) https:\/\/t.co\/yOw55fZSbT",
  "id" : 790228658103455749,
  "created_at" : "2016-10-23 16:29:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everyday Health",
      "screen_name" : "EverydayHealth",
      "indices" : [ 32, 47 ],
      "id_str" : "17393790",
      "id" : 17393790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/EA93W14v2O",
      "expanded_url" : "http:\/\/www.everydayhealth.com\/sleep\/falling-asleep-with-anxiety.aspx",
      "display_url" : "everydayhealth.com\/sleep\/falling-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790225724003221504",
  "text" : "Falling Asleep with Anxiety via @EverydayHealth https:\/\/t.co\/EA93W14v2O",
  "id" : 790225724003221504,
  "created_at" : "2016-10-23 16:17:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790222781887737858",
  "text" : "it also is just wanting a hot girl and being done wrong too.",
  "id" : 790222781887737858,
  "created_at" : "2016-10-23 16:06:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790222400814276608",
  "text" : "I've seen my analytics.",
  "id" : 790222400814276608,
  "created_at" : "2016-10-23 16:04:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790222318270283776",
  "text" : "I'm probably more on the anxiety spectrum that psychosis I hear neighbors more than anything and they just won't come out.",
  "id" : 790222318270283776,
  "created_at" : "2016-10-23 16:04:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/UFWQuKn4sq",
      "expanded_url" : "https:\/\/www.ncbi.nlm.nih.gov\/pmc\/articles\/PMC2933872\/",
      "display_url" : "ncbi.nlm.nih.gov\/pmc\/articles\/P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790220899177885696",
  "text" : "The psycho gene https:\/\/t.co\/UFWQuKn4sq",
  "id" : 790220899177885696,
  "created_at" : "2016-10-23 15:58:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/qplzUGXhs8",
      "expanded_url" : "http:\/\/www.latinpost.com\/articles\/72256\/20150815\/scientists-have-discovered-the-psychopath-gene.htm",
      "display_url" : "latinpost.com\/articles\/72256\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790220755237830656",
  "text" : "Scientists Have Discovered the Psychopath Gene https:\/\/t.co\/qplzUGXhs8",
  "id" : 790220755237830656,
  "created_at" : "2016-10-23 15:58:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/OleTKQFg05",
      "expanded_url" : "https:\/\/www.scientificamerican.com\/article\/do-genes-make-people-evil\/?wt.mc=SA_Twitter-Share",
      "display_url" : "scientificamerican.com\/article\/do-gen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790219889785114624",
  "text" : "Do genes make people evil? https:\/\/t.co\/OleTKQFg05 #science",
  "id" : 790219889785114624,
  "created_at" : "2016-10-23 15:54:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790209675702796289",
  "text" : "There used to be a Microsoft research community listserv now it's just twitter and I really don't like it.",
  "id" : 790209675702796289,
  "created_at" : "2016-10-23 15:14:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790207407909695492",
  "text" : "Microsoft if you start showing me \"Us\" I might be mad.",
  "id" : 790207407909695492,
  "created_at" : "2016-10-23 15:05:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft Studios",
      "screen_name" : "MSStudiosBlog",
      "indices" : [ 3, 17 ],
      "id_str" : "214618570",
      "id" : 214618570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OriBlindForest",
      "indices" : [ 66, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/97IrhsaJ1H",
      "expanded_url" : "https:\/\/twitter.com\/garethcoker\/status\/708108702750892034",
      "display_url" : "twitter.com\/garethcoker\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790206913090842624",
  "text" : "RT @MSStudiosBlog: Check out Gareth Coker's Bandcamp page for the #OriBlindForest Definitive Edition soundtrack. https:\/\/t.co\/97IrhsaJ1H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OriBlindForest",
        "indices" : [ 47, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/97IrhsaJ1H",
        "expanded_url" : "https:\/\/twitter.com\/garethcoker\/status\/708108702750892034",
        "display_url" : "twitter.com\/garethcoker\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "708835116588474369",
    "text" : "Check out Gareth Coker's Bandcamp page for the #OriBlindForest Definitive Edition soundtrack. https:\/\/t.co\/97IrhsaJ1H",
    "id" : 708835116588474369,
    "created_at" : "2016-03-13 02:00:35 +0000",
    "user" : {
      "name" : "Microsoft Studios",
      "screen_name" : "MSStudiosBlog",
      "protected" : false,
      "id_str" : "214618570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519997031171903488\/1DKPgWIj_normal.jpeg",
      "id" : 214618570,
      "verified" : true
    }
  },
  "id" : 790206913090842624,
  "created_at" : "2016-10-23 15:03:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790205871515197440",
  "text" : "I'm not paying for your 4.99 app you won't even pay 4.00 for one of my albums.",
  "id" : 790205871515197440,
  "created_at" : "2016-10-23 14:58:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790202306163773440",
  "text" : "I do like Microsoft Academic search. I may see if ArXIV has alerts.",
  "id" : 790202306163773440,
  "created_at" : "2016-10-23 14:44:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790200173708382208",
  "text" : "I will go through my Gmail an decide who to update my outlook address too. Plus I don't know what to do about scholar yet.",
  "id" : 790200173708382208,
  "created_at" : "2016-10-23 14:36:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/N6SSGcg5yo",
      "expanded_url" : "http:\/\/lifehacker.com\/how-to-start-your-own-podcast-1709798447?utm_medium=sharefromsite&utm_source=Lifehacker_twitter",
      "display_url" : "lifehacker.com\/how-to-start-y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790195136659591172",
  "text" : "How to Start Your Own Podcast https:\/\/t.co\/N6SSGcg5yo",
  "id" : 790195136659591172,
  "created_at" : "2016-10-23 14:16:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790194557468151808",
  "text" : "Anyone can send me a Direct Message on Twitter.",
  "id" : 790194557468151808,
  "created_at" : "2016-10-23 14:13:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790193575090847748",
  "text" : "I do love my iPhone 6s Apple. And maybe I should have gotten an iPod instead of a Zune but the Zune was a gift from Microsoft.",
  "id" : 790193575090847748,
  "created_at" : "2016-10-23 14:10:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790189592083304448",
  "text" : "Google that spam didn't even get into my outlook. However it got to my gmail inbox.",
  "id" : 790189592083304448,
  "created_at" : "2016-10-23 13:54:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790186336707805185",
  "text" : "I have two Outlook emails now one for solicitations and on for regular email. Plus i have my old BVU Outlook archive.",
  "id" : 790186336707805185,
  "created_at" : "2016-10-23 13:41:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790184698152615938",
  "text" : "I really should have never left Outlook and Evolution.",
  "id" : 790184698152615938,
  "created_at" : "2016-10-23 13:34:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 52, 60 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/lUyjkpMZAr",
      "expanded_url" : "https:\/\/youtu.be\/B23tnmvTlVY",
      "display_url" : "youtu.be\/B23tnmvTlVY"
    } ]
  },
  "geo" : { },
  "id_str" : "790181630946213888",
  "text" : "Urge Overkill - Dropout https:\/\/t.co\/lUyjkpMZAr via @YouTube",
  "id" : 790181630946213888,
  "created_at" : "2016-10-23 13:22:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790181094310158336",
  "text" : "I really don't want anymore trouble from the area my dad's smoke alarm went off at 4 am and that is where I get my mail.",
  "id" : 790181094310158336,
  "created_at" : "2016-10-23 13:20:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/wR5tCWO2JR",
      "expanded_url" : "https:\/\/www.leavegooglebehind.com\/google-vs-microsoft\/",
      "display_url" : "leavegooglebehind.com\/google-vs-micr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790179033287909377",
  "text" : "https:\/\/t.co\/wR5tCWO2JR Google vs Microsoft leave Google behind.",
  "id" : 790179033287909377,
  "created_at" : "2016-10-23 13:12:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790178217583837184",
  "text" : "Google what happened to the app passwords? Hi Hilary and wonder woman.",
  "id" : 790178217583837184,
  "created_at" : "2016-10-23 13:09:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790170564610682880",
  "text" : "I'm thinking about upgrading to Windows 10 LTSB.",
  "id" : 790170564610682880,
  "created_at" : "2016-10-23 12:38:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BI Advertising",
      "screen_name" : "BI_Advertising",
      "indices" : [ 96, 111 ],
      "id_str" : "413391241",
      "id" : 413391241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/MKt41i24YV",
      "expanded_url" : "http:\/\/read.bi\/1C5Wntu",
      "display_url" : "read.bi\/1C5Wntu"
    } ]
  },
  "geo" : { },
  "id_str" : "790165911294582784",
  "text" : "Microsoft finally\u00A0abandoned its anti-Google \"Scroogled\" ad campaign https:\/\/t.co\/MKt41i24YV via @BI_Advertising",
  "id" : 790165911294582784,
  "created_at" : "2016-10-23 12:20:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790165348318322688",
  "text" : "Google I'm not paying you to be in your search results. That's not how search works it is webmaster tools and metadata like Bing.",
  "id" : 790165348318322688,
  "created_at" : "2016-10-23 12:17:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790162401345830913",
  "text" : "Or someone it the neighborhood stole my email address.",
  "id" : 790162401345830913,
  "created_at" : "2016-10-23 12:06:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790160930831294469",
  "text" : "I can't find NextDoor support screw it for now. I did check to see if the was another phone on my Google account and there wasn't.",
  "id" : 790160930831294469,
  "created_at" : "2016-10-23 12:00:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790160444740730881",
  "text" : "Plus I really don't know these people at least I have seen my social report.",
  "id" : 790160444740730881,
  "created_at" : "2016-10-23 11:58:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790159483917983744",
  "text" : "I really don't like NextDoor I signed up but don't think I activated it. I need support to send me a reset password.",
  "id" : 790159483917983744,
  "created_at" : "2016-10-23 11:54:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790153085360439297",
  "text" : "I really don't now if Path will make it maybe NextDoor.",
  "id" : 790153085360439297,
  "created_at" : "2016-10-23 11:29:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790147539051876352",
  "text" : "I'm keeping Path for my family an neighborhood. And everyone better be good my neighborhood is active for may Path.",
  "id" : 790147539051876352,
  "created_at" : "2016-10-23 11:07:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 71, 79 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/gJtssCAPrN",
      "expanded_url" : "https:\/\/youtu.be\/CJLOAjsamEE",
      "display_url" : "youtu.be\/CJLOAjsamEE"
    } ]
  },
  "geo" : { },
  "id_str" : "789523512599846912",
  "text" : "REM - Country Feedback - best live version https:\/\/t.co\/gJtssCAPrN via @YouTube",
  "id" : 789523512599846912,
  "created_at" : "2016-10-21 17:47:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JHU Public Health",
      "screen_name" : "JohnsHopkinsSPH",
      "indices" : [ 3, 19 ],
      "id_str" : "22019881",
      "id" : 22019881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/LqXSVW3u0t",
      "expanded_url" : "http:\/\/hub.jhu.edu\/2016\/10\/10\/nci-cancer-center-wirtz\/",
      "display_url" : "hub.jhu.edu\/2016\/10\/10\/nci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "789523133027844096",
  "text" : "RT @JohnsHopkinsSPH: Johns Hopkins-led research effort will explore cancer's deadly ability to spread https:\/\/t.co\/LqXSVW3u0t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/LqXSVW3u0t",
        "expanded_url" : "http:\/\/hub.jhu.edu\/2016\/10\/10\/nci-cancer-center-wirtz\/",
        "display_url" : "hub.jhu.edu\/2016\/10\/10\/nci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "789523042137440257",
    "text" : "Johns Hopkins-led research effort will explore cancer's deadly ability to spread https:\/\/t.co\/LqXSVW3u0t",
    "id" : 789523042137440257,
    "created_at" : "2016-10-21 17:45:36 +0000",
    "user" : {
      "name" : "JHU Public Health",
      "screen_name" : "JohnsHopkinsSPH",
      "protected" : false,
      "id_str" : "22019881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757931432098533376\/mXLJTmUf_normal.jpg",
      "id" : 22019881,
      "verified" : true
    }
  },
  "id" : 789523133027844096,
  "created_at" : "2016-10-21 17:45:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789093767534022657",
  "text" : "I've never even retouched a photo Dr. Ray. Fuck you lose some weight.",
  "id" : 789093767534022657,
  "created_at" : "2016-10-20 13:19:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789091954332172288",
  "text" : "WHY DO YOU KEEP SAYING YOU WANT TO BE ON TV?",
  "id" : 789091954332172288,
  "created_at" : "2016-10-20 13:12:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CleanTechnica",
      "screen_name" : "cleantechnica",
      "indices" : [ 74, 88 ],
      "id_str" : "17060015",
      "id" : 17060015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/1daxnYL8tj",
      "expanded_url" : "http:\/\/cleantechnica.com\/2016\/06\/28\/solar-roadways-coming-route-66-missouri\/",
      "display_url" : "cleantechnica.com\/2016\/06\/28\/sol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "789090680484274176",
  "text" : "Solar Roadways Coming To Route 66 In Missouri https:\/\/t.co\/1daxnYL8tj via @CleanTechnica",
  "id" : 789090680484274176,
  "created_at" : "2016-10-20 13:07:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/PNfE5PTS9p",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=qlTA3rnpgzU&feature=kp",
      "display_url" : "youtube.com\/watch?v=qlTA3r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "789089884141187072",
  "text" : "https:\/\/t.co\/PNfE5PTS9p Solar Roadways.",
  "id" : 789089884141187072,
  "created_at" : "2016-10-20 13:04:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/mdBiZOFdyz",
      "expanded_url" : "http:\/\/www.groom.com\/media\/publication\/1260_Paying_Employee_Benefit_Plan_Expenses.pdf",
      "display_url" : "groom.com\/media\/publicat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "788464696819085312",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne https:\/\/t.co\/mdBiZOFdyz This is NOT spam, but a law document on how to pay with plan assets. I'm trying too.",
  "id" : 788464696819085312,
  "created_at" : "2016-10-18 19:40:07 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Procopio",
      "screen_name" : "jproco",
      "indices" : [ 3, 10 ],
      "id_str" : "46165648",
      "id" : 46165648
    }, {
      "name" : "Automated Insights",
      "screen_name" : "AInsights",
      "indices" : [ 19, 29 ],
      "id_str" : "311613062",
      "id" : 311613062
    }, {
      "name" : "Mike Riggs",
      "screen_name" : "MikeRiggs",
      "indices" : [ 35, 45 ],
      "id_str" : "11929312",
      "id" : 11929312
    }, {
      "name" : "Freethink",
      "screen_name" : "freethinkmedia",
      "indices" : [ 49, 64 ],
      "id_str" : "97999865",
      "id" : 97999865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788164558947020800",
  "text" : "RT @jproco: I talk @AInsights with @MikeRiggs at @freethinkmedia: This Computer Can Write 2,000 Snarky Articles Per Second - https:\/\/t.co\/h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Automated Insights",
        "screen_name" : "AInsights",
        "indices" : [ 7, 17 ],
        "id_str" : "311613062",
        "id" : 311613062
      }, {
        "name" : "Mike Riggs",
        "screen_name" : "MikeRiggs",
        "indices" : [ 23, 33 ],
        "id_str" : "11929312",
        "id" : 11929312
      }, {
        "name" : "Freethink",
        "screen_name" : "freethinkmedia",
        "indices" : [ 37, 52 ],
        "id_str" : "97999865",
        "id" : 97999865
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/hURg9QqlBI",
        "expanded_url" : "http:\/\/ow.ly\/XRhF304tebT",
        "display_url" : "ow.ly\/XRhF304tebT"
      } ]
    },
    "geo" : { },
    "id_str" : "779029231686782976",
    "text" : "I talk @AInsights with @MikeRiggs at @freethinkmedia: This Computer Can Write 2,000 Snarky Articles Per Second - https:\/\/t.co\/hURg9QqlBI",
    "id" : 779029231686782976,
    "created_at" : "2016-09-22 18:46:57 +0000",
    "user" : {
      "name" : "Joe Procopio",
      "screen_name" : "jproco",
      "protected" : false,
      "id_str" : "46165648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635091921556369408\/Kc6YnMvQ_normal.jpg",
      "id" : 46165648,
      "verified" : false
    }
  },
  "id" : 788164558947020800,
  "created_at" : "2016-10-17 23:47:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787103885680934912",
  "text" : "I just don't want to know anything right now I may sleep all day tomorrow.",
  "id" : 787103885680934912,
  "created_at" : "2016-10-15 01:32:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787098101475602432",
  "text" : "How can you laugh when you know I'm down.",
  "id" : 787098101475602432,
  "created_at" : "2016-10-15 01:09:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787097226568986625",
  "text" : "Enjoy your friends be happy your not a genius. Goodnight.",
  "id" : 787097226568986625,
  "created_at" : "2016-10-15 01:06:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 60, 68 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/JGqCaS0gp2",
      "expanded_url" : "https:\/\/youtu.be\/1EktZbtJxFs",
      "display_url" : "youtu.be\/1EktZbtJxFs"
    } ]
  },
  "geo" : { },
  "id_str" : "787095640409014272",
  "text" : "The Beatles - I'm Down - Lyrics https:\/\/t.co\/JGqCaS0gp2 via @YouTube",
  "id" : 787095640409014272,
  "created_at" : "2016-10-15 00:59:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/R4PfrP1ztR",
      "expanded_url" : "http:\/\/www.genomenewsnetwork.org\/articles\/09_00\/DRD4_gene.shtml",
      "display_url" : "genomenewsnetwork.org\/articles\/09_00\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787093738627670016",
  "text" : "https:\/\/t.co\/R4PfrP1ztR The DRD4 Gene: Psychiatry's Repeat Offender. I'm on it.",
  "id" : 787093738627670016,
  "created_at" : "2016-10-15 00:52:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/bJl7sTiqaH",
      "expanded_url" : "http:\/\/playdosgamesonline.com\/donald-ducks-playground.html",
      "display_url" : "playdosgamesonline.com\/donald-ducks-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787092333804290048",
  "text" : "https:\/\/t.co\/bJl7sTiqaH Donald Duck Playground I had this was I was six. Might have been DOS too.",
  "id" : 787092333804290048,
  "created_at" : "2016-10-15 00:46:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/S46f1qjazB",
      "expanded_url" : "https:\/\/twitter.com\/IBMbigdata\/status\/787089411838271488",
      "display_url" : "twitter.com\/IBMbigdata\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787090652613971968",
  "text" : "offline first apps I might like.And Deep Dive. https:\/\/t.co\/S46f1qjazB",
  "id" : 787090652613971968,
  "created_at" : "2016-10-15 00:40:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/bFdrCjqzTF",
      "expanded_url" : "https:\/\/support.mozilla.org\/en-US\/kb\/search-contents-current-page-text-or-links",
      "display_url" : "support.mozilla.org\/en-US\/kb\/searc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787090277911650304",
  "text" : "https:\/\/t.co\/bFdrCjqzTF Ctlr-R to find.",
  "id" : 787090277911650304,
  "created_at" : "2016-10-15 00:38:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/nbtI2uUQXc",
      "expanded_url" : "http:\/\/www.trs-80.com\/sql-search-rs-catalogs-process.php",
      "display_url" : "trs-80.com\/sql-search-rs-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787089339893313536",
  "text" : "https:\/\/t.co\/nbtI2uUQXc Yogi Bear and Donald duck software if on hear somewhere.",
  "id" : 787089339893313536,
  "created_at" : "2016-10-15 00:34:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787088765676322816",
  "text" : "Somehow I connected Yogi the Bear or Donald Duck to it too.",
  "id" : 787088765676322816,
  "created_at" : "2016-10-15 00:32:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techland",
      "screen_name" : "Techland",
      "indices" : [ 104, 113 ],
      "id_str" : "87798068",
      "id" : 87798068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/3fPFRtpd0X",
      "expanded_url" : "http:\/\/ti.me\/1nieDMf",
      "display_url" : "ti.me\/1nieDMf"
    } ]
  },
  "geo" : { },
  "id_str" : "787087604416143360",
  "text" : "Fifty Years of BASIC, the Programming Language That Made Computers Personal https:\/\/t.co\/3fPFRtpd0X via @Techland",
  "id" : 787087604416143360,
  "created_at" : "2016-10-15 00:28:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 82, 90 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/pUYCFtg58j",
      "expanded_url" : "https:\/\/youtu.be\/dd0iqUp96Qo",
      "display_url" : "youtu.be\/dd0iqUp96Qo"
    } ]
  },
  "geo" : { },
  "id_str" : "787086721649414144",
  "text" : "Tandy Model 102 Computer and CCR-81 Cassette Recorder https:\/\/t.co\/pUYCFtg58j via @YouTube",
  "id" : 787086721649414144,
  "created_at" : "2016-10-15 00:24:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787085437907116032",
  "text" : "I got an electronic's set or kit And a Tandy computer from Xmas with I was six.",
  "id" : 787085437907116032,
  "created_at" : "2016-10-15 00:19:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bearcat Baseball",
      "screen_name" : "vhsbearcats",
      "indices" : [ 3, 15 ],
      "id_str" : "148019836",
      "id" : 148019836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787083572310118400",
  "text" : "RT @vhsbearcats: 11:08 Qtr 2 [Abingdo 21 VA High 7] [Poss Abingdo\u25C0] [KICKOFF on \u25B640]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/iscorecentral.com\/football\/\" rel=\"nofollow\"\u003EiScore Football\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787081767484260352",
    "text" : "11:08 Qtr 2 [Abingdo 21 VA High 7] [Poss Abingdo\u25C0] [KICKOFF on \u25B640]",
    "id" : 787081767484260352,
    "created_at" : "2016-10-15 00:04:51 +0000",
    "user" : {
      "name" : "Bearcat Baseball",
      "screen_name" : "vhsbearcats",
      "protected" : false,
      "id_str" : "148019836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1850403763\/Bearcats_normal.jpg",
      "id" : 148019836,
      "verified" : false
    }
  },
  "id" : 787083572310118400,
  "created_at" : "2016-10-15 00:12:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787082820258848768",
  "text" : "Reznor you do end the show with 'head like a hole' too. And my profile picture is meant to be an avatar not logo.",
  "id" : 787082820258848768,
  "created_at" : "2016-10-15 00:09:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 79, 87 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/UTIOo8rC7L",
      "expanded_url" : "https:\/\/youtu.be\/_pWxyJTL0-w",
      "display_url" : "youtu.be\/_pWxyJTL0-w"
    } ]
  },
  "geo" : { },
  "id_str" : "787081499552124928",
  "text" : "The Frail (Things Falling Apart) - Nine Inch Nails https:\/\/t.co\/UTIOo8rC7L via @YouTube",
  "id" : 787081499552124928,
  "created_at" : "2016-10-15 00:03:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787080835988160513",
  "text" : "I just can't say I'll never want another CPU or memory maybe never another graphics card.",
  "id" : 787080835988160513,
  "created_at" : "2016-10-15 00:01:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787079927149563904",
  "text" : "Now I just feel cheap and I paid $3,000 for my laptop.",
  "id" : 787079927149563904,
  "created_at" : "2016-10-14 23:57:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/XIjqbaXiKg",
      "expanded_url" : "http:\/\/ram.userbenchmark.com\/",
      "display_url" : "ram.userbenchmark.com"
    } ]
  },
  "geo" : { },
  "id_str" : "787078863537012736",
  "text" : "https:\/\/t.co\/XIjqbaXiKg User Benchmark is good.",
  "id" : 787078863537012736,
  "created_at" : "2016-10-14 23:53:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bearcat Baseball",
      "screen_name" : "vhsbearcats",
      "indices" : [ 3, 15 ],
      "id_str" : "148019836",
      "id" : 148019836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787077771130470401",
  "text" : "RT @vhsbearcats: 4:48 Qtr 1 [Abingdo 6 VA High 7] [Poss VA High\u25C0] [KICKOFF on \u25B640]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/iscorecentral.com\/football\/\" rel=\"nofollow\"\u003EiScore Football\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787077266626924544",
    "text" : "4:48 Qtr 1 [Abingdo 6 VA High 7] [Poss VA High\u25C0] [KICKOFF on \u25B640]",
    "id" : 787077266626924544,
    "created_at" : "2016-10-14 23:46:58 +0000",
    "user" : {
      "name" : "Bearcat Baseball",
      "screen_name" : "vhsbearcats",
      "protected" : false,
      "id_str" : "148019836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1850403763\/Bearcats_normal.jpg",
      "id" : 148019836,
      "verified" : false
    }
  },
  "id" : 787077771130470401,
  "created_at" : "2016-10-14 23:48:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787077672975360000",
  "text" : "A computer.",
  "id" : 787077672975360000,
  "created_at" : "2016-10-14 23:48:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787077019171430400",
  "text" : "I built a server in 2003.I still have it.",
  "id" : 787077019171430400,
  "created_at" : "2016-10-14 23:45:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/gvw7VazdRN",
      "expanded_url" : "http:\/\/www.wikihow.com\/Build-an-Ultimate-Gaming-PC",
      "display_url" : "wikihow.com\/Build-an-Ultim\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787076776992337921",
  "text" : "https:\/\/t.co\/gvw7VazdRN If the company with just let you put on nothing. I do like stickers.",
  "id" : 787076776992337921,
  "created_at" : "2016-10-14 23:45:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787075267214835712",
  "text" : "I'm not killing a company I would just like my own unbranded.",
  "id" : 787075267214835712,
  "created_at" : "2016-10-14 23:39:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 104, 112 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/Gbah1qDvny",
      "expanded_url" : "https:\/\/youtu.be\/QdGW1xE6d_k",
      "display_url" : "youtu.be\/QdGW1xE6d_k"
    } ]
  },
  "geo" : { },
  "id_str" : "787074106118266884",
  "text" : "How a Motherboard is Made - Futurelooks Visits the GIGABYTE Nan Ping Fac... https:\/\/t.co\/Gbah1qDvny via @YouTube",
  "id" : 787074106118266884,
  "created_at" : "2016-10-14 23:34:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Register",
      "screen_name" : "TheRegister",
      "indices" : [ 99, 111 ],
      "id_str" : "78012548",
      "id" : 78012548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/kjlTdQRRBS",
      "expanded_url" : "http:\/\/www.theregister.co.uk\/2015\/08\/07\/another_death_apple_assembly_plant\/",
      "display_url" : "theregister.co.uk\/2015\/08\/07\/ano\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787073286219915265",
  "text" : "Another death in Apple's 'Mordor' \u2013 its Foxconn Chinese assembly plant https:\/\/t.co\/kjlTdQRRBS via @theregister",
  "id" : 787073286219915265,
  "created_at" : "2016-10-14 23:31:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/El6AFfo3oO",
      "expanded_url" : "http:\/\/www.quantatw.com\/Quanta\/english\/",
      "display_url" : "quantatw.com\/Quanta\/english\/"
    } ]
  },
  "geo" : { },
  "id_str" : "787072520096710657",
  "text" : "https:\/\/t.co\/El6AFfo3oO Hello Apple, Dell, HP, and Microsoft.",
  "id" : 787072520096710657,
  "created_at" : "2016-10-14 23:28:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787069761679138825",
  "text" : "I do have some PC designs I did in Maya in college I just would want to sell them.",
  "id" : 787069761679138825,
  "created_at" : "2016-10-14 23:17:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/RcMsj9VN5m",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Gradle",
      "display_url" : "en.wikipedia.org\/wiki\/Gradle"
    } ]
  },
  "geo" : { },
  "id_str" : "787067461321523202",
  "text" : "https:\/\/t.co\/RcMsj9VN5m I do like Gradle.",
  "id" : 787067461321523202,
  "created_at" : "2016-10-14 23:08:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787063616063336448",
  "text" : "I do like Maple Matlab isn't that good.",
  "id" : 787063616063336448,
  "created_at" : "2016-10-14 22:52:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/3lrXBXf1tU",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/List_of_computer_algebra_systems",
      "display_url" : "en.wikipedia.org\/wiki\/List_of_c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787062729743986688",
  "text" : "https:\/\/t.co\/3lrXBXf1tU Reduce is the oldest and I have some of Wolfram.",
  "id" : 787062729743986688,
  "created_at" : "2016-10-14 22:49:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787060573913636864",
  "text" : "The goal is to one day finally have a free and open OS with a lot of original software. That is now proprietary. And rarely changes.",
  "id" : 787060573913636864,
  "created_at" : "2016-10-14 22:40:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787059719248764928",
  "text" : "I'm done with these new tech startups honey.",
  "id" : 787059719248764928,
  "created_at" : "2016-10-14 22:37:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787058527642722304",
  "text" : "I never have spammed one person you just don't know what the fuck I'm talking about.",
  "id" : 787058527642722304,
  "created_at" : "2016-10-14 22:32:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/9N4UF8SYs1",
      "expanded_url" : "https:\/\/octopkg.wordpress.com\/",
      "display_url" : "octopkg.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "787058118815518721",
  "text" : "https:\/\/t.co\/9N4UF8SYs1",
  "id" : 787058118815518721,
  "created_at" : "2016-10-14 22:30:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787057296685854720",
  "text" : "I am interested in Data Science and if the data center is getting smaller. I might keep FreeBSD on my Dell.",
  "id" : 787057296685854720,
  "created_at" : "2016-10-14 22:27:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787054432307515392",
  "text" : "I'm trying to be generic too. And if you want free internet use OpenVPN. They will route you to Europe.",
  "id" : 787054432307515392,
  "created_at" : "2016-10-14 22:16:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787049967596756992",
  "text" : "And I'll have to upgrade monoskel to gtk-sharp 2.0.",
  "id" : 787049967596756992,
  "created_at" : "2016-10-14 21:58:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787049803851194368",
  "text" : "I found a UI pkg manager for FreeBSD called Octopkg. Thanks to Jordan Hubbard. It would be nice to look at DesktopBSD too.",
  "id" : 787049803851194368,
  "created_at" : "2016-10-14 21:57:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/umdblC7QgH",
      "expanded_url" : "http:\/\/unix.stackexchange.com\/questions\/39524\/sharing-folder-from-windows-host-to-freebsd-guest",
      "display_url" : "unix.stackexchange.com\/questions\/3952\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787031587904946176",
  "text" : "https:\/\/t.co\/umdblC7QgH Did they ever get shared folders to work? I want SUA back not Linux. Fuck this today.",
  "id" : 787031587904946176,
  "created_at" : "2016-10-14 20:45:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787027338886320132",
  "text" : "I am getting a 'no gacutil' tool found in Cygwin Mono is not installed for cygwin And I'm not sure it can be maybe.",
  "id" : 787027338886320132,
  "created_at" : "2016-10-14 20:28:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/UbxAUVBvry",
      "expanded_url" : "http:\/\/triggerwarning.us\/",
      "display_url" : "triggerwarning.us"
    } ]
  },
  "geo" : { },
  "id_str" : "787024265681989633",
  "text" : "https:\/\/t.co\/UbxAUVBvry",
  "id" : 787024265681989633,
  "created_at" : "2016-10-14 20:16:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787023080187133952",
  "text" : "When I'm 60 Hilary and still haven't had a 25 year old and that wannabe Machiavelli is getting laid with my secrets than I will just shoot.",
  "id" : 787023080187133952,
  "created_at" : "2016-10-14 20:11:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787021190066008064",
  "text" : "\"My first shipping product\" and I'm kinda laughing at you. Did you just upload it to the gallery or bandcamp?",
  "id" : 787021190066008064,
  "created_at" : "2016-10-14 20:04:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787012030318387200",
  "text" : "You want me to kill myself don't you news media? Been on Social Media for 8 years and not one knock on my door that I haven't paid.",
  "id" : 787012030318387200,
  "created_at" : "2016-10-14 19:27:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787009882373390341",
  "text" : "I have been in and out of treatment because of SWVA conformity.",
  "id" : 787009882373390341,
  "created_at" : "2016-10-14 19:19:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787009245644484608",
  "text" : "I still remember Vedder do you?",
  "id" : 787009245644484608,
  "created_at" : "2016-10-14 19:16:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 79, 87 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/0B9NiBkVNR",
      "expanded_url" : "https:\/\/youtu.be\/LF-CGv7DdoM",
      "display_url" : "youtu.be\/LF-CGv7DdoM"
    } ]
  },
  "geo" : { },
  "id_str" : "787008505349869569",
  "text" : "Pearl Jam - Not For You (Lollapalooza Brasil 2013) https:\/\/t.co\/0B9NiBkVNR via @YouTube",
  "id" : 787008505349869569,
  "created_at" : "2016-10-14 19:13:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/357PqLYM6g",
      "expanded_url" : "http:\/\/historynewsnetwork.org\/article\/160407",
      "display_url" : "historynewsnetwork.org\/article\/160407"
    } ]
  },
  "geo" : { },
  "id_str" : "787006378476965888",
  "text" : "https:\/\/t.co\/357PqLYM6g The hippies won the culture war.",
  "id" : 787006378476965888,
  "created_at" : "2016-10-14 19:05:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 109, 116 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/3sYWFWZO1T",
      "expanded_url" : "https:\/\/www.amazon.com\/dp\/0393076369\/ref=cm_sw_r_tw_dp_x_4RsaybKK486QR",
      "display_url" : "amazon.com\/dp\/0393076369\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787004853981704193",
  "text" : "How the Hippies Saved Physics: Science, Counterculture, and the Quantum Reviv... https:\/\/t.co\/3sYWFWZO1T via @amazon",
  "id" : 787004853981704193,
  "created_at" : "2016-10-14 18:59:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/R4X9iGfi8w",
      "expanded_url" : "http:\/\/www.anorak.co.uk\/295171\/money\/why-hippy-communes-die-out-the-unequal-societies-just-kill-them-off.html\/",
      "display_url" : "anorak.co.uk\/295171\/money\/w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787004061233086464",
  "text" : "https:\/\/t.co\/R4X9iGfi8w Society does just want to kill hippies too.",
  "id" : 787004061233086464,
  "created_at" : "2016-10-14 18:56:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 48, 56 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/Gm1pOgZ3z8",
      "expanded_url" : "https:\/\/youtu.be\/7F6KP99fEAM",
      "display_url" : "youtu.be\/7F6KP99fEAM"
    } ]
  },
  "geo" : { },
  "id_str" : "787001895281913856",
  "text" : "Inxs - Tiny daggers https:\/\/t.co\/Gm1pOgZ3z8 via @YouTube",
  "id" : 787001895281913856,
  "created_at" : "2016-10-14 18:47:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/2BZQZUdhGf",
      "expanded_url" : "http:\/\/emonic.sourceforge.net\/",
      "display_url" : "emonic.sourceforge.net"
    } ]
  },
  "geo" : { },
  "id_str" : "787001007872024577",
  "text" : "https:\/\/t.co\/2BZQZUdhGf I always come back to emonic.",
  "id" : 787001007872024577,
  "created_at" : "2016-10-14 18:43:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/xLWoc7R1Np",
      "expanded_url" : "https:\/\/doingmyprogramming.com\/2013\/09\/09\/configuring-netbeans-for-gtk-development\/",
      "display_url" : "doingmyprogramming.com\/2013\/09\/09\/con\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787000101923323904",
  "text" : "https:\/\/t.co\/xLWoc7R1Np Netbeans and Glade.. Thinking.",
  "id" : 787000101923323904,
  "created_at" : "2016-10-14 18:40:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786999716366221313",
  "text" : "monodevelop is marked broken and does not start on FreeeBSD.",
  "id" : 786999716366221313,
  "created_at" : "2016-10-14 18:38:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/sihkeKlUUA",
      "expanded_url" : "http:\/\/tirania.org\/blog\/archive\/2014\/Apr-09.html",
      "display_url" : "tirania.org\/blog\/archive\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786997620979986432",
  "text" : "https:\/\/t.co\/sihkeKlUUA Mono and Roslyn.",
  "id" : 786997620979986432,
  "created_at" : "2016-10-14 18:30:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/kSmaaiLUh4",
      "expanded_url" : "https:\/\/github.com\/mono\/roslyn",
      "display_url" : "github.com\/mono\/roslyn"
    } ]
  },
  "geo" : { },
  "id_str" : "786997025430704128",
  "text" : "https:\/\/t.co\/kSmaaiLUh4 Mono Rosyln.",
  "id" : 786997025430704128,
  "created_at" : "2016-10-14 18:28:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786995405292761088",
  "text" : "XAML is pronounced 'ZAMAL'",
  "id" : 786995405292761088,
  "created_at" : "2016-10-14 18:21:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ekPF0l3Wbg",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Glade_Interface_Designer",
      "display_url" : "en.wikipedia.org\/wiki\/Glade_Int\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786994554608218113",
  "text" : "https:\/\/t.co\/ekPF0l3Wbg Glade is probably the closest people will get other than QT and it is for Gnome you can have themes.",
  "id" : 786994554608218113,
  "created_at" : "2016-10-14 18:18:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/kMJbO5h2xS",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/XForms",
      "display_url" : "en.wikipedia.org\/wiki\/XForms"
    } ]
  },
  "geo" : { },
  "id_str" : "786993478936956928",
  "text" : "https:\/\/t.co\/kMJbO5h2xS Or XForms those are Lotus Notes Aren't they IBM?",
  "id" : 786993478936956928,
  "created_at" : "2016-10-14 18:14:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/IXk8RatCWm",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/QML",
      "display_url" : "en.wikipedia.org\/wiki\/QML"
    } ]
  },
  "geo" : { },
  "id_str" : "786992400375906305",
  "text" : "https:\/\/t.co\/IXk8RatCWm Maybe QML. It is QT.",
  "id" : 786992400375906305,
  "created_at" : "2016-10-14 18:09:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/zS3AYNzYuf",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/List_of_user_interface_markup_languages",
      "display_url" : "en.wikipedia.org\/wiki\/List_of_u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786991444624044032",
  "text" : "https:\/\/t.co\/zS3AYNzYuf List of UI markup languages.",
  "id" : 786991444624044032,
  "created_at" : "2016-10-14 18:05:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/5maTlipzAX",
      "expanded_url" : "https:\/\/github.com\/ddobrev\/QtSharp",
      "display_url" : "github.com\/ddobrev\/QtSharp"
    } ]
  },
  "geo" : { },
  "id_str" : "786990718917238784",
  "text" : "https:\/\/t.co\/5maTlipzAX QT Sharp. Glade save's the UI as as \"glade\" file not standard XML.",
  "id" : 786990718917238784,
  "created_at" : "2016-10-14 18:03:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/5fOEVdBahT",
      "expanded_url" : "https:\/\/www.freshports.org\/devel\/glade\/",
      "display_url" : "freshports.org\/devel\/glade\/"
    } ]
  },
  "geo" : { },
  "id_str" : "786988704065814528",
  "text" : "https:\/\/t.co\/5fOEVdBahT Freshports; Glade, looking for a QT C# equivalent.",
  "id" : 786988704065814528,
  "created_at" : "2016-10-14 17:55:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/BImueMgZCj",
      "expanded_url" : "https:\/\/glade.gnome.org\/",
      "display_url" : "glade.gnome.org"
    } ]
  },
  "geo" : { },
  "id_str" : "786987424954155009",
  "text" : "https:\/\/t.co\/BImueMgZCj Glade is GTK not QT.",
  "id" : 786987424954155009,
  "created_at" : "2016-10-14 17:49:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/5U81Due2eC",
      "expanded_url" : "https:\/\/gestalt.codeplex.com\/",
      "display_url" : "gestalt.codeplex.com"
    } ]
  },
  "geo" : { },
  "id_str" : "786986671782895621",
  "text" : "https:\/\/t.co\/5U81Due2eC it is XAML Microsoft but I do have a standard Winform with XML from the Code Project.",
  "id" : 786986671782895621,
  "created_at" : "2016-10-14 17:46:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786984422792921088",
  "text" : "I will report to the IRS but that law document states that the assets will pay for the report.",
  "id" : 786984422792921088,
  "created_at" : "2016-10-14 17:38:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786983894981763073",
  "text" : "Do look up the definition of 'profit' it is simply a 'gain'.",
  "id" : 786983894981763073,
  "created_at" : "2016-10-14 17:35:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "azcentral",
      "screen_name" : "azcentral",
      "indices" : [ 54, 64 ],
      "id_str" : "13115682",
      "id" : 13115682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/RvnNZRCFAZ",
      "expanded_url" : "http:\/\/yourbusiness.azcentral.com\/payroll-vs-distributions-27144.html",
      "display_url" : "yourbusiness.azcentral.com\/payroll-vs-dis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786983571433091072",
  "text" : "Payroll Vs. Distributions https:\/\/t.co\/RvnNZRCFAZ via @azcentral",
  "id" : 786983571433091072,
  "created_at" : "2016-10-14 17:34:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786982747092946945",
  "text" : "it is called a shareholders distribution too. Maybe just don't evade taxes.",
  "id" : 786982747092946945,
  "created_at" : "2016-10-14 17:31:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786981645131911168",
  "text" : "You just can't deposit your technological equity into the bank. The bank won't let you it would just be a transaction too.",
  "id" : 786981645131911168,
  "created_at" : "2016-10-14 17:27:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/dNqCmKnWvi",
      "expanded_url" : "https:\/\/letitknow.wordpress.com\/2012\/02\/29\/how-to-install-openerp-on-freebsd\/",
      "display_url" : "letitknow.wordpress.com\/2012\/02\/29\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786978875972739072",
  "text" : "https:\/\/t.co\/dNqCmKnWvi Maybe OpenERP for FreeBSD right now.",
  "id" : 786978875972739072,
  "created_at" : "2016-10-14 17:16:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786975993856655360",
  "text" : "What's one life to you Bill Gates?",
  "id" : 786975993856655360,
  "created_at" : "2016-10-14 17:04:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786974951689613312",
  "text" : "I took Economics for two weeks at UVa and three people showed. I dropped it after two weeks.",
  "id" : 786974951689613312,
  "created_at" : "2016-10-14 17:00:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/NVbkuL8Bhg",
      "expanded_url" : "http:\/\/www.ign.com\/boards\/threads\/fact-economics-is-the-worst-most-boring-subject-ever-created.189675933\/",
      "display_url" : "ign.com\/boards\/threads\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786974215891218436",
  "text" : "https:\/\/t.co\/NVbkuL8Bhg Economics is the most boring subject ever created.",
  "id" : 786974215891218436,
  "created_at" : "2016-10-14 16:57:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT",
      "screen_name" : "MIT",
      "indices" : [ 3, 7 ],
      "id_str" : "15460048",
      "id" : 15460048
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fusion",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/e5gtPBO9AL",
      "expanded_url" : "http:\/\/mitsha.re\/A4Dc305bMhT",
      "display_url" : "mitsha.re\/A4Dc305bMhT"
    } ]
  },
  "geo" : { },
  "id_str" : "786973545104572416",
  "text" : "RT @MIT: Go Tech! MIT's nuclear #fusion experiment established a world record on its last day of operation: https:\/\/t.co\/e5gtPBO9AL https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MIT\/status\/786971578735132672\/photo\/1",
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/DvAxzr07aB",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CuvibH7WAAAv3ar.jpg",
        "id_str" : "786971515518582784",
        "id" : 786971515518582784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CuvibH7WAAAv3ar.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/DvAxzr07aB"
      } ],
      "hashtags" : [ {
        "text" : "fusion",
        "indices" : [ 23, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/e5gtPBO9AL",
        "expanded_url" : "http:\/\/mitsha.re\/A4Dc305bMhT",
        "display_url" : "mitsha.re\/A4Dc305bMhT"
      } ]
    },
    "geo" : { },
    "id_str" : "786971578735132672",
    "text" : "Go Tech! MIT's nuclear #fusion experiment established a world record on its last day of operation: https:\/\/t.co\/e5gtPBO9AL https:\/\/t.co\/DvAxzr07aB",
    "id" : 786971578735132672,
    "created_at" : "2016-10-14 16:47:00 +0000",
    "user" : {
      "name" : "MIT",
      "screen_name" : "MIT",
      "protected" : false,
      "id_str" : "15460048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726083204122312704\/C_SBTZQ__normal.jpg",
      "id" : 15460048,
      "verified" : true
    }
  },
  "id" : 786973545104572416,
  "created_at" : "2016-10-14 16:54:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/5cE1TcLVis",
      "expanded_url" : "http:\/\/www.gateway.com\/gw\/en\/US\/content\/dx-series-features\/dx-series",
      "display_url" : "gateway.com\/gw\/en\/US\/conte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786972489834528772",
  "text" : "https:\/\/t.co\/5cE1TcLVis I'm not play Gateway. Dell went private too.",
  "id" : 786972489834528772,
  "created_at" : "2016-10-14 16:50:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/AxaQBqUFQa",
      "expanded_url" : "https:\/\/forums.digitalpoint.com\/threads\/how-can-i-produce-my-own-debit-card.1729897\/",
      "display_url" : "forums.digitalpoint.com\/threads\/how-ca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786971254507073538",
  "text" : "https:\/\/t.co\/AxaQBqUFQa I do just need my own debit card too.",
  "id" : 786971254507073538,
  "created_at" : "2016-10-14 16:45:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/dGfcGJSVek",
      "expanded_url" : "https:\/\/www.erp5.com\/",
      "display_url" : "erp5.com"
    } ]
  },
  "geo" : { },
  "id_str" : "786970351855108096",
  "text" : "https:\/\/t.co\/dGfcGJSVek This is what to central banks use too. ERP5 and it's open.",
  "id" : 786970351855108096,
  "created_at" : "2016-10-14 16:42:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786968792014487553",
  "text" : "I have MatLab 2011a and 2015a all I want until I get the source. And I don't want to change Mathworks just for them to be open.",
  "id" : 786968792014487553,
  "created_at" : "2016-10-14 16:35:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786967811935567872",
  "text" : "Maybe the relationship should die because of jealousy old boyfriends and such. Maybe that secret Harvard meeting was right.",
  "id" : 786967811935567872,
  "created_at" : "2016-10-14 16:32:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yogi Products",
      "screen_name" : "YogiProducts",
      "indices" : [ 3, 16 ],
      "id_str" : "1909489135",
      "id" : 1909489135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786966996311281664",
  "text" : "RT @YogiProducts: Happy Friday! This rainy, fall weather calls for a warm &amp; delicous cup of tea and some words of inspiration. Have a beaut\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.falcon.io\" rel=\"nofollow\"\u003EFalcon Social Media Management \u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/YogiProducts\/status\/786966366674903040\/photo\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/2GrPlYwVV9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuvdvR9WEAA4IQZ.jpg",
        "id_str" : "786966364250574848",
        "id" : 786966364250574848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuvdvR9WEAA4IQZ.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/2GrPlYwVV9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786966366674903040",
    "text" : "Happy Friday! This rainy, fall weather calls for a warm &amp; delicous cup of tea and some words of inspiration. Have a beautiful weekend! https:\/\/t.co\/2GrPlYwVV9",
    "id" : 786966366674903040,
    "created_at" : "2016-10-14 16:26:17 +0000",
    "user" : {
      "name" : "Yogi Products",
      "screen_name" : "YogiProducts",
      "protected" : false,
      "id_str" : "1909489135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/492021771709591552\/SgXf4y5k_normal.jpeg",
      "id" : 1909489135,
      "verified" : false
    }
  },
  "id" : 786966996311281664,
  "created_at" : "2016-10-14 16:28:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786966562892869632",
  "text" : "If you build FreeBSD the Apple way it really isn't that hard. My text editor is nano.",
  "id" : 786966562892869632,
  "created_at" : "2016-10-14 16:27:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 62, 66 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/whp7OdiH81",
      "expanded_url" : "http:\/\/on.wsj.com\/1stdWCl",
      "display_url" : "on.wsj.com\/1stdWCl"
    } ]
  },
  "geo" : { },
  "id_str" : "786965904332652547",
  "text" : "'Talentism' Is the New Capitalism https:\/\/t.co\/whp7OdiH81 via @WSJ Remember This?",
  "id" : 786965904332652547,
  "created_at" : "2016-10-14 16:24:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786965072102957056",
  "text" : "My dad helped me clean my apartment. We both shared to duties. Now I just need to change my air filer tomorrow.",
  "id" : 786965072102957056,
  "created_at" : "2016-10-14 16:21:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786964189180989440",
  "text" : "These people do just want to wait until we are done like Africa.",
  "id" : 786964189180989440,
  "created_at" : "2016-10-14 16:17:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 104, 111 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/KKxpNkT9WW",
      "expanded_url" : "https:\/\/www.amazon.com\/dp\/0132545187\/ref=cm_sw_r_tw_dp_x_ysqayb0DXC3AK",
      "display_url" : "amazon.com\/dp\/0132545187\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786963662619734016",
  "text" : "Computers Are Your Future, Introductory (12th Edition) by Catherine Laberta https:\/\/t.co\/KKxpNkT9WW via @amazon",
  "id" : 786963662619734016,
  "created_at" : "2016-10-14 16:15:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/1SbY4hIR1U",
      "expanded_url" : "http:\/\/www.cyberciti.biz\/faq\/howto-setup-freebsd-ipfw-firewall\/",
      "display_url" : "cyberciti.biz\/faq\/howto-setu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786947958495477761",
  "text" : "https:\/\/t.co\/1SbY4hIR1U Configuring a FreeBSD firewall.",
  "id" : 786947958495477761,
  "created_at" : "2016-10-14 15:13:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huffington Post LA",
      "screen_name" : "HuffPostLA",
      "indices" : [ 55, 66 ],
      "id_str" : "89792919",
      "id" : 89792919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/KpKY7Qo5BU",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/chiaku-hanson\/why-are-women-so-insecure_b_9352540.html?ncid=engmodushpmg00000004",
      "display_url" : "huffingtonpost.com\/chiaku-hanson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786947217940709377",
  "text" : "Why Are Women So Insecure? https:\/\/t.co\/KpKY7Qo5BU via @HuffPostLA",
  "id" : 786947217940709377,
  "created_at" : "2016-10-14 15:10:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Skoglund",
      "screen_name" : "kskoglund",
      "indices" : [ 99, 109 ],
      "id_str" : "4595781",
      "id" : 4595781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Developer",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/mrrq5gGRur",
      "expanded_url" : "http:\/\/Lynda.com",
      "display_url" : "Lynda.com"
    }, {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/kiVzgjinye",
      "expanded_url" : "https:\/\/www.lynda.com\/PHP-tutorials\/Creating-Secure-PHP-Websites\/133321-2.html",
      "display_url" : "lynda.com\/PHP-tutorials\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786946711226871808",
  "text" : "I learned about #Developer on https:\/\/t.co\/mrrq5gGRur. I completed Creating Secure PHP Websites by @kskoglund  https:\/\/t.co\/kiVzgjinye",
  "id" : 786946711226871808,
  "created_at" : "2016-10-14 15:08:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/0xBPNz8763",
      "expanded_url" : "https:\/\/www.quora.com\/Which-language-provide-better-security-on-comparing-NET-with-PHP",
      "display_url" : "quora.com\/Which-language\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786945504726904832",
  "text" : "https:\/\/t.co\/0xBPNz8763  ASPNET might be more secure than PHP.",
  "id" : 786945504726904832,
  "created_at" : "2016-10-14 15:03:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/TnOMPZKsDW",
      "expanded_url" : "https:\/\/www.digitalocean.com\/community\/tutorials\/how-to-install-linux-apache-mysql-php-lamp-stack-on-ubuntu-14-04",
      "display_url" : "digitalocean.com\/community\/tuto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786944515940679680",
  "text" : "https:\/\/t.co\/TnOMPZKsDW LAMP Stack",
  "id" : 786944515940679680,
  "created_at" : "2016-10-14 14:59:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Gaw2hgHb3W",
      "expanded_url" : "https:\/\/www.openttd.org\/en\/",
      "display_url" : "openttd.org\/en\/"
    } ]
  },
  "geo" : { },
  "id_str" : "786943414084497408",
  "text" : "https:\/\/t.co\/Gaw2hgHb3W The number two capitalist game. The number #1 is capitalism an closed.",
  "id" : 786943414084497408,
  "created_at" : "2016-10-14 14:55:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786942408860762112",
  "text" : "I would like for what I have to finally be open and come together.",
  "id" : 786942408860762112,
  "created_at" : "2016-10-14 14:51:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786942216556142592",
  "text" : "I will say my computer and the people that work with technology almost have never let me down at least the computer.",
  "id" : 786942216556142592,
  "created_at" : "2016-10-14 14:50:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Herterich",
      "screen_name" : "PHerterich",
      "indices" : [ 3, 14 ],
      "id_str" : "402180727",
      "id" : 402180727
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PHerterich\/status\/553128306456154112\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/ccaK5uWftO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B60bP9bIcAAnTx1.jpg",
      "id_str" : "553128290236788736",
      "id" : 553128290236788736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B60bP9bIcAAnTx1.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ccaK5uWftO"
    } ],
    "hashtags" : [ {
      "text" : "openaccess",
      "indices" : [ 21, 32 ]
    }, {
      "text" : "opendata",
      "indices" : [ 45, 54 ]
    }, {
      "text" : "cernopendata",
      "indices" : [ 63, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786941456846118912",
  "text" : "RT @PHerterich: From #openaccess he moves to #opendata and the #cernopendata portal :-) http:\/\/t.co\/ccaK5uWftO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PHerterich\/status\/553128306456154112\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/ccaK5uWftO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B60bP9bIcAAnTx1.jpg",
        "id_str" : "553128290236788736",
        "id" : 553128290236788736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B60bP9bIcAAnTx1.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ccaK5uWftO"
      } ],
      "hashtags" : [ {
        "text" : "openaccess",
        "indices" : [ 5, 16 ]
      }, {
        "text" : "opendata",
        "indices" : [ 29, 38 ]
      }, {
        "text" : "cernopendata",
        "indices" : [ 47, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "553128306456154112",
    "text" : "From #openaccess he moves to #opendata and the #cernopendata portal :-) http:\/\/t.co\/ccaK5uWftO",
    "id" : 553128306456154112,
    "created_at" : "2015-01-08 09:57:19 +0000",
    "user" : {
      "name" : "Patricia Herterich",
      "screen_name" : "PHerterich",
      "protected" : false,
      "id_str" : "402180727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799996732079833093\/E8HgfAMf_normal.jpg",
      "id" : 402180727,
      "verified" : false
    }
  },
  "id" : 786941456846118912,
  "created_at" : "2016-10-14 14:47:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 67, 75 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/wXfwI6UjU4",
      "expanded_url" : "https:\/\/youtu.be\/bmoh0bmvF9s",
      "display_url" : "youtu.be\/bmoh0bmvF9s"
    } ]
  },
  "geo" : { },
  "id_str" : "786940097476321280",
  "text" : "Madonna   Material Girl   Male Version https:\/\/t.co\/wXfwI6UjU4 via @YouTube",
  "id" : 786940097476321280,
  "created_at" : "2016-10-14 14:41:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 96, 103 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/5XdkaqisiG",
      "expanded_url" : "https:\/\/www.amazon.com\/dp\/1603580786\/ref=cm_sw_r_tw_dp_x_L1oaybVCK9F47",
      "display_url" : "amazon.com\/dp\/1603580786\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786938808008859648",
  "text" : "The End of Money and the Future of Civilization by Thomas Greco Jr. https:\/\/t.co\/5XdkaqisiG via @amazon I bought this book in 2013.",
  "id" : 786938808008859648,
  "created_at" : "2016-10-14 14:36:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Read",
      "screen_name" : "ReadKev",
      "indices" : [ 3, 11 ],
      "id_str" : "223729403",
      "id" : 223729403
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bd2kAHM",
      "indices" : [ 133, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786936802615693313",
  "text" : "RT @ReadKev: Great open source tools for data management &amp; discovery coming out of Stanford including DeepDive, OpenSim and SNAP #bd2kAHM #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bd2kAHM",
        "indices" : [ 120, 128 ]
      }, {
        "text" : "datalibs",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664815870447890434",
    "text" : "Great open source tools for data management &amp; discovery coming out of Stanford including DeepDive, OpenSim and SNAP #bd2kAHM #datalibs",
    "id" : 664815870447890434,
    "created_at" : "2015-11-12 14:43:49 +0000",
    "user" : {
      "name" : "Kevin Read",
      "screen_name" : "ReadKev",
      "protected" : false,
      "id_str" : "223729403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563443269929955328\/mVhLIXMV_normal.png",
      "id" : 223729403,
      "verified" : false
    }
  },
  "id" : 786936802615693313,
  "created_at" : "2016-10-14 14:28:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786936582758686720",
  "text" : "I built Chapel in 2012 on my Laptop with Cygwin.",
  "id" : 786936582758686720,
  "created_at" : "2016-10-14 14:27:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/1krFlG45I7",
      "expanded_url" : "http:\/\/www.datacenterknowledge.com\/archives\/2014\/06\/13\/cloud-may-getting-lot-smaller\/",
      "display_url" : "datacenterknowledge.com\/archives\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786935256410652672",
  "text" : "https:\/\/t.co\/1krFlG45I7",
  "id" : 786935256410652672,
  "created_at" : "2016-10-14 14:22:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/BkfnbzEkNn",
      "expanded_url" : "https:\/\/archive.org\/details\/webstersseventhn00unse",
      "display_url" : "archive.org\/details\/webste\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786933668426182656",
  "text" : "https:\/\/t.co\/BkfnbzEkNn Webster's seventh collegiate dictionary 1960's My grandpa's do just look up the money.",
  "id" : 786933668426182656,
  "created_at" : "2016-10-14 14:16:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeUseOf",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/JFCwImmI0d",
      "expanded_url" : "http:\/\/www.makeuseof.com\/tag\/4-ways-you-can-be-tracked-when-in-private-browsing\/",
      "display_url" : "makeuseof.com\/tag\/4-ways-you\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786933111506493441",
  "text" : "4 Ways You Can Be Tracked When In Private Browsing https:\/\/t.co\/JFCwImmI0d #MakeUseOf",
  "id" : 786933111506493441,
  "created_at" : "2016-10-14 14:14:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBC News",
      "screen_name" : "NBCNews",
      "indices" : [ 75, 83 ],
      "id_str" : "14173315",
      "id" : 14173315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/Gk9FtZeRaK",
      "expanded_url" : "http:\/\/nbcnews.to\/1FxUISh",
      "display_url" : "nbcnews.to\/1FxUISh"
    } ]
  },
  "geo" : { },
  "id_str" : "786932341037867011",
  "text" : "Bernie Sanders Won't Win. But His Ideas Might. https:\/\/t.co\/Gk9FtZeRaK via @nbcnews",
  "id" : 786932341037867011,
  "created_at" : "2016-10-14 14:11:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bloomberg Markets",
      "screen_name" : "markets",
      "indices" : [ 92, 100 ],
      "id_str" : "69620713",
      "id" : 69620713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/RIHt3lo30X",
      "expanded_url" : "http:\/\/bloom.bg\/2dSDNSn",
      "display_url" : "bloom.bg\/2dSDNSn"
    } ]
  },
  "geo" : { },
  "id_str" : "786931723552616448",
  "text" : "Wells Fargo CEO Stumpf Steps down in fallout from fake accounts https:\/\/t.co\/RIHt3lo30X via @markets",
  "id" : 786931723552616448,
  "created_at" : "2016-10-14 14:08:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786925091691098112",
  "text" : "Matlab is written in Fortan and I do have some source some of it is open.",
  "id" : 786925091691098112,
  "created_at" : "2016-10-14 13:42:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/xLMmmtzgdm",
      "expanded_url" : "http:\/\/endgameeconomics.blogspot.com\/",
      "display_url" : "endgameeconomics.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "786922395915415552",
  "text" : "https:\/\/t.co\/xLMmmtzgdm End Game Economics.",
  "id" : 786922395915415552,
  "created_at" : "2016-10-14 13:31:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cointelegraph",
      "screen_name" : "CoinTelegraph",
      "indices" : [ 68, 82 ],
      "id_str" : "2207129125",
      "id" : 2207129125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/TlTm1yeH6R",
      "expanded_url" : "https:\/\/cointelegraph.com\/news\/the-open-source-world-is-worth-billions",
      "display_url" : "cointelegraph.com\/news\/the-open-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786921592173498368",
  "text" : "The Open Source World Is Worth Billions https:\/\/t.co\/TlTm1yeH6R via @Cointelegraph",
  "id" : 786921592173498368,
  "created_at" : "2016-10-14 13:28:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HarvardPublicHealth",
      "screen_name" : "HarvardChanSPH",
      "indices" : [ 3, 18 ],
      "id_str" : "42651647",
      "id" : 42651647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/dxT0l6ag4g",
      "expanded_url" : "http:\/\/hvrd.me\/qEbI305b8rk",
      "display_url" : "hvrd.me\/qEbI305b8rk"
    } ]
  },
  "geo" : { },
  "id_str" : "786920187585003520",
  "text" : "RT @HarvardChanSPH: Dessert doesn't have to be a tradeoff between unhealthy ingredients and flavor https:\/\/t.co\/dxT0l6ag4g #NationalDessert\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HarvardChanSPH\/status\/786905674001313793\/photo\/1",
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/cPwK6sJvXI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuumiZcWAAAOfS8.jpg",
        "id_str" : "786905669781815296",
        "id" : 786905669781815296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuumiZcWAAAOfS8.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/cPwK6sJvXI"
      } ],
      "hashtags" : [ {
        "text" : "NationalDessertDay",
        "indices" : [ 103, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/dxT0l6ag4g",
        "expanded_url" : "http:\/\/hvrd.me\/qEbI305b8rk",
        "display_url" : "hvrd.me\/qEbI305b8rk"
      } ]
    },
    "geo" : { },
    "id_str" : "786905674001313793",
    "text" : "Dessert doesn't have to be a tradeoff between unhealthy ingredients and flavor https:\/\/t.co\/dxT0l6ag4g #NationalDessertDay https:\/\/t.co\/cPwK6sJvXI",
    "id" : 786905674001313793,
    "created_at" : "2016-10-14 12:25:07 +0000",
    "user" : {
      "name" : "HarvardPublicHealth",
      "screen_name" : "HarvardChanSPH",
      "protected" : false,
      "id_str" : "42651647",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575390676612857857\/vmDt14tE_normal.png",
      "id" : 42651647,
      "verified" : true
    }
  },
  "id" : 786920187585003520,
  "created_at" : "2016-10-14 13:22:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 64, 72 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/GhJsDqqv0r",
      "expanded_url" : "https:\/\/youtu.be\/vimZj8HW0Kg",
      "display_url" : "youtu.be\/vimZj8HW0Kg"
    } ]
  },
  "geo" : { },
  "id_str" : "786918560249606144",
  "text" : "LL Cool J - Mama Said Knock You Out https:\/\/t.co\/GhJsDqqv0r via @YouTube",
  "id" : 786918560249606144,
  "created_at" : "2016-10-14 13:16:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/HOQoFDEK5S",
      "expanded_url" : "https:\/\/www.sitepoint.com\/web-desktop-apps\/",
      "display_url" : "sitepoint.com\/web-desktop-ap\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786918304388681728",
  "text" : "https:\/\/t.co\/HOQoFDEK5S Desktop Apps are making a comeback.",
  "id" : 786918304388681728,
  "created_at" : "2016-10-14 13:15:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Qk0AYIeK6g",
      "expanded_url" : "http:\/\/ugene.net\/external.html",
      "display_url" : "ugene.net\/external.html"
    } ]
  },
  "geo" : { },
  "id_str" : "786917209293590528",
  "text" : "https:\/\/t.co\/Qk0AYIeK6g all the external tools a biologist needs. And it works on FreeBSD.",
  "id" : 786917209293590528,
  "created_at" : "2016-10-14 13:10:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unipro UGENE",
      "screen_name" : "UniproUgene",
      "indices" : [ 3, 15 ],
      "id_str" : "128547179",
      "id" : 128547179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786916069894160384",
  "text" : "RT @UniproUgene: UGENE 1.25.0 has been released\nNew parameter for reads mappers\nSupport of different options for CutAdapt parameters.\nhttps\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/gvV8SMXHgW",
        "expanded_url" : "http:\/\/ugene.net",
        "display_url" : "ugene.net"
      } ]
    },
    "geo" : { },
    "id_str" : "785277264262893568",
    "text" : "UGENE 1.25.0 has been released\nNew parameter for reads mappers\nSupport of different options for CutAdapt parameters.\nhttps:\/\/t.co\/gvV8SMXHgW",
    "id" : 785277264262893568,
    "created_at" : "2016-10-10 00:34:24 +0000",
    "user" : {
      "name" : "Unipro UGENE",
      "screen_name" : "UniproUgene",
      "protected" : false,
      "id_str" : "128547179",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790393157\/ugene_normal.png",
      "id" : 128547179,
      "verified" : false
    }
  },
  "id" : 786916069894160384,
  "created_at" : "2016-10-14 13:06:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/W71Gpoxe7Y",
      "expanded_url" : "http:\/\/www.extremetech.com\/extreme\/134672-harvard-cracks-dna-storage-crams-700-terabytes-of-data-into-a-single-gram",
      "display_url" : "extremetech.com\/extreme\/134672\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786913981793525760",
  "text" : "Harvard cracks DNA storage, crams 700 terabytes of data into a single gram | ExtremeT https:\/\/t.co\/W71Gpoxe7Y Remember this.",
  "id" : 786913981793525760,
  "created_at" : "2016-10-14 12:58:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/FqylIsZveB",
      "expanded_url" : "http:\/\/wccftech.com\/amd-private-aquires-nvidia-reverse-takeover-releasing-ipo\/",
      "display_url" : "wccftech.com\/amd-private-aq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786804579669114880",
  "text" : "AMD Goes Private, Acquires Nvidia in A Reverse Takeover Maneuver \u2013 Pascal Islands Launching Q1 2016 https:\/\/t.co\/FqylIsZveB",
  "id" : 786804579669114880,
  "created_at" : "2016-10-14 05:43:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ftdIedvnMe",
      "expanded_url" : "https:\/\/github.com\/GPUOpen-LibrariesAndSDKs",
      "display_url" : "github.com\/GPUOpen-Librar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786803078234112000",
  "text" : "https:\/\/t.co\/ftdIedvnMe",
  "id" : 786803078234112000,
  "created_at" : "2016-10-14 05:37:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/JfXRWAJFhd",
      "expanded_url" : "http:\/\/gpuopen.com\/",
      "display_url" : "gpuopen.com"
    } ]
  },
  "geo" : { },
  "id_str" : "786802545209454592",
  "text" : "https:\/\/t.co\/JfXRWAJFhd M.i.T. I am done for tonight. GPU Open that was obvious wasn't it?",
  "id" : 786802545209454592,
  "created_at" : "2016-10-14 05:35:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ExtremeTech",
      "screen_name" : "ExtremeTech",
      "indices" : [ 106, 118 ],
      "id_str" : "23455553",
      "id" : 23455553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/EAJgOL9f1w",
      "expanded_url" : "http:\/\/www.extremetech.com\/gaming\/219434-amd-finally-unveils-an-open-source-answer-to-nvidias-gameworks",
      "display_url" : "extremetech.com\/gaming\/219434-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786801477037588480",
  "text" : "AMD finally unveils an open-source answer to Nvidia\u2019s GameWorks | ExtremeTech https:\/\/t.co\/EAJgOL9f1w via @ExtremeTech",
  "id" : 786801477037588480,
  "created_at" : "2016-10-14 05:31:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/O18m3z0Pxr",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Mantle_(API)",
      "display_url" : "en.wikipedia.org\/wiki\/Mantle_(A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786801043577286656",
  "text" : "https:\/\/t.co\/O18m3z0Pxr Maybe Mantle by AMD Apple you pussy. That is Nvidia isn't it?",
  "id" : 786801043577286656,
  "created_at" : "2016-10-14 05:29:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786797610984050689",
  "text" : "Microsoft you have made me feel like a fucking geek with Vulcan if it is open Apple I'll work on a Windows port for Metal.",
  "id" : 786797610984050689,
  "created_at" : "2016-10-14 05:15:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/CvseJwG3X3",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Metal_(API)",
      "display_url" : "en.wikipedia.org\/wiki\/Metal_(AP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786796347877842944",
  "text" : "https:\/\/t.co\/CvseJwG3X3 It Metal Open Apple?",
  "id" : 786796347877842944,
  "created_at" : "2016-10-14 05:10:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/1h90mkKcKN",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/ClanLib",
      "display_url" : "en.wikipedia.org\/wiki\/ClanLib"
    } ]
  },
  "geo" : { },
  "id_str" : "786795833551237120",
  "text" : "https:\/\/t.co\/1h90mkKcKN ClanLib IDK yet.",
  "id" : 786795833551237120,
  "created_at" : "2016-10-14 05:08:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/9iNq5ZdjyG",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/List_of_3D_graphics_libraries",
      "display_url" : "en.wikipedia.org\/wiki\/List_of_3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786795044573368322",
  "text" : "https:\/\/t.co\/9iNq5ZdjyG 3d Graphics libraries and I do want to find one that is real and won't change.",
  "id" : 786795044573368322,
  "created_at" : "2016-10-14 05:05:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/cJfIMI4YQB",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/Doom\/comments\/4ibcdg\/doom_supports_vulkan_performance_120fps_vs_50fps\/",
      "display_url" : "reddit.com\/r\/Doom\/comment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786793092619771904",
  "text" : "https:\/\/t.co\/cJfIMI4YQB IDK Id it is OpenGL. too.",
  "id" : 786793092619771904,
  "created_at" : "2016-10-14 04:57:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ReluMBUKcQ",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/LinuxActionShow\/comments\/4c6yv4\/ryan_c_gordon_on_vulcan_vs_opengl_78_lines_for\/",
      "display_url" : "reddit.com\/r\/LinuxActionS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786792344590749696",
  "text" : "https:\/\/t.co\/ReluMBUKcQ I might say OpenGL too everyone.",
  "id" : 786792344590749696,
  "created_at" : "2016-10-14 04:54:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/fTkw3Y1yaM",
      "expanded_url" : "http:\/\/www.anandtech.com\/show\/9038\/next-generation-opengl-becomes-vulkan-additional-details-released",
      "display_url" : "anandtech.com\/show\/9038\/next\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786791447999549440",
  "text" : "https:\/\/t.co\/fTkw3Y1yaM NextGen OpenGL becomes Vulcan.",
  "id" : 786791447999549440,
  "created_at" : "2016-10-14 04:51:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786790629938311168",
  "text" : "I played Quake on my IBM Aptiva in 1997.",
  "id" : 786790629938311168,
  "created_at" : "2016-10-14 04:47:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/W2NWRhO8hc",
      "expanded_url" : "http:\/\/www.pcgamer.com\/doom-benchmarks-return-vulkan-vs-opengl\/",
      "display_url" : "pcgamer.com\/doom-benchmark\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786789607656390660",
  "text" : "Doom benchmarks return: Vulkan vs. OpenGL https:\/\/t.co\/W2NWRhO8hc",
  "id" : 786789607656390660,
  "created_at" : "2016-10-14 04:43:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ExtremeTech",
      "screen_name" : "ExtremeTech",
      "indices" : [ 97, 109 ],
      "id_str" : "23455553",
      "id" : 23455553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/LWAjWckJ6y",
      "expanded_url" : "http:\/\/www.extremetech.com\/gaming\/133824-valve-opengl-is-faster-than-directx-even-on-windows",
      "display_url" : "extremetech.com\/gaming\/133824-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786787358737702912",
  "text" : "Valve: OpenGL is faster than DirectX \u2014 even on Windows | ExtremeTech https:\/\/t.co\/LWAjWckJ6y via @ExtremeTech",
  "id" : 786787358737702912,
  "created_at" : "2016-10-14 04:34:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/3LdKQ59WxJ",
      "expanded_url" : "https:\/\/mitpress.mit.edu\/books\/csound-book",
      "display_url" : "mitpress.mit.edu\/books\/csound-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786786294944768001",
  "text" : "https:\/\/t.co\/3LdKQ59WxJ CSound book I have read only partially.",
  "id" : 786786294944768001,
  "created_at" : "2016-10-14 04:30:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 81, 87 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/hnNldwAdRO",
      "expanded_url" : "https:\/\/www.wired.com\/2013\/08\/jordan-hubbard\/",
      "display_url" : "wired.com\/2013\/08\/jordan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786786076312506369",
  "text" : "Apple\u2019s Operating System Guru Goes Back to His Roots https:\/\/t.co\/hnNldwAdRO via @WIRED",
  "id" : 786786076312506369,
  "created_at" : "2016-10-14 04:29:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 81, 87 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/hnNldwAdRO",
      "expanded_url" : "https:\/\/www.wired.com\/2013\/08\/jordan-hubbard\/",
      "display_url" : "wired.com\/2013\/08\/jordan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786785154639421440",
  "text" : "Apple\u2019s Operating System Guru Goes Back to His Roots https:\/\/t.co\/hnNldwAdRO via @WIRED I think we all have now Apple.",
  "id" : 786785154639421440,
  "created_at" : "2016-10-14 04:26:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "InfoWorld",
      "screen_name" : "infoworld",
      "indices" : [ 104, 114 ],
      "id_str" : "15426758",
      "id" : 15426758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/dFSu4Ppw1W",
      "expanded_url" : "http:\/\/www.infoworld.com\/article\/2885466\/application-development\/entity-framework-7-providing-support-for-new-platforms-and-new-data-stores.html",
      "display_url" : "infoworld.com\/article\/288546\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786784256102010880",
  "text" : "Entity Framework 7: Providing support for new platforms and new data stores https:\/\/t.co\/dFSu4Ppw1W via @infoworld",
  "id" : 786784256102010880,
  "created_at" : "2016-10-14 04:22:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/KZkMsyOdwb",
      "expanded_url" : "http:\/\/www.infragistics.com\/community\/blogs\/devtoolsguy\/archive\/2015\/06\/10\/the-future-of-wpf-beyond-the-net-framework-4-6.aspx",
      "display_url" : "infragistics.com\/community\/blog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786783015145922561",
  "text" : "https:\/\/t.co\/KZkMsyOdwb WPF on UNIX is Mono's project Olive.",
  "id" : 786783015145922561,
  "created_at" : "2016-10-14 04:17:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786778984793202688",
  "text" : "Procedure succeeded goodnight.",
  "id" : 786778984793202688,
  "created_at" : "2016-10-14 04:01:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/yiNNJlBmjQ",
      "expanded_url" : "https:\/\/www.amazon.com\/Precisely-MIT-Press-Peter-Sestoft\/dp\/0262516861",
      "display_url" : "amazon.com\/Precisely-MIT-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786778469812363264",
  "text" : "https:\/\/t.co\/yiNNJlBmjQ Anders Thank You. I would like one more C# book from M.I.T. Press UVa that C# book sucked.",
  "id" : 786778469812363264,
  "created_at" : "2016-10-14 03:59:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/oIzh8f44xQ",
      "expanded_url" : "http:\/\/news.mit.edu\/2015\/qs-ranks-mit-worlds-top-univeristy-0917",
      "display_url" : "news.mit.edu\/2015\/qs-ranks-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786776717771804672",
  "text" : "https:\/\/t.co\/oIzh8f44xQ M.I.T #1 university in the world.",
  "id" : 786776717771804672,
  "created_at" : "2016-10-14 03:52:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786775835827142657",
  "text" : "I might run course discovery. But use EdX I would like to download all of EdX but not change it is from M.I.T.",
  "id" : 786775835827142657,
  "created_at" : "2016-10-14 03:49:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edX",
      "screen_name" : "edXOnline",
      "indices" : [ 3, 13 ],
      "id_str" : "567360618",
      "id" : 567360618
    }, {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 108, 116 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786775068118573056",
  "text" : "RT @edXOnline: Are we alone in the universe? Where should we look to find life outside of earth? Learn from @Harvard astronomers: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Harvard University",
        "screen_name" : "Harvard",
        "indices" : [ 93, 101 ],
        "id_str" : "39585367",
        "id" : 39585367
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/MeITWYi6Om",
        "expanded_url" : "http:\/\/bit.ly\/2dP6L8n",
        "display_url" : "bit.ly\/2dP6L8n"
      } ]
    },
    "geo" : { },
    "id_str" : "784121256291565568",
    "text" : "Are we alone in the universe? Where should we look to find life outside of earth? Learn from @Harvard astronomers: https:\/\/t.co\/MeITWYi6Om",
    "id" : 784121256291565568,
    "created_at" : "2016-10-06 20:00:50 +0000",
    "user" : {
      "name" : "edX",
      "screen_name" : "edXOnline",
      "protected" : false,
      "id_str" : "567360618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717789136606928896\/ddrecp7p_normal.jpg",
      "id" : 567360618,
      "verified" : true
    }
  },
  "id" : 786775068118573056,
  "created_at" : "2016-10-14 03:46:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786772267896336384",
  "text" : "It is just the accrual method of accounting too and a wage.",
  "id" : 786772267896336384,
  "created_at" : "2016-10-14 03:35:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/G7byTMipDk",
      "expanded_url" : "http:\/\/go.sap.com\/developer\/topics\/sap-hana-express.html",
      "display_url" : "go.sap.com\/developer\/topi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786771734900924416",
  "text" : "https:\/\/t.co\/G7byTMipDk I just don't know what SAP HANA is.",
  "id" : 786771734900924416,
  "created_at" : "2016-10-14 03:32:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/3Rho0kQQJ2",
      "expanded_url" : "https:\/\/github.com\/edx",
      "display_url" : "github.com\/edx"
    } ]
  },
  "geo" : { },
  "id_str" : "786770450978312194",
  "text" : "https:\/\/t.co\/3Rho0kQQJ2",
  "id" : 786770450978312194,
  "created_at" : "2016-10-14 03:27:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/DBl6IzFqE5",
      "expanded_url" : "https:\/\/github.com\/SAP",
      "display_url" : "github.com\/SAP"
    } ]
  },
  "geo" : { },
  "id_str" : "786769382902988801",
  "text" : "https:\/\/t.co\/DBl6IzFqE5 Germany.",
  "id" : 786769382902988801,
  "created_at" : "2016-10-14 03:23:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/lzBnbw7PeL",
      "expanded_url" : "http:\/\/www.connectedbenefits.com\/",
      "display_url" : "connectedbenefits.com"
    } ]
  },
  "geo" : { },
  "id_str" : "786768626317746176",
  "text" : "https:\/\/t.co\/lzBnbw7PeL Connected Benefits it's an app.",
  "id" : 786768626317746176,
  "created_at" : "2016-10-14 03:20:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786768023562616837",
  "text" : "It's all in Oracle's E business suite just too complicated.",
  "id" : 786768023562616837,
  "created_at" : "2016-10-14 03:18:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/PKudmuDfs9",
      "expanded_url" : "http:\/\/www.capterra.com\/benefits-administration-software\/",
      "display_url" : "capterra.com\/benefits-admin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786767563913068544",
  "text" : "https:\/\/t.co\/PKudmuDfs9 Best benefits software.",
  "id" : 786767563913068544,
  "created_at" : "2016-10-14 03:16:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Lotich",
      "screen_name" : "PatriciaLotich",
      "indices" : [ 95, 110 ],
      "id_str" : "129878012",
      "id" : 129878012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/ymMaSUKvNd",
      "expanded_url" : "http:\/\/thethrivingsmallbusiness.com\/employee-benefits\/",
      "display_url" : "thethrivingsmallbusiness.com\/employee-benef\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786767093039566848",
  "text" : "5 Employee Benefits Required by Law \u2014 The Thriving Small Business https:\/\/t.co\/ymMaSUKvNd via @@patricialotich",
  "id" : 786767093039566848,
  "created_at" : "2016-10-14 03:14:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/gxMZJVbCxO",
      "expanded_url" : "http:\/\/apps.law.georgetown.edu\/curriculum\/tab_courses.cfm?Status=Course&Detail=2606",
      "display_url" : "apps.law.georgetown.edu\/curriculum\/tab\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786766409871261697",
  "text" : "https:\/\/t.co\/gxMZJVbCxO Employee Benefits Law Executive compensation.",
  "id" : 786766409871261697,
  "created_at" : "2016-10-14 03:11:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/KXts47NDef",
      "expanded_url" : "https:\/\/twitter.github.io\/",
      "display_url" : "twitter.github.io"
    } ]
  },
  "geo" : { },
  "id_str" : "786763570625282048",
  "text" : "https:\/\/t.co\/KXts47NDef It is Twitter I'll research the best social news feed. Remember digital paper?",
  "id" : 786763570625282048,
  "created_at" : "2016-10-14 03:00:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/CoDntvNEGX",
      "expanded_url" : "http:\/\/gaizupath.com\/coconut-oil-for-gray-hair\/",
      "display_url" : "gaizupath.com\/coconut-oil-fo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786762797929627648",
  "text" : "https:\/\/t.co\/CoDntvNEGX Coconut Oil is popular right know It might prevent grey hair.",
  "id" : 786762797929627648,
  "created_at" : "2016-10-14 02:57:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786761838293880832",
  "text" : "ready money?",
  "id" : 786761838293880832,
  "created_at" : "2016-10-14 02:53:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 71, 81 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/QrTQcczcXW",
      "expanded_url" : "https:\/\/shar.es\/1E69ii",
      "display_url" : "shar.es\/1E69ii"
    } ]
  },
  "geo" : { },
  "id_str" : "786761649399160833",
  "text" : "HR Evolves Into 'Human Capital Management' https:\/\/t.co\/QrTQcczcXW via @sharethis",
  "id" : 786761649399160833,
  "created_at" : "2016-10-14 02:52:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/QwZh5vMWQn",
      "expanded_url" : "https:\/\/twitter.com\/analyticbridge\/status\/786733598212780032",
      "display_url" : "twitter.com\/analyticbridge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786761261564526592",
  "text" : "Score'em in Human Capital management everyone. https:\/\/t.co\/QwZh5vMWQn",
  "id" : 786761261564526592,
  "created_at" : "2016-10-14 02:51:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786760505373429760",
  "text" : "I the TV could be in a window like the live video on Twitter in might be alright.",
  "id" : 786760505373429760,
  "created_at" : "2016-10-14 02:48:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/e3TQXgCi9Z",
      "expanded_url" : "https:\/\/twitter.com\/techreview\/status\/786758563406442496",
      "display_url" : "twitter.com\/techreview\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786759948915077121",
  "text" : "Everyone take your flu shot I have they might be replaced with something better soon. https:\/\/t.co\/e3TQXgCi9Z",
  "id" : 786759948915077121,
  "created_at" : "2016-10-14 02:46:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786759467153158144",
  "text" : "LaBlanc that is man with a plan isn't it. Hope it does well.",
  "id" : 786759467153158144,
  "created_at" : "2016-10-14 02:44:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786758473295990785",
  "text" : "That IT story is on the G+ Vanguard community somewhere.UK.",
  "id" : 786758473295990785,
  "created_at" : "2016-10-14 02:40:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/PfuL1iEeBG",
      "expanded_url" : "http:\/\/kidneysteps.com\/2013\/01\/kidney-disease-and-testosterone\/",
      "display_url" : "kidneysteps.com\/2013\/01\/kidney\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786756327204945920",
  "text" : "Kidney Disease and Testosterone https:\/\/t.co\/PfuL1iEeBG I look at women maybe once a week. I can't even have a real one can I Hillary?",
  "id" : 786756327204945920,
  "created_at" : "2016-10-14 02:31:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 3, 16 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Xe0MpCWZTX",
      "expanded_url" : "http:\/\/econ.st\/2e7UpIg",
      "display_url" : "econ.st\/2e7UpIg"
    } ]
  },
  "geo" : { },
  "id_str" : "786755221401772034",
  "text" : "RT @TheEconomist: Italy\u2019s cherished opera houses are in the midst of a serious financial crisis https:\/\/t.co\/Xe0MpCWZTX https:\/\/t.co\/ZrLlzG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheEconomist\/status\/786741543893950465\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/ZrLlzG8Lci",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CusRQ5BWgAAkGwl.jpg",
        "id_str" : "786741541788352512",
        "id" : 786741541788352512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CusRQ5BWgAAkGwl.jpg",
        "sizes" : [ {
          "h" : 335,
          "resize" : "fit",
          "w" : 595
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 595
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 595
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 595
        } ],
        "display_url" : "pic.twitter.com\/ZrLlzG8Lci"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/Xe0MpCWZTX",
        "expanded_url" : "http:\/\/econ.st\/2e7UpIg",
        "display_url" : "econ.st\/2e7UpIg"
      } ]
    },
    "geo" : { },
    "id_str" : "786741543893950465",
    "text" : "Italy\u2019s cherished opera houses are in the midst of a serious financial crisis https:\/\/t.co\/Xe0MpCWZTX https:\/\/t.co\/ZrLlzG8Lci",
    "id" : 786741543893950465,
    "created_at" : "2016-10-14 01:32:55 +0000",
    "user" : {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "protected" : false,
      "id_str" : "5988062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461499742950678528\/2JnpHjUo_normal.png",
      "id" : 5988062,
      "verified" : true
    }
  },
  "id" : 786755221401772034,
  "created_at" : "2016-10-14 02:27:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 133, 156 ],
      "url" : "https:\/\/t.co\/3Wx7lin8zr",
      "expanded_url" : "https:\/\/twitter.com\/jasonnazar\/status\/755573996372922369",
      "display_url" : "twitter.com\/jasonnazar\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786753281842372608",
  "text" : "I know, I just don't like to be told what to do like Satan always have. It is just a good  but somewhat violent Christian story too. https:\/\/t.co\/3Wx7lin8zr",
  "id" : 786753281842372608,
  "created_at" : "2016-10-14 02:19:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Women in the World",
      "screen_name" : "WomenintheWorld",
      "indices" : [ 3, 19 ],
      "id_str" : "120153772",
      "id" : 120153772
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WomenintheWorld\/status\/786733264266522627\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/hKI2fqwEjG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuqT5jJXgAAyxbT.jpg",
      "id_str" : "786603701825929216",
      "id" : 786603701825929216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuqT5jJXgAAyxbT.jpg",
      "sizes" : [ {
        "h" : 394,
        "resize" : "fit",
        "w" : 594
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 594
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 594
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 594
      } ],
      "display_url" : "pic.twitter.com\/hKI2fqwEjG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/VycKXHUT3R",
      "expanded_url" : "http:\/\/nyti.ms\/2e0Biyr",
      "display_url" : "nyti.ms\/2e0Biyr"
    } ]
  },
  "geo" : { },
  "id_str" : "786752618681012224",
  "text" : "RT @WomenintheWorld: Japanese teacher ordered by court to use her married name at work: https:\/\/t.co\/VycKXHUT3R https:\/\/t.co\/hKI2fqwEjG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WomenintheWorld\/status\/786733264266522627\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/hKI2fqwEjG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuqT5jJXgAAyxbT.jpg",
        "id_str" : "786603701825929216",
        "id" : 786603701825929216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuqT5jJXgAAyxbT.jpg",
        "sizes" : [ {
          "h" : 394,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 594
        } ],
        "display_url" : "pic.twitter.com\/hKI2fqwEjG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/VycKXHUT3R",
        "expanded_url" : "http:\/\/nyti.ms\/2e0Biyr",
        "display_url" : "nyti.ms\/2e0Biyr"
      } ]
    },
    "geo" : { },
    "id_str" : "786733264266522627",
    "text" : "Japanese teacher ordered by court to use her married name at work: https:\/\/t.co\/VycKXHUT3R https:\/\/t.co\/hKI2fqwEjG",
    "id" : 786733264266522627,
    "created_at" : "2016-10-14 01:00:01 +0000",
    "user" : {
      "name" : "Women in the World",
      "screen_name" : "WomenintheWorld",
      "protected" : false,
      "id_str" : "120153772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579026092914294784\/KFrOWkX__normal.png",
      "id" : 120153772,
      "verified" : true
    }
  },
  "id" : 786752618681012224,
  "created_at" : "2016-10-14 02:16:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786752218934509568",
  "text" : "I'm not the election make me mad I voted for neither. And by absentee. A dem yes but a right wing dem.",
  "id" : 786752218934509568,
  "created_at" : "2016-10-14 02:15:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/pTRFVB3BZK",
      "expanded_url" : "https:\/\/forums.freebsd.org\/threads\/33398\/",
      "display_url" : "forums.freebsd.org\/threads\/33398\/"
    } ]
  },
  "geo" : { },
  "id_str" : "786750907526545408",
  "text" : "https:\/\/t.co\/pTRFVB3BZK Win32DiskImger.",
  "id" : 786750907526545408,
  "created_at" : "2016-10-14 02:10:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786750232013012993",
  "text" : "I will just be studying String Theory. Screw VR.",
  "id" : 786750232013012993,
  "created_at" : "2016-10-14 02:07:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786748468031283200",
  "text" : "Is Hillary going to arrest engineers for chatting with hot girls of age like the U.K? Zuckerberg making engineers get off to VR?",
  "id" : 786748468031283200,
  "created_at" : "2016-10-14 02:00:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786747013270532096",
  "text" : "I'm sure you like Bob Hope too Hilary? Look what he did in the Caribbean.",
  "id" : 786747013270532096,
  "created_at" : "2016-10-14 01:54:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786746211403493377",
  "text" : "Sue Hefner Hilary.",
  "id" : 786746211403493377,
  "created_at" : "2016-10-14 01:51:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786745882943320065",
  "text" : "The Dems are going to win on women's rights when they are the biggest cheaters.",
  "id" : 786745882943320065,
  "created_at" : "2016-10-14 01:50:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "indices" : [ 3, 10 ],
      "id_str" : "17471979",
      "id" : 17471979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/jT52IHgup2",
      "expanded_url" : "http:\/\/on.natgeo.com\/2dR2jXl",
      "display_url" : "on.natgeo.com\/2dR2jXl"
    } ]
  },
  "geo" : { },
  "id_str" : "786745523625680896",
  "text" : "RT @NatGeo: Watch: Contorting, shape-shifting, camouflaging\u2014often all at once\u2014octopuses are absolutely fascinating\n https:\/\/t.co\/jT52IHgup2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/jT52IHgup2",
        "expanded_url" : "http:\/\/on.natgeo.com\/2dR2jXl",
        "display_url" : "on.natgeo.com\/2dR2jXl"
      } ]
    },
    "geo" : { },
    "id_str" : "786737805191946240",
    "text" : "Watch: Contorting, shape-shifting, camouflaging\u2014often all at once\u2014octopuses are absolutely fascinating\n https:\/\/t.co\/jT52IHgup2",
    "id" : 786737805191946240,
    "created_at" : "2016-10-14 01:18:04 +0000",
    "user" : {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "protected" : false,
      "id_str" : "17471979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798181194202566656\/U8QbCBdH_normal.jpg",
      "id" : 17471979,
      "verified" : true
    }
  },
  "id" : 786745523625680896,
  "created_at" : "2016-10-14 01:48:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786744951094833156",
  "text" : "Hilary don't start.",
  "id" : 786744951094833156,
  "created_at" : "2016-10-14 01:46:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TNF",
      "indices" : [ 42, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/eH68P8dO8z",
      "expanded_url" : "https:\/\/twitter.com\/i\/live\/768633364911788032",
      "display_url" : "twitter.com\/i\/live\/7686333\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786744301849972742",
  "text" : "Watch live! \"NFL Thursday Night Football\" #TNF https:\/\/t.co\/eH68P8dO8z",
  "id" : 786744301849972742,
  "created_at" : "2016-10-14 01:43:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786743429673971713",
  "text" : "The Steinberg SDK is open id is good C++. so is RackAFX from Will Prickle.",
  "id" : 786743429673971713,
  "created_at" : "2016-10-14 01:40:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/HcHFmevRtt",
      "expanded_url" : "http:\/\/wpo.st\/sg362",
      "display_url" : "wpo.st\/sg362"
    } ]
  },
  "geo" : { },
  "id_str" : "786742449867751424",
  "text" : "Occupy Wall Street just won https:\/\/t.co\/HcHFmevRtt See Wall Street we want smart consumers.",
  "id" : 786742449867751424,
  "created_at" : "2016-10-14 01:36:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Computerworld",
      "screen_name" : "Computerworld",
      "indices" : [ 66, 80 ],
      "id_str" : "14539324",
      "id" : 14539324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/Di3tEjf4so",
      "expanded_url" : "http:\/\/www.computerworld.com\/article\/2491794\/database-administration\/mysql-users-caution-against-nosql-fad.html",
      "display_url" : "computerworld.com\/article\/249179\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786742007330988032",
  "text" : "MySQL users caution against NoSQL fad https:\/\/t.co\/Di3tEjf4so via @computerworld",
  "id" : 786742007330988032,
  "created_at" : "2016-10-14 01:34:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/EmGLJjwXV2",
      "expanded_url" : "https:\/\/cs.stanford.edu\/people\/eroberts\/courses\/soco\/projects\/risc\/risccisc\/",
      "display_url" : "cs.stanford.edu\/people\/erobert\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786741391842021376",
  "text" : "https:\/\/t.co\/EmGLJjwXV2 RISC vs CISC.",
  "id" : 786741391842021376,
  "created_at" : "2016-10-14 01:32:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786740818463850499",
  "text" : "I do like Darwin Apple if you would let people build you OS.",
  "id" : 786740818463850499,
  "created_at" : "2016-10-14 01:30:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/xkYHKyqiwy",
      "expanded_url" : "https:\/\/sourceforge.net\/projects\/win32diskimager\/",
      "display_url" : "sourceforge.net\/projects\/win32\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786740038637916160",
  "text" : "https:\/\/t.co\/xkYHKyqiwy Make your FreeBSD USB stick in Windows you could use dd also.",
  "id" : 786740038637916160,
  "created_at" : "2016-10-14 01:26:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/j4hjSVbosO",
      "expanded_url" : "http:\/\/www.dell.com\/learn\/us\/en\/555\/campaigns\/xps-linux-laptop?c=us&l=en&s=biz",
      "display_url" : "dell.com\/learn\/us\/en\/55\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786739320992456704",
  "text" : "https:\/\/t.co\/j4hjSVbosO Dell it is Ubuntu. and easy to install. I'm not sure.",
  "id" : 786739320992456704,
  "created_at" : "2016-10-14 01:24:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/IPIq8z2aeD",
      "expanded_url" : "http:\/\/futurist.se\/gldt\/",
      "display_url" : "futurist.se\/gldt\/"
    } ]
  },
  "geo" : { },
  "id_str" : "786738170834616320",
  "text" : "https:\/\/t.co\/IPIq8z2aeD History of Linux Debian and Slackware and I'm done.",
  "id" : 786738170834616320,
  "created_at" : "2016-10-14 01:19:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBM developerWorks",
      "screen_name" : "developerWorks",
      "indices" : [ 56, 71 ],
      "id_str" : "16362921",
      "id" : 16362921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/zmwQqx6rcl",
      "expanded_url" : "http:\/\/ibm.co\/1bjI4XB",
      "display_url" : "ibm.co\/1bjI4XB"
    } ]
  },
  "geo" : { },
  "id_str" : "786737198100049920",
  "text" : "POSIX threads explained https:\/\/t.co\/zmwQqx6rcl via IBM @developerWorks",
  "id" : 786737198100049920,
  "created_at" : "2016-10-14 01:15:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Mullins",
      "screen_name" : "TechThoughtsWeb",
      "indices" : [ 62, 78 ],
      "id_str" : "83963894",
      "id" : 83963894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/NhnZuvyBTa",
      "expanded_url" : "https:\/\/billmullins.wordpress.com\/2009\/05\/31\/pc-bsd-best-unix-for-beginners-2\/",
      "display_url" : "billmullins.wordpress.com\/2009\/05\/31\/pc-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786736498414608384",
  "text" : "PC-BSD \u2013 Best Unix for Beginners? https:\/\/t.co\/NhnZuvyBTa via @TechThoughtsWeb",
  "id" : 786736498414608384,
  "created_at" : "2016-10-14 01:12:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/8FNoAaGCoZ",
      "expanded_url" : "http:\/\/read.bi\/1o2wxhU",
      "display_url" : "read.bi\/1o2wxhU"
    } ]
  },
  "geo" : { },
  "id_str" : "786735800394326018",
  "text" : "The most ambitious artificial intelligence project in the world has been operating in near-secrecy for 30 years https:\/\/t.co\/8FNoAaGCoZ",
  "id" : 786735800394326018,
  "created_at" : "2016-10-14 01:10:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sourceforge",
      "screen_name" : "sourceforge",
      "indices" : [ 3, 15 ],
      "id_str" : "14118534",
      "id" : 14118534
    }, {
      "name" : "Go Parallel",
      "screen_name" : "Go_Parallel",
      "indices" : [ 114, 126 ],
      "id_str" : "1504640684",
      "id" : 1504640684
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Supercomputing",
      "indices" : [ 35, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786735066844192772",
  "text" : "RT @sourceforge: Rest Easy, Folks: #Supercomputing simulations say Mercury Won\u2019t  Collide With Earth anytime soon @Go_Parallel \nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Go Parallel",
        "screen_name" : "Go_Parallel",
        "indices" : [ 97, 109 ],
        "id_str" : "1504640684",
        "id" : 1504640684
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sourceforge\/status\/786733467065282560\/photo\/1",
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/dog8QmMPoK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CusJ6r5XYAE_hwU.jpg",
        "id_str" : "786733463726678017",
        "id" : 786733463726678017,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CusJ6r5XYAE_hwU.jpg",
        "sizes" : [ {
          "h" : 714,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 714,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 714,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/dog8QmMPoK"
      } ],
      "hashtags" : [ {
        "text" : "Supercomputing",
        "indices" : [ 18, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/I3EAvKdVLB",
        "expanded_url" : "http:\/\/sdm.link\/merc",
        "display_url" : "sdm.link\/merc"
      } ]
    },
    "geo" : { },
    "id_str" : "786733467065282560",
    "text" : "Rest Easy, Folks: #Supercomputing simulations say Mercury Won\u2019t  Collide With Earth anytime soon @Go_Parallel \nhttps:\/\/t.co\/I3EAvKdVLB https:\/\/t.co\/dog8QmMPoK",
    "id" : 786733467065282560,
    "created_at" : "2016-10-14 01:00:50 +0000",
    "user" : {
      "name" : "sourceforge",
      "screen_name" : "sourceforge",
      "protected" : false,
      "id_str" : "14118534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1101343930\/sf_badge_64s_normal.png",
      "id" : 14118534,
      "verified" : true
    }
  },
  "id" : 786735066844192772,
  "created_at" : "2016-10-14 01:07:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "indices" : [ 3, 11 ],
      "id_str" : "39585367",
      "id" : 39585367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/gi9qrPdwpd",
      "expanded_url" : "http:\/\/hvrd.me\/l02N3058Rcw",
      "display_url" : "hvrd.me\/l02N3058Rcw"
    } ]
  },
  "geo" : { },
  "id_str" : "786735027686170624",
  "text" : "RT @Harvard: The refugee crisis in black and white: A new photo exhibit documents tribulations endured by emigrants https:\/\/t.co\/gi9qrPdwpd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Harvard\/status\/786733523445088256\/photo\/1",
        "indices" : [ 127, 150 ],
        "url" : "https:\/\/t.co\/IB24Wfr3Ep",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CusJ9_ZWcAAusNl.jpg",
        "id_str" : "786733520500715520",
        "id" : 786733520500715520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CusJ9_ZWcAAusNl.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/IB24Wfr3Ep"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/gi9qrPdwpd",
        "expanded_url" : "http:\/\/hvrd.me\/l02N3058Rcw",
        "display_url" : "hvrd.me\/l02N3058Rcw"
      } ]
    },
    "geo" : { },
    "id_str" : "786733523445088256",
    "text" : "The refugee crisis in black and white: A new photo exhibit documents tribulations endured by emigrants https:\/\/t.co\/gi9qrPdwpd https:\/\/t.co\/IB24Wfr3Ep",
    "id" : 786733523445088256,
    "created_at" : "2016-10-14 01:01:03 +0000",
    "user" : {
      "name" : "Harvard University",
      "screen_name" : "Harvard",
      "protected" : false,
      "id_str" : "39585367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466953024271679488\/3rftwYWT_normal.jpeg",
      "id" : 39585367,
      "verified" : true
    }
  },
  "id" : 786735027686170624,
  "created_at" : "2016-10-14 01:07:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786733821077102592",
  "text" : "All I would really ask is if is POSIX compliant. It might be Linux too.",
  "id" : 786733821077102592,
  "created_at" : "2016-10-14 01:02:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/SkLCV6uhmK",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Smart_city",
      "display_url" : "en.wikipedia.org\/wiki\/Smart_city"
    } ]
  },
  "geo" : { },
  "id_str" : "786733387201572864",
  "text" : "https:\/\/t.co\/SkLCV6uhmK All they are saying is Open Platforms probably a BSD. And when you configure your firewall you really are done.",
  "id" : 786733387201572864,
  "created_at" : "2016-10-14 01:00:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C# Corner",
      "screen_name" : "CsharpCorner",
      "indices" : [ 65, 78 ],
      "id_str" : "241007239",
      "id" : 241007239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/eUnMJAtcyp",
      "expanded_url" : "http:\/\/www.c-sharpcorner.com\/article\/simple-nslookup-implementation-in-c-sharp\/",
      "display_url" : "c-sharpcorner.com\/article\/simple\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786732199227850753",
  "text" : "Simple NSLookUp Implementation in C# https:\/\/t.co\/eUnMJAtcyp via @CsharpCorner",
  "id" : 786732199227850753,
  "created_at" : "2016-10-14 00:55:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786730928999690240",
  "text" : "Kid 'A' you will just laugh until you head comes off like I did.",
  "id" : 786730928999690240,
  "created_at" : "2016-10-14 00:50:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786730378300104704",
  "text" : "Lookup the definition of liqidity in the 1060 Websters collegiate dictionary.",
  "id" : 786730378300104704,
  "created_at" : "2016-10-14 00:48:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life Extension",
      "screen_name" : "LifeExtension",
      "indices" : [ 3, 17 ],
      "id_str" : "27188645",
      "id" : 27188645
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CoQ10",
      "indices" : [ 102, 108 ]
    }, {
      "text" : "health",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/pVUGYc1fiC",
      "expanded_url" : "http:\/\/trib.al\/mz3k4MH",
      "display_url" : "trib.al\/mz3k4MH"
    } ]
  },
  "geo" : { },
  "id_str" : "786729797636546561",
  "text" : "RT @LifeExtension: Are you taking the right form of CoQ10? It really matters! https:\/\/t.co\/pVUGYc1fiC #CoQ10 #health",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CoQ10",
        "indices" : [ 83, 89 ]
      }, {
        "text" : "health",
        "indices" : [ 90, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/pVUGYc1fiC",
        "expanded_url" : "http:\/\/trib.al\/mz3k4MH",
        "display_url" : "trib.al\/mz3k4MH"
      } ]
    },
    "geo" : { },
    "id_str" : "786728740130787330",
    "text" : "Are you taking the right form of CoQ10? It really matters! https:\/\/t.co\/pVUGYc1fiC #CoQ10 #health",
    "id" : 786728740130787330,
    "created_at" : "2016-10-14 00:42:03 +0000",
    "user" : {
      "name" : "Life Extension",
      "screen_name" : "LifeExtension",
      "protected" : false,
      "id_str" : "27188645",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466584195842592768\/C9ajd_Y__normal.jpeg",
      "id" : 27188645,
      "verified" : false
    }
  },
  "id" : 786729797636546561,
  "created_at" : "2016-10-14 00:46:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/0bBxhy622R",
      "expanded_url" : "https:\/\/twitter.com\/IBM\/status\/786728915213492225",
      "display_url" : "twitter.com\/IBM\/status\/786\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786729470514298880",
  "text" : "It is OpenCyc IBM. https:\/\/t.co\/0bBxhy622R",
  "id" : 786729470514298880,
  "created_at" : "2016-10-14 00:44:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Sl5sBsPlLk",
      "expanded_url" : "https:\/\/www.scribd.com\/document\/142074985\/Benchmarking-FreeBSD",
      "display_url" : "scribd.com\/document\/14207\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786729332857303045",
  "text" : "https:\/\/t.co\/Sl5sBsPlLk Benchmarking FreeBSD.",
  "id" : 786729332857303045,
  "created_at" : "2016-10-14 00:44:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/dKC8gIOxiM",
      "expanded_url" : "http:\/\/www.ibm.com\/smarterplanet\/us\/en\/smarter_cities\/overview\/",
      "display_url" : "ibm.com\/smarterplanet\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786728363939532801",
  "text" : "https:\/\/t.co\/dKC8gIOxiM Obama made sure Hawaii had one. A Smart City.",
  "id" : 786728363939532801,
  "created_at" : "2016-10-14 00:40:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CE Pro",
      "screen_name" : "ce_pro",
      "indices" : [ 79, 86 ],
      "id_str" : "34280870",
      "id" : 34280870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/MBEhkzV4LU",
      "expanded_url" : "http:\/\/www.cepro.com\/article\/the_myth_of_whole_house_surge_protection",
      "display_url" : "cepro.com\/article\/the_my\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786728047689039872",
  "text" : "The Myth of Whole-House Surge Protection - CE Pro: https:\/\/t.co\/MBEhkzV4LU via @ce_pro",
  "id" : 786728047689039872,
  "created_at" : "2016-10-14 00:39:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/yrW7tCG2mK",
      "expanded_url" : "http:\/\/techomebuilder.com\/emagazine-articles-1\/home-automation\/5-things-to-know-about-whole-house-surge-protection",
      "display_url" : "techomebuilder.com\/emagazine-arti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786727694901866496",
  "text" : "5 Things to Know About Whole House Surge Protection https:\/\/t.co\/yrW7tCG2mK",
  "id" : 786727694901866496,
  "created_at" : "2016-10-14 00:37:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/mGAJkhqnGe",
      "expanded_url" : "http:\/\/www.usa.philips.com\/",
      "display_url" : "usa.philips.com"
    } ]
  },
  "geo" : { },
  "id_str" : "786726097870262272",
  "text" : "https:\/\/t.co\/mGAJkhqnGe !930's I think for your surge protector.",
  "id" : 786726097870262272,
  "created_at" : "2016-10-14 00:31:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/iCUCMEngYi",
      "expanded_url" : "http:\/\/www.wmur.com\/article\/fire-reported-at-purple-urchin-restaurant-at-hampton-beach\/5493429",
      "display_url" : "wmur.com\/article\/fire-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786725287706890240",
  "text" : "Short circuit causes fire at Purple Urchin restaurant at Hampton Beach https:\/\/t.co\/iCUCMEngYi",
  "id" : 786725287706890240,
  "created_at" : "2016-10-14 00:28:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786724858583478272",
  "text" : "The land lord said all of the electrical in new.",
  "id" : 786724858583478272,
  "created_at" : "2016-10-14 00:26:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786724536184082433",
  "text" : "Enemies of a PC? Dust and Heat.",
  "id" : 786724536184082433,
  "created_at" : "2016-10-14 00:25:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/lvfHCJYpnA",
      "expanded_url" : "https:\/\/www.technologyreview.com\/s\/510471\/getting-to-bono-a-cover-history\/#",
      "display_url" : "technologyreview.com\/s\/510471\/getti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786723865892417536",
  "text" : "https:\/\/t.co\/lvfHCJYpnA Getting to Bono M.I.T Cover story.",
  "id" : 786723865892417536,
  "created_at" : "2016-10-14 00:22:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786722633400320001",
  "text" : "Sony needs to get the Blu-Ray working and HP the touch screen I'll help if it is open.",
  "id" : 786722633400320001,
  "created_at" : "2016-10-14 00:17:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786722134378905601",
  "text" : "My Dell is 8 years old and I just upgraded to FreeBSD 11.0 with a base image of 7.x. I will so you how to make a USB installer.",
  "id" : 786722134378905601,
  "created_at" : "2016-10-14 00:15:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786720372385320960",
  "text" : "And cops I've had it with these sirens too. I am giving these people what the need to know. Control yourself everyone.",
  "id" : 786720372385320960,
  "created_at" : "2016-10-14 00:08:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786718413142056960",
  "text" : "There will always be a company and I hope original ones at least with a standard or two. I really don't want a company. I'm just one person.",
  "id" : 786718413142056960,
  "created_at" : "2016-10-14 00:01:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/fPabSrrGHJ",
      "expanded_url" : "https:\/\/archive.org\/details\/ATTUNIXSystemVRelease4Version2",
      "display_url" : "archive.org\/details\/ATTUNI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786717479938715652",
  "text" : "https:\/\/t.co\/fPabSrrGHJ System V source.",
  "id" : 786717479938715652,
  "created_at" : "2016-10-13 23:57:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/RlfAGutCgj",
      "expanded_url" : "https:\/\/winworldpc.com\/download\/4061DCDB-18DA-11E4-99E5-7054D21A8599",
      "display_url" : "winworldpc.com\/download\/4061D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786717076257968128",
  "text" : "https:\/\/t.co\/RlfAGutCgj Here's System V.",
  "id" : 786717076257968128,
  "created_at" : "2016-10-13 23:55:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/XbUlD9oPDY",
      "expanded_url" : "https:\/\/www.freebsd.org\/doc\/en_US.ISO8859-1\/articles\/explaining-bsd\/what-a-real-unix.html",
      "display_url" : "freebsd.org\/doc\/en_US.ISO8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786714574250803201",
  "text" : "https:\/\/t.co\/XbUlD9oPDY A real UNIX FreeBSD.",
  "id" : 786714574250803201,
  "created_at" : "2016-10-13 23:45:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786714140308045824",
  "text" : "Just make sure it builds on a BSD POSIX compatible. I am.",
  "id" : 786714140308045824,
  "created_at" : "2016-10-13 23:44:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 67, 75 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/bycNqEhrpI",
      "expanded_url" : "https:\/\/youtu.be\/vYNM7aronA8",
      "display_url" : "youtu.be\/vYNM7aronA8"
    } ]
  },
  "geo" : { },
  "id_str" : "786711585255485440",
  "text" : "20 - U2 - Lemon (ZOO TV - Sydney 1993) https:\/\/t.co\/bycNqEhrpI via @YouTube",
  "id" : 786711585255485440,
  "created_at" : "2016-10-13 23:33:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786711110401527809",
  "text" : "The history book are already written Apple.",
  "id" : 786711110401527809,
  "created_at" : "2016-10-13 23:31:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/TlsT9i7YIc",
      "expanded_url" : "https:\/\/developer.apple.com\/library\/content\/documentation\/Darwin\/Conceptual\/KernelProgramming\/BSD\/BSD.html",
      "display_url" : "developer.apple.com\/library\/conten\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786710469750951936",
  "text" : "https:\/\/t.co\/TlsT9i7YIc Stop Lying Apple on Wikipedia.",
  "id" : 786710469750951936,
  "created_at" : "2016-10-13 23:29:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "InfoWorld",
      "screen_name" : "infoworld",
      "indices" : [ 58, 68 ],
      "id_str" : "15426758",
      "id" : 15426758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/LpCOwWqcaP",
      "expanded_url" : "http:\/\/www.infoworld.com\/article\/2621410\/operating-systems\/why-aren-t-you-using-freebsd-.html",
      "display_url" : "infoworld.com\/article\/262141\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786708649968177152",
  "text" : "Why aren't you using FreeBSD? https:\/\/t.co\/LpCOwWqcaP via @infoworld",
  "id" : 786708649968177152,
  "created_at" : "2016-10-13 23:22:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Healthline",
      "screen_name" : "Healthline",
      "indices" : [ 73, 84 ],
      "id_str" : "14985126",
      "id" : 14985126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/JDXqCVhUU8",
      "expanded_url" : "http:\/\/www.healthline.com\/health\/high-blood-pressure-hypertension\/lower-it-fast",
      "display_url" : "healthline.com\/health\/high-bl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786707885581565953",
  "text" : "6 Tips for Lowering Your Blood Pressure Fast https:\/\/t.co\/JDXqCVhUU8 via @healthline I'm trying to tell my dad to watch less TV as read too.",
  "id" : 786707885581565953,
  "created_at" : "2016-10-13 23:19:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786706243121537026",
  "text" : "Linus all we really need from you is the kernel. and maybe the synaptic package manager.",
  "id" : 786706243121537026,
  "created_at" : "2016-10-13 23:12:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/QrkM94aq3i",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Shared_Source_Common_Language_Infrastructure",
      "display_url" : "en.wikipedia.org\/wiki\/Shared_So\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786704184804536320",
  "text" : "https:\/\/t.co\/QrkM94aq3i I built this for FreeBSD in 2003.",
  "id" : 786704184804536320,
  "created_at" : "2016-10-13 23:04:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/CuR0PMsMAw",
      "expanded_url" : "http:\/\/codinggorilla.domemtech.com\/?p=1499",
      "display_url" : "codinggorilla.domemtech.com\/?p=1499"
    } ]
  },
  "geo" : { },
  "id_str" : "786703583555231744",
  "text" : "https:\/\/t.co\/CuR0PMsMAw I am saying Mono Microsoft they really have done a good job with the Common Lang. Infst.",
  "id" : 786703583555231744,
  "created_at" : "2016-10-13 23:02:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 57, 65 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/kdG15foPV0",
      "expanded_url" : "https:\/\/youtu.be\/vOa--Dhu11M",
      "display_url" : "youtu.be\/vOa--Dhu11M"
    } ]
  },
  "geo" : { },
  "id_str" : "786701536646889472",
  "text" : "Radiohead - I Might Be Wrong https:\/\/t.co\/kdG15foPV0 via @YouTube",
  "id" : 786701536646889472,
  "created_at" : "2016-10-13 22:53:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786700053448646656",
  "text" : "If it is written in C\/C++ you will have to link the Microsoft C\/C++ runtime libraries with cygwin. I think they teach you howin the OpenJDK.",
  "id" : 786700053448646656,
  "created_at" : "2016-10-13 22:48:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/2769EA6gMD",
      "expanded_url" : "https:\/\/www.cygwin.com\/",
      "display_url" : "cygwin.com"
    } ]
  },
  "geo" : { },
  "id_str" : "786698686927605760",
  "text" : "https:\/\/t.co\/2769EA6gMD See POSIX compatible.",
  "id" : 786698686927605760,
  "created_at" : "2016-10-13 22:42:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/0mXN13xu3J",
      "expanded_url" : "https:\/\/github.com\/mono\/monoskel-gapi",
      "display_url" : "github.com\/mono\/monoskel-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786697342435135488",
  "text" : "https:\/\/t.co\/0mXN13xu3J Autotools in C#.",
  "id" : 786697342435135488,
  "created_at" : "2016-10-13 22:37:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/lYa9dRcGnu",
      "expanded_url" : "https:\/\/developer.gnome.org\/anjuta-build-tutorial\/stable\/create-autotools.html.en",
      "display_url" : "developer.gnome.org\/anjuta-build-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786696315673673728",
  "text" : "https:\/\/t.co\/lYa9dRcGnu Autotools on Gnome.",
  "id" : 786696315673673728,
  "created_at" : "2016-10-13 22:33:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786520291640041472",
  "text" : "Maybe I shouldn't tell you all I know without a wife it does just leave me depressed.",
  "id" : 786520291640041472,
  "created_at" : "2016-10-13 10:53:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786388574916620288",
  "text" : "You get paid but you suck goodnight.",
  "id" : 786388574916620288,
  "created_at" : "2016-10-13 02:10:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/vilrLLCqwP",
      "expanded_url" : "https:\/\/visualstudiogallery.msdn.microsoft.com\/c89ff880-8509-47a4-a262-e4fa07168408",
      "display_url" : "visualstudiogallery.msdn.microsoft.com\/c89ff880-8509-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786388235203162113",
  "text" : "QtPackage : https:\/\/t.co\/vilrLLCqwP",
  "id" : 786388235203162113,
  "created_at" : "2016-10-13 02:09:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/6Dkt5HosrO",
      "expanded_url" : "https:\/\/visualstudiogallery.msdn.microsoft.com\/ee6e6d8c-c837-41fb-886a-6b50ae2d06a2",
      "display_url" : "visualstudiogallery.msdn.microsoft.com\/ee6e6d8c-c837-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786387569298722816",
  "text" : "Web Essentials 2015.3 : https:\/\/t.co\/6Dkt5HosrO",
  "id" : 786387569298722816,
  "created_at" : "2016-10-13 02:06:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/HcPUeGhS1L",
      "expanded_url" : "https:\/\/visualstudiogallery.msdn.microsoft.com\/68c1575b-e0bf-420d-a94b-1b0f4bcdcbcc",
      "display_url" : "visualstudiogallery.msdn.microsoft.com\/68c1575b-e0bf-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786385378928304128",
  "text" : "Refactoring Essentials for Visual Studio : https:\/\/t.co\/HcPUeGhS1L",
  "id" : 786385378928304128,
  "created_at" : "2016-10-13 01:57:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786385206437552128",
  "text" : "How to Solve it by Computer",
  "id" : 786385206437552128,
  "created_at" : "2016-10-13 01:56:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786382942134075392",
  "text" : "I am reading Princeton's \"How to solve it\" and Oxford Press's 'Unfair to genius'.",
  "id" : 786382942134075392,
  "created_at" : "2016-10-13 01:47:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/X6iGFnBw8g",
      "expanded_url" : "http:\/\/serendip.brynmawr.edu\/exchange\/story-evolution-and-evolution-stories-evolit\/why-movie-never-good-book",
      "display_url" : "serendip.brynmawr.edu\/exchange\/story\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786382423114158081",
  "text" : "https:\/\/t.co\/X6iGFnBw8g The movie is never good as the book Neanderthal men and hot women.",
  "id" : 786382423114158081,
  "created_at" : "2016-10-13 01:45:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/NM7pncEo33",
      "expanded_url" : "http:\/\/imgur.com\/COEo6pz",
      "display_url" : "imgur.com\/COEo6pz"
    } ]
  },
  "geo" : { },
  "id_str" : "786381270783660033",
  "text" : "The cure to ADHD https:\/\/t.co\/NM7pncEo33",
  "id" : 786381270783660033,
  "created_at" : "2016-10-13 01:41:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/JjvK09HXVf",
      "expanded_url" : "http:\/\/www.healthyplace.com\/adhd\/adhd-children\/adhd-cure-is-there-a-cure-for-add\/",
      "display_url" : "healthyplace.com\/adhd\/adhd-chil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786380479620485120",
  "text" : "https:\/\/t.co\/JjvK09HXVf ADHD Cure: Is There a Cure for ADD?",
  "id" : 786380479620485120,
  "created_at" : "2016-10-13 01:38:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786379691947008001",
  "text" : "Maybe some news networks can partner with NBC or Comcast or some of the other ISP's",
  "id" : 786379691947008001,
  "created_at" : "2016-10-13 01:35:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/03mVHqfbMx",
      "expanded_url" : "http:\/\/corporate.comcast.com\/news-information\/news-feed\/nbcuniversal-news-group-announces-strategic-investment-content-partnership-with-revere-digital",
      "display_url" : "corporate.comcast.com\/news-informati\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786379036607913984",
  "text" : "https:\/\/t.co\/03mVHqfbMx NBC partners with re\/code.",
  "id" : 786379036607913984,
  "created_at" : "2016-10-13 01:32:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/VU6Zhj68ff",
      "expanded_url" : "https:\/\/www.quora.com\/Why-are-some-white-women-attracted-to-only-black-men",
      "display_url" : "quora.com\/Why-are-some-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786376436336566272",
  "text" : "https:\/\/t.co\/VU6Zhj68ff They do deserve each other they both steal and cheat.",
  "id" : 786376436336566272,
  "created_at" : "2016-10-13 01:22:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Bank",
      "screen_name" : "WorldBank",
      "indices" : [ 3, 13 ],
      "id_str" : "27860681",
      "id" : 27860681
    }, {
      "name" : "infoDev",
      "screen_name" : "infoDev",
      "indices" : [ 104, 112 ],
      "id_str" : "18968956",
      "id" : 18968956
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SMEs",
      "indices" : [ 58, 63 ]
    }, {
      "text" : "growth",
      "indices" : [ 73, 80 ]
    }, {
      "text" : "GWoctober",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786375774106361857",
  "text" : "RT @WorldBank: Watch LIVE10\/13 at 11AM ET: How to promote #SMEs to drive #growth. Join the discussion w\/@infoDev #GWoctober https:\/\/t.co\/KV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "infoDev",
        "screen_name" : "infoDev",
        "indices" : [ 89, 97 ],
        "id_str" : "18968956",
        "id" : 18968956
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WorldBank\/status\/786371061722013696\/photo\/1",
        "indices" : [ 133, 156 ],
        "url" : "https:\/\/t.co\/rncz2FByNG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CunAT55WgAAj1G1.jpg",
        "id_str" : "786371058144280576",
        "id" : 786371058144280576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CunAT55WgAAj1G1.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/rncz2FByNG"
      } ],
      "hashtags" : [ {
        "text" : "SMEs",
        "indices" : [ 43, 48 ]
      }, {
        "text" : "growth",
        "indices" : [ 58, 65 ]
      }, {
        "text" : "GWoctober",
        "indices" : [ 98, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/KV72FFAE3y",
        "expanded_url" : "http:\/\/wrld.bg\/Hw943057ydU",
        "display_url" : "wrld.bg\/Hw943057ydU"
      } ]
    },
    "geo" : { },
    "id_str" : "786371061722013696",
    "text" : "Watch LIVE10\/13 at 11AM ET: How to promote #SMEs to drive #growth. Join the discussion w\/@infoDev #GWoctober https:\/\/t.co\/KV72FFAE3y https:\/\/t.co\/rncz2FByNG",
    "id" : 786371061722013696,
    "created_at" : "2016-10-13 01:00:45 +0000",
    "user" : {
      "name" : "World Bank",
      "screen_name" : "WorldBank",
      "protected" : false,
      "id_str" : "27860681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725323426588688385\/elPT0mkW_normal.jpg",
      "id" : 27860681,
      "verified" : true
    }
  },
  "id" : 786375774106361857,
  "created_at" : "2016-10-13 01:19:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786375110898831360",
  "text" : "ABC it isn't always the men.",
  "id" : 786375110898831360,
  "created_at" : "2016-10-13 01:16:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 91, 95 ],
      "id_str" : "28785486",
      "id" : 28785486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/LRLOZlARwX",
      "expanded_url" : "http:\/\/abcnews.go.com\/Health\/scientists-discover-gene-responsible-cheating-promiscuous-sex-habits\/story?id=12322891",
      "display_url" : "abcnews.go.com\/Health\/scienti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786374500761804800",
  "text" : "Thrill-Seeking Gene Can Lead to More Sex Partners - ABC News - https:\/\/t.co\/LRLOZlARwX via @ABC",
  "id" : 786374500761804800,
  "created_at" : "2016-10-13 01:14:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/1sJp0lCcEh",
      "expanded_url" : "http:\/\/fw.to\/azph9dQ",
      "display_url" : "fw.to\/azph9dQ"
    } ]
  },
  "geo" : { },
  "id_str" : "786373920895008768",
  "text" : "Giving up on Trump? Ryan shifts focus to saving GOP majority in Congress https:\/\/t.co\/1sJp0lCcEh",
  "id" : 786373920895008768,
  "created_at" : "2016-10-13 01:12:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/vOJcTugpjW",
      "expanded_url" : "http:\/\/www.theatlantic.com\/health\/archive\/2014\/09\/exercise-seems-to-be-beneficial-to-children\/380844\/",
      "display_url" : "theatlantic.com\/health\/archive\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786373491532533760",
  "text" : "Exercise Is ADHD Medication https:\/\/t.co\/vOJcTugpjW IDK Yet.",
  "id" : 786373491532533760,
  "created_at" : "2016-10-13 01:10:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/ekScOaW4xg",
      "expanded_url" : "https:\/\/twitter.com\/thegooglecar\/status\/786363860013821952",
      "display_url" : "twitter.com\/thegooglecar\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786370563337953281",
  "text" : "Everyone just move off of the islands. I know they are pretty but scientists need funding to stop them. https:\/\/t.co\/ekScOaW4xg",
  "id" : 786370563337953281,
  "created_at" : "2016-10-13 00:58:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786369390228885504",
  "text" : "Women see your shrink and he\/she might perscribe you something for cheating.",
  "id" : 786369390228885504,
  "created_at" : "2016-10-13 00:54:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/xOu527LsUM",
      "expanded_url" : "http:\/\/www.nature.com\/mp\/journal\/v3\/n1\/abs\/4000354a.html",
      "display_url" : "nature.com\/mp\/journal\/v3\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786368951773044736",
  "text" : "https:\/\/t.co\/xOu527LsUM ABC you had it in 2010 it is on my Facebook and it is the DRD4 gene.",
  "id" : 786368951773044736,
  "created_at" : "2016-10-13 00:52:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/Iy7n3RcWeE",
      "expanded_url" : "http:\/\/nyti.ms\/1BgMxEz",
      "display_url" : "nyti.ms\/1BgMxEz"
    } ]
  },
  "geo" : { },
  "id_str" : "786368225072197632",
  "text" : "Infidelity Lurks in Your Genes https:\/\/t.co\/Iy7n3RcWeE",
  "id" : 786368225072197632,
  "created_at" : "2016-10-13 00:49:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786367057231175680",
  "text" : "I ma just give her a kid and say goodbye too.",
  "id" : 786367057231175680,
  "created_at" : "2016-10-13 00:44:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Women in the World",
      "screen_name" : "WomenintheWorld",
      "indices" : [ 124, 140 ],
      "id_str" : "120153772",
      "id" : 120153772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/5w7SpNxOlQ",
      "expanded_url" : "http:\/\/nytlive.nytimes.com\/womenintheworld\/2016\/08\/22\/scientists-say-women-are-genetically-programmed-to-have-affairs-its-like-mate-insurance\/",
      "display_url" : "nytlive.nytimes.com\/womenintheworl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786366590002434048",
  "text" : "Scientists say women are 'genetically programmed to have affairs' -- it's like 'mate insurance' https:\/\/t.co\/5w7SpNxOlQ via @WomenintheWorld",
  "id" : 786366590002434048,
  "created_at" : "2016-10-13 00:42:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786366234656804865",
  "text" : "I'm smart and want a 25 year old hot good girl is that so bad? I know I won't be able to trust her.",
  "id" : 786366234656804865,
  "created_at" : "2016-10-13 00:41:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786365548959453184",
  "text" : "These women just want men to be dumb slaves and I'm not.",
  "id" : 786365548959453184,
  "created_at" : "2016-10-13 00:38:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786364980614483968",
  "text" : "I would share 'instead' Marone not trigger warning. you are bit of a feminist and it's not really queer culture either.",
  "id" : 786364980614483968,
  "created_at" : "2016-10-13 00:36:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786359395332395008",
  "text" : "I do like most of the open source programs they just aren't all original..",
  "id" : 786359395332395008,
  "created_at" : "2016-10-13 00:14:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786358774483161088",
  "text" : "Attached the new monitor and I would like to get the touch screen working on BSD.It is a nice HP touchscreen. Everything is working.",
  "id" : 786358774483161088,
  "created_at" : "2016-10-13 00:11:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seattlepi",
      "screen_name" : "seattlepi",
      "indices" : [ 86, 96 ],
      "id_str" : "10648962",
      "id" : 10648962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/d3CeerWk6r",
      "expanded_url" : "http:\/\/www.seattlepi.com\/local\/article\/Gates-estate-staff-member-sentenced-for-child-6344956.php?cmpid=twitter-desktop",
      "display_url" : "seattlepi.com\/local\/article\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786353719906447360",
  "text" : "Gates employee sentenced for child pornography collection https:\/\/t.co\/d3CeerWk6r via @seattlepi",
  "id" : 786353719906447360,
  "created_at" : "2016-10-12 23:51:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 65, 73 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/4ApKJMfnuJ",
      "expanded_url" : "https:\/\/youtu.be\/diIVUe2lKII",
      "display_url" : "youtu.be\/diIVUe2lKII"
    } ]
  },
  "geo" : { },
  "id_str" : "786351716622938112",
  "text" : "Hail to the Thief 8-bit [Full Album] https:\/\/t.co\/4ApKJMfnuJ via @YouTube",
  "id" : 786351716622938112,
  "created_at" : "2016-10-12 23:43:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786351168620421120",
  "text" : "uname -a FreeBSD 11.0 Release I'm eating a late dinner. You corporate child molester and culture thief.",
  "id" : 786351168620421120,
  "created_at" : "2016-10-12 23:41:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786350663554863105",
  "text" : "The dock doesn't have a maintainer, does everyone want to work for fucking Apple. Apple stole BSD you know.",
  "id" : 786350663554863105,
  "created_at" : "2016-10-12 23:39:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786348373402001409",
  "text" : "I may have to remove opencl 2.0 and just use openmp.",
  "id" : 786348373402001409,
  "created_at" : "2016-10-12 23:30:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786347675796942848",
  "text" : "installing texmf then almost done.",
  "id" : 786347675796942848,
  "created_at" : "2016-10-12 23:27:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786344116128915456",
  "text" : "I hope I don't have to build the dock from source again after the pkg upgrade.",
  "id" : 786344116128915456,
  "created_at" : "2016-10-12 23:13:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786342027520712704",
  "text" : "pkg autoremove - removes orphan packages",
  "id" : 786342027520712704,
  "created_at" : "2016-10-12 23:05:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786340875169243136",
  "text" : "I really don't know about natural gas in cars Fiat.",
  "id" : 786340875169243136,
  "created_at" : "2016-10-12 23:00:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786340156685094916",
  "text" : "4 GB package upgrade then my last freebsd-update.",
  "id" : 786340156685094916,
  "created_at" : "2016-10-12 22:57:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786339038517088256",
  "text" : "No the monitor is going bad. Had an 8 year run. No worries I have a new touch screen monitor.",
  "id" : 786339038517088256,
  "created_at" : "2016-10-12 22:53:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786336466058084352",
  "text" : "I got a feeling? Everyone like you wanna be free and go out because you accomplished something or had a little success? Sit.",
  "id" : 786336466058084352,
  "created_at" : "2016-10-12 22:43:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/vQQ34A0Bbs",
      "expanded_url" : "https:\/\/twitter.com\/TheEconomist\/status\/786335385773277190",
      "display_url" : "twitter.com\/TheEconomist\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786335803769249792",
  "text" : "I use one tank of fuel a month in my car. And my 2004 car only has 74,000 miles on it. https:\/\/t.co\/vQQ34A0Bbs",
  "id" : 786335803769249792,
  "created_at" : "2016-10-12 22:40:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Zvb6duHNmt",
      "expanded_url" : "https:\/\/www.freebsd.org\/releases\/11.0R\/installation.html#upgrade",
      "display_url" : "freebsd.org\/releases\/11.0R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786335532351565824",
  "text" : "https:\/\/t.co\/Zvb6duHNmt. Use freebsd-update.",
  "id" : 786335532351565824,
  "created_at" : "2016-10-12 22:39:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786332071614640130",
  "text" : "You'll learn kid, but I do deserve your wife don't I?",
  "id" : 786332071614640130,
  "created_at" : "2016-10-12 22:25:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786331171001016321",
  "text" : "The old monitor seems fine now I have a new one in case I need one.",
  "id" : 786331171001016321,
  "created_at" : "2016-10-12 22:22:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786329333694619648",
  "text" : "Play NIN's Echoplex.",
  "id" : 786329333694619648,
  "created_at" : "2016-10-12 22:14:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bloomberg Markets",
      "screen_name" : "markets",
      "indices" : [ 92, 100 ],
      "id_str" : "69620713",
      "id" : 69620713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/RIHt3lFDSv",
      "expanded_url" : "http:\/\/bloom.bg\/2dSDNSn",
      "display_url" : "bloom.bg\/2dSDNSn"
    } ]
  },
  "geo" : { },
  "id_str" : "786328796089622529",
  "text" : "Wells Fargo CEO Stumpf Steps down in fallout from fake accounts https:\/\/t.co\/RIHt3lFDSv via @markets",
  "id" : 786328796089622529,
  "created_at" : "2016-10-12 22:12:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786327546031767552",
  "text" : "I've upgraded to FreeBSD 11.0 Release my base image was 7.x and I've added a new monitor and did a package upgrade.",
  "id" : 786327546031767552,
  "created_at" : "2016-10-12 22:07:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/DJdxAXfqlf",
      "expanded_url" : "http:\/\/hackeducation.com\/2011\/10\/08\/steve-jobs-apple-and-the-failure-of-education-technology",
      "display_url" : "hackeducation.com\/2011\/10\/08\/ste\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786320375437144065",
  "text" : "https:\/\/t.co\/DJdxAXfqlf Steve Jobs, Apple, and the Failure of Education Technology.",
  "id" : 786320375437144065,
  "created_at" : "2016-10-12 21:39:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786319542188400640",
  "text" : "I've had my Dell 8 years and I'm upgrading it to FreeBSD 11.0 sometime this week.",
  "id" : 786319542188400640,
  "created_at" : "2016-10-12 21:36:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/5lvgvgwGR9",
      "expanded_url" : "https:\/\/support.microsoft.com\/en-us\/help\/13853\/windows-lifecycle-fact-sheet",
      "display_url" : "support.microsoft.com\/en-us\/help\/138\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786316425212276736",
  "text" : "https:\/\/t.co\/5lvgvgwGR9 Software just may be a PhD course to me by 2023. Microsoft. If you make me buy another machine ever 3 years.",
  "id" : 786316425212276736,
  "created_at" : "2016-10-12 21:23:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KTLA",
      "screen_name" : "KTLA",
      "indices" : [ 104, 109 ],
      "id_str" : "10252962",
      "id" : 10252962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/uqkB5TP8Sx",
      "expanded_url" : "http:\/\/on.ktla.com\/D35mh",
      "display_url" : "on.ktla.com\/D35mh"
    } ]
  },
  "geo" : { },
  "id_str" : "786314969662894080",
  "text" : "Microsoft Will Give You A Free PC If They Can't Upgrade Yours to Windows 10 https:\/\/t.co\/uqkB5TP8Sx via @ktla",
  "id" : 786314969662894080,
  "created_at" : "2016-10-12 21:17:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786311894932058112",
  "text" : "I do have every version of Windows with some Beta's been here since '84",
  "id" : 786311894932058112,
  "created_at" : "2016-10-12 21:05:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786310694379491329",
  "text" : "Oh no BBC get on terror over pussy.",
  "id" : 786310694379491329,
  "created_at" : "2016-10-12 21:00:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786310097177686016",
  "text" : "And I do have Windows 10 Enterprise LTBS and I'm gay, I mean happy not a homosexual.",
  "id" : 786310097177686016,
  "created_at" : "2016-10-12 20:58:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WDYM",
      "indices" : [ 30, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/WgiRGK1a4z",
      "expanded_url" : "https:\/\/twitter.com\/i\/live\/783805218228088832",
      "display_url" : "twitter.com\/i\/live\/7838052\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786308821907931136",
  "text" : "Watch live! \"What'd You Miss\" #WDYM https:\/\/t.co\/WgiRGK1a4z",
  "id" : 786308821907931136,
  "created_at" : "2016-10-12 20:53:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786307988093100032",
  "text" : "That 25 year old that I want may be 75 and feeble when I die. She'll be wishing she were dead too.",
  "id" : 786307988093100032,
  "created_at" : "2016-10-12 20:50:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786306688831803392",
  "text" : "I download Windows Server 2016 Server Data Center Edition from my MSDN subscription I wanted something new.",
  "id" : 786306688831803392,
  "created_at" : "2016-10-12 20:44:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786302088523505664",
  "text" : "Waiting for the equipment of mine to get old? You've succeed. My iPad isn't getting any more updates.",
  "id" : 786302088523505664,
  "created_at" : "2016-10-12 20:26:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/y70HKaMQVI",
      "expanded_url" : "https:\/\/www.ncbi.nlm.nih.gov\/pubmed\/12496735",
      "display_url" : "ncbi.nlm.nih.gov\/pubmed\/12496735"
    } ]
  },
  "geo" : { },
  "id_str" : "786301007164649472",
  "text" : "Marriage: an evolutionary perspective. - PubMed - NCBI https:\/\/t.co\/y70HKaMQVI It may say taller but we now know they don't live as long.",
  "id" : 786301007164649472,
  "created_at" : "2016-10-12 20:22:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786299418655940608",
  "text" : "I'm unliking 'Brain pickings' on Facebook.",
  "id" : 786299418655940608,
  "created_at" : "2016-10-12 20:16:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786298118950170624",
  "text" : "I have to talk about tuition for the Gifted Program at the university of Connecticut next week they what me to apply.",
  "id" : 786298118950170624,
  "created_at" : "2016-10-12 20:10:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/g7J1yHCrI1",
      "expanded_url" : "https:\/\/twitter.com\/guardian\/status\/786296848877223937",
      "display_url" : "twitter.com\/guardian\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786297250183942144",
  "text" : "Eat. https:\/\/t.co\/g7J1yHCrI1",
  "id" : 786297250183942144,
  "created_at" : "2016-10-12 20:07:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786296969295572992",
  "text" : "I also took a Basis today.",
  "id" : 786296969295572992,
  "created_at" : "2016-10-12 20:06:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786296340074467328",
  "text" : "I just got off of a conference call with the W3C.",
  "id" : 786296340074467328,
  "created_at" : "2016-10-12 20:03:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBM Research",
      "screen_name" : "IBMResearch",
      "indices" : [ 3, 15 ],
      "id_str" : "16319797",
      "id" : 16319797
    }, {
      "name" : "IQC",
      "screen_name" : "QuantumIQC",
      "indices" : [ 29, 40 ],
      "id_str" : "39522998",
      "id" : 39522998
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QuantumExperience",
      "indices" : [ 50, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786294930213777409",
  "text" : "RT @IBMResearch: Students at @QuantumIQC used the #QuantumExperience to test algorithms they learned from IBMer Sarah Sheldon https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/percolate.com\" rel=\"nofollow\"\u003EPercolate\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IQC",
        "screen_name" : "QuantumIQC",
        "indices" : [ 12, 23 ],
        "id_str" : "39522998",
        "id" : 39522998
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "QuantumExperience",
        "indices" : [ 33, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/n7oZ04dgzJ",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=HleHktccO3E",
        "display_url" : "youtube.com\/watch?v=HleHkt\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "786294629813526528",
    "text" : "Students at @QuantumIQC used the #QuantumExperience to test algorithms they learned from IBMer Sarah Sheldon https:\/\/t.co\/n7oZ04dgzJ",
    "id" : 786294629813526528,
    "created_at" : "2016-10-12 19:57:03 +0000",
    "user" : {
      "name" : "IBM Research",
      "screen_name" : "IBMResearch",
      "protected" : false,
      "id_str" : "16319797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2453018418\/fn1i02hac59i02ccd9c1_normal.jpeg",
      "id" : 16319797,
      "verified" : true
    }
  },
  "id" : 786294930213777409,
  "created_at" : "2016-10-12 19:58:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/kms7epgVDQ",
      "expanded_url" : "http:\/\/bigthink.com\/robby-berman\/enjoy-your-friends-and-be-glad-youre-not-a-genius",
      "display_url" : "bigthink.com\/robby-berman\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786294856704364545",
  "text" : "https:\/\/t.co\/kms7epgVDQ Enjoy Your Friends and Be Glad You\u2019re Not a Genius.",
  "id" : 786294856704364545,
  "created_at" : "2016-10-12 19:57:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786294029453361152",
  "text" : "When I see a profile picture I do expect to just see you or your avatar. Can't wait for Avatar 2.",
  "id" : 786294029453361152,
  "created_at" : "2016-10-12 19:54:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786289589480632320",
  "text" : "It's getting late the gullible nice pills are beginning to wear off I am the better man aren't I?",
  "id" : 786289589480632320,
  "created_at" : "2016-10-12 19:37:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/aBsSWuqmsA",
      "expanded_url" : "https:\/\/twitter.com\/amazon\/status\/786274238458109952",
      "display_url" : "twitter.com\/amazon\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786288578473005056",
  "text" : "I wish Amazon had this in SWVA. https:\/\/t.co\/aBsSWuqmsA",
  "id" : 786288578473005056,
  "created_at" : "2016-10-12 19:33:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raghavendrachari",
      "screen_name" : "raghavendrak08",
      "indices" : [ 3, 18 ],
      "id_str" : "2441795318",
      "id" : 2441795318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786287901340348416",
  "text" : "RT @raghavendrak08: Checking out \"As a software engineer, what's the best skill set to have for th\" on Data Science Central: https:\/\/t.co\/X\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/XDk8z5dkQw",
        "expanded_url" : "http:\/\/www.datasciencecentral.com\/forum\/topics\/as-a-software-engineer-what-s-the-best-skill-set-to-have-for-the-",
        "display_url" : "datasciencecentral.com\/forum\/topics\/a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "786195689365647361",
    "text" : "Checking out \"As a software engineer, what's the best skill set to have for th\" on Data Science Central: https:\/\/t.co\/XDk8z5dkQw",
    "id" : 786195689365647361,
    "created_at" : "2016-10-12 13:23:53 +0000",
    "user" : {
      "name" : "raghavendrachari",
      "screen_name" : "raghavendrak08",
      "protected" : false,
      "id_str" : "2441795318",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636536028686249984\/6HGOixqT_normal.jpg",
      "id" : 2441795318,
      "verified" : false
    }
  },
  "id" : 786287901340348416,
  "created_at" : "2016-10-12 19:30:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/PTWUmaNunR",
      "expanded_url" : "http:\/\/www.beveragedaily.com\/Regulation-Safety\/US-court-dismisses-misleading-labeling-suit-against-Campbell-s-V8-V-Fusion-juice",
      "display_url" : "beveragedaily.com\/Regulation-Saf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786286768177881092",
  "text" : "https:\/\/t.co\/PTWUmaNunR I am having a V8 low sodium original.",
  "id" : 786286768177881092,
  "created_at" : "2016-10-12 19:25:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786284838462459904",
  "text" : "Kid don't even try to be a millionaire at 18 either it is about education.",
  "id" : 786284838462459904,
  "created_at" : "2016-10-12 19:18:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Propellerhead",
      "screen_name" : "PropellerheadSW",
      "indices" : [ 3, 19 ],
      "id_str" : "22631376",
      "id" : 22631376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786281823793926144",
  "text" : "RT @PropellerheadSW: Join the Parsec Song Challenge for a chance to win Parsec 2 + ALL Propellerhead-made Rack Extensions! Learn more: http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PropellerheadSW\/status\/786275754317385728\/photo\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/ugqzLfw8wA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CulpoX2WIAAGLZA.jpg",
        "id_str" : "786275752270503936",
        "id" : 786275752270503936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CulpoX2WIAAGLZA.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ugqzLfw8wA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/q68GlKvwSW",
        "expanded_url" : "http:\/\/buff.ly\/2dkkotD",
        "display_url" : "buff.ly\/2dkkotD"
      } ]
    },
    "geo" : { },
    "id_str" : "786275754317385728",
    "text" : "Join the Parsec Song Challenge for a chance to win Parsec 2 + ALL Propellerhead-made Rack Extensions! Learn more: https:\/\/t.co\/q68GlKvwSW https:\/\/t.co\/ugqzLfw8wA",
    "id" : 786275754317385728,
    "created_at" : "2016-10-12 18:42:02 +0000",
    "user" : {
      "name" : "Propellerhead",
      "screen_name" : "PropellerheadSW",
      "protected" : false,
      "id_str" : "22631376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558288234363367424\/qChNU38G_normal.png",
      "id" : 22631376,
      "verified" : true
    }
  },
  "id" : 786281823793926144,
  "created_at" : "2016-10-12 19:06:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/zaC1POgZo5",
      "expanded_url" : "https:\/\/twitter.com\/guardian\/status\/786275654199341056",
      "display_url" : "twitter.com\/guardian\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786281225820397568",
  "text" : "Trump I'm not that bad. https:\/\/t.co\/zaC1POgZo5",
  "id" : 786281225820397568,
  "created_at" : "2016-10-12 19:03:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincent Granville",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/HNHH0ZWHF1",
      "expanded_url" : "http:\/\/ow.ly\/EnwG304LYa4",
      "display_url" : "ow.ly\/EnwG304LYa4"
    } ]
  },
  "geo" : { },
  "id_str" : "786280981279887360",
  "text" : "RT @analyticbridge: Making the Most of Survey Research Data https:\/\/t.co\/HNHH0ZWHF1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/HNHH0ZWHF1",
        "expanded_url" : "http:\/\/ow.ly\/EnwG304LYa4",
        "display_url" : "ow.ly\/EnwG304LYa4"
      } ]
    },
    "geo" : { },
    "id_str" : "786276716138340353",
    "text" : "Making the Most of Survey Research Data https:\/\/t.co\/HNHH0ZWHF1",
    "id" : 786276716138340353,
    "created_at" : "2016-10-12 18:45:52 +0000",
    "user" : {
      "name" : "Vincent Granville",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729843251453140992\/SPucfBPm_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 786280981279887360,
  "created_at" : "2016-10-12 19:02:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786280690769760256",
  "text" : "I do have SOOO much more than what is in my \"build lab\" that I just haven't worked on in a couple of months.",
  "id" : 786280690769760256,
  "created_at" : "2016-10-12 19:01:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NAGC",
      "screen_name" : "NAGCGIFTED",
      "indices" : [ 3, 14 ],
      "id_str" : "52407188",
      "id" : 52407188
    }, {
      "name" : "Lisa Van Gemert",
      "screen_name" : "gifted_guru",
      "indices" : [ 110, 122 ],
      "id_str" : "251368748",
      "id" : 251368748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gifted",
      "indices" : [ 17, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786279855201488896",
  "text" : "RT @NAGCGIFTED: \"#Gifted is different, not better. Labeling is identification &amp; information, not destiny\" @gifted_guru https:\/\/t.co\/x2z9n2W\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lisa Van Gemert",
        "screen_name" : "gifted_guru",
        "indices" : [ 94, 106 ],
        "id_str" : "251368748",
        "id" : 251368748
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gifted",
        "indices" : [ 1, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/x2z9n2WqW0",
        "expanded_url" : "http:\/\/bit.ly\/2dcT8d8",
        "display_url" : "bit.ly\/2dcT8d8"
      } ]
    },
    "geo" : { },
    "id_str" : "786279596706500608",
    "text" : "\"#Gifted is different, not better. Labeling is identification &amp; information, not destiny\" @gifted_guru https:\/\/t.co\/x2z9n2WqW0",
    "id" : 786279596706500608,
    "created_at" : "2016-10-12 18:57:18 +0000",
    "user" : {
      "name" : "NAGC",
      "screen_name" : "NAGCGIFTED",
      "protected" : false,
      "id_str" : "52407188",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/290303861\/NAGC-logo-man-rgb_normal.jpg",
      "id" : 52407188,
      "verified" : false
    }
  },
  "id" : 786279855201488896,
  "created_at" : "2016-10-12 18:58:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786279806883155968",
  "text" : "And will this person know as much as me about the technology in this area probably not.",
  "id" : 786279806883155968,
  "created_at" : "2016-10-12 18:58:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786278780180369408",
  "text" : "I am choosing the market approach and I could use COCOMO models if they didn't want an inexpedient third party.",
  "id" : 786278780180369408,
  "created_at" : "2016-10-12 18:54:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/fbdVCVvcw2",
      "expanded_url" : "https:\/\/www.gnu.org\/philosophy\/why-free.en.html",
      "display_url" : "gnu.org\/philosophy\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786277999096107008",
  "text" : "https:\/\/t.co\/fbdVCVvcw2 This is a debate. Should Software have owners. I am written my own software.",
  "id" : 786277999096107008,
  "created_at" : "2016-10-12 18:50:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786277342205218816",
  "text" : "Hi Stallman. You don't want software to have owners do you? IDK.",
  "id" : 786277342205218816,
  "created_at" : "2016-10-12 18:48:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786276470054277120",
  "text" : "Tearing it all down you little high school terrorist? Can't keep it together? Work on it.",
  "id" : 786276470054277120,
  "created_at" : "2016-10-12 18:44:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786275730598473728",
  "text" : "I do just organize like DNS would .com, .net, .org, and .edu.",
  "id" : 786275730598473728,
  "created_at" : "2016-10-12 18:41:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786274149299658752",
  "text" : "The only problem you would run into is ownership of the technological intellectual property. You can have copies of the assets.",
  "id" : 786274149299658752,
  "created_at" : "2016-10-12 18:35:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/9atzixyqkv",
      "expanded_url" : "https:\/\/www.theguardian.com\/technology\/2016\/may\/20\/music-industry-battling-google-youtube-what-happens-next?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/technology\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786272716609294336",
  "text" : "Why is the music industry battling YouTube and what happens next? https:\/\/t.co\/9atzixyqkv",
  "id" : 786272716609294336,
  "created_at" : "2016-10-12 18:29:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 62, 70 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/xmTLUcFRTE",
      "expanded_url" : "https:\/\/youtu.be\/kVneUCY_Klw",
      "display_url" : "youtu.be\/kVneUCY_Klw"
    } ]
  },
  "geo" : { },
  "id_str" : "786272011962028034",
  "text" : "MP3 format, does it sound so bad? https:\/\/t.co\/xmTLUcFRTE via @YouTube",
  "id" : 786272011962028034,
  "created_at" : "2016-10-12 18:27:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UVA",
      "screen_name" : "UVA",
      "indices" : [ 3, 7 ],
      "id_str" : "1910771",
      "id" : 1910771
    }, {
      "name" : "Nichole M. Flores",
      "screen_name" : "nicholemflores",
      "indices" : [ 10, 25 ],
      "id_str" : "359354972",
      "id" : 359354972
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UVA",
      "indices" : [ 120, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786269939476803584",
  "text" : "RT @UVA: .@nicholemflores combines her interest in government, social justice and the Catholic Church as a professor at #UVA. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nichole M. Flores",
        "screen_name" : "nicholemflores",
        "indices" : [ 1, 16 ],
        "id_str" : "359354972",
        "id" : 359354972
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/UVA\/status\/786267146657509376\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/gjwqJeQ7Z2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CulhzCbWEAAbPlC.jpg",
        "id_str" : "786267139405647872",
        "id" : 786267139405647872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CulhzCbWEAAbPlC.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1520,
          "resize" : "fit",
          "w" : 2280
        } ],
        "display_url" : "pic.twitter.com\/gjwqJeQ7Z2"
      } ],
      "hashtags" : [ {
        "text" : "UVA",
        "indices" : [ 111, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/oN94m6HvQf",
        "expanded_url" : "http:\/\/ow.ly\/1UwD3056JXY",
        "display_url" : "ow.ly\/1UwD3056JXY"
      } ]
    },
    "geo" : { },
    "id_str" : "786267146657509376",
    "text" : ".@nicholemflores combines her interest in government, social justice and the Catholic Church as a professor at #UVA. https:\/\/t.co\/oN94m6HvQf https:\/\/t.co\/gjwqJeQ7Z2",
    "id" : 786267146657509376,
    "created_at" : "2016-10-12 18:07:50 +0000",
    "user" : {
      "name" : "UVA",
      "screen_name" : "UVA",
      "protected" : false,
      "id_str" : "1910771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459389985766907904\/hlr_iWeN_normal.png",
      "id" : 1910771,
      "verified" : true
    }
  },
  "id" : 786269939476803584,
  "created_at" : "2016-10-12 18:18:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mayo Clinic",
      "screen_name" : "MayoClinic",
      "indices" : [ 3, 14 ],
      "id_str" : "14592723",
      "id" : 14592723
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MayoClinic\/status\/786268957254844416\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Cdge2pnWsx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuljctDWIAQWMZB.jpg",
      "id_str" : "786268954733977604",
      "id" : 786268954733977604,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuljctDWIAQWMZB.jpg",
      "sizes" : [ {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Cdge2pnWsx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/pJ84eFhwdi",
      "expanded_url" : "http:\/\/mayocl.in\/2aOGdjK",
      "display_url" : "mayocl.in\/2aOGdjK"
    } ]
  },
  "geo" : { },
  "id_str" : "786269748342296576",
  "text" : "RT @MayoClinic: Proton beam therapy gives hope to patients with difficult-to-treat cancers. https:\/\/t.co\/pJ84eFhwdi https:\/\/t.co\/Cdge2pnWsx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MayoClinic\/status\/786268957254844416\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/Cdge2pnWsx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuljctDWIAQWMZB.jpg",
        "id_str" : "786268954733977604",
        "id" : 786268954733977604,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuljctDWIAQWMZB.jpg",
        "sizes" : [ {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/Cdge2pnWsx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/pJ84eFhwdi",
        "expanded_url" : "http:\/\/mayocl.in\/2aOGdjK",
        "display_url" : "mayocl.in\/2aOGdjK"
      } ]
    },
    "geo" : { },
    "id_str" : "786268957254844416",
    "text" : "Proton beam therapy gives hope to patients with difficult-to-treat cancers. https:\/\/t.co\/pJ84eFhwdi https:\/\/t.co\/Cdge2pnWsx",
    "id" : 786268957254844416,
    "created_at" : "2016-10-12 18:15:02 +0000",
    "user" : {
      "name" : "Mayo Clinic",
      "screen_name" : "MayoClinic",
      "protected" : false,
      "id_str" : "14592723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760454818422857728\/2WFm5vUI_normal.jpg",
      "id" : 14592723,
      "verified" : true
    }
  },
  "id" : 786269748342296576,
  "created_at" : "2016-10-12 18:18:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786269531832356866",
  "text" : "I've never done anything that bad just download a few torrents and impress women with my brain.",
  "id" : 786269531832356866,
  "created_at" : "2016-10-12 18:17:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/VRhhJX0OJq",
      "expanded_url" : "http:\/\/www.politico.com\/magazine\/story\/2015\/08\/how-google-could-rig-the-2016-election-121548.html",
      "display_url" : "politico.com\/magazine\/story\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786268151021309956",
  "text" : "How Google Could Rig the 2016 Election https:\/\/t.co\/VRhhJX0OJq",
  "id" : 786268151021309956,
  "created_at" : "2016-10-12 18:11:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/2Bor5kIufw",
      "expanded_url" : "http:\/\/org-www.festival-cannes.com\/en\/archives\/2004\/awardCompetition.html",
      "display_url" : "org-www.festival-cannes.com\/en\/archives\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786267058417700864",
  "text" : "https:\/\/t.co\/2Bor5kIufw 2004 Palme d'Or.",
  "id" : 786267058417700864,
  "created_at" : "2016-10-12 18:07:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elite Daily",
      "screen_name" : "EliteDaily",
      "indices" : [ 106, 117 ],
      "id_str" : "331057915",
      "id" : 331057915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/ial02cIRne",
      "expanded_url" : "http:\/\/elitedaily.com\/?p=853340",
      "display_url" : "elitedaily.com\/?p=853340"
    } ]
  },
  "geo" : { },
  "id_str" : "786265753716527104",
  "text" : "Why Legalizing Prostitution Would Make America Healthier, Wealthier And Safer https:\/\/t.co\/ial02cIRne via @EliteDaily",
  "id" : 786265753716527104,
  "created_at" : "2016-10-12 18:02:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT Tech Review",
      "screen_name" : "techreview",
      "indices" : [ 3, 14 ],
      "id_str" : "15808647",
      "id" : 15808647
    }, {
      "name" : "Natl Inst of Justice",
      "screen_name" : "OJPNIJ",
      "indices" : [ 111, 118 ],
      "id_str" : "950069113",
      "id" : 950069113
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "datascience",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/7lQ9XCkVhQ",
      "expanded_url" : "http:\/\/ow.ly\/dOVE3057fA0",
      "display_url" : "ow.ly\/dOVE3057fA0"
    } ]
  },
  "geo" : { },
  "id_str" : "786265478360539136",
  "text" : "RT @techreview: Are you up for the Crime Forecasting Challenge? - https:\/\/t.co\/7lQ9XCkVhQ (Partner content via @OJPNIJ) #datascience https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Natl Inst of Justice",
        "screen_name" : "OJPNIJ",
        "indices" : [ 95, 102 ],
        "id_str" : "950069113",
        "id" : 950069113
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/techreview\/status\/786263102123872256\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/S6DEU3dz89",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuleH3fWYAAVSoK.jpg",
        "id_str" : "786263099200397312",
        "id" : 786263099200397312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuleH3fWYAAVSoK.jpg",
        "sizes" : [ {
          "h" : 437,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 1401
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 1401
        }, {
          "h" : 772,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/S6DEU3dz89"
      } ],
      "hashtags" : [ {
        "text" : "datascience",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/7lQ9XCkVhQ",
        "expanded_url" : "http:\/\/ow.ly\/dOVE3057fA0",
        "display_url" : "ow.ly\/dOVE3057fA0"
      } ]
    },
    "geo" : { },
    "id_str" : "786263102123872256",
    "text" : "Are you up for the Crime Forecasting Challenge? - https:\/\/t.co\/7lQ9XCkVhQ (Partner content via @OJPNIJ) #datascience https:\/\/t.co\/S6DEU3dz89",
    "id" : 786263102123872256,
    "created_at" : "2016-10-12 17:51:46 +0000",
    "user" : {
      "name" : "MIT Tech Review",
      "screen_name" : "techreview",
      "protected" : false,
      "id_str" : "15808647",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731132378001879040\/HWk2Eaxg_normal.jpg",
      "id" : 15808647,
      "verified" : true
    }
  },
  "id" : 786265478360539136,
  "created_at" : "2016-10-12 18:01:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786264441977384960",
  "text" : "There wasn't a war was there Bush?",
  "id" : 786264441977384960,
  "created_at" : "2016-10-12 17:57:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/NgAfnT87Xq",
      "expanded_url" : "http:\/\/www.gq.com\/story\/obama-greatest-president-legacy",
      "display_url" : "gq.com\/story\/obama-gr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786264306891395072",
  "text" : "Why Obama Will Go Down as One of the Greatest Presidents of All Time | GQ https:\/\/t.co\/NgAfnT87Xq",
  "id" : 786264306891395072,
  "created_at" : "2016-10-12 17:56:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786263655075581953",
  "text" : "I never was a big romantic I do care but I'm about education.",
  "id" : 786263655075581953,
  "created_at" : "2016-10-12 17:53:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Z5qMm5iyy9",
      "expanded_url" : "https:\/\/www.treasurydirect.gov\/indiv\/research\/indepth\/ebonds\/res_e_bonds_eeredeem.htm",
      "display_url" : "treasurydirect.gov\/indiv\/research\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786262956778467328",
  "text" : "https:\/\/t.co\/Z5qMm5iyy9 Redeeming or cashing a bond not sure about the details yet.",
  "id" : 786262956778467328,
  "created_at" : "2016-10-12 17:51:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786261969854619648",
  "text" : "There is \"So much to do\" isn't there Vedder?",
  "id" : 786261969854619648,
  "created_at" : "2016-10-12 17:47:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/1tr9vULRru",
      "expanded_url" : "http:\/\/www.headlesshollow.com\/2013\/05\/stop-the-adobe-creative-cloud\/",
      "display_url" : "headlesshollow.com\/2013\/05\/stop-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786260994330730496",
  "text" : "https:\/\/t.co\/1tr9vULRru \nStop the Monopoly. Don\u2019t Join Adobe\u2019s Creative Cloud. Open Adobe.",
  "id" : 786260994330730496,
  "created_at" : "2016-10-12 17:43:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786258772150800385",
  "text" : "'God' is defined as the supreme reality in the dictionary. When we make progress with String Theory I will tell you.",
  "id" : 786258772150800385,
  "created_at" : "2016-10-12 17:34:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BizInnovationFactory",
      "screen_name" : "TheBIF",
      "indices" : [ 3, 10 ],
      "id_str" : "17325009",
      "id" : 17325009
    }, {
      "name" : "healthydebate.ca",
      "screen_name" : "HealthyDebate",
      "indices" : [ 66, 80 ],
      "id_str" : "81955135",
      "id" : 81955135
    }, {
      "name" : "Kavita Patel M.D.",
      "screen_name" : "kavitapmd",
      "indices" : [ 120, 130 ],
      "id_str" : "580453937",
      "id" : 580453937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/fmG28Iixho",
      "expanded_url" : "http:\/\/ln.is\/healthydebate.ca\/201\/YGHUU",
      "display_url" : "ln.is\/healthydebate.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786257579974336512",
  "text" : "RT @TheBIF: Loneliness in seniors has serious health effects says @HealthyDebate  https:\/\/t.co\/fmG28Iixho Reminds us of @kavitapmd's #BIF20\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/linkis.com\" rel=\"nofollow\"\u003EPut your button on any page! \u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "healthydebate.ca",
        "screen_name" : "HealthyDebate",
        "indices" : [ 54, 68 ],
        "id_str" : "81955135",
        "id" : 81955135
      }, {
        "name" : "Kavita Patel M.D.",
        "screen_name" : "kavitapmd",
        "indices" : [ 108, 118 ],
        "id_str" : "580453937",
        "id" : 580453937
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BIF2016",
        "indices" : [ 121, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/fmG28Iixho",
        "expanded_url" : "http:\/\/ln.is\/healthydebate.ca\/201\/YGHUU",
        "display_url" : "ln.is\/healthydebate.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "786256455800328192",
    "text" : "Loneliness in seniors has serious health effects says @HealthyDebate  https:\/\/t.co\/fmG28Iixho Reminds us of @kavitapmd's #BIF2016 talk",
    "id" : 786256455800328192,
    "created_at" : "2016-10-12 17:25:21 +0000",
    "user" : {
      "name" : "BizInnovationFactory",
      "screen_name" : "TheBIF",
      "protected" : false,
      "id_str" : "17325009",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611967409\/bif-logo_normal.gif",
      "id" : 17325009,
      "verified" : false
    }
  },
  "id" : 786257579974336512,
  "created_at" : "2016-10-12 17:29:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786257257533026304",
  "text" : "Big bang theory is his name 'Sherman' See I really don't know I don't watch it. I do watch the Olympics",
  "id" : 786257257533026304,
  "created_at" : "2016-10-12 17:28:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786256212916473856",
  "text" : "Intel is I see Big Bang Theory again I am going off.",
  "id" : 786256212916473856,
  "created_at" : "2016-10-12 17:24:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFLScience",
      "screen_name" : "IFLScience",
      "indices" : [ 65, 76 ],
      "id_str" : "838464523",
      "id" : 838464523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/u9BRzEYz8E",
      "expanded_url" : "http:\/\/www.iflscience.com\/physics\/cern-releases-300-terabytes-worth-data-public\/",
      "display_url" : "iflscience.com\/physics\/cern-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786255804584210432",
  "text" : "CERN Just Released 300 Terabytes Worth Of Data To The Public via @IFLScience: https:\/\/t.co\/u9BRzEYz8E",
  "id" : 786255804584210432,
  "created_at" : "2016-10-12 17:22:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ignite Talks",
      "screen_name" : "ignitetalks",
      "indices" : [ 3, 15 ],
      "id_str" : "3230044693",
      "id" : 3230044693
    }, {
      "name" : "Jennifer Pahlka",
      "screen_name" : "pahlkadot",
      "indices" : [ 56, 66 ],
      "id_str" : "74543",
      "id" : 74543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Government",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/7rI0C9QoqH",
      "expanded_url" : "http:\/\/buff.ly\/2e4aABz",
      "display_url" : "buff.ly\/2e4aABz"
    } ]
  },
  "geo" : { },
  "id_str" : "786254976695750656",
  "text" : "RT @ignitetalks: \"#Government programs are really big.\" @pahlkadot talks about problems and solutions in local gov: https:\/\/t.co\/7rI0C9QoqH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jennifer Pahlka",
        "screen_name" : "pahlkadot",
        "indices" : [ 39, 49 ],
        "id_str" : "74543",
        "id" : 74543
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ignitetalks\/status\/786252849017720832\/photo\/1",
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/UDuUgM5kfy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CulUzIrWgAAuDxq.jpg",
        "id_str" : "786252847432237056",
        "id" : 786252847432237056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CulUzIrWgAAuDxq.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/UDuUgM5kfy"
      } ],
      "hashtags" : [ {
        "text" : "Government",
        "indices" : [ 1, 12 ]
      }, {
        "text" : "ignitetalks",
        "indices" : [ 123, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/7rI0C9QoqH",
        "expanded_url" : "http:\/\/buff.ly\/2e4aABz",
        "display_url" : "buff.ly\/2e4aABz"
      } ]
    },
    "geo" : { },
    "id_str" : "786252849017720832",
    "text" : "\"#Government programs are really big.\" @pahlkadot talks about problems and solutions in local gov: https:\/\/t.co\/7rI0C9QoqH #ignitetalks https:\/\/t.co\/UDuUgM5kfy",
    "id" : 786252849017720832,
    "created_at" : "2016-10-12 17:11:01 +0000",
    "user" : {
      "name" : "Ignite Talks",
      "screen_name" : "ignitetalks",
      "protected" : false,
      "id_str" : "3230044693",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747294407632650240\/SibaEeqv_normal.jpg",
      "id" : 3230044693,
      "verified" : false
    }
  },
  "id" : 786254976695750656,
  "created_at" : "2016-10-12 17:19:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/JiTHal0odD",
      "expanded_url" : "http:\/\/www.iphandbook.org\/handbook\/ch09\/p02\/",
      "display_url" : "iphandbook.org\/handbook\/ch09\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786251583814197249",
  "text" : "https:\/\/t.co\/JiTHal0odD Technology Valuation: An Introduction.",
  "id" : 786251583814197249,
  "created_at" : "2016-10-12 17:06:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786246360764788736",
  "text" : "I do have two 5 terabyte drives worth of source, they should me my valuation is probably worth more than a million no lie.",
  "id" : 786246360764788736,
  "created_at" : "2016-10-12 16:45:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786245771683213313",
  "text" : "The question is will they let everyone have a $500,000 to million dollar bond like the law states or are the banks going to deny you.",
  "id" : 786245771683213313,
  "created_at" : "2016-10-12 16:42:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786244512255315968",
  "text" : "I did go outside today where only the birds tweet and enjoyed it a little.",
  "id" : 786244512255315968,
  "created_at" : "2016-10-12 16:37:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/yPjvGvSHNR",
      "expanded_url" : "http:\/\/www.techrepublic.com\/blog\/10-things\/10-differences-between-linux-and-bsd\/",
      "display_url" : "techrepublic.com\/blog\/10-things\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786243345890762752",
  "text" : "https:\/\/t.co\/yPjvGvSHNR  10 differences between Linux and BSD.",
  "id" : 786243345890762752,
  "created_at" : "2016-10-12 16:33:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Usabilla",
      "screen_name" : "usabilla",
      "indices" : [ 57, 66 ],
      "id_str" : "16601140",
      "id" : 16601140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/Y7PWU5QiHT",
      "expanded_url" : "http:\/\/blog.usabilla.com\/flat-design-going-far\/",
      "display_url" : "blog.usabilla.com\/flat-design-go\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786242068871942144",
  "text" : "Flat Design Is Going Too Far https:\/\/t.co\/Y7PWU5QiHT via @usabilla",
  "id" : 786242068871942144,
  "created_at" : "2016-10-12 16:28:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 3, 16 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheEconomist\/status\/786238219474042880\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/jNtsQhjN6N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CulHfiAWcAEtgRZ.jpg",
      "id_str" : "786238216982654977",
      "id" : 786238216982654977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CulHfiAWcAEtgRZ.jpg",
      "sizes" : [ {
        "h" : 627,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 627,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 627,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/jNtsQhjN6N"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/TGiyy0lGD7",
      "expanded_url" : "http:\/\/econ.st\/2es023u",
      "display_url" : "econ.st\/2es023u"
    } ]
  },
  "geo" : { },
  "id_str" : "786241473356312576",
  "text" : "RT @TheEconomist: In 2020, Republicans will make American populism mainstream again https:\/\/t.co\/TGiyy0lGD7 https:\/\/t.co\/jNtsQhjN6N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheEconomist\/status\/786238219474042880\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/jNtsQhjN6N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CulHfiAWcAEtgRZ.jpg",
        "id_str" : "786238216982654977",
        "id" : 786238216982654977,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CulHfiAWcAEtgRZ.jpg",
        "sizes" : [ {
          "h" : 627,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/jNtsQhjN6N"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/TGiyy0lGD7",
        "expanded_url" : "http:\/\/econ.st\/2es023u",
        "display_url" : "econ.st\/2es023u"
      } ]
    },
    "geo" : { },
    "id_str" : "786238219474042880",
    "text" : "In 2020, Republicans will make American populism mainstream again https:\/\/t.co\/TGiyy0lGD7 https:\/\/t.co\/jNtsQhjN6N",
    "id" : 786238219474042880,
    "created_at" : "2016-10-12 16:12:53 +0000",
    "user" : {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "protected" : false,
      "id_str" : "5988062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461499742950678528\/2JnpHjUo_normal.png",
      "id" : 5988062,
      "verified" : true
    }
  },
  "id" : 786241473356312576,
  "created_at" : "2016-10-12 16:25:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mayo Clinic",
      "screen_name" : "MayoClinic",
      "indices" : [ 3, 14 ],
      "id_str" : "14592723",
      "id" : 14592723
    }, {
      "name" : "MIT",
      "screen_name" : "MIT",
      "indices" : [ 32, 36 ],
      "id_str" : "15460048",
      "id" : 15460048
    }, {
      "name" : "National Cancer Inst",
      "screen_name" : "theNCI",
      "indices" : [ 120, 127 ],
      "id_str" : "38530021",
      "id" : 38530021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/gA41OYrY3f",
      "expanded_url" : "http:\/\/mayocl.in\/2dRFvn6",
      "display_url" : "mayocl.in\/2dRFvn6"
    } ]
  },
  "geo" : { },
  "id_str" : "786241173371228164",
  "text" : "RT @MayoClinic: Mayo Clinic and @MIT receive grant to support physical sciences-oncology center https:\/\/t.co\/gA41OYrY3f @theNCI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MIT",
        "screen_name" : "MIT",
        "indices" : [ 16, 20 ],
        "id_str" : "15460048",
        "id" : 15460048
      }, {
        "name" : "National Cancer Inst",
        "screen_name" : "theNCI",
        "indices" : [ 104, 111 ],
        "id_str" : "38530021",
        "id" : 38530021
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/gA41OYrY3f",
        "expanded_url" : "http:\/\/mayocl.in\/2dRFvn6",
        "display_url" : "mayocl.in\/2dRFvn6"
      } ]
    },
    "geo" : { },
    "id_str" : "786238775219347456",
    "text" : "Mayo Clinic and @MIT receive grant to support physical sciences-oncology center https:\/\/t.co\/gA41OYrY3f @theNCI",
    "id" : 786238775219347456,
    "created_at" : "2016-10-12 16:15:06 +0000",
    "user" : {
      "name" : "Mayo Clinic",
      "screen_name" : "MayoClinic",
      "protected" : false,
      "id_str" : "14592723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760454818422857728\/2WFm5vUI_normal.jpg",
      "id" : 14592723,
      "verified" : true
    }
  },
  "id" : 786241173371228164,
  "created_at" : "2016-10-12 16:24:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carnegie Mellon",
      "screen_name" : "CarnegieMellon",
      "indices" : [ 3, 18 ],
      "id_str" : "17631078",
      "id" : 17631078
    }, {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 29, 35 ],
      "id_str" : "1344951",
      "id" : 1344951
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 37, 43 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/pEghNsG7rd",
      "expanded_url" : "http:\/\/cmu.li\/ntZs3056LOX",
      "display_url" : "cmu.li\/ntZs3056LOX"
    } ]
  },
  "geo" : { },
  "id_str" : "786241087874576385",
  "text" : "RT @CarnegieMellon: Today in @WIRED: @POTUS on America's new frontiers: https:\/\/t.co\/pEghNsG7rd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WIRED",
        "screen_name" : "WIRED",
        "indices" : [ 9, 15 ],
        "id_str" : "1344951",
        "id" : 1344951
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 17, 23 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/pEghNsG7rd",
        "expanded_url" : "http:\/\/cmu.li\/ntZs3056LOX",
        "display_url" : "cmu.li\/ntZs3056LOX"
      } ]
    },
    "geo" : { },
    "id_str" : "786238849387200512",
    "text" : "Today in @WIRED: @POTUS on America's new frontiers: https:\/\/t.co\/pEghNsG7rd",
    "id" : 786238849387200512,
    "created_at" : "2016-10-12 16:15:23 +0000",
    "user" : {
      "name" : "Carnegie Mellon",
      "screen_name" : "CarnegieMellon",
      "protected" : false,
      "id_str" : "17631078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583587004316647424\/2pjjWvhP_normal.png",
      "id" : 17631078,
      "verified" : true
    }
  },
  "id" : 786241087874576385,
  "created_at" : "2016-10-12 16:24:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Zb18M9rHxO",
      "expanded_url" : "http:\/\/www.onlamp.com\/pub\/a\/bsd\/2002\/10\/03\/FreeBSD_Basics.html",
      "display_url" : "onlamp.com\/pub\/a\/bsd\/2002\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786239726567067648",
  "text" : "https:\/\/t.co\/Zb18M9rHxO DVD playback on FreeBSD. Blu-ray should be next if Sony gives back.",
  "id" : 786239726567067648,
  "created_at" : "2016-10-12 16:18:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT",
      "screen_name" : "MIT",
      "indices" : [ 3, 7 ],
      "id_str" : "15460048",
      "id" : 15460048
    }, {
      "name" : "Smarking Inc.",
      "screen_name" : "SmarkingInc",
      "indices" : [ 21, 33 ],
      "id_str" : "2515812662",
      "id" : 2515812662
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MIT\/status\/786236288005443584\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/kNKFjxHtM8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CulFvD7WcAAfFXK.jpg",
      "id_str" : "786236284763271168",
      "id" : 786236284763271168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CulFvD7WcAAfFXK.jpg",
      "sizes" : [ {
        "h" : 632,
        "resize" : "fit",
        "w" : 948
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 948
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 948
      } ],
      "display_url" : "pic.twitter.com\/kNKFjxHtM8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/Z3IFlJNYuQ",
      "expanded_url" : "http:\/\/mitsha.re\/D9AC3056Yq6",
      "display_url" : "mitsha.re\/D9AC3056Yq6"
    } ]
  },
  "geo" : { },
  "id_str" : "786237156696010752",
  "text" : "RT @MIT: MIT spinoff @SmarkingInc is working to provide predictive parking data analytics. https:\/\/t.co\/Z3IFlJNYuQ https:\/\/t.co\/kNKFjxHtM8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Smarking Inc.",
        "screen_name" : "SmarkingInc",
        "indices" : [ 12, 24 ],
        "id_str" : "2515812662",
        "id" : 2515812662
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MIT\/status\/786236288005443584\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/kNKFjxHtM8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CulFvD7WcAAfFXK.jpg",
        "id_str" : "786236284763271168",
        "id" : 786236284763271168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CulFvD7WcAAfFXK.jpg",
        "sizes" : [ {
          "h" : 632,
          "resize" : "fit",
          "w" : 948
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 948
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 948
        } ],
        "display_url" : "pic.twitter.com\/kNKFjxHtM8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/Z3IFlJNYuQ",
        "expanded_url" : "http:\/\/mitsha.re\/D9AC3056Yq6",
        "display_url" : "mitsha.re\/D9AC3056Yq6"
      } ]
    },
    "geo" : { },
    "id_str" : "786236288005443584",
    "text" : "MIT spinoff @SmarkingInc is working to provide predictive parking data analytics. https:\/\/t.co\/Z3IFlJNYuQ https:\/\/t.co\/kNKFjxHtM8",
    "id" : 786236288005443584,
    "created_at" : "2016-10-12 16:05:13 +0000",
    "user" : {
      "name" : "MIT",
      "screen_name" : "MIT",
      "protected" : false,
      "id_str" : "15460048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726083204122312704\/C_SBTZQ__normal.jpg",
      "id" : 15460048,
      "verified" : true
    }
  },
  "id" : 786237156696010752,
  "created_at" : "2016-10-12 16:08:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/NwC0yDZzW2",
      "expanded_url" : "http:\/\/www.zdnet.com\/article\/why-microsoft-is-turning-into-an-open-source-company\/",
      "display_url" : "zdnet.com\/article\/why-mi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786237086399467522",
  "text" : "https:\/\/t.co\/NwC0yDZzW2 Why Microsoft is turning into an open-source company.",
  "id" : 786237086399467522,
  "created_at" : "2016-10-12 16:08:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Community Grid",
      "screen_name" : "WCGrid",
      "indices" : [ 3, 10 ],
      "id_str" : "26388412",
      "id" : 26388412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786236309790601216",
  "text" : "RT @WCGrid: PROJECT UPDATE: The Clean Energy Project research team discusses their data analysis and a new collaboration. https:\/\/t.co\/zdk4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WCGrid\/status\/786231541051469824\/photo\/1",
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/aJL4fEYtVk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CulBZokWcAAf04M.jpg",
        "id_str" : "786231518595280896",
        "id" : 786231518595280896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CulBZokWcAAf04M.jpg",
        "sizes" : [ {
          "h" : 281,
          "resize" : "fit",
          "w" : 305
        }, {
          "h" : 281,
          "resize" : "fit",
          "w" : 305
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 281,
          "resize" : "fit",
          "w" : 305
        }, {
          "h" : 281,
          "resize" : "fit",
          "w" : 305
        } ],
        "display_url" : "pic.twitter.com\/aJL4fEYtVk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/zdk4K4iB2A",
        "expanded_url" : "https:\/\/www.worldcommunitygrid.org\/about_us\/viewNewsArticle.do?articleId=502",
        "display_url" : "worldcommunitygrid.org\/about_us\/viewN\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "786231541051469824",
    "text" : "PROJECT UPDATE: The Clean Energy Project research team discusses their data analysis and a new collaboration. https:\/\/t.co\/zdk4K4iB2A https:\/\/t.co\/aJL4fEYtVk",
    "id" : 786231541051469824,
    "created_at" : "2016-10-12 15:46:21 +0000",
    "user" : {
      "name" : "World Community Grid",
      "screen_name" : "WCGrid",
      "protected" : false,
      "id_str" : "26388412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448919987281866752\/T4oA5jtc_normal.png",
      "id" : 26388412,
      "verified" : false
    }
  },
  "id" : 786236309790601216,
  "created_at" : "2016-10-12 16:05:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBM",
      "screen_name" : "IBM",
      "indices" : [ 3, 7 ],
      "id_str" : "18994444",
      "id" : 18994444
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 14, 19 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "indices" : [ 28, 42 ],
      "id_str" : "34554134",
      "id" : 34554134
    }, {
      "name" : "IBM Analytics",
      "screen_name" : "IBMAnalytics",
      "indices" : [ 56, 69 ],
      "id_str" : "267908574",
      "id" : 267908574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786236205645959168",
  "text" : "RT @IBM: IBM, @NASA and the @SETIInstitute are applying @IBMAnalytics + machine learning to listen for signs of alien life: https:\/\/t.co\/kw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/percolate.com\" rel=\"nofollow\"\u003EPercolate\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 5, 10 ],
        "id_str" : "11348282",
        "id" : 11348282
      }, {
        "name" : "The SETI Institute",
        "screen_name" : "SETIInstitute",
        "indices" : [ 19, 33 ],
        "id_str" : "34554134",
        "id" : 34554134
      }, {
        "name" : "IBM Analytics",
        "screen_name" : "IBMAnalytics",
        "indices" : [ 47, 60 ],
        "id_str" : "267908574",
        "id" : 267908574
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IBM\/status\/786005547791200257\/photo\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/20PucGiOCc",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cuhz4LhUAAALEfw.jpg",
        "id_str" : "786005543978532864",
        "id" : 786005543978532864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cuhz4LhUAAALEfw.jpg",
        "sizes" : [ {
          "h" : 260,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/20PucGiOCc"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/kwZ4rW0QWO",
        "expanded_url" : "http:\/\/bit.ly\/2dZQl8X",
        "display_url" : "bit.ly\/2dZQl8X"
      } ]
    },
    "geo" : { },
    "id_str" : "786005547791200257",
    "text" : "IBM, @NASA and the @SETIInstitute are applying @IBMAnalytics + machine learning to listen for signs of alien life: https:\/\/t.co\/kwZ4rW0QWO https:\/\/t.co\/20PucGiOCc",
    "id" : 786005547791200257,
    "created_at" : "2016-10-12 00:48:20 +0000",
    "user" : {
      "name" : "IBM",
      "screen_name" : "IBM",
      "protected" : false,
      "id_str" : "18994444",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614802024832610304\/_CZY2puL_normal.jpg",
      "id" : 18994444,
      "verified" : true
    }
  },
  "id" : 786236205645959168,
  "created_at" : "2016-10-12 16:04:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Economic Forum",
      "screen_name" : "Davos",
      "indices" : [ 3, 9 ],
      "id_str" : "102700680",
      "id" : 102700680
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Davos\/status\/786235248505942016\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/rAcJ8nAEUc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CulEyofWIAU_E-K.jpg",
      "id_str" : "786235246605901829",
      "id" : 786235246605901829,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CulEyofWIAU_E-K.jpg",
      "sizes" : [ {
        "h" : 520,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 442,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/rAcJ8nAEUc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/0I4RHZpigN",
      "expanded_url" : "http:\/\/wef.ch\/2dQQ35S",
      "display_url" : "wef.ch\/2dQQ35S"
    } ]
  },
  "geo" : { },
  "id_str" : "786235829815382016",
  "text" : "RT @Davos: Three ways organic electronics could change your life https:\/\/t.co\/0I4RHZpigN https:\/\/t.co\/rAcJ8nAEUc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Davos\/status\/786235248505942016\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/rAcJ8nAEUc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CulEyofWIAU_E-K.jpg",
        "id_str" : "786235246605901829",
        "id" : 786235246605901829,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CulEyofWIAU_E-K.jpg",
        "sizes" : [ {
          "h" : 520,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/rAcJ8nAEUc"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/0I4RHZpigN",
        "expanded_url" : "http:\/\/wef.ch\/2dQQ35S",
        "display_url" : "wef.ch\/2dQQ35S"
      } ]
    },
    "geo" : { },
    "id_str" : "786235248505942016",
    "text" : "Three ways organic electronics could change your life https:\/\/t.co\/0I4RHZpigN https:\/\/t.co\/rAcJ8nAEUc",
    "id" : 786235248505942016,
    "created_at" : "2016-10-12 16:01:05 +0000",
    "user" : {
      "name" : "World Economic Forum",
      "screen_name" : "Davos",
      "protected" : false,
      "id_str" : "102700680",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689479051841372160\/brN1Bg7W_normal.png",
      "id" : 102700680,
      "verified" : false
    }
  },
  "id" : 786235829815382016,
  "created_at" : "2016-10-12 16:03:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cambridge Enterprise",
      "screen_name" : "UCamEnterprise",
      "indices" : [ 3, 18 ],
      "id_str" : "42889753",
      "id" : 42889753
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "10YearsofInnovation",
      "indices" : [ 42, 62 ]
    }, {
      "text" : "Campath",
      "indices" : [ 82, 90 ]
    }, {
      "text" : "innovation",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786235728199987200",
  "text" : "RT @UCamEnterprise: The next story in our #10YearsofInnovation series reflects on #Campath's path from #innovation to impact https:\/\/t.co\/S\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "10YearsofInnovation",
        "indices" : [ 22, 42 ]
      }, {
        "text" : "Campath",
        "indices" : [ 62, 70 ]
      }, {
        "text" : "innovation",
        "indices" : [ 83, 94 ]
      }, {
        "text" : "enterprise",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/SF8MXV9UJe",
        "expanded_url" : "https:\/\/www.enterprise.cam.ac.uk\/stories\/sticking-with-it\/",
        "display_url" : "enterprise.cam.ac.uk\/stories\/sticki\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "786234813170659328",
    "text" : "The next story in our #10YearsofInnovation series reflects on #Campath's path from #innovation to impact https:\/\/t.co\/SF8MXV9UJe #enterprise",
    "id" : 786234813170659328,
    "created_at" : "2016-10-12 15:59:21 +0000",
    "user" : {
      "name" : "Cambridge Enterprise",
      "screen_name" : "UCamEnterprise",
      "protected" : false,
      "id_str" : "42889753",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639077659046187008\/i8U9QbzR_normal.png",
      "id" : 42889753,
      "verified" : false
    }
  },
  "id" : 786235728199987200,
  "created_at" : "2016-10-12 16:02:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 61, 68 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/JDVVzbaUlG",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/ewanspence\/2016\/04\/17\/microsoft-surface-book-review-real-world\/#334f33fb5ed6",
      "display_url" : "forbes.com\/sites\/ewanspen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786235049393786882",
  "text" : "Microsoft's Frustrating View Of The Laptop Of The Future via @forbes https:\/\/t.co\/JDVVzbaUlG",
  "id" : 786235049393786882,
  "created_at" : "2016-10-12 16:00:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/MJdG0HDSVx",
      "expanded_url" : "https:\/\/www.wired.com\/insights\/2014\/06\/laptop-future-may-closer-think\/",
      "display_url" : "wired.com\/insights\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786234718786166784",
  "text" : "The Laptop of the Future May Be Closer Than You Think https:\/\/t.co\/MJdG0HDSVx",
  "id" : 786234718786166784,
  "created_at" : "2016-10-12 15:58:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786229795814252544",
  "text" : "It never was about the money for me but about the relationship and no I don't want to play pool.",
  "id" : 786229795814252544,
  "created_at" : "2016-10-12 15:39:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786229545733070848",
  "text" : "I would tell you about securities and a passive income too that I've known about for a long time too.",
  "id" : 786229545733070848,
  "created_at" : "2016-10-12 15:38:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786227748951855104",
  "text" : "What is eligible is a EISA bond and some other things the bond might be upwards to a million dollars.",
  "id" : 786227748951855104,
  "created_at" : "2016-10-12 15:31:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/tNZmhulnBW",
      "expanded_url" : "http:\/\/www.groom.com\/media\/publication\/1260_Paying_Employee_Benefit_Plan_Expenses.pdf",
      "display_url" : "groom.com\/media\/publicat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786227284860506112",
  "text" : "https:\/\/t.co\/tNZmhulnBW Paying with Plan assets.",
  "id" : 786227284860506112,
  "created_at" : "2016-10-12 15:29:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/aOmEMFqUdU",
      "expanded_url" : "https:\/\/www.fightaging.org\/archives\/2013\/08\/the-cost-of-being-tall-is-a-shorter-life-expectancy\/",
      "display_url" : "fightaging.org\/archives\/2013\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786224898964283392",
  "text" : "https:\/\/t.co\/aOmEMFqUdU The Cost of Being Tall is a Shorter Life Expectancy.",
  "id" : 786224898964283392,
  "created_at" : "2016-10-12 15:19:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786223188124499969",
  "text" : "There needs to be arranged marriages and beauty according to education not social class and more discipline.",
  "id" : 786223188124499969,
  "created_at" : "2016-10-12 15:13:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/bZmddTnupC",
      "expanded_url" : "http:\/\/www.thehealthsite.com\/diseases-conditions\/6-worst-health-problems-common-with-computer-use-sh214\/",
      "display_url" : "thehealthsite.com\/diseases-condi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786219844131663872",
  "text" : "6 worst health problems common with computer use https:\/\/t.co\/bZmddTnupC",
  "id" : 786219844131663872,
  "created_at" : "2016-10-12 14:59:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786217400454840321",
  "text" : "The banks do just make up the money out of thin air I really don't know why we even spend.",
  "id" : 786217400454840321,
  "created_at" : "2016-10-12 14:50:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786212778004492289",
  "text" : "Want To Live Forever? Trials For Drug Believed To Slow Down Aging Process Will Begin Next Winter",
  "id" : 786212778004492289,
  "created_at" : "2016-10-12 14:31:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786210163732668416",
  "text" : "All I really need to worry about is immortality to piss off the males and male doctors right?",
  "id" : 786210163732668416,
  "created_at" : "2016-10-12 14:21:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786186103166537728",
  "text" : "Come over and you will see me waking and running.",
  "id" : 786186103166537728,
  "created_at" : "2016-10-12 12:45:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786185534041382912",
  "text" : "Do get up from your computer about an hour at a time.",
  "id" : 786185534041382912,
  "created_at" : "2016-10-12 12:43:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/eAPMkrDKXn",
      "expanded_url" : "https:\/\/www.theguardian.com\/science\/2010\/jan\/11\/watching-television-increases-death-heart-disease?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/science\/2010\/j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786185048043249664",
  "text" : "Watching television increases risk of death from heart disease https:\/\/t.co\/eAPMkrDKXn",
  "id" : 786185048043249664,
  "created_at" : "2016-10-12 12:41:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/BxmHjJrfbD",
      "expanded_url" : "http:\/\/ti.me\/1kf0l9U",
      "display_url" : "ti.me\/1kf0l9U"
    } ]
  },
  "geo" : { },
  "id_str" : "786184748716658688",
  "text" : "Sitting isn't equally bad for everyone https:\/\/t.co\/BxmHjJrfbD",
  "id" : 786184748716658688,
  "created_at" : "2016-10-12 12:40:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786176511091085312",
  "text" : "And everything is not on Linux.",
  "id" : 786176511091085312,
  "created_at" : "2016-10-12 12:07:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786171632574459904",
  "text" : "Don't hack me do just call and you can come over. Or is that not the corporate thing to do?",
  "id" : 786171632574459904,
  "created_at" : "2016-10-12 11:48:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786168974883028992",
  "text" : "If these women just knew what was on our computers they wouldn't want the travel that much either.",
  "id" : 786168974883028992,
  "created_at" : "2016-10-12 11:37:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786167494834851841",
  "text" : "I am lucky in a lot of ways I do just get mad because I don't have a girlfriend or wife and really haven't felt love in 20 years.",
  "id" : 786167494834851841,
  "created_at" : "2016-10-12 11:31:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 61, 69 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/EPYNWVHPpB",
      "expanded_url" : "https:\/\/youtu.be\/mwy5uqemp6c",
      "display_url" : "youtu.be\/mwy5uqemp6c"
    } ]
  },
  "geo" : { },
  "id_str" : "786015953691643904",
  "text" : "Tokens - The Lion Sleeps Tonight https:\/\/t.co\/EPYNWVHPpB via @YouTube Get it. Goodnight AWWWW",
  "id" : 786015953691643904,
  "created_at" : "2016-10-12 01:29:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/eFwo755gkG",
      "expanded_url" : "https:\/\/www.algemeiner.com\/2012\/07\/05\/orthodox-rabbi-may-be-first-als-patient-cured-by-israeli-drug\/\/",
      "display_url" : "algemeiner.com\/2012\/07\/05\/ort\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786012317393690625",
  "text" : "Orthodox Rabbi May be First ALS Patient Cured by Israeli Drug https:\/\/t.co\/eFwo755gkG",
  "id" : 786012317393690625,
  "created_at" : "2016-10-12 01:15:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/H4cEfDSJ0W",
      "expanded_url" : "http:\/\/abc7.com\/health\/hope-for-als-treatment-after-groundbreaking-study\/1155201\/",
      "display_url" : "abc7.com\/health\/hope-fo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786011402955739136",
  "text" : "https:\/\/t.co\/H4cEfDSJ0W Groundbreaking ALS treatment.",
  "id" : 786011402955739136,
  "created_at" : "2016-10-12 01:11:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 70, 77 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/MiSUdpbmQ5",
      "expanded_url" : "https:\/\/www.amazon.com\/dp\/0780631315\/ref=cm_sw_r_tw_dp_x_mZy.xbTGEFQF2",
      "display_url" : "amazon.com\/dp\/0780631315\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786010608709668864",
  "text" : "Stephen Hawking's Universe PBS Home Video https:\/\/t.co\/MiSUdpbmQ5 via @amazon",
  "id" : 786010608709668864,
  "created_at" : "2016-10-12 01:08:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786009177982398464",
  "text" : "Vic Microsoft. iTunes sucks too.",
  "id" : 786009177982398464,
  "created_at" : "2016-10-12 01:02:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786008718953615360",
  "text" : "I had the universe but I just bought the original PBS DVD of Hawkins universe.",
  "id" : 786008718953615360,
  "created_at" : "2016-10-12 01:00:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786002511337549824",
  "text" : "I do have that movie and I hoped it would focus on his scientific career. But it didn't for girls.",
  "id" : 786002511337549824,
  "created_at" : "2016-10-12 00:36:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786000121347641344",
  "text" : "I don't want to know what that bitch did Hawking.",
  "id" : 786000121347641344,
  "created_at" : "2016-10-12 00:26:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785991331692814340",
  "text" : "We are trying to make this better. When I see a profile picture I expect to just see you.",
  "id" : 785991331692814340,
  "created_at" : "2016-10-11 23:51:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785989595905323008",
  "text" : "And LinkedIn.",
  "id" : 785989595905323008,
  "created_at" : "2016-10-11 23:44:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785989248386273280",
  "text" : "Twitter was the only social media app I kept on my phone. That and Mendeley. I will and Path for my family.",
  "id" : 785989248386273280,
  "created_at" : "2016-10-11 23:43:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Academia",
      "screen_name" : "academia",
      "indices" : [ 40, 49 ],
      "id_str" : "22809165",
      "id" : 22809165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/CZimu2vIwM",
      "expanded_url" : "http:\/\/www.academia.edu\/29076309\/About_Soical_Networks",
      "display_url" : "academia.edu\/29076309\/About\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785899864785756160",
  "text" : "I just added 'About Soical Networks' to @academia! https:\/\/t.co\/CZimu2vIwM",
  "id" : 785899864785756160,
  "created_at" : "2016-10-11 17:48:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BI Education",
      "screen_name" : "BI_University",
      "indices" : [ 109, 123 ],
      "id_str" : "1528233787",
      "id" : 1528233787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/RlJWczGaVG",
      "expanded_url" : "http:\/\/read.bi\/1JFujor",
      "display_url" : "read.bi\/1JFujor"
    } ]
  },
  "geo" : { },
  "id_str" : "785847155311448066",
  "text" : "Yale psychiatrist has one explanation for why students are so anxious these days https:\/\/t.co\/RlJWczGaVG via @bi_university",
  "id" : 785847155311448066,
  "created_at" : "2016-10-11 14:18:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shareaholic",
      "screen_name" : "Shareaholic",
      "indices" : [ 62, 74 ],
      "id_str" : "791635",
      "id" : 791635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/L5QXSc022j",
      "expanded_url" : "http:\/\/go.shr.lc\/2aBEUUw",
      "display_url" : "go.shr.lc\/2aBEUUw"
    } ]
  },
  "geo" : { },
  "id_str" : "785844785655545856",
  "text" : "Why Social Media Causes Anxiety - https:\/\/t.co\/L5QXSc022j via @Shareaholic",
  "id" : 785844785655545856,
  "created_at" : "2016-10-11 14:09:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785766722460540928",
  "text" : "'Opponent Process Theory' aka 'Four Point Zero' began streaming in 2014 worldwide. Soon Vol. 1 will be streaming world wide too.",
  "id" : 785766722460540928,
  "created_at" : "2016-10-11 08:59:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785764070355898368",
  "text" : "I have been streamed worldwide on almost every internet platform and I do have a high net worth. Just without an official valuation.",
  "id" : 785764070355898368,
  "created_at" : "2016-10-11 08:48:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/lN9yFSGKZq",
      "expanded_url" : "http:\/\/www.bbc.com\/news\/entertainment-arts-37294911",
      "display_url" : "bbc.com\/news\/entertain\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785763369768751104",
  "text" : "BBC News - Fame, fortune, fear: Why do pop stars struggle with anxiety? https:\/\/t.co\/lN9yFSGKZq",
  "id" : 785763369768751104,
  "created_at" : "2016-10-11 08:46:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/xn2CJAFieH",
      "expanded_url" : "http:\/\/lifehacker.com\/what-anxiety-actually-does-to-you-and-what-you-can-do-a-1468128356?utm_medium=sharefromsite&utm_source=Lifehacker_twitter",
      "display_url" : "lifehacker.com\/what-anxiety-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785756553458495490",
  "text" : "What Anxiety Does to Your Brain and What You Can Do About It https:\/\/t.co\/xn2CJAFieH",
  "id" : 785756553458495490,
  "created_at" : "2016-10-11 08:18:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K-State Collegian",
      "screen_name" : "kstatecollegian",
      "indices" : [ 85, 101 ],
      "id_str" : "16870352",
      "id" : 16870352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/bFs6yYFpI9",
      "expanded_url" : "http:\/\/www.kstatecollegian.com\/2012\/01\/26\/excessive-internet-usage-can-lead-to-anxiety-depression\/",
      "display_url" : "kstatecollegian.com\/2012\/01\/26\/exc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785755699045208065",
  "text" : "Excessive Internet usage can lead to anxiety, depression https:\/\/t.co\/bFs6yYFpI9 via @kstatecollegian",
  "id" : 785755699045208065,
  "created_at" : "2016-10-11 08:15:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IAPP Daily Dashboard",
      "screen_name" : "DailyDashboard",
      "indices" : [ 67, 82 ],
      "id_str" : "372372472",
      "id" : 372372472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/kEM3G49vc2",
      "expanded_url" : "http:\/\/iapp.org\/news\/a\/the-privacy-act-turned-40-got-roasted\/",
      "display_url" : "iapp.org\/news\/a\/the-pri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785750918243360768",
  "text" : "The Privacy Act Turned 40, Got Roasted https:\/\/t.co\/kEM3G49vc2 via @DailyDashboard",
  "id" : 785750918243360768,
  "created_at" : "2016-10-11 07:56:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "indices" : [ 73, 82 ],
      "id_str" : "15754281",
      "id" : 15754281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/HJDRDqD7JX",
      "expanded_url" : "http:\/\/usat.ly\/1dcpgrI",
      "display_url" : "usat.ly\/1dcpgrI"
    } ]
  },
  "geo" : { },
  "id_str" : "785742492763234305",
  "text" : "Cellphone data spying: It's not just the NSA https:\/\/t.co\/HJDRDqD7JX via @usatoday",
  "id" : 785742492763234305,
  "created_at" : "2016-10-11 07:23:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "European Commission",
      "screen_name" : "EU_Commission",
      "indices" : [ 118, 132 ],
      "id_str" : "157981564",
      "id" : 157981564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/yLgqr9zQLc",
      "expanded_url" : "http:\/\/europa.eu\/!kV43fu",
      "display_url" : "europa.eu\/!kV43fu"
    } ]
  },
  "geo" : { },
  "id_str" : "785741796416466944",
  "text" : "Germany, a world leader in technology, engineering and innovation | Digital Single Market https:\/\/t.co\/yLgqr9zQLc via @EU_Commission",
  "id" : 785741796416466944,
  "created_at" : "2016-10-11 07:20:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/SVTuM2ZpBi",
      "expanded_url" : "https:\/\/hbr.org\/2014\/05\/why-germany-dominates-the-u-s-in-innovation",
      "display_url" : "hbr.org\/2014\/05\/why-ge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785741627306283008",
  "text" : "https:\/\/t.co\/SVTuM2ZpBi Germany Dominates the U.S in innovation.",
  "id" : 785741627306283008,
  "created_at" : "2016-10-11 07:19:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/o08ihBbAtI",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Medical_genetics_of_Jews",
      "display_url" : "en.wikipedia.org\/wiki\/Medical_g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785736671077597184",
  "text" : "I'm not racist but Jews have genetic disorders.https:\/\/t.co\/o08ihBbAtI I have been framed.",
  "id" : 785736671077597184,
  "created_at" : "2016-10-11 06:59:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/r6JQxNm4z2",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Adobe_World_Headquarters",
      "display_url" : "en.wikipedia.org\/wiki\/Adobe_Wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785479081802473472",
  "text" : "https:\/\/t.co\/r6JQxNm4z2 Adobe world headquarters. SWVA.",
  "id" : 785479081802473472,
  "created_at" : "2016-10-10 13:56:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 0, 16 ],
      "id_str" : "25073877",
      "id" : 25073877
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 21, 36 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785478660123951104",
  "in_reply_to_user_id" : 25073877,
  "text" : "@realDonaldTrump and @HillaryClinton Here in little SWVA I've always have had trouble with jealous men and women since I worked for Adobe.",
  "id" : 785478660123951104,
  "created_at" : "2016-10-10 13:54:40 +0000",
  "in_reply_to_screen_name" : "realDonaldTrump",
  "in_reply_to_user_id_str" : "25073877",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 0, 15 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785415496271355904",
  "in_reply_to_user_id" : 1339835893,
  "text" : "@HillaryClinton Also I discovered a law document about how you can pay with plan assets.The bank doesn't know what to say to me yet.",
  "id" : 785415496271355904,
  "created_at" : "2016-10-10 09:43:41 +0000",
  "in_reply_to_screen_name" : "HillaryClinton",
  "in_reply_to_user_id_str" : "1339835893",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 0, 16 ],
      "id_str" : "25073877",
      "id" : 25073877
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 21, 36 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785411358032527360",
  "in_reply_to_user_id" : 25073877,
  "text" : "@realDonaldTrump and @HillaryClinton about my diagnoses I haven't been hugged by a women in 20 years that would make you a little moody.",
  "id" : 785411358032527360,
  "created_at" : "2016-10-10 09:27:14 +0000",
  "in_reply_to_screen_name" : "realDonaldTrump",
  "in_reply_to_user_id_str" : "25073877",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 0, 16 ],
      "id_str" : "25073877",
      "id" : 25073877
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 21, 36 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785410583575355392",
  "in_reply_to_user_id" : 25073877,
  "text" : "@realDonaldTrump and @HillaryClinton What are both of your stances on arranged marriages? It is about genetics. I'm believed to have klotho.",
  "id" : 785410583575355392,
  "created_at" : "2016-10-10 09:24:10 +0000",
  "in_reply_to_screen_name" : "realDonaldTrump",
  "in_reply_to_user_id_str" : "25073877",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 102, 117 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debate",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785309004004257793",
  "text" : "Where to you stand on in home sex therapy or prostitution in America, it would lead to less violence. @HillaryClinton #debate",
  "id" : 785309004004257793,
  "created_at" : "2016-10-10 02:40:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life Extension",
      "screen_name" : "LifeExtension",
      "indices" : [ 3, 17 ],
      "id_str" : "27188645",
      "id" : 27188645
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "resveratrol",
      "indices" : [ 34, 46 ]
    }, {
      "text" : "calorierestriction",
      "indices" : [ 54, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784772527885352960",
  "text" : "RT @LifeExtension: This analog of #resveratrol mimics #calorierestriction and offers a range of powerful health benefits: https:\/\/t.co\/y85i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "resveratrol",
        "indices" : [ 15, 27 ]
      }, {
        "text" : "calorierestriction",
        "indices" : [ 35, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/y85iufraON",
        "expanded_url" : "http:\/\/trib.al\/BweS0XP",
        "display_url" : "trib.al\/BweS0XP"
      } ]
    },
    "geo" : { },
    "id_str" : "784763055456546816",
    "text" : "This analog of #resveratrol mimics #calorierestriction and offers a range of powerful health benefits: https:\/\/t.co\/y85iufraON",
    "id" : 784763055456546816,
    "created_at" : "2016-10-08 14:31:07 +0000",
    "user" : {
      "name" : "Life Extension",
      "screen_name" : "LifeExtension",
      "protected" : false,
      "id_str" : "27188645",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466584195842592768\/C9ajd_Y__normal.jpeg",
      "id" : 27188645,
      "verified" : false
    }
  },
  "id" : 784772527885352960,
  "created_at" : "2016-10-08 15:08:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784769436154728448",
  "text" : "I just did get a facebook friend request from a nice looking brown eyed girl. If she is real I might accept.",
  "id" : 784769436154728448,
  "created_at" : "2016-10-08 14:56:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Final Fantasy XV",
      "screen_name" : "FFXVEN",
      "indices" : [ 3, 10 ],
      "id_str" : "3448803028",
      "id" : 3448803028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784766185678266368",
  "text" : "RT @FFXVEN: Good Morning #NYCC#2016\uD83D\uDDFD! We are starting the day with a full crowd! Guests who play will get the grey Noctis &amp; Regis shirt! #f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FFXVEN\/status\/784763256225292288\/photo\/1",
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/y1RwiGJpsL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuQKA5XWYAAadyJ.jpg",
        "id_str" : "784763245584343040",
        "id" : 784763245584343040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuQKA5XWYAAadyJ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/y1RwiGJpsL"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/FFXVEN\/status\/784763256225292288\/photo\/1",
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/y1RwiGJpsL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuQKAuAXgAAynsA.jpg",
        "id_str" : "784763242535157760",
        "id" : 784763242535157760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuQKAuAXgAAynsA.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/y1RwiGJpsL"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/FFXVEN\/status\/784763256225292288\/photo\/1",
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/y1RwiGJpsL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuQKAt-WgAAOsyV.jpg",
        "id_str" : "784763242526703616",
        "id" : 784763242526703616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuQKAt-WgAAOsyV.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/y1RwiGJpsL"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/FFXVEN\/status\/784763256225292288\/photo\/1",
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/y1RwiGJpsL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuQKAt9XEAEHFCx.jpg",
        "id_str" : "784763242522546177",
        "id" : 784763242522546177,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuQKAt9XEAEHFCx.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/y1RwiGJpsL"
      } ],
      "hashtags" : [ {
        "text" : "ffxv",
        "indices" : [ 129, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "784763256225292288",
    "text" : "Good Morning #NYCC#2016\uD83D\uDDFD! We are starting the day with a full crowd! Guests who play will get the grey Noctis &amp; Regis shirt! #ffxv https:\/\/t.co\/y1RwiGJpsL",
    "id" : 784763256225292288,
    "created_at" : "2016-10-08 14:31:55 +0000",
    "user" : {
      "name" : "Final Fantasy XV",
      "screen_name" : "FFXVEN",
      "protected" : false,
      "id_str" : "3448803028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719468170835271681\/WDEOuMHI_normal.jpg",
      "id" : 3448803028,
      "verified" : true
    }
  },
  "id" : 784766185678266368,
  "created_at" : "2016-10-08 14:43:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/dFFNRw9SA7",
      "expanded_url" : "http:\/\/www.breitbart.com\/tech\/2016\/01\/09\/twitter-declares-war-on-conservative-media-unverifies-breitbart-tech-editor\/",
      "display_url" : "breitbart.com\/tech\/2016\/01\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "784765973324783616",
  "text" : "Twitter Declares War On Conservative Media, Unverifies Breitbart Tech Editor https:\/\/t.co\/dFFNRw9SA7",
  "id" : 784765973324783616,
  "created_at" : "2016-10-08 14:42:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784764833128452096",
  "text" : "OSF is double authenticated with a QR code too. So don't even try to hack me.",
  "id" : 784764833128452096,
  "created_at" : "2016-10-08 14:38:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 69, 77 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/sBFQZbFPlC",
      "expanded_url" : "https:\/\/youtu.be\/4ebx-TCiH8M",
      "display_url" : "youtu.be\/4ebx-TCiH8M"
    } ]
  },
  "geo" : { },
  "id_str" : "784760757418332160",
  "text" : "Oasis - I Can See A Liar (album version) https:\/\/t.co\/sBFQZbFPlC via @YouTube",
  "id" : 784760757418332160,
  "created_at" : "2016-10-08 14:21:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/2Ng8CaxV2e",
      "expanded_url" : "http:\/\/EzineArticles.com\/1939354",
      "display_url" : "EzineArticles.com\/1939354"
    } ]
  },
  "geo" : { },
  "id_str" : "784760164188651520",
  "text" : "Reading 'Fear of Computers - How to Stop Being Afraid of Computers' here: https:\/\/t.co\/2Ng8CaxV2e",
  "id" : 784760164188651520,
  "created_at" : "2016-10-08 14:19:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MIT OpenCourseWare",
      "screen_name" : "MITOCW",
      "indices" : [ 3, 10 ],
      "id_str" : "19540483",
      "id" : 19540483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/iz83NkEmFO",
      "expanded_url" : "http:\/\/ow.ly\/SLUc304Yam0",
      "display_url" : "ow.ly\/SLUc304Yam0"
    }, {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/sqRUniddmw",
      "expanded_url" : "http:\/\/ow.ly\/xf72304YbbX",
      "display_url" : "ow.ly\/xf72304YbbX"
    } ]
  },
  "geo" : { },
  "id_str" : "784759616819359745",
  "text" : "RT @MITOCW: Free calculus homework help videos--87 of them!  https:\/\/t.co\/iz83NkEmFO \n\nMore calc resources: https:\/\/t.co\/sqRUniddmw #ispeak\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MITOCW\/status\/784759096486526976\/photo\/1",
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/FT7MucG6m1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuQGPKkWcAEC6B_.jpg",
        "id_str" : "784759092673933313",
        "id" : 784759092673933313,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuQGPKkWcAEC6B_.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/FT7MucG6m1"
      } ],
      "hashtags" : [ {
        "text" : "ispeakcalculus",
        "indices" : [ 120, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/iz83NkEmFO",
        "expanded_url" : "http:\/\/ow.ly\/SLUc304Yam0",
        "display_url" : "ow.ly\/SLUc304Yam0"
      }, {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/sqRUniddmw",
        "expanded_url" : "http:\/\/ow.ly\/xf72304YbbX",
        "display_url" : "ow.ly\/xf72304YbbX"
      } ]
    },
    "geo" : { },
    "id_str" : "784759096486526976",
    "text" : "Free calculus homework help videos--87 of them!  https:\/\/t.co\/iz83NkEmFO \n\nMore calc resources: https:\/\/t.co\/sqRUniddmw #ispeakcalculus https:\/\/t.co\/FT7MucG6m1",
    "id" : 784759096486526976,
    "created_at" : "2016-10-08 14:15:23 +0000",
    "user" : {
      "name" : "MIT OpenCourseWare",
      "screen_name" : "MITOCW",
      "protected" : false,
      "id_str" : "19540483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568117575792336896\/IAullcXh_normal.png",
      "id" : 19540483,
      "verified" : false
    }
  },
  "id" : 784759616819359745,
  "created_at" : "2016-10-08 14:17:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784759557365100544",
  "text" : "I am writing a sociology paper about social networks in general not just social media.I hope to have it done by January.",
  "id" : 784759557365100544,
  "created_at" : "2016-10-08 14:17:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784757312997195781",
  "text" : "I am trying to do more for you than just a loan always have been.",
  "id" : 784757312997195781,
  "created_at" : "2016-10-08 14:08:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/Fb7qBf5Z3z",
      "expanded_url" : "http:\/\/politi.co\/2cxAzQw",
      "display_url" : "politi.co\/2cxAzQw"
    } ]
  },
  "geo" : { },
  "id_str" : "784756784275783681",
  "text" : "Clinton is right about Trump's 'very small' $14 million loan https:\/\/t.co\/Fb7qBf5Z3z",
  "id" : 784756784275783681,
  "created_at" : "2016-10-08 14:06:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784756212390830081",
  "text" : "Trump won't get you any money he's a liar. I didn't vote for either, but defiantly not Trump.All he'll possibly get you are loans.",
  "id" : 784756212390830081,
  "created_at" : "2016-10-08 14:03:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/dIp9ZBe59e",
      "expanded_url" : "https:\/\/twitter.com\/ZDNet\/status\/784751523523887108",
      "display_url" : "twitter.com\/ZDNet\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "784754907907850243",
  "text" : "I might login to my Azure account. https:\/\/t.co\/dIp9ZBe59e",
  "id" : 784754907907850243,
  "created_at" : "2016-10-08 13:58:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784330589541281792",
  "text" : "I've already voted in this election by absentee. I voted of Sen Joe Donnelly.  he is pro-life and against guns.",
  "id" : 784330589541281792,
  "created_at" : "2016-10-07 09:52:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784321665584869376",
  "text" : "Thanks for the follow \"social report\" I would like to finally know what these networks have said about me. I'm not in the wrong.",
  "id" : 784321665584869376,
  "created_at" : "2016-10-07 09:17:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quantum",
      "screen_name" : "QuantumCorp",
      "indices" : [ 3, 15 ],
      "id_str" : "57387160",
      "id" : 57387160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/LObrjRePMI",
      "expanded_url" : "https:\/\/cards.twitter.com\/cards\/p0r2g9\/2b5ip",
      "display_url" : "cards.twitter.com\/cards\/p0r2g9\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "784321064461410309",
  "text" : "RT @QuantumCorp: Quantum is announcing a redesigned platform to handle unstructured data growth. https:\/\/t.co\/LObrjRePMI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/LObrjRePMI",
        "expanded_url" : "https:\/\/cards.twitter.com\/cards\/p0r2g9\/2b5ip",
        "display_url" : "cards.twitter.com\/cards\/p0r2g9\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "784132820289617924",
    "text" : "Quantum is announcing a redesigned platform to handle unstructured data growth. https:\/\/t.co\/LObrjRePMI",
    "id" : 784132820289617924,
    "created_at" : "2016-10-06 20:46:47 +0000",
    "user" : {
      "name" : "Quantum",
      "screen_name" : "QuantumCorp",
      "protected" : false,
      "id_str" : "57387160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000336063546\/2017d01ce8fc22c566eb98b518a0cd96_normal.jpeg",
      "id" : 57387160,
      "verified" : true
    }
  },
  "id" : 784321064461410309,
  "created_at" : "2016-10-07 09:14:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/N1FLM0mXrz",
      "expanded_url" : "http:\/\/arstechnica.com\/?post_type=post&p=437793",
      "display_url" : "arstechnica.com\/?post_type=pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "784068684948078592",
  "text" : "How Boeing merges its data centers with the Amazon and Microsoft clouds https:\/\/t.co\/N1FLM0mXrz Boeing uses .NET.",
  "id" : 784068684948078592,
  "created_at" : "2016-10-06 16:31:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 0, 6 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783465970434277376",
  "in_reply_to_user_id" : 1536791610,
  "text" : "@POTUS Mr. President I've had it with so much rejection in SWVA after all my hard work please do something about Facebook.",
  "id" : 783465970434277376,
  "created_at" : "2016-10-05 00:36:58 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/B8IXPNvPpB",
      "expanded_url" : "https:\/\/goo.gl\/W62zch",
      "display_url" : "goo.gl\/W62zch"
    } ]
  },
  "geo" : { },
  "id_str" : "783247069028945920",
  "text" : "We demand that the Seattle Police Department opened a case KURT COBAIN https:\/\/t.co\/B8IXPNvPpB Please sign the petition.",
  "id" : 783247069028945920,
  "created_at" : "2016-10-04 10:07:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783230689173004288",
  "text" : "That's really all I am to you isn't it a damn battery.",
  "id" : 783230689173004288,
  "created_at" : "2016-10-04 09:02:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 70, 78 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/5mxtz3MIus",
      "expanded_url" : "https:\/\/youtu.be\/6ZAmtYxfGxs",
      "display_url" : "youtu.be\/6ZAmtYxfGxs"
    } ]
  },
  "geo" : { },
  "id_str" : "783040101760761857",
  "text" : "Aerosmith - I'm down - Houston 02-15-1988 https:\/\/t.co\/5mxtz3MIus via @YouTube",
  "id" : 783040101760761857,
  "created_at" : "2016-10-03 20:24:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783039568362741761",
  "text" : "Downloaded another open source VST. Linux source I hate Linux. I'll build it for Windows.",
  "id" : 783039568362741761,
  "created_at" : "2016-10-03 20:22:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783038458583519232",
  "text" : "Klotho was working at it's finest today.",
  "id" : 783038458583519232,
  "created_at" : "2016-10-03 20:18:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783034974148653060",
  "text" : "beautiful women are insecure and make there men fat to make themselves feel better.",
  "id" : 783034974148653060,
  "created_at" : "2016-10-03 20:04:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 51, 59 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/I1tWDdKONu",
      "expanded_url" : "https:\/\/youtu.be\/cF0Ai5i3gjk",
      "display_url" : "youtu.be\/cF0Ai5i3gjk"
    } ]
  },
  "geo" : { },
  "id_str" : "783028993821929478",
  "text" : "KMFDM - Rip The System https:\/\/t.co\/I1tWDdKONu via @YouTube",
  "id" : 783028993821929478,
  "created_at" : "2016-10-03 19:40:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783027990447919105",
  "text" : "It's sad when all of the hot women run away from intelligent good looking men. Sad time for America.",
  "id" : 783027990447919105,
  "created_at" : "2016-10-03 19:36:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783027652835827713",
  "text" : "They didn't know what to say he said he would have to get back with me I have his card.",
  "id" : 783027652835827713,
  "created_at" : "2016-10-03 19:35:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783027371691667456",
  "text" : "Scored the bank today threw a 15 year old experienced former Merrill Lynch advisor a curve ball with one law document.",
  "id" : 783027371691667456,
  "created_at" : "2016-10-03 19:34:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/jbeGjL1mNV",
      "expanded_url" : "http:\/\/wpo.st\/PeD22",
      "display_url" : "wpo.st\/PeD22"
    } ]
  },
  "geo" : { },
  "id_str" : "782984817679929344",
  "text" : "Gravitational wave detection is a favorite for the 2016 physics Nobel Prize https:\/\/t.co\/jbeGjL1mNV",
  "id" : 782984817679929344,
  "created_at" : "2016-10-03 16:45:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782984432340860928",
  "text" : "I just built an integrated Abelton Live VST.",
  "id" : 782984432340860928,
  "created_at" : "2016-10-03 16:43:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782982896592224256",
  "text" : "Smart people don't tell the beautiful people how to do anything on social media they are just using you.",
  "id" : 782982896592224256,
  "created_at" : "2016-10-03 16:37:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782950218266542084",
  "text" : "My hair is growing again thanks to the carcinogenic free shampoo and body wash.",
  "id" : 782950218266542084,
  "created_at" : "2016-10-03 14:27:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782949336737017857",
  "text" : "\"The kids should defend themselves against the 70's it's not reality, just someone else's sentimentality.",
  "id" : 782949336737017857,
  "created_at" : "2016-10-03 14:24:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782948987229859840",
  "text" : "They will probably ask me to be a godfather to their child first I will just say no.",
  "id" : 782948987229859840,
  "created_at" : "2016-10-03 14:22:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "American Mensa",
      "screen_name" : "AmericanMensa",
      "indices" : [ 3, 17 ],
      "id_str" : "16128259",
      "id" : 16128259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/Utg8nzn3wM",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/programmes\/p0490wzp#play",
      "display_url" : "bbc.co.uk\/programmes\/p04\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782948325351981057",
  "text" : "RT @AmericanMensa: BBC's Rachael Gillman speaks to Mensa archivist Ian Fergus about the society's founding https:\/\/t.co\/Utg8nzn3wM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/Utg8nzn3wM",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/programmes\/p0490wzp#play",
        "display_url" : "bbc.co.uk\/programmes\/p04\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "782938541944737792",
    "text" : "BBC's Rachael Gillman speaks to Mensa archivist Ian Fergus about the society's founding https:\/\/t.co\/Utg8nzn3wM",
    "id" : 782938541944737792,
    "created_at" : "2016-10-03 13:41:09 +0000",
    "user" : {
      "name" : "American Mensa",
      "screen_name" : "AmericanMensa",
      "protected" : false,
      "id_str" : "16128259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643461590625357825\/RCeSXbed_normal.jpg",
      "id" : 16128259,
      "verified" : true
    }
  },
  "id" : 782948325351981057,
  "created_at" : "2016-10-03 14:20:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBM Big Data",
      "screen_name" : "IBMBigData",
      "indices" : [ 3, 14 ],
      "id_str" : "267283568",
      "id" : 267283568
    }, {
      "name" : "Uday Tekumalla",
      "screen_name" : "udayte",
      "indices" : [ 17, 24 ],
      "id_str" : "34931516",
      "id" : 34931516
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DataScientists",
      "indices" : [ 32, 47 ]
    }, {
      "text" : "IBMWoW",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/qb8NqZ8d9j",
      "expanded_url" : "http:\/\/ibm.com\/insight",
      "display_url" : "ibm.com\/insight"
    } ]
  },
  "geo" : { },
  "id_str" : "782947755887095808",
  "text" : "RT @IBMbigdata: .@udayte on why #DataScientists can\u2019t afford to miss #IBMWoW. \nRegister today: https:\/\/t.co\/qb8NqZ8d9j \nhttps:\/\/t.co\/yKAOhj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Uday Tekumalla",
        "screen_name" : "udayte",
        "indices" : [ 1, 8 ],
        "id_str" : "34931516",
        "id" : 34931516
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DataScientists",
        "indices" : [ 16, 31 ]
      }, {
        "text" : "IBMWoW",
        "indices" : [ 53, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/qb8NqZ8d9j",
        "expanded_url" : "http:\/\/ibm.com\/insight",
        "display_url" : "ibm.com\/insight"
      }, {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/yKAOhj0vpc",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=3o7xpBLpKaU",
        "display_url" : "youtube.com\/watch?v=3o7xpB\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "782945861487759360",
    "text" : ".@udayte on why #DataScientists can\u2019t afford to miss #IBMWoW. \nRegister today: https:\/\/t.co\/qb8NqZ8d9j \nhttps:\/\/t.co\/yKAOhj0vpc",
    "id" : 782945861487759360,
    "created_at" : "2016-10-03 14:10:14 +0000",
    "user" : {
      "name" : "IBM Big Data",
      "screen_name" : "IBMBigData",
      "protected" : false,
      "id_str" : "267283568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795689250129899520\/teG0s8AW_normal.jpg",
      "id" : 267283568,
      "verified" : true
    }
  },
  "id" : 782947755887095808,
  "created_at" : "2016-10-03 14:17:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFLScience",
      "screen_name" : "IFLScience",
      "indices" : [ 48, 59 ],
      "id_str" : "838464523",
      "id" : 838464523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/fIjfzlNw5a",
      "expanded_url" : "http:\/\/www.iflscience.com\/health-and-medicine\/scientists-reverse-aging-human-cells-line\/",
      "display_url" : "iflscience.com\/health-and-med\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782933395508699141",
  "text" : "Scientists Reverse Aging In Human Cell Line via @IFLScience: https:\/\/t.co\/fIjfzlNw5a",
  "id" : 782933395508699141,
  "created_at" : "2016-10-03 13:20:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Moore",
      "screen_name" : "Moore",
      "indices" : [ 0, 6 ],
      "id_str" : "9632752",
      "id" : 9632752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782792541959774212",
  "in_reply_to_user_id" : 9632752,
  "text" : "@Moore Like the social networks? I bet your wife has cheated on you.",
  "id" : 782792541959774212,
  "created_at" : "2016-10-03 04:01:00 +0000",
  "in_reply_to_screen_name" : "Moore",
  "in_reply_to_user_id_str" : "9632752",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Moore",
      "screen_name" : "Moore",
      "indices" : [ 0, 6 ],
      "id_str" : "9632752",
      "id" : 9632752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782791518201475072",
  "in_reply_to_user_id" : 9632752,
  "text" : "@Moore it's an HTML5 video with a gradient how hard is that?",
  "id" : 782791518201475072,
  "created_at" : "2016-10-03 03:56:56 +0000",
  "in_reply_to_screen_name" : "Moore",
  "in_reply_to_user_id_str" : "9632752",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Moore",
      "screen_name" : "Moore",
      "indices" : [ 0, 6 ],
      "id_str" : "9632752",
      "id" : 9632752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782789821521592320",
  "in_reply_to_user_id" : 9632752,
  "text" : "@Moore You know I scored you with the higgs boson I want your domain.",
  "id" : 782789821521592320,
  "created_at" : "2016-10-03 03:50:11 +0000",
  "in_reply_to_screen_name" : "Moore",
  "in_reply_to_user_id_str" : "9632752",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782788941816684544",
  "text" : "I'm not revealing anymore secrets until I get married can't tolerate how people use me.",
  "id" : 782788941816684544,
  "created_at" : "2016-10-03 03:46:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782788214121721856",
  "text" : "They do need to talk to me about my PhD too.",
  "id" : 782788214121721856,
  "created_at" : "2016-10-03 03:43:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Economic Forum",
      "screen_name" : "wef",
      "indices" : [ 123, 127 ],
      "id_str" : "5120691",
      "id" : 5120691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/ZZhoXwPtbl",
      "expanded_url" : "https:\/\/www.weforum.org\/agenda\/2016\/09\/scientists-studied-5-000-gifted-children-for-45-years-this-is-what-they-learned-about-success\/",
      "display_url" : "weforum.org\/agenda\/2016\/09\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782787856574152704",
  "text" : "Scientists studied 5,000 gifted children for 45 years. This is what they learned about success https:\/\/t.co\/ZZhoXwPtbl via @wef",
  "id" : 782787856574152704,
  "created_at" : "2016-10-03 03:42:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/mHbw57xVt7",
      "expanded_url" : "https:\/\/www.moogmusic.com\/products\/apps\/voyager-plug-se-vstau",
      "display_url" : "moogmusic.com\/products\/apps\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782785034717659136",
  "text" : "https:\/\/t.co\/mHbw57xVt7",
  "id" : 782785034717659136,
  "created_at" : "2016-10-03 03:31:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782784735659556865",
  "text" : "Reznor I hope you liked the Voyager VST I tweeted you. It was official Moog.",
  "id" : 782784735659556865,
  "created_at" : "2016-10-03 03:29:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782782329156726784",
  "text" : "The Song 'Earth' just isn't going to make it after watching 'soaked in bleach'.",
  "id" : 782782329156726784,
  "created_at" : "2016-10-03 03:20:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782780021257695232",
  "text" : "I do have the views and following.",
  "id" : 782780021257695232,
  "created_at" : "2016-10-03 03:11:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782779953851006976",
  "text" : "I'm not adding myself as an artist on Equipment board yet because I haven't toured and won't and don't have a verified Twitter account.",
  "id" : 782779953851006976,
  "created_at" : "2016-10-03 03:10:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782777604323631105",
  "text" : "Mine sounds good in beats or bose.",
  "id" : 782777604323631105,
  "created_at" : "2016-10-03 03:01:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782777506831208452",
  "text" : "I really don't know why Google wants to make consumer speakers sound good when people really should buy studio monitors.",
  "id" : 782777506831208452,
  "created_at" : "2016-10-03 03:01:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/TidJFuSxgL",
      "expanded_url" : "https:\/\/www.shoutcast.com\/",
      "display_url" : "shoutcast.com"
    } ]
  },
  "geo" : { },
  "id_str" : "782771425799245824",
  "text" : "https:\/\/t.co\/TidJFuSxgL Don't let Winamp Die.",
  "id" : 782771425799245824,
  "created_at" : "2016-10-03 02:37:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782770440192286720",
  "text" : "I am going to say this once more. Planes cause environmental damage All I want is to stay, engineer, make music, learn,and have radio shows.",
  "id" : 782770440192286720,
  "created_at" : "2016-10-03 02:33:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782762937383518208",
  "text" : "My Dean is a classic Dean guitar I really don't know want model yet.",
  "id" : 782762937383518208,
  "created_at" : "2016-10-03 02:03:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Equipboard",
      "screen_name" : "Equipboard",
      "indices" : [ 16, 27 ],
      "id_str" : "871993495",
      "id" : 871993495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/WYWnXXc3d5",
      "expanded_url" : "http:\/\/equipboard.com\/jdm7dv?src=twitter",
      "display_url" : "equipboard.com\/jdm7dv?src=twi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782762189224550400",
  "text" : "I'm building my @Equipboard, come check out the music gear I use. https:\/\/t.co\/WYWnXXc3d5",
  "id" : 782762189224550400,
  "created_at" : "2016-10-03 02:00:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/GiYxlUpSms",
      "expanded_url" : "https:\/\/exemplore.com\/paranormal\/Do-Ghosts-Exist-Evidence",
      "display_url" : "exemplore.com\/paranormal\/Do-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782554092551938048",
  "text" : "Scientific Evidence and Proof That Ghosts Exist https:\/\/t.co\/GiYxlUpSms 2016 evp and emf",
  "id" : 782554092551938048,
  "created_at" : "2016-10-02 12:13:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NOVA Physics",
      "screen_name" : "novaphysics",
      "indices" : [ 79, 91 ],
      "id_str" : "390814062",
      "id" : 390814062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/Ea2nCLnjzI",
      "expanded_url" : "http:\/\/www.pbs.org\/wgbh\/nova\/blogs\/physics\/?p=1753",
      "display_url" : "pbs.org\/wgbh\/nova\/blog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782548534247784448",
  "text" : "How Many Dimensions Does the Universe Really Have? https:\/\/t.co\/Ea2nCLnjzI via @novaphysics",
  "id" : 782548534247784448,
  "created_at" : "2016-10-02 11:51:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Seattle Times",
      "screen_name" : "seattletimes",
      "indices" : [ 84, 97 ],
      "id_str" : "14352556",
      "id" : 14352556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/00zdxNk90h",
      "expanded_url" : "http:\/\/www.seattletimes.com\/seattle-news\/politics\/initiative-seeks-to-get-corporate-money-out-of-politics\/?utm_source=twitter&utm_medium=social&utm_campaign=article_left_1.1",
      "display_url" : "seattletimes.com\/seattle-news\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782480912785219584",
  "text" : "Initiative seeks to get corporate money out of politics https:\/\/t.co\/00zdxNk90h via @seattletimes",
  "id" : 782480912785219584,
  "created_at" : "2016-10-02 07:22:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/UwkNQFlXMt",
      "expanded_url" : "https:\/\/twitter.com\/techreview\/status\/782233667888439297",
      "display_url" : "twitter.com\/techreview\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782300563945955328",
  "text" : "He should come back. https:\/\/t.co\/UwkNQFlXMt",
  "id" : 782300563945955328,
  "created_at" : "2016-10-01 19:26:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Authentic Skincare",
      "screen_name" : "BrinkleyBeauty",
      "indices" : [ 3, 18 ],
      "id_str" : "2482611997",
      "id" : 2482611997
    }, {
      "name" : "WAG Magazine",
      "screen_name" : "WAGmagazine",
      "indices" : [ 38, 50 ],
      "id_str" : "250850075",
      "id" : 250850075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "christiebrinkleyauthenticskincare",
      "indices" : [ 84, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782299827187122177",
  "text" : "RT @BrinkleyBeauty: Thanks so much to @WAGmagazine for giving everyone the scoop on #christiebrinkleyauthenticskincare! https:\/\/t.co\/kXYJbL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WAG Magazine",
        "screen_name" : "WAGmagazine",
        "indices" : [ 18, 30 ],
        "id_str" : "250850075",
        "id" : 250850075
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BrinkleyBeauty\/status\/782252637194448900\/photo\/1",
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/bspNd0pCDD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtseoFmXgAAqWz7.jpg",
        "id_str" : "782252634325614592",
        "id" : 782252634325614592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtseoFmXgAAqWz7.jpg",
        "sizes" : [ {
          "h" : 816,
          "resize" : "fit",
          "w" : 1101
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 1101
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 1101
        } ],
        "display_url" : "pic.twitter.com\/bspNd0pCDD"
      } ],
      "hashtags" : [ {
        "text" : "christiebrinkleyauthenticskincare",
        "indices" : [ 64, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/kXYJbLB5r5",
        "expanded_url" : "http:\/\/bit.ly\/2clwzFj",
        "display_url" : "bit.ly\/2clwzFj"
      } ]
    },
    "geo" : { },
    "id_str" : "782252637194448900",
    "text" : "Thanks so much to @WAGmagazine for giving everyone the scoop on #christiebrinkleyauthenticskincare! https:\/\/t.co\/kXYJbLB5r5 https:\/\/t.co\/bspNd0pCDD",
    "id" : 782252637194448900,
    "created_at" : "2016-10-01 16:15:36 +0000",
    "user" : {
      "name" : "Authentic Skincare",
      "screen_name" : "BrinkleyBeauty",
      "protected" : false,
      "id_str" : "2482611997",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/803327261424291840\/AZq9BcdL_normal.jpg",
      "id" : 2482611997,
      "verified" : false
    }
  },
  "id" : 782299827187122177,
  "created_at" : "2016-10-01 19:23:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/mrpze54vyW",
      "expanded_url" : "https:\/\/twitter.com\/LifeExtension\/status\/782282699859951616",
      "display_url" : "twitter.com\/LifeExtension\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782299210091753473",
  "text" : "I have gone through a lot of pain. https:\/\/t.co\/mrpze54vyW",
  "id" : 782299210091753473,
  "created_at" : "2016-10-01 19:20:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/y19sMdancn",
      "expanded_url" : "https:\/\/support.google.com\/mail\/answer\/6579?src=soctw",
      "display_url" : "support.google.com\/mail\/answer\/65\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782298564869357568",
  "text" : "https:\/\/t.co\/y19sMdancn Create rules or filters for your Gmail. Reminds me of Outlook.",
  "id" : 782298564869357568,
  "created_at" : "2016-10-01 19:18:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/h7BfX3EtAU",
      "expanded_url" : "https:\/\/youtu.be\/BoTF67O5jx4",
      "display_url" : "youtu.be\/BoTF67O5jx4"
    } ]
  },
  "geo" : { },
  "id_str" : "782285413406896129",
  "text" : "Nine Inch Nails - All Time Low https:\/\/t.co\/h7BfX3EtAU via @YouTube",
  "id" : 782285413406896129,
  "created_at" : "2016-10-01 18:25:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/t6LbM5Q0Ip",
      "expanded_url" : "https:\/\/twitter.com\/moogmusicinc\/status\/782254562564505600",
      "display_url" : "twitter.com\/moogmusicinc\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782265810576404481",
  "text" : "Reznor's a geek too. https:\/\/t.co\/t6LbM5Q0Ip",
  "id" : 782265810576404481,
  "created_at" : "2016-10-01 17:07:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782265307339583488",
  "text" : "I can't find the torrent I wanted the PDF. I guess I will just have to buy it. I did tell her first. I won.",
  "id" : 782265307339583488,
  "created_at" : "2016-10-01 17:05:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782260909196673025",
  "text" : "I'm buying one more book today or tomorrow a financial law book. I t probably the best book on it too. I just might not read it.",
  "id" : 782260909196673025,
  "created_at" : "2016-10-01 16:48:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782242610257731584",
  "text" : "Soon I'll be learning about Einstein and the hydrogen atom.",
  "id" : 782242610257731584,
  "created_at" : "2016-10-01 15:35:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782241786236399616",
  "text" : "If I wanted too Bono I could become the largest person on Twitter.",
  "id" : 782241786236399616,
  "created_at" : "2016-10-01 15:32:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 104, 112 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/D7M0zsHpgH",
      "expanded_url" : "https:\/\/youtu.be\/JwHWeIqb9Zs",
      "display_url" : "youtu.be\/JwHWeIqb9Zs"
    } ]
  },
  "geo" : { },
  "id_str" : "782240350920384513",
  "text" : "17 - U2 - Where the Streets Have No Name (Live from Mexico City) - with ... https:\/\/t.co\/D7M0zsHpgH via @YouTube",
  "id" : 782240350920384513,
  "created_at" : "2016-10-01 15:26:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 104, 112 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/wbp8tV27gG",
      "expanded_url" : "https:\/\/youtu.be\/QFAgV-zPUL4",
      "display_url" : "youtu.be\/QFAgV-zPUL4"
    } ]
  },
  "geo" : { },
  "id_str" : "782238575228321792",
  "text" : "10 - U2 - I Still Haven't Found What I'm Looking For (Live from Mexico C... https:\/\/t.co\/wbp8tV27gG via @YouTube Found it and got rejected.",
  "id" : 782238575228321792,
  "created_at" : "2016-10-01 15:19:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782236592949882880",
  "text" : "Pay for that article ACM? No.",
  "id" : 782236592949882880,
  "created_at" : "2016-10-01 15:11:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mayo Clinic",
      "screen_name" : "MayoClinic",
      "indices" : [ 3, 14 ],
      "id_str" : "14592723",
      "id" : 14592723
    }, {
      "name" : "Judy Boughey",
      "screen_name" : "DrJudyBoughey",
      "indices" : [ 42, 56 ],
      "id_str" : "1482479442",
      "id" : 1482479442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MayoClinicRadio",
      "indices" : [ 24, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782234807510106112",
  "text" : "RT @MayoClinic: Next on #MayoClinicRadio, @DrJudyBoughey discusses new recommendations for contralateral prophylactic mastectomy. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Judy Boughey",
        "screen_name" : "DrJudyBoughey",
        "indices" : [ 26, 40 ],
        "id_str" : "1482479442",
        "id" : 1482479442
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MayoClinic\/status\/782227323324080128\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/ZFIanTO0v4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtsHmrJWgAEKVCy.jpg",
        "id_str" : "782227321277284353",
        "id" : 782227321277284353,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtsHmrJWgAEKVCy.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ZFIanTO0v4"
      } ],
      "hashtags" : [ {
        "text" : "MayoClinicRadio",
        "indices" : [ 8, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782227323324080128",
    "text" : "Next on #MayoClinicRadio, @DrJudyBoughey discusses new recommendations for contralateral prophylactic mastectomy. https:\/\/t.co\/ZFIanTO0v4",
    "id" : 782227323324080128,
    "created_at" : "2016-10-01 14:35:01 +0000",
    "user" : {
      "name" : "Mayo Clinic",
      "screen_name" : "MayoClinic",
      "protected" : false,
      "id_str" : "14592723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760454818422857728\/2WFm5vUI_normal.jpg",
      "id" : 14592723,
      "verified" : true
    }
  },
  "id" : 782234807510106112,
  "created_at" : "2016-10-01 15:04:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 80, 88 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/stg1u9J0uW",
      "expanded_url" : "https:\/\/youtu.be\/hkwcehPhOXw",
      "display_url" : "youtu.be\/hkwcehPhOXw"
    } ]
  },
  "geo" : { },
  "id_str" : "782233949359734784",
  "text" : "Bad Religion - I Love My Computer - The New America https:\/\/t.co\/stg1u9J0uW via @YouTube",
  "id" : 782233949359734784,
  "created_at" : "2016-10-01 15:01:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Community Grid",
      "screen_name" : "WCGrid",
      "indices" : [ 3, 10 ],
      "id_str" : "26388412",
      "id" : 26388412
    }, {
      "name" : "OpenZika",
      "screen_name" : "OpenZika",
      "indices" : [ 73, 82 ],
      "id_str" : "734769368131833856",
      "id" : 734769368131833856
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WCGrid\/status\/782230953779400705\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/p0s6OdN1J3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtotG_KW8AA5LcW.jpg",
      "id_str" : "781987083359547392",
      "id" : 781987083359547392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtotG_KW8AA5LcW.jpg",
      "sizes" : [ {
        "h" : 671,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/p0s6OdN1J3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/w24NGRc8Xv",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/Science",
      "display_url" : "reddit.com\/r\/Science"
    } ]
  },
  "geo" : { },
  "id_str" : "782232103467511808",
  "text" : "RT @WCGrid: Don't miss the chance to learn more about the science behind @OpenZika! https:\/\/t.co\/w24NGRc8Xv https:\/\/t.co\/p0s6OdN1J3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenZika",
        "screen_name" : "OpenZika",
        "indices" : [ 61, 70 ],
        "id_str" : "734769368131833856",
        "id" : 734769368131833856
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WCGrid\/status\/782230953779400705\/photo\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/p0s6OdN1J3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtotG_KW8AA5LcW.jpg",
        "id_str" : "781987083359547392",
        "id" : 781987083359547392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtotG_KW8AA5LcW.jpg",
        "sizes" : [ {
          "h" : 671,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 570,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 671,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 671,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/p0s6OdN1J3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/w24NGRc8Xv",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/Science",
        "display_url" : "reddit.com\/r\/Science"
      } ]
    },
    "geo" : { },
    "id_str" : "782230953779400705",
    "text" : "Don't miss the chance to learn more about the science behind @OpenZika! https:\/\/t.co\/w24NGRc8Xv https:\/\/t.co\/p0s6OdN1J3",
    "id" : 782230953779400705,
    "created_at" : "2016-10-01 14:49:27 +0000",
    "user" : {
      "name" : "World Community Grid",
      "screen_name" : "WCGrid",
      "protected" : false,
      "id_str" : "26388412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448919987281866752\/T4oA5jtc_normal.png",
      "id" : 26388412,
      "verified" : false
    }
  },
  "id" : 782232103467511808,
  "created_at" : "2016-10-01 14:54:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782231014655594497",
  "text" : "The upper class would just raise prices to try and kill you too in the U.S. that is why I like Russia. From Russia with love.",
  "id" : 782231014655594497,
  "created_at" : "2016-10-01 14:49:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 88, 96 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/VnimpFPUDP",
      "expanded_url" : "https:\/\/youtu.be\/Ck6cCyvo5vo",
      "display_url" : "youtu.be\/Ck6cCyvo5vo"
    } ]
  },
  "geo" : { },
  "id_str" : "782227860283125761",
  "text" : "Songs - Traditional - He's Got the Whole World in His Hands https:\/\/t.co\/VnimpFPUDP via @YouTube",
  "id" : 782227860283125761,
  "created_at" : "2016-10-01 14:37:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782222767357882368",
  "text" : "I really wish people would look at the contact us of a .com. to see where they are located.",
  "id" : 782222767357882368,
  "created_at" : "2016-10-01 14:16:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782221126315438081",
  "text" : "You can run the Mendeley examples on IIS(old Apache code base) or Apache and register the \"app\" or the small example.",
  "id" : 782221126315438081,
  "created_at" : "2016-10-01 14:10:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "indices" : [ 3, 9 ],
      "id_str" : "3819701",
      "id" : 3819701
    }, {
      "name" : "Tas Bindi",
      "screen_name" : "TasnuvaB",
      "indices" : [ 111, 120 ],
      "id_str" : "746316325",
      "id" : 746316325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/ehm3NMNdqf",
      "expanded_url" : "http:\/\/zd.net\/2djgceg",
      "display_url" : "zd.net\/2djgceg"
    } ]
  },
  "geo" : { },
  "id_str" : "782218985693675520",
  "text" : "RT @ZDNet: Deakin University unveils first robotic surgical system with sense of touch https:\/\/t.co\/ehm3NMNdqf @TasnuvaB https:\/\/t.co\/gD1lQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tas Bindi",
        "screen_name" : "TasnuvaB",
        "indices" : [ 100, 109 ],
        "id_str" : "746316325",
        "id" : 746316325
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ZDNet\/status\/782214821509001216\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/gD1lQUXq1u",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ctr8O9kWYAA2fxn.jpg",
        "id_str" : "782214819277594624",
        "id" : 782214819277594624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ctr8O9kWYAA2fxn.jpg",
        "sizes" : [ {
          "h" : 487,
          "resize" : "fit",
          "w" : 770
        }, {
          "h" : 487,
          "resize" : "fit",
          "w" : 770
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 487,
          "resize" : "fit",
          "w" : 770
        } ],
        "display_url" : "pic.twitter.com\/gD1lQUXq1u"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/ehm3NMNdqf",
        "expanded_url" : "http:\/\/zd.net\/2djgceg",
        "display_url" : "zd.net\/2djgceg"
      } ]
    },
    "geo" : { },
    "id_str" : "782214821509001216",
    "text" : "Deakin University unveils first robotic surgical system with sense of touch https:\/\/t.co\/ehm3NMNdqf @TasnuvaB https:\/\/t.co\/gD1lQUXq1u",
    "id" : 782214821509001216,
    "created_at" : "2016-10-01 13:45:20 +0000",
    "user" : {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "protected" : false,
      "id_str" : "3819701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706961982545473536\/Ibj46-DX_normal.jpg",
      "id" : 3819701,
      "verified" : true
    }
  },
  "id" : 782218985693675520,
  "created_at" : "2016-10-01 14:01:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782218342866255872",
  "text" : "It is just the Mendeley Desktop source I think thanks to Austria and the EU.",
  "id" : 782218342866255872,
  "created_at" : "2016-10-01 13:59:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782216551927836673",
  "text" : "Some of the source is offline they must be moving to github. I really don't know if this platform is any good yet.",
  "id" : 782216551927836673,
  "created_at" : "2016-10-01 13:52:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782213328298991616",
  "text" : "I just got source EU. Britain I don't knot that is the EU. It's Saturady I'll work with this platform on some today. I did see the Mendeley",
  "id" : 782213328298991616,
  "created_at" : "2016-10-01 13:39:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782211612711280641",
  "text" : "Me and Germany are working on the same thing An Open Access Platform they are in beta. I downloaded the paper. Soon.",
  "id" : 782211612711280641,
  "created_at" : "2016-10-01 13:32:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mendeley API",
      "screen_name" : "mendeleyAPI",
      "indices" : [ 74, 86 ],
      "id_str" : "177222469",
      "id" : 177222469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782205791860293632",
  "text" : "I am looking a my top tweet. About the journals. Maybe I should work with @mendeleyAPI today. Schwarz they won't take me alive either.",
  "id" : 782205791860293632,
  "created_at" : "2016-10-01 13:09:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782201640011128832",
  "text" : "You can go to the Defcon website all you get there are the videos not the tools I got when I went. Maybe if you watch they might talk.",
  "id" : 782201640011128832,
  "created_at" : "2016-10-01 12:52:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782201096169254913",
  "text" : "I really don't like what is happening in Syria.",
  "id" : 782201096169254913,
  "created_at" : "2016-10-01 12:50:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 138, 161 ],
      "url" : "https:\/\/t.co\/inaA73OjIx",
      "expanded_url" : "https:\/\/twitter.com\/techreview\/status\/782199708076875776",
      "display_url" : "twitter.com\/techreview\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782200789783683072",
  "text" : "M.I.T all I want is justice too. My heritage has been destroyed in SWVA. All I have used was just my brain and the freedom of speech too. https:\/\/t.co\/inaA73OjIx",
  "id" : 782200789783683072,
  "created_at" : "2016-10-01 12:49:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782193702856978432",
  "text" : "Thanks for accepting Flora. Time to work on the old Microsoft Home. I hate my Apple Home app.",
  "id" : 782193702856978432,
  "created_at" : "2016-10-01 12:21:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/xI8bk72aNF",
      "expanded_url" : "http:\/\/www.meltingasphalt.com\/the-economics-of-social-status\/",
      "display_url" : "meltingasphalt.com\/the-economics-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782192441269088256",
  "text" : "https:\/\/t.co\/xI8bk72aNF I do have a high social status given my work. And I did get an A in sociology",
  "id" : 782192441269088256,
  "created_at" : "2016-10-01 12:16:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782190124851494912",
  "text" : "See United States it is evolution isn't it?",
  "id" : 782190124851494912,
  "created_at" : "2016-10-01 12:07:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782187577558331392",
  "text" : "I will say if America were truly open there might not be a new cold war and there is a Russian mail order bride at my fingertips.",
  "id" : 782187577558331392,
  "created_at" : "2016-10-01 11:57:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782183885501296640",
  "text" : "I do have the only open source iPS software that medical student will ever have probably unless there is something new.",
  "id" : 782183885501296640,
  "created_at" : "2016-10-01 11:42:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/jolYvXn4bc",
      "expanded_url" : "http:\/\/www.sciencemag.org\/site\/special\/privacy\/",
      "display_url" : "sciencemag.org\/site\/special\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782181073178468352",
  "text" : "https:\/\/t.co\/jolYvXn4bc The end of privacy.",
  "id" : 782181073178468352,
  "created_at" : "2016-10-01 11:31:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/u6M1SNmuRd",
      "expanded_url" : "http:\/\/www.inc.com\/john-boitnott\/3-ways-to-use-your-social-media-data-to-beat-the-competition.html",
      "display_url" : "inc.com\/john-boitnott\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782175650044055552",
  "text" : "https:\/\/t.co\/u6M1SNmuRd Mensa and the Higgs are enough.",
  "id" : 782175650044055552,
  "created_at" : "2016-10-01 11:09:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]