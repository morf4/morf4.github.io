Grailbird.data.tweets_2014_02 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/QmLqixtTp3",
      "expanded_url" : "http:\/\/fw.to\/IypyT2k",
      "display_url" : "fw.to\/IypyT2k"
    } ]
  },
  "geo" : { },
  "id_str" : "439150976608387072",
  "text" : "Why dark chocolate is good for your heart http:\/\/t.co\/QmLqixtTp3",
  "id" : 439150976608387072,
  "created_at" : "2014-02-27 21:32:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]