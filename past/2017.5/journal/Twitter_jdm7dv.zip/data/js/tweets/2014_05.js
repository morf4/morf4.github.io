Grailbird.data.tweets_2014_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/cBno7HppX3",
      "expanded_url" : "http:\/\/www.poliquingroup.com\/ArticlesMultimedia\/Articles\/Article\/980\/Tips_To_Prevent_Oxidative_Stress_For_Optimal_Body_.aspx",
      "display_url" : "poliquingroup.com\/ArticlesMultim\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "471662940794667009",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor http:\/\/t.co\/cBno7HppX3 prevent oxidative stress",
  "id" : 471662940794667009,
  "created_at" : "2014-05-28 14:43:02 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/Oh3CkEa6xF",
      "expanded_url" : "http:\/\/www.imi.europa.eu\/content\/ebisc",
      "display_url" : "imi.europa.eu\/content\/ebisc"
    } ]
  },
  "geo" : { },
  "id_str" : "471065889190973440",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor http:\/\/t.co\/Oh3CkEa6xF European bank for iPS",
  "id" : 471065889190973440,
  "created_at" : "2014-05-26 23:10:34 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468561236880543745",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor I really am trying to get FDA approval for it take it at your own risk.",
  "id" : 468561236880543745,
  "created_at" : "2014-05-20 01:17:58 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468560543885062144",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor Trent I really don't know what else say to make people talk, I will call them eloi like H.G Wells. Here is ST-5 with MigraStem",
  "id" : 468560543885062144,
  "created_at" : "2014-05-20 01:15:13 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/5rxM6fZ2Sn",
      "expanded_url" : "https:\/\/bitbucket.org\/ableton",
      "display_url" : "bitbucket.org\/ableton"
    } ]
  },
  "geo" : { },
  "id_str" : "463214461328039936",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor Ableton is on bitbucket! https:\/\/t.co\/5rxM6fZ2Sn",
  "id" : 463214461328039936,
  "created_at" : "2014-05-05 07:11:48 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]