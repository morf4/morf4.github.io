Grailbird.data.tweets_2014_03 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 81, 94 ],
      "id_str" : "19546277",
      "id" : 19546277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/xzofrSob9l",
      "expanded_url" : "http:\/\/finance.yahoo.com\/news\/p-gives-top-rating-microsofts-202133478.html?soc_src=mediacontentstory",
      "display_url" : "finance.yahoo.com\/news\/p-gives-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448893685011206145",
  "text" : "S&amp;P gives top rating to Microsoft's debt offering http:\/\/t.co\/xzofrSob9l via @YahooFinance",
  "id" : 448893685011206145,
  "created_at" : "2014-03-26 18:46:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/kJU62gwNyS",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=1E8f6SuKi1A",
      "display_url" : "youtube.com\/watch?v=1E8f6S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441298302944813056",
  "text" : "https:\/\/t.co\/kJU62gwNyS Sceil, Rejenerative Medicine.",
  "id" : 441298302944813056,
  "created_at" : "2014-03-05 19:44:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]