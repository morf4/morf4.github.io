Grailbird.data.tweets_2016_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/9sLM9AKTZx",
      "expanded_url" : "http:\/\/shr.gs\/oc0ZyaN",
      "display_url" : "shr.gs\/oc0ZyaN"
    } ]
  },
  "geo" : { },
  "id_str" : "747742122317615104",
  "text" : "100 reasons why climate change is natural https:\/\/t.co\/9sLM9AKTZx",
  "id" : 747742122317615104,
  "created_at" : "2016-06-28 10:43:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/BBc69PLDSc",
      "expanded_url" : "http:\/\/sciencenordic.com\/scientists-discover-cause-behind-prehistoric-climate-change",
      "display_url" : "sciencenordic.com\/scientists-dis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747576915050008577",
  "text" : "Scientists discover what caused prehistoric climate change. https:\/\/t.co\/BBc69PLDSc",
  "id" : 747576915050008577,
  "created_at" : "2016-06-27 23:46:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747008822665969664",
  "text" : "I really have had it with people coming into the engineers field with shitty certifications. If a hot girl from my area would ever call.",
  "id" : 747008822665969664,
  "created_at" : "2016-06-26 10:09:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746819936673202176",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne Time to eat for me sometimes I don't even want to take food.",
  "id" : 746819936673202176,
  "created_at" : "2016-06-25 21:38:42 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moog Synthesizers",
      "screen_name" : "moogmusicinc",
      "indices" : [ 3, 16 ],
      "id_str" : "26779967",
      "id" : 26779967
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOAT",
      "indices" : [ 80, 85 ]
    }, {
      "text" : "RIPBernieWorrell",
      "indices" : [ 111, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/wmbEPaWkVI",
      "expanded_url" : "http:\/\/www.moogmusic.com\/news\/thank-you-bernie-1",
      "display_url" : "moogmusic.com\/news\/thank-you\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746819614533816320",
  "text" : "RT @moogmusicinc: Thank you sweet Bernie for blessing us with the funk of life. #GOAT\n\nhttps:\/\/t.co\/wmbEPaWkVI #RIPBernieWorrell https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/moogmusicinc\/status\/746479107500806144\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/kJp3WUr49Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClwEU6oXIAALHwC.jpg",
        "id_str" : "746476395619098624",
        "id" : 746476395619098624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClwEU6oXIAALHwC.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/kJp3WUr49Z"
      } ],
      "hashtags" : [ {
        "text" : "GOAT",
        "indices" : [ 62, 67 ]
      }, {
        "text" : "RIPBernieWorrell",
        "indices" : [ 93, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/wmbEPaWkVI",
        "expanded_url" : "http:\/\/www.moogmusic.com\/news\/thank-you-bernie-1",
        "display_url" : "moogmusic.com\/news\/thank-you\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "746479107500806144",
    "text" : "Thank you sweet Bernie for blessing us with the funk of life. #GOAT\n\nhttps:\/\/t.co\/wmbEPaWkVI #RIPBernieWorrell https:\/\/t.co\/kJp3WUr49Z",
    "id" : 746479107500806144,
    "created_at" : "2016-06-24 23:04:22 +0000",
    "user" : {
      "name" : "Moog Synthesizers",
      "screen_name" : "moogmusicinc",
      "protected" : false,
      "id_str" : "26779967",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736287958584721409\/JcZWLecp_normal.jpg",
      "id" : 26779967,
      "verified" : true
    }
  },
  "id" : 746819614533816320,
  "created_at" : "2016-06-25 21:37:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 0, 11 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746371506729525250",
  "in_reply_to_user_id" : 30313925,
  "text" : "@WhiteHouse Mr. President when are you going to give me the hot 20 something after all I've accomplished?",
  "id" : 746371506729525250,
  "created_at" : "2016-06-24 15:56:48 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 0, 11 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/4Qr8yJza4S",
      "expanded_url" : "http:\/\/goo.gl\/tXzscA",
      "display_url" : "goo.gl\/tXzscA"
    } ]
  },
  "geo" : { },
  "id_str" : "746318823410761728",
  "in_reply_to_user_id" : 30313925,
  "text" : "@WhiteHouse Bioviva on aging  https:\/\/t.co\/4Qr8yJza4S",
  "id" : 746318823410761728,
  "created_at" : "2016-06-24 12:27:28 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Axl Rose",
      "screen_name" : "axlrose",
      "indices" : [ 0, 8 ],
      "id_str" : "95956928",
      "id" : 95956928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/4Qr8yJza4S",
      "expanded_url" : "http:\/\/goo.gl\/tXzscA",
      "display_url" : "goo.gl\/tXzscA"
    } ]
  },
  "geo" : { },
  "id_str" : "746315398283419648",
  "in_reply_to_user_id" : 95956928,
  "text" : "@axlrose Bioviva on aging https:\/\/t.co\/4Qr8yJza4S",
  "id" : 746315398283419648,
  "created_at" : "2016-06-24 12:13:51 +0000",
  "in_reply_to_screen_name" : "axlrose",
  "in_reply_to_user_id_str" : "95956928",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/4Qr8yJza4S",
      "expanded_url" : "http:\/\/goo.gl\/tXzscA",
      "display_url" : "goo.gl\/tXzscA"
    } ]
  },
  "geo" : { },
  "id_str" : "746315277319737344",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne Bioviva on aging https:\/\/t.co\/4Qr8yJza4S",
  "id" : 746315277319737344,
  "created_at" : "2016-06-24 12:13:22 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/4Qr8yJza4S",
      "expanded_url" : "http:\/\/goo.gl\/tXzscA",
      "display_url" : "goo.gl\/tXzscA"
    } ]
  },
  "geo" : { },
  "id_str" : "746315199909601280",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor Bioviva on aging https:\/\/t.co\/4Qr8yJza4S",
  "id" : 746315199909601280,
  "created_at" : "2016-06-24 12:13:04 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/cglDEn4feY",
      "expanded_url" : "https:\/\/www.gopetition.com\/tag\/gun%20control",
      "display_url" : "gopetition.com\/tag\/gun%20cont\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746089901788139521",
  "text" : "Guns controls petitions https:\/\/t.co\/cglDEn4feY",
  "id" : 746089901788139521,
  "created_at" : "2016-06-23 21:17:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746005378912108544",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor You might want to consider taking down those Instagram photos of you in the tux. I'm just looking out for your safety.",
  "id" : 746005378912108544,
  "created_at" : "2016-06-23 15:41:57 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746001349607890944",
  "text" : "A wage can be non cash as long as it's $600 or more. I was reading on the I.R.S website.",
  "id" : 746001349607890944,
  "created_at" : "2016-06-23 15:25:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/WlQvzIaau5",
      "expanded_url" : "https:\/\/wh.gov\/ismWx",
      "display_url" : "wh.gov\/ismWx"
    } ]
  },
  "geo" : { },
  "id_str" : "744299042394505216",
  "text" : "The Arecibo Observatory in PR is in danger of being closed or severely impaired, take action to keep it well funded. https:\/\/t.co\/WlQvzIaau5",
  "id" : 744299042394505216,
  "created_at" : "2016-06-18 22:41:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/arYiEBwxSx",
      "expanded_url" : "https:\/\/www.ted.com\/talks\/gary_slutkin_let_s_treat_violence_like_a_contagious_disease?language=en&utm_source=twitter.com&utm_medium=social&utm_campaign=tedspread",
      "display_url" : "ted.com\/talks\/gary_slu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744090201740414976",
  "text" : "Let's treat violence like a contagious disease  https:\/\/t.co\/arYiEBwxSx",
  "id" : 744090201740414976,
  "created_at" : "2016-06-18 08:51:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/FoQrsY5ffv",
      "expanded_url" : "http:\/\/www.bbc.com\/news\/science-environment-29760212",
      "display_url" : "bbc.com\/news\/science-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744089593855737857",
  "text" : "BBC News - Two genes linked with violent crime https:\/\/t.co\/FoQrsY5ffv",
  "id" : 744089593855737857,
  "created_at" : "2016-06-18 08:49:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/nl47HT9zQd",
      "expanded_url" : "http:\/\/gu.com\/p\/4dxe4\/stw",
      "display_url" : "gu.com\/p\/4dxe4\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "744087921683271680",
  "text" : "1,000 mass shootings in 1,260 days: this is what America's gun crisis looks like https:\/\/t.co\/nl47HT9zQd",
  "id" : 744087921683271680,
  "created_at" : "2016-06-18 08:42:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 77, 85 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/N2MqDpHkL8",
      "expanded_url" : "https:\/\/youtu.be\/V4A0Qya23y0",
      "display_url" : "youtu.be\/V4A0Qya23y0"
    } ]
  },
  "geo" : { },
  "id_str" : "744086776587902976",
  "text" : "Rage Against The Machine: Voice Of The Voiceless https:\/\/t.co\/N2MqDpHkL8 via @YouTube",
  "id" : 744086776587902976,
  "created_at" : "2016-06-18 08:38:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/WKTzWJA6s8",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=3-oJt_5JvV4",
      "display_url" : "youtube.com\/watch?v=3-oJt_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744085263266242560",
  "text" : "https:\/\/t.co\/WKTzWJA6s8 Pink Floyd Sheep.",
  "id" : 744085263266242560,
  "created_at" : "2016-06-18 08:32:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/6QiSNRxMuG",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/googleplus\/comments\/44h45h\/i_hate_new_design_of_g\/",
      "display_url" : "reddit.com\/r\/googleplus\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744084928447549440",
  "text" : "Why I hate the new G+ https:\/\/t.co\/6QiSNRxMuG",
  "id" : 744084928447549440,
  "created_at" : "2016-06-18 08:30:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/QJKd30ZlsU",
      "expanded_url" : "http:\/\/a.msn.com\/05\/en-us\/CCroJP?ocid=st",
      "display_url" : "a.msn.com\/05\/en-us\/CCroJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744074509905465344",
  "text" : "70 Most Popular Sodas Ranked by How Toxic They Are https:\/\/t.co\/QJKd30ZlsU",
  "id" : 744074509905465344,
  "created_at" : "2016-06-18 07:49:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743441250473414656",
  "text" : "I am really a star the area just doesn't want to admit it.",
  "id" : 743441250473414656,
  "created_at" : "2016-06-16 13:53:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "indices" : [ 3, 17 ],
      "id_str" : "34554134",
      "id" : 34554134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/30bBOynW8C",
      "expanded_url" : "http:\/\/buff.ly\/1sEdGDp",
      "display_url" : "buff.ly\/1sEdGDp"
    } ]
  },
  "geo" : { },
  "id_str" : "742757471211655168",
  "text" : "RT @SETIInstitute: VLT Snaps An Exotic Exoplanet \u201CFirst\u201D - Possible second planet around CVSO 30 https:\/\/t.co\/30bBOynW8C https:\/\/t.co\/kTo84\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SETIInstitute\/status\/742705868358221824\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/kTo84I8Tmg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck6fDNcXEAAmdeI.jpg",
        "id_str" : "742705866059747328",
        "id" : 742705866059747328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck6fDNcXEAAmdeI.jpg",
        "sizes" : [ {
          "h" : 714,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 714,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 667
        }, {
          "h" : 714,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/kTo84I8Tmg"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/30bBOynW8C",
        "expanded_url" : "http:\/\/buff.ly\/1sEdGDp",
        "display_url" : "buff.ly\/1sEdGDp"
      } ]
    },
    "geo" : { },
    "id_str" : "742705868358221824",
    "text" : "VLT Snaps An Exotic Exoplanet \u201CFirst\u201D - Possible second planet around CVSO 30 https:\/\/t.co\/30bBOynW8C https:\/\/t.co\/kTo84I8Tmg",
    "id" : 742705868358221824,
    "created_at" : "2016-06-14 13:10:52 +0000",
    "user" : {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "protected" : false,
      "id_str" : "34554134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758705567556743168\/TGjZ9Uwf_normal.jpg",
      "id" : 34554134,
      "verified" : true
    }
  },
  "id" : 742757471211655168,
  "created_at" : "2016-06-14 16:35:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742714749578809344",
  "text" : "Young dumb and full of cum you are.",
  "id" : 742714749578809344,
  "created_at" : "2016-06-14 13:46:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/y2KtFtDrSI",
      "expanded_url" : "http:\/\/goo.gl\/40CRBN",
      "display_url" : "goo.gl\/40CRBN"
    } ]
  },
  "geo" : { },
  "id_str" : "742713798189060096",
  "text" : "Disease competition from PubMed. https:\/\/t.co\/y2KtFtDrSI",
  "id" : 742713798189060096,
  "created_at" : "2016-06-14 13:42:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/VzJoy4AeNT",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=_ZpSQIyIKGw",
      "display_url" : "youtube.com\/watch?v=_ZpSQI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742711532744790016",
  "text" : "Coil absolute elsewhere .https:\/\/t.co\/VzJoy4AeNT",
  "id" : 742711532744790016,
  "created_at" : "2016-06-14 13:33:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/WjqQXDDNh1",
      "expanded_url" : "http:\/\/goo.gl\/cEks8P",
      "display_url" : "goo.gl\/cEks8P"
    } ]
  },
  "geo" : { },
  "id_str" : "742711277324226561",
  "text" : "https:\/\/t.co\/WjqQXDDNh1 Nine Inch Nails on Coil.",
  "id" : 742711277324226561,
  "created_at" : "2016-06-14 13:32:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742393307121258496",
  "text" : "The youth does just use me and tell me I can't have a hot girl after all I've given them I'm giving 3tb of my stuff to an elder.",
  "id" : 742393307121258496,
  "created_at" : "2016-06-13 16:28:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/0fD8fIL4TE",
      "expanded_url" : "https:\/\/twitter.com\/thegooglecar\/status\/742189279653199874",
      "display_url" : "twitter.com\/thegooglecar\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742345061489332224",
  "text" : "I'll always be here. https:\/\/t.co\/0fD8fIL4TE",
  "id" : 742345061489332224,
  "created_at" : "2016-06-13 13:17:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Trujillo",
      "screen_name" : "JulioTrujillo_",
      "indices" : [ 3, 18 ],
      "id_str" : "494027719",
      "id" : 494027719
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DataScience",
      "indices" : [ 23, 35 ]
    }, {
      "text" : "abdsc",
      "indices" : [ 112, 118 ]
    }, {
      "text" : "BigData",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/3I6Km3ubS1",
      "expanded_url" : "http:\/\/www.datasciencecentral.com\/m\/blogpost?id=6448529%3ABlogPost%3A432024",
      "display_url" : "datasciencecentral.com\/m\/blogpost?id=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742344651273818114",
  "text" : "RT @JulioTrujillo_: 19 #DataScience Tools for people who aren\u2019t so good at Programming: https:\/\/t.co\/3I6Km3ubS1 #abdsc #BigData https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JulioTrujillo_\/status\/741308401855135745\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/Jh86ZQ5p8d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkmoDnzWUAAQsGX.jpg",
        "id_str" : "741308393856585728",
        "id" : 741308393856585728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkmoDnzWUAAQsGX.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/Jh86ZQ5p8d"
      } ],
      "hashtags" : [ {
        "text" : "DataScience",
        "indices" : [ 3, 15 ]
      }, {
        "text" : "abdsc",
        "indices" : [ 92, 98 ]
      }, {
        "text" : "BigData",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/3I6Km3ubS1",
        "expanded_url" : "http:\/\/www.datasciencecentral.com\/m\/blogpost?id=6448529%3ABlogPost%3A432024",
        "display_url" : "datasciencecentral.com\/m\/blogpost?id=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "741308401855135745",
    "text" : "19 #DataScience Tools for people who aren\u2019t so good at Programming: https:\/\/t.co\/3I6Km3ubS1 #abdsc #BigData https:\/\/t.co\/Jh86ZQ5p8d",
    "id" : 741308401855135745,
    "created_at" : "2016-06-10 16:37:50 +0000",
    "user" : {
      "name" : "Julio Trujillo",
      "screen_name" : "JulioTrujillo_",
      "protected" : false,
      "id_str" : "494027719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543334027696939009\/450mnKkk_normal.jpeg",
      "id" : 494027719,
      "verified" : false
    }
  },
  "id" : 742344651273818114,
  "created_at" : "2016-06-13 13:15:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apple News",
      "screen_name" : "applenws",
      "indices" : [ 3, 12 ],
      "id_str" : "37019708",
      "id" : 37019708
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/applenws\/status\/742312243379863554\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/FatyyV10up",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck05Cs1VAAAj5ox.jpg",
      "id_str" : "742312232143355904",
      "id" : 742312232143355904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck05Cs1VAAAj5ox.jpg",
      "sizes" : [ {
        "h" : 361,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 307,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/FatyyV10up"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/rVArCxECGK",
      "expanded_url" : "http:\/\/applenws.com\/bethesda-and-id-software-announce-quake-champions-at-e3-2016\/2016\/mac-rumors",
      "display_url" : "applenws.com\/bethesda-and-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742343803017695232",
  "text" : "RT @applenws: Bethesda and iD Software Announce 'Quake Champions' at E3\u00A02016 https:\/\/t.co\/rVArCxECGK https:\/\/t.co\/FatyyV10up",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/applenws\/status\/742312243379863554\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/FatyyV10up",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck05Cs1VAAAj5ox.jpg",
        "id_str" : "742312232143355904",
        "id" : 742312232143355904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck05Cs1VAAAj5ox.jpg",
        "sizes" : [ {
          "h" : 361,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 307,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/FatyyV10up"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/rVArCxECGK",
        "expanded_url" : "http:\/\/applenws.com\/bethesda-and-id-software-announce-quake-champions-at-e3-2016\/2016\/mac-rumors",
        "display_url" : "applenws.com\/bethesda-and-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "742312243379863554",
    "text" : "Bethesda and iD Software Announce 'Quake Champions' at E3\u00A02016 https:\/\/t.co\/rVArCxECGK https:\/\/t.co\/FatyyV10up",
    "id" : 742312243379863554,
    "created_at" : "2016-06-13 11:06:44 +0000",
    "user" : {
      "name" : "Apple News",
      "screen_name" : "applenws",
      "protected" : false,
      "id_str" : "37019708",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639785559225954304\/XtQnsHHI_normal.jpg",
      "id" : 37019708,
      "verified" : false
    }
  },
  "id" : 742343803017695232,
  "created_at" : "2016-06-13 13:12:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNBC International",
      "screen_name" : "CNBCi",
      "indices" : [ 3, 9 ],
      "id_str" : "19898168",
      "id" : 19898168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/qqLa9Rz82y",
      "expanded_url" : "http:\/\/cnb.cx\/1XiwO6C",
      "display_url" : "cnb.cx\/1XiwO6C"
    } ]
  },
  "geo" : { },
  "id_str" : "742343670817525760",
  "text" : "RT @CNBCi: Walgreens cuts all ties with Theranos in latest blow for former Silicon Valley darling https:\/\/t.co\/qqLa9Rz82y https:\/\/t.co\/y4w7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CNBCi\/status\/742318131104886784\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/y4w7s9ZuX9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck0-Z5OWEAAWxzm.jpg",
        "id_str" : "742318128164638720",
        "id" : 742318128164638720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck0-Z5OWEAAWxzm.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1910
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1910
        } ],
        "display_url" : "pic.twitter.com\/y4w7s9ZuX9"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/qqLa9Rz82y",
        "expanded_url" : "http:\/\/cnb.cx\/1XiwO6C",
        "display_url" : "cnb.cx\/1XiwO6C"
      } ]
    },
    "geo" : { },
    "id_str" : "742318131104886784",
    "text" : "Walgreens cuts all ties with Theranos in latest blow for former Silicon Valley darling https:\/\/t.co\/qqLa9Rz82y https:\/\/t.co\/y4w7s9ZuX9",
    "id" : 742318131104886784,
    "created_at" : "2016-06-13 11:30:08 +0000",
    "user" : {
      "name" : "CNBC International",
      "screen_name" : "CNBCi",
      "protected" : false,
      "id_str" : "19898168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670203992157343744\/e7C_nltR_normal.jpg",
      "id" : 19898168,
      "verified" : true
    }
  },
  "id" : 742343670817525760,
  "created_at" : "2016-06-13 13:11:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "indices" : [ 3, 9 ],
      "id_str" : "3819701",
      "id" : 3819701
    }, {
      "name" : "Mary Jo Foley",
      "screen_name" : "maryjofoley",
      "indices" : [ 88, 100 ],
      "id_str" : "49465463",
      "id" : 49465463
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ZDNet\/status\/742337926223278080\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/gMNRJqBjm8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck1QaIZXIAAlKRg.jpg",
      "id_str" : "742337923446677504",
      "id" : 742337923446677504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck1QaIZXIAAlKRg.jpg",
      "sizes" : [ {
        "h" : 575,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/gMNRJqBjm8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/TO68JRYOy6",
      "expanded_url" : "http:\/\/zd.net\/1PWXsj9",
      "display_url" : "zd.net\/1PWXsj9"
    } ]
  },
  "geo" : { },
  "id_str" : "742343179194781696",
  "text" : "RT @ZDNet: ICYMI: Microsoft buys LinkedIn for $26.2 billion https:\/\/t.co\/TO68JRYOy6  by @maryjofoley https:\/\/t.co\/gMNRJqBjm8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mary Jo Foley",
        "screen_name" : "maryjofoley",
        "indices" : [ 77, 89 ],
        "id_str" : "49465463",
        "id" : 49465463
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ZDNet\/status\/742337926223278080\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/gMNRJqBjm8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck1QaIZXIAAlKRg.jpg",
        "id_str" : "742337923446677504",
        "id" : 742337923446677504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck1QaIZXIAAlKRg.jpg",
        "sizes" : [ {
          "h" : 575,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/gMNRJqBjm8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/TO68JRYOy6",
        "expanded_url" : "http:\/\/zd.net\/1PWXsj9",
        "display_url" : "zd.net\/1PWXsj9"
      } ]
    },
    "geo" : { },
    "id_str" : "742337926223278080",
    "text" : "ICYMI: Microsoft buys LinkedIn for $26.2 billion https:\/\/t.co\/TO68JRYOy6  by @maryjofoley https:\/\/t.co\/gMNRJqBjm8",
    "id" : 742337926223278080,
    "created_at" : "2016-06-13 12:48:48 +0000",
    "user" : {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "protected" : false,
      "id_str" : "3819701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706961982545473536\/Ibj46-DX_normal.jpg",
      "id" : 3819701,
      "verified" : true
    }
  },
  "id" : 742343179194781696,
  "created_at" : "2016-06-13 13:09:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft",
      "screen_name" : "Microsoft",
      "indices" : [ 3, 13 ],
      "id_str" : "74286565",
      "id" : 74286565
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Microsoft\/status\/742334718813868032\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/ChUbNT0eSX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck1NfatXEAAID_Y.jpg",
      "id_str" : "742334715726860288",
      "id" : 742334715726860288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck1NfatXEAAID_Y.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/ChUbNT0eSX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/ijfD6gZmiB",
      "expanded_url" : "http:\/\/msft.it\/6019Bs4ht",
      "display_url" : "msft.it\/6019Bs4ht"
    } ]
  },
  "geo" : { },
  "id_str" : "742342260335988736",
  "text" : "RT @Microsoft: Microsoft to acquire LinkedIn. https:\/\/t.co\/ijfD6gZmiB https:\/\/t.co\/ChUbNT0eSX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Microsoft\/status\/742334718813868032\/photo\/1",
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/ChUbNT0eSX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck1NfatXEAAID_Y.jpg",
        "id_str" : "742334715726860288",
        "id" : 742334715726860288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck1NfatXEAAID_Y.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/ChUbNT0eSX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/ijfD6gZmiB",
        "expanded_url" : "http:\/\/msft.it\/6019Bs4ht",
        "display_url" : "msft.it\/6019Bs4ht"
      } ]
    },
    "geo" : { },
    "id_str" : "742334718813868032",
    "text" : "Microsoft to acquire LinkedIn. https:\/\/t.co\/ijfD6gZmiB https:\/\/t.co\/ChUbNT0eSX",
    "id" : 742334718813868032,
    "created_at" : "2016-06-13 12:36:03 +0000",
    "user" : {
      "name" : "Microsoft",
      "screen_name" : "Microsoft",
      "protected" : false,
      "id_str" : "74286565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709852306632744960\/zQ0xyGGK_normal.jpg",
      "id" : 74286565,
      "verified" : true
    }
  },
  "id" : 742342260335988736,
  "created_at" : "2016-06-13 13:06:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/SYNIflwLsv",
      "expanded_url" : "http:\/\/goo.gl\/NH6gdI",
      "display_url" : "goo.gl\/NH6gdI"
    } ]
  },
  "geo" : { },
  "id_str" : "742341882630508544",
  "text" : "https:\/\/t.co\/SYNIflwLsv Facebook not the good for people with low self-esteem.",
  "id" : 742341882630508544,
  "created_at" : "2016-06-13 13:04:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742334234120097792",
  "text" : "No clicks on the elder abuse huh?",
  "id" : 742334234120097792,
  "created_at" : "2016-06-13 12:34:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/kH2LZzFmQz",
      "expanded_url" : "http:\/\/goo.gl\/kYTOSn",
      "display_url" : "goo.gl\/kYTOSn"
    } ]
  },
  "geo" : { },
  "id_str" : "742330731205124096",
  "text" : "https:\/\/t.co\/kH2LZzFmQz The dark side of care giving, elder abuse. Plus doctors love to save and make women beautiful.",
  "id" : 742330731205124096,
  "created_at" : "2016-06-13 12:20:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/cf0OiPIpwO",
      "expanded_url" : "http:\/\/goo.gl\/kKr7NM",
      "display_url" : "goo.gl\/kKr7NM"
    } ]
  },
  "geo" : { },
  "id_str" : "742290345799602176",
  "text" : "https:\/\/t.co\/cf0OiPIpwO Males smarter than women 2006 but still relevant.",
  "id" : 742290345799602176,
  "created_at" : "2016-06-13 09:39:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/KFVM7L8b0G",
      "expanded_url" : "http:\/\/goo.gl\/ng3Nlv",
      "display_url" : "goo.gl\/ng3Nlv"
    } ]
  },
  "geo" : { },
  "id_str" : "742287632605020160",
  "text" : "https:\/\/t.co\/KFVM7L8b0G Girl cured of cancer with stem cell therapy.",
  "id" : 742287632605020160,
  "created_at" : "2016-06-13 09:28:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/m4G2xSQndI",
      "expanded_url" : "https:\/\/goo.gl\/LCvohs",
      "display_url" : "goo.gl\/LCvohs"
    }, {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/x3XVP4Sy2Q",
      "expanded_url" : "https:\/\/goo.gl\/ZP6s0p",
      "display_url" : "goo.gl\/ZP6s0p"
    } ]
  },
  "geo" : { },
  "id_str" : "742287052323061760",
  "text" : "https:\/\/t.co\/m4G2xSQndI DrGaP Download https:\/\/t.co\/x3XVP4Sy2Q",
  "id" : 742287052323061760,
  "created_at" : "2016-06-13 09:26:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/CaUCq79OlD",
      "expanded_url" : "http:\/\/goo.gl\/EX8fRn",
      "display_url" : "goo.gl\/EX8fRn"
    } ]
  },
  "geo" : { },
  "id_str" : "742282572160487424",
  "text" : "https:\/\/t.co\/CaUCq79OlD Cancer Genomics Software.",
  "id" : 742282572160487424,
  "created_at" : "2016-06-13 09:08:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/mH2OHewUIH",
      "expanded_url" : "http:\/\/goo.gl\/Hmlm7K",
      "display_url" : "goo.gl\/Hmlm7K"
    } ]
  },
  "geo" : { },
  "id_str" : "742280419459125248",
  "text" : "How nanotechnology could one cure cancer and other diseases. https:\/\/t.co\/mH2OHewUIH",
  "id" : 742280419459125248,
  "created_at" : "2016-06-13 09:00:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 3, 6 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GlobalGoals",
      "indices" : [ 12, 24 ]
    }, {
      "text" : "NotGhosts",
      "indices" : [ 111, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/hZnDvvCy48",
      "expanded_url" : "http:\/\/www.un.org\/en\/events\/albinismday\/",
      "display_url" : "un.org\/en\/events\/albi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742279264830115840",
  "text" : "RT @UN: The #GlobalGoals pledge to leave no one behind. That includes ppl w\/ albinism. https:\/\/t.co\/hZnDvvCy48 #NotGhosts https:\/\/t.co\/Byns\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/UN\/status\/742206128109424641\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/Byns2fejV1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ckq54paXEAAFHzK.jpg",
        "id_str" : "741609471496097792",
        "id" : 741609471496097792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ckq54paXEAAFHzK.jpg",
        "sizes" : [ {
          "h" : 486,
          "resize" : "fit",
          "w" : 864
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 864
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 864
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Byns2fejV1"
      } ],
      "hashtags" : [ {
        "text" : "GlobalGoals",
        "indices" : [ 4, 16 ]
      }, {
        "text" : "NotGhosts",
        "indices" : [ 103, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/hZnDvvCy48",
        "expanded_url" : "http:\/\/www.un.org\/en\/events\/albinismday\/",
        "display_url" : "un.org\/en\/events\/albi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "742206128109424641",
    "text" : "The #GlobalGoals pledge to leave no one behind. That includes ppl w\/ albinism. https:\/\/t.co\/hZnDvvCy48 #NotGhosts https:\/\/t.co\/Byns2fejV1",
    "id" : 742206128109424641,
    "created_at" : "2016-06-13 04:05:05 +0000",
    "user" : {
      "name" : "United Nations",
      "screen_name" : "UN",
      "protected" : false,
      "id_str" : "14159148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538328216729968642\/SdfeQXSM_normal.png",
      "id" : 14159148,
      "verified" : true
    }
  },
  "id" : 742279264830115840,
  "created_at" : "2016-06-13 08:55:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deutsche Bank",
      "screen_name" : "DeutscheBank",
      "indices" : [ 3, 16 ],
      "id_str" : "41330603",
      "id" : 41330603
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Energiewende",
      "indices" : [ 25, 38 ]
    }, {
      "text" : "dbresearch",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/4e5uEBnVb9",
      "expanded_url" : "http:\/\/www.dbresearch.com\/MAIL\/DBR_INTERNET_EN-PROD\/PROD0000000000406742.pdf",
      "display_url" : "dbresearch.com\/MAIL\/DBR_INTER\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742279004821028864",
  "text" : "RT @DeutscheBank: German #Energiewende: up to 95% cut in greenhouse-gas emissions by 2050 realistic? https:\/\/t.co\/4e5uEBnVb9\n#dbresearch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Energiewende",
        "indices" : [ 7, 20 ]
      }, {
        "text" : "dbresearch",
        "indices" : [ 107, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/4e5uEBnVb9",
        "expanded_url" : "http:\/\/www.dbresearch.com\/MAIL\/DBR_INTERNET_EN-PROD\/PROD0000000000406742.pdf",
        "display_url" : "dbresearch.com\/MAIL\/DBR_INTER\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "742235294183854080",
    "text" : "German #Energiewende: up to 95% cut in greenhouse-gas emissions by 2050 realistic? https:\/\/t.co\/4e5uEBnVb9\n#dbresearch",
    "id" : 742235294183854080,
    "created_at" : "2016-06-13 06:00:58 +0000",
    "user" : {
      "name" : "Deutsche Bank",
      "screen_name" : "DeutscheBank",
      "protected" : false,
      "id_str" : "41330603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472463469556416513\/KlKUMZtb_normal.jpeg",
      "id" : 41330603,
      "verified" : true
    }
  },
  "id" : 742279004821028864,
  "created_at" : "2016-06-13 08:54:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Williams-Sonoma",
      "screen_name" : "WilliamsSonoma",
      "indices" : [ 3, 18 ],
      "id_str" : "29247574",
      "id" : 29247574
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodnews",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/BWlfrF2OfY",
      "expanded_url" : "http:\/\/wsono.ma\/6014BsL1q",
      "display_url" : "wsono.ma\/6014BsL1q"
    } ]
  },
  "geo" : { },
  "id_str" : "742278981714595840",
  "text" : "RT @WilliamsSonoma: 5 signs you shouldn't buy berries + more in our weekly #foodnews roundup: https:\/\/t.co\/BWlfrF2OfY https:\/\/t.co\/TiC8SN85\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WilliamsSonoma\/status\/742124827650183169\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/TiC8SN85Fr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkyOmEBXAAUYYP8.jpg",
        "id_str" : "742124823174905861",
        "id" : 742124823174905861,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkyOmEBXAAUYYP8.jpg",
        "sizes" : [ {
          "h" : 507,
          "resize" : "fit",
          "w" : 507
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 507
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 507
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 507
        } ],
        "display_url" : "pic.twitter.com\/TiC8SN85Fr"
      } ],
      "hashtags" : [ {
        "text" : "foodnews",
        "indices" : [ 55, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/BWlfrF2OfY",
        "expanded_url" : "http:\/\/wsono.ma\/6014BsL1q",
        "display_url" : "wsono.ma\/6014BsL1q"
      } ]
    },
    "geo" : { },
    "id_str" : "742124827650183169",
    "text" : "5 signs you shouldn't buy berries + more in our weekly #foodnews roundup: https:\/\/t.co\/BWlfrF2OfY https:\/\/t.co\/TiC8SN85Fr",
    "id" : 742124827650183169,
    "created_at" : "2016-06-12 22:42:01 +0000",
    "user" : {
      "name" : "Williams-Sonoma",
      "screen_name" : "WilliamsSonoma",
      "protected" : false,
      "id_str" : "29247574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1148307110\/pineapple_normal.jpg",
      "id" : 29247574,
      "verified" : true
    }
  },
  "id" : 742278981714595840,
  "created_at" : "2016-06-13 08:54:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742109505987747841",
  "text" : "I'm getting my Scholar alerts Hilary and I'm not really talking to you or Trump.",
  "id" : 742109505987747841,
  "created_at" : "2016-06-12 21:41:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742107557158879232",
  "text" : "I'm taking my THE anti-aging pill that I found on M.I.T. Technology review three years ago when it came out. I gave that to a lot of women.",
  "id" : 742107557158879232,
  "created_at" : "2016-06-12 21:33:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742106611901202433",
  "text" : "I get Pearl Jam an why they hired an old keyboard player. He wasn't that threatening was he guys. While we are young people.",
  "id" : 742106611901202433,
  "created_at" : "2016-06-12 21:29:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742103414788763653",
  "text" : "SWVA women have just been metaphorically fucking me for some time now. And I'll tell that to my manager.",
  "id" : 742103414788763653,
  "created_at" : "2016-06-12 21:16:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/vxbxmvhra7",
      "expanded_url" : "https:\/\/goo.gl\/Qz5xAs",
      "display_url" : "goo.gl\/Qz5xAs"
    } ]
  },
  "geo" : { },
  "id_str" : "742101050551832576",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne https:\/\/t.co\/vxbxmvhra7 Terence Tao from UCLA is teaching me my math again he went to Princeton and is married.",
  "id" : 742101050551832576,
  "created_at" : "2016-06-12 21:07:32 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/rc5Sv60Wv6",
      "expanded_url" : "http:\/\/goo.gl\/uyBM2H",
      "display_url" : "goo.gl\/uyBM2H"
    } ]
  },
  "geo" : { },
  "id_str" : "742084845216641024",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor https:\/\/t.co\/rc5Sv60Wv6 Voyager VST MoogMusic.",
  "id" : 742084845216641024,
  "created_at" : "2016-06-12 20:03:09 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/CfgVl1cpvV",
      "expanded_url" : "https:\/\/goo.gl\/lKWjLU",
      "display_url" : "goo.gl\/lKWjLU"
    } ]
  },
  "geo" : { },
  "id_str" : "742070347554557953",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne https:\/\/t.co\/CfgVl1cpvV can't find a better man Avril?",
  "id" : 742070347554557953,
  "created_at" : "2016-06-12 19:05:32 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/QY5glyDDzS",
      "expanded_url" : "https:\/\/goo.gl\/wMcSgY",
      "display_url" : "goo.gl\/wMcSgY"
    } ]
  },
  "geo" : { },
  "id_str" : "742067047920730112",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor https:\/\/t.co\/QY5glyDDzS iPs Stem cell project in Berlin.",
  "id" : 742067047920730112,
  "created_at" : "2016-06-12 18:52:25 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/QY5glyDDzS",
      "expanded_url" : "https:\/\/goo.gl\/wMcSgY",
      "display_url" : "goo.gl\/wMcSgY"
    } ]
  },
  "geo" : { },
  "id_str" : "742066948117254145",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne https:\/\/t.co\/QY5glyDDzS iPs Stem cell project in Berlin.",
  "id" : 742066948117254145,
  "created_at" : "2016-06-12 18:52:02 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/rRoewHgTvk",
      "expanded_url" : "http:\/\/goo.gl\/gJxNvx",
      "display_url" : "goo.gl\/gJxNvx"
    } ]
  },
  "geo" : { },
  "id_str" : "742064630089011200",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor https:\/\/t.co\/rRoewHgTvk Follow OpenCyc Musk is just a kid. That didn't go to school.",
  "id" : 742064630089011200,
  "created_at" : "2016-06-12 18:42:49 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742063532590673920",
  "text" : "Valuation let me count the ways. 20 years at about 6-8 hours a day. At a software engineers salary. Plus the software.",
  "id" : 742063532590673920,
  "created_at" : "2016-06-12 18:38:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/HxVK7SYn84",
      "expanded_url" : "http:\/\/www.jonathanmoore.net",
      "display_url" : "jonathanmoore.net"
    } ]
  },
  "geo" : { },
  "id_str" : "742059021142724608",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne https:\/\/t.co\/HxVK7SYn84",
  "id" : 742059021142724608,
  "created_at" : "2016-06-12 18:20:32 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/HxVK7SYn84",
      "expanded_url" : "http:\/\/www.jonathanmoore.net",
      "display_url" : "jonathanmoore.net"
    } ]
  },
  "geo" : { },
  "id_str" : "742058353145303040",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor https:\/\/t.co\/HxVK7SYn84",
  "id" : 742058353145303040,
  "created_at" : "2016-06-12 18:17:52 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742054938444988416",
  "text" : "After my valuation (who knows how high) I will think about releasing more thing for free. All currencies are just fiat money.",
  "id" : 742054938444988416,
  "created_at" : "2016-06-12 18:04:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742053980126220288",
  "text" : "My Gifted Quarterly came today in the mail from the National association for the gifted.",
  "id" : 742053980126220288,
  "created_at" : "2016-06-12 18:00:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/amPbFwQHCE",
      "expanded_url" : "http:\/\/goo.gl\/Wj2Lo6",
      "display_url" : "goo.gl\/Wj2Lo6"
    } ]
  },
  "geo" : { },
  "id_str" : "742024875242586114",
  "text" : "Gene Partner DNA matching. I know mine will be hot.They are in Switzerland.  More neutral. https:\/\/t.co\/amPbFwQHCE",
  "id" : 742024875242586114,
  "created_at" : "2016-06-12 16:04:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/WIIqKombgb",
      "expanded_url" : "http:\/\/goo.gl\/Ch0Cq0",
      "display_url" : "goo.gl\/Ch0Cq0"
    } ]
  },
  "geo" : { },
  "id_str" : "742022132285222912",
  "text" : "People not music cause the violence la times. https:\/\/t.co\/WIIqKombgb",
  "id" : 742022132285222912,
  "created_at" : "2016-06-12 15:53:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBM Watson",
      "screen_name" : "IBMWatson",
      "indices" : [ 3, 13 ],
      "id_str" : "29735775",
      "id" : 29735775
    }, {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 31, 46 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AI",
      "indices" : [ 85, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/GRJ5gjpUKg",
      "expanded_url" : "http:\/\/ibm.co\/28sPFQd",
      "display_url" : "ibm.co\/28sPFQd"
    } ]
  },
  "geo" : { },
  "id_str" : "742009072522780672",
  "text" : "RT @IBMWatson: Great read from @washingtonpost: \"Everything you think you know about #AI is wrong\" https:\/\/t.co\/GRJ5gjpUKg https:\/\/t.co\/vqO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Washington Post",
        "screen_name" : "washingtonpost",
        "indices" : [ 16, 31 ],
        "id_str" : "2467791",
        "id" : 2467791
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IBMWatson\/status\/741711047954812929\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/vqON9M9wE9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CksWQ9xUkAEi5Gv.jpg",
        "id_str" : "741711044347727873",
        "id" : 741711044347727873,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CksWQ9xUkAEi5Gv.jpg",
        "sizes" : [ {
          "h" : 834,
          "resize" : "fit",
          "w" : 1484
        }, {
          "h" : 674,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 834,
          "resize" : "fit",
          "w" : 1484
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/vqON9M9wE9"
      } ],
      "hashtags" : [ {
        "text" : "AI",
        "indices" : [ 70, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/GRJ5gjpUKg",
        "expanded_url" : "http:\/\/ibm.co\/28sPFQd",
        "display_url" : "ibm.co\/28sPFQd"
      } ]
    },
    "geo" : { },
    "id_str" : "741711047954812929",
    "text" : "Great read from @washingtonpost: \"Everything you think you know about #AI is wrong\" https:\/\/t.co\/GRJ5gjpUKg https:\/\/t.co\/vqON9M9wE9",
    "id" : 741711047954812929,
    "created_at" : "2016-06-11 19:17:48 +0000",
    "user" : {
      "name" : "IBM Watson",
      "screen_name" : "IBMWatson",
      "protected" : false,
      "id_str" : "29735775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799709755623309312\/VieAIRsg_normal.jpg",
      "id" : 29735775,
      "verified" : true
    }
  },
  "id" : 742009072522780672,
  "created_at" : "2016-06-12 15:02:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FreeBSD Foundation",
      "screen_name" : "freebsdfndation",
      "indices" : [ 3, 19 ],
      "id_str" : "50052513",
      "id" : 50052513
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreeBSD",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742009007062290432",
  "text" : "RT @freebsdfndation: Happy winners! 2 more to go. Enter &amp; support #FreeBSD by donating before the closing session. Thank you@NetgateUSA htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/freebsdfndation\/status\/741681213434437632\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/d85eXwuz6x",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ckr7IcEUYAA5BS5.jpg",
        "id_str" : "741681211047698432",
        "id" : 741681211047698432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ckr7IcEUYAA5BS5.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/d85eXwuz6x"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/freebsdfndation\/status\/741681213434437632\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/d85eXwuz6x",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ckr7IbKUUAEMKVT.jpg",
        "id_str" : "741681210804424705",
        "id" : 741681210804424705,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ckr7IbKUUAEMKVT.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/d85eXwuz6x"
      } ],
      "hashtags" : [ {
        "text" : "FreeBSD",
        "indices" : [ 49, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741681213434437632",
    "text" : "Happy winners! 2 more to go. Enter &amp; support #FreeBSD by donating before the closing session. Thank you@NetgateUSA https:\/\/t.co\/d85eXwuz6x",
    "id" : 741681213434437632,
    "created_at" : "2016-06-11 17:19:15 +0000",
    "user" : {
      "name" : "FreeBSD Foundation",
      "screen_name" : "freebsdfndation",
      "protected" : false,
      "id_str" : "50052513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/803996894972125188\/tr4MTFJZ_normal.jpg",
      "id" : 50052513,
      "verified" : true
    }
  },
  "id" : 742009007062290432,
  "created_at" : "2016-06-12 15:01:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moog Synthesizers",
      "screen_name" : "moogmusicinc",
      "indices" : [ 3, 16 ],
      "id_str" : "26779967",
      "id" : 26779967
    }, {
      "name" : "money mark",
      "screen_name" : "moneymark",
      "indices" : [ 27, 37 ],
      "id_str" : "20726991",
      "id" : 20726991
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moogfactory",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742008928188391424",
  "text" : "RT @moogmusicinc: Keyboard @moneymark you know he's not havin it. Just give him some wood and he'll build you a cabinet. #moogfactory https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "money mark",
        "screen_name" : "moneymark",
        "indices" : [ 9, 19 ],
        "id_str" : "20726991",
        "id" : 20726991
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/moogmusicinc\/status\/741841299779817472\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/sefMehiIKy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkuMuWLXIAIcb57.jpg",
        "id_str" : "741841291487682562",
        "id" : 741841291487682562,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkuMuWLXIAIcb57.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1364,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1364,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/sefMehiIKy"
      } ],
      "hashtags" : [ {
        "text" : "moogfactory",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741841299779817472",
    "text" : "Keyboard @moneymark you know he's not havin it. Just give him some wood and he'll build you a cabinet. #moogfactory https:\/\/t.co\/sefMehiIKy",
    "id" : 741841299779817472,
    "created_at" : "2016-06-12 03:55:23 +0000",
    "user" : {
      "name" : "Moog Synthesizers",
      "screen_name" : "moogmusicinc",
      "protected" : false,
      "id_str" : "26779967",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736287958584721409\/JcZWLecp_normal.jpg",
      "id" : 26779967,
      "verified" : true
    }
  },
  "id" : 742008928188391424,
  "created_at" : "2016-06-12 15:01:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742008439954640897",
  "text" : "Wanna arrest the musician for making music? Hardly",
  "id" : 742008439954640897,
  "created_at" : "2016-06-12 14:59:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/oASkE4CYX3",
      "expanded_url" : "https:\/\/twitter.com\/CNBCi\/status\/742005157563641856",
      "display_url" : "twitter.com\/CNBCi\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742007651933016064",
  "text" : "I'm not a domestic terrorist I'm just an intellectual treat to your union. I am the better man. https:\/\/t.co\/oASkE4CYX3",
  "id" : 742007651933016064,
  "created_at" : "2016-06-12 14:56:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742005088412127232",
  "text" : "I am putting a song \"Why don't you want to know?\" on my next album for all of the people that know have Chromebooks and iPads.",
  "id" : 742005088412127232,
  "created_at" : "2016-06-12 14:46:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/gQpxrwZNuz",
      "expanded_url" : "https:\/\/goo.gl\/YeGCXh",
      "display_url" : "goo.gl\/YeGCXh"
    } ]
  },
  "geo" : { },
  "id_str" : "741674892672827392",
  "text" : "Princeton's independent concentration would be my only academic fit if they were online and for credit. https:\/\/t.co\/gQpxrwZNuz",
  "id" : 741674892672827392,
  "created_at" : "2016-06-11 16:54:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/j81WgDSiA9",
      "expanded_url" : "http:\/\/goo.gl\/k6yjqA",
      "display_url" : "goo.gl\/k6yjqA"
    } ]
  },
  "geo" : { },
  "id_str" : "741672739078049792",
  "text" : "M.I.T. studies show MOOCS are on par with in classroom studies and where most talent comes from, gifted issues. https:\/\/t.co\/j81WgDSiA9",
  "id" : 741672739078049792,
  "created_at" : "2016-06-11 16:45:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BI Tech",
      "screen_name" : "SAI",
      "indices" : [ 96, 100 ],
      "id_str" : "8841372",
      "id" : 8841372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/9X9mm7LIpQ",
      "expanded_url" : "http:\/\/read.bi\/1hGGWN0",
      "display_url" : "read.bi\/1hGGWN0"
    } ]
  },
  "geo" : { },
  "id_str" : "741666107606597633",
  "text" : "This 55-year-old software developer explains why he can't get a job https:\/\/t.co\/9X9mm7LIpQ via @sai",
  "id" : 741666107606597633,
  "created_at" : "2016-06-11 16:19:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Smith",
      "screen_name" : "BradSmi",
      "indices" : [ 0, 8 ],
      "id_str" : "14505546",
      "id" : 14505546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741395125193052161",
  "in_reply_to_user_id" : 14505546,
  "text" : "@BradSmi Mr. Smith I'm trying to find a misunderstood and neglected youth to give my XBox Kinect too.",
  "id" : 741395125193052161,
  "created_at" : "2016-06-10 22:22:26 +0000",
  "in_reply_to_screen_name" : "BradSmi",
  "in_reply_to_user_id_str" : "14505546",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Explore Oracle",
      "screen_name" : "ExploreOracle",
      "indices" : [ 3, 17 ],
      "id_str" : "23964994",
      "id" : 23964994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OracleVolunteers",
      "indices" : [ 19, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740971509666156544",
  "text" : "RT @ExploreOracle: #OracleVolunteers in Beijing work w\/ kids from Zhi Guang Special Education &amp; Training School on tech! https:\/\/t.co\/QHO86\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/manage.involver.com\" rel=\"nofollow\"\u003EOracle Engage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ExploreOracle\/status\/740770462658138113\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/QHO86jJe7O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cke-zthWYAA3R-m.jpg",
        "id_str" : "740770459327815680",
        "id" : 740770459327815680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cke-zthWYAA3R-m.jpg",
        "sizes" : [ {
          "h" : 521,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 834
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 834
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 834
        } ],
        "display_url" : "pic.twitter.com\/QHO86jJe7O"
      } ],
      "hashtags" : [ {
        "text" : "OracleVolunteers",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740770462658138113",
    "text" : "#OracleVolunteers in Beijing work w\/ kids from Zhi Guang Special Education &amp; Training School on tech! https:\/\/t.co\/QHO86jJe7O",
    "id" : 740770462658138113,
    "created_at" : "2016-06-09 05:00:15 +0000",
    "user" : {
      "name" : "Explore Oracle",
      "screen_name" : "ExploreOracle",
      "protected" : false,
      "id_str" : "23964994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744872610240954370\/XgLphAw__normal.jpg",
      "id" : 23964994,
      "verified" : false
    }
  },
  "id" : 740971509666156544,
  "created_at" : "2016-06-09 18:19:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/QPEQ31T8PB",
      "expanded_url" : "https:\/\/jdm7dv.blogspot.com\/2016\/06\/people.html",
      "display_url" : "jdm7dv.blogspot.com\/2016\/06\/people\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740970335181373441",
  "text" : "I am giving my Kinect to a misunderstood neglected child in the area like me. https:\/\/t.co\/QPEQ31T8PB",
  "id" : 740970335181373441,
  "created_at" : "2016-06-09 18:14:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740680941560037378",
  "text" : "I upgraded to CS5.5 and go the HTML5 and CSS3 expansion pack. Plus I got Acrobat DC Pro.",
  "id" : 740680941560037378,
  "created_at" : "2016-06-08 23:04:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740621681144795136",
  "text" : "I'm taking a nap, the area where I live is so jealous of me that when I called 911 one time the cops didn't even show.",
  "id" : 740621681144795136,
  "created_at" : "2016-06-08 19:09:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740619545090592768",
  "text" : "I did get a 4.0 GPA in college in CS. If the upper class just raise prices so they just want to buy their smarts I'm telling the president.",
  "id" : 740619545090592768,
  "created_at" : "2016-06-08 19:00:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/73BDJVZYYt",
      "expanded_url" : "http:\/\/news.jonathanmoore.net\/",
      "display_url" : "news.jonathanmoore.net"
    } ]
  },
  "geo" : { },
  "id_str" : "740617193994526720",
  "text" : "https:\/\/t.co\/73BDJVZYYt my personal news site Prime News Soup. Thumbnails to come later.",
  "id" : 740617193994526720,
  "created_at" : "2016-06-08 18:51:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IEEE",
      "screen_name" : "IEEEorg",
      "indices" : [ 3, 11 ],
      "id_str" : "54290504",
      "id" : 54290504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740581670168977408",
  "text" : "RT @IEEEorg: Today in 1955, the founder of the World Wide Web, Tim Berners-Lee was born in London. Happy birthday, TimBL! https:\/\/t.co\/x1t4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IEEEorg\/status\/740544165683945472\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/x1t4tCjZyp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ckbw_oiXAAA0K5S.jpg",
        "id_str" : "740544164752982016",
        "id" : 740544164752982016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ckbw_oiXAAA0K5S.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/x1t4tCjZyp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740544165683945472",
    "text" : "Today in 1955, the founder of the World Wide Web, Tim Berners-Lee was born in London. Happy birthday, TimBL! https:\/\/t.co\/x1t4tCjZyp",
    "id" : 740544165683945472,
    "created_at" : "2016-06-08 14:01:02 +0000",
    "user" : {
      "name" : "IEEE",
      "screen_name" : "IEEEorg",
      "protected" : false,
      "id_str" : "54290504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474591466749034496\/2-H1zqWf_normal.jpeg",
      "id" : 54290504,
      "verified" : false
    }
  },
  "id" : 740581670168977408,
  "created_at" : "2016-06-08 16:30:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 82, 89 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/1dIPA6sPpz",
      "expanded_url" : "https:\/\/www.amazon.com\/dp\/B00LLOKFUE\/ref=cm_sw_r_tw_asp_MThJL.CTFQNPT",
      "display_url" : "amazon.com\/dp\/B00LLOKFUE\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740186677952544772",
  "text" : "I just bought: '2014 World Book Multimedia Encyclopedia on DVD' by World Book via @amazon https:\/\/t.co\/1dIPA6sPpz",
  "id" : 740186677952544772,
  "created_at" : "2016-06-07 14:20:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Accu Web Hosting",
      "screen_name" : "accuwebhosting",
      "indices" : [ 60, 75 ],
      "id_str" : "38817096",
      "id" : 38817096
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DedicatedServers",
      "indices" : [ 42, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ay6y83DLpH",
      "expanded_url" : "https:\/\/goo.gl\/2XLpuD",
      "display_url" : "goo.gl\/2XLpuD"
    } ]
  },
  "geo" : { },
  "id_str" : "740136434611425280",
  "text" : "Low Cost Dedicated Servers - $110\/Month - #DedicatedServers @accuwebhosting  - https:\/\/t.co\/ay6y83DLpH",
  "id" : 740136434611425280,
  "created_at" : "2016-06-07 11:00:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Accu Web Hosting",
      "screen_name" : "accuwebhosting",
      "indices" : [ 58, 73 ],
      "id_str" : "38817096",
      "id" : 38817096
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VirtualServers",
      "indices" : [ 42, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/sm5IKZ6H8O",
      "expanded_url" : "https:\/\/goo.gl\/pGZkQy",
      "display_url" : "goo.gl\/pGZkQy"
    } ]
  },
  "geo" : { },
  "id_str" : "740136352629592065",
  "text" : "Pure SSD Virtual Servers - $18.00\/Month - #VirtualServers @accuwebhosting - https:\/\/t.co\/sm5IKZ6H8O",
  "id" : 740136352629592065,
  "created_at" : "2016-06-07 11:00:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Accu Web Hosting",
      "screen_name" : "accuwebhosting",
      "indices" : [ 63, 78 ],
      "id_str" : "38817096",
      "id" : 38817096
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WordPress",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "Hosting",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/b0Hgx8yccv",
      "expanded_url" : "https:\/\/goo.gl\/igfo2p",
      "display_url" : "goo.gl\/igfo2p"
    } ]
  },
  "geo" : { },
  "id_str" : "740136291187183617",
  "text" : "#WordPress Optimized #Hosting, Pure SSD drives - $3.99\/Month - @accuwebhosting - https:\/\/t.co\/b0Hgx8yccv",
  "id" : 740136291187183617,
  "created_at" : "2016-06-07 11:00:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Accu Web Hosting",
      "screen_name" : "accuwebhosting",
      "indices" : [ 60, 75 ],
      "id_str" : "38817096",
      "id" : 38817096
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WindowsVPS",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/9UGh83DSbJ",
      "expanded_url" : "https:\/\/goo.gl\/AARdE9",
      "display_url" : "goo.gl\/AARdE9"
    } ]
  },
  "geo" : { },
  "id_str" : "740136246635331584",
  "text" : "Windows VPS Server with 4 GB RAM $37.99\/Month - #WindowsVPS @accuwebhosting - https:\/\/t.co\/9UGh83DSbJ",
  "id" : 740136246635331584,
  "created_at" : "2016-06-07 11:00:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Accu Web Hosting",
      "screen_name" : "accuwebhosting",
      "indices" : [ 0, 15 ],
      "id_str" : "38817096",
      "id" : 38817096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/lrUszCXTU9",
      "expanded_url" : "http:\/\/website.Click",
      "display_url" : "website.Click"
    }, {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/KNPvSfbHDW",
      "expanded_url" : "http:\/\/goo.gl\/Ewpl9U",
      "display_url" : "goo.gl\/Ewpl9U"
    } ]
  },
  "geo" : { },
  "id_str" : "740136151453995008",
  "in_reply_to_user_id" : 38817096,
  "text" : "@AccuWebHosting to host my https:\/\/t.co\/lrUszCXTU9 https:\/\/t.co\/KNPvSfbHDW to try them out and get 15% discount using code ACCUWelcome",
  "id" : 740136151453995008,
  "created_at" : "2016-06-07 10:59:44 +0000",
  "in_reply_to_screen_name" : "accuwebhosting",
  "in_reply_to_user_id_str" : "38817096",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]