Grailbird.data.tweets_2016_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Signal Solutions",
      "screen_name" : "scottbradley77",
      "indices" : [ 3, 18 ],
      "id_str" : "14748513",
      "id" : 14748513
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/scottbradley77\/status\/693567456024096769\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/eQHGcTVef7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaAL7RXW0AEDbwR.jpg",
      "id_str" : "693567455516610561",
      "id" : 693567455516610561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaAL7RXW0AEDbwR.jpg",
      "sizes" : [ {
        "h" : 470,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 470,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 470,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/eQHGcTVef7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/GUFZgicXnC",
      "expanded_url" : "http:\/\/bit.ly\/1Lcs3DE",
      "display_url" : "bit.ly\/1Lcs3DE"
    } ]
  },
  "geo" : { },
  "id_str" : "693579158857879552",
  "text" : "RT @scottbradley77: Peeps, check out The Skimm Daily, Free Synopsis of important news: https:\/\/t.co\/GUFZgicXnC https:\/\/t.co\/eQHGcTVef7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetjukebox.com\" rel=\"nofollow\"\u003ETweet Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scottbradley77\/status\/693567456024096769\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/eQHGcTVef7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaAL7RXW0AEDbwR.jpg",
        "id_str" : "693567455516610561",
        "id" : 693567455516610561,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaAL7RXW0AEDbwR.jpg",
        "sizes" : [ {
          "h" : 470,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 266,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 470,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 470,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/eQHGcTVef7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/GUFZgicXnC",
        "expanded_url" : "http:\/\/bit.ly\/1Lcs3DE",
        "display_url" : "bit.ly\/1Lcs3DE"
      } ]
    },
    "geo" : { },
    "id_str" : "693567456024096769",
    "text" : "Peeps, check out The Skimm Daily, Free Synopsis of important news: https:\/\/t.co\/GUFZgicXnC https:\/\/t.co\/eQHGcTVef7",
    "id" : 693567456024096769,
    "created_at" : "2016-01-30 22:52:22 +0000",
    "user" : {
      "name" : "Signal Solutions",
      "screen_name" : "scottbradley77",
      "protected" : false,
      "id_str" : "14748513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638785166878605312\/gxdHb17m_normal.jpg",
      "id" : 14748513,
      "verified" : false
    }
  },
  "id" : 693579158857879552,
  "created_at" : "2016-01-30 23:38:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]