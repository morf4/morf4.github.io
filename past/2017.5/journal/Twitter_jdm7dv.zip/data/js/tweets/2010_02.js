Grailbird.data.tweets_2010_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Intel Official News",
      "screen_name" : "intelnews",
      "indices" : [ 3, 13 ],
      "id_str" : "47465882",
      "id" : 47465882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 131, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9153080129",
  "text" : "RT @IntelNews: Futuristic Intel Chip Could Reshape How Consumers Interact with Their PCs and Personal Devices http:\/\/bit.ly\/5GerJF #fb",
  "id" : 9153080129,
  "created_at" : "2010-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]