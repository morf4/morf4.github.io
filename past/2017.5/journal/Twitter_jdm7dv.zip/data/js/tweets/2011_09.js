Grailbird.data.tweets_2011_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/GXLVXr1S",
      "expanded_url" : "http:\/\/fb.me\/1g5encDAV",
      "display_url" : "fb.me\/1g5encDAV"
    } ]
  },
  "geo" : { },
  "id_str" : "119822587080605696",
  "text" : "The Smallest Revolution: Five Recent Breakthroughs in Nanomedicine | Guest Blog, Scientific American http:\/\/t.co\/GXLVXr1S",
  "id" : 119822587080605696,
  "created_at" : "2011-09-30 17:15:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/fNNYYH6b",
      "expanded_url" : "http:\/\/fb.me\/1l7Y2CSiU",
      "display_url" : "fb.me\/1l7Y2CSiU"
    } ]
  },
  "geo" : { },
  "id_str" : "119777217705279488",
  "text" : "Hyperthymesia \u2013 A Newly Discovered Memory In Which People Remember Every Day Of Their Lives (video). http:\/\/t.co\/fNNYYH6b",
  "id" : 119777217705279488,
  "created_at" : "2011-09-30 14:14:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/reTpKFTS",
      "expanded_url" : "http:\/\/fb.me\/ZAgF6P8f",
      "display_url" : "fb.me\/ZAgF6P8f"
    } ]
  },
  "geo" : { },
  "id_str" : "119772817574203392",
  "text" : "Immune System, Loaded With Remade T-cells, Vanquishes Cancer http:\/\/t.co\/reTpKFTS",
  "id" : 119772817574203392,
  "created_at" : "2011-09-30 13:57:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jdm7dv",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115132588791824385",
  "text" : "only going to focus on BioHPC on my research site everything else will take a back seat. #jdm7dv",
  "id" : 115132588791824385,
  "created_at" : "2011-09-17 18:38:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jdm7dv",
      "indices" : [ 38, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115126324959526912",
  "text" : "I'm starting to get random G+ adds :\/ #jdm7dv",
  "id" : 115126324959526912,
  "created_at" : "2011-09-17 18:13:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jdm7dv",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115084104088817664",
  "text" : "Enough work today. Time to relax #jdm7dv",
  "id" : 115084104088817664,
  "created_at" : "2011-09-17 15:26:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jdm7dv",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114941265610678272",
  "text" : "creating a task on ifttt for G+ #jdm7dv",
  "id" : 114941265610678272,
  "created_at" : "2011-09-17 05:58:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jdm7dv",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114932221592342528",
  "text" : "now installing Windows Server Developer Preview #jdm7dv",
  "id" : 114932221592342528,
  "created_at" : "2011-09-17 05:22:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "callingitanight",
      "indices" : [ 0, 16 ]
    }, {
      "text" : "jdm7dv",
      "indices" : [ 17, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114907106561376256",
  "text" : "#callingitanight #jdm7dv",
  "id" : 114907106561376256,
  "created_at" : "2011-09-17 03:42:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jdm7dv",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114895916808409088",
  "text" : "finished downloading visual studio 11 developer preview. #jdm7dv",
  "id" : 114895916808409088,
  "created_at" : "2011-09-17 02:58:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 79 ],
      "url" : "http:\/\/t.co\/5XaFw5X",
      "expanded_url" : "http:\/\/fb.me\/19IECglue",
      "display_url" : "fb.me\/19IECglue"
    } ]
  },
  "geo" : { },
  "id_str" : "111182977530204160",
  "text" : "HPCwire: An Open Source Platform for Virtual Supercomputing http:\/\/t.co\/5XaFw5X",
  "id" : 111182977530204160,
  "created_at" : "2011-09-06 21:04:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 72 ],
      "url" : "http:\/\/t.co\/GWEUknC",
      "expanded_url" : "http:\/\/fb.me\/Hp1RMxvE",
      "display_url" : "fb.me\/Hp1RMxvE"
    } ]
  },
  "geo" : { },
  "id_str" : "110882122012704769",
  "text" : "Capturing Lazy Asteroids to Plunder : Discovery News http:\/\/t.co\/GWEUknC",
  "id" : 110882122012704769,
  "created_at" : "2011-09-06 01:08:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 21, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 61 ],
      "url" : "http:\/\/t.co\/Usxqryf",
      "expanded_url" : "http:\/\/www.facebook.com\/pages\/Research26\/297326075514",
      "display_url" : "facebook.com\/pages\/Research\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "110830129864908801",
  "text" : "'Like' research26 on #fb new site in Jan. http:\/\/t.co\/Usxqryf",
  "id" : 110830129864908801,
  "created_at" : "2011-09-05 21:42:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]