Grailbird.data.tweets_2010_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29380669189",
  "text" : "Twitter Techniques to Manage 20,000+ Followers | Ecommerce News http:\/\/bit.ly\/bUpTUP",
  "id" : 29380669189,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29236629236",
  "text" : "Azure account activated.",
  "id" : 29236629236,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.TechHit.com\/TwInbox\/\" rel=\"nofollow\"\u003ETwInbox\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 63, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29179498835",
  "text" : "an app that I'm going to use with Bing Maps is now using MVVM. #fb",
  "id" : 29179498835,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 123, 131 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 132, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 118 ],
      "url" : "http:\/\/t.co\/GJ30Zb3",
      "expanded_url" : "http:\/\/www.roboticstrends.com\/research_academics\/article\/carnegie_mellon_launches_7_million_initiative_using_robots_to_boost_science",
      "display_url" : "roboticstrends.com\/research_acade\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "29120431510",
  "text" : "Carnegie Mellon Launches $7 Million Initiative Using Robots To Boost Science and Technology Majors http:\/\/t.co\/GJ30Zb3 via @AddThis #fb",
  "id" : 29120431510,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 95, 103 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 104, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 90 ],
      "url" : "http:\/\/t.co\/ZF2rpxT",
      "expanded_url" : "http:\/\/www.roboticstrends.com\/research_academics\/article\/smu_led_research_center_aims_to_connect_brain_signals_to_robotic_limbs",
      "display_url" : "roboticstrends.com\/research_acade\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "29121189267",
  "text" : "SMU-led Research Center Aims to Connect Brain Signals to Robotic Limbs http:\/\/t.co\/ZF2rpxT via @AddThis #fb",
  "id" : 29121189267,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TNW Social Media",
      "screen_name" : "TNWsocialmedia",
      "indices" : [ 94, 109 ],
      "id_str" : "106418930",
      "id" : 106418930
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 110, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 89 ],
      "url" : "http:\/\/t.co\/hX1m1mT",
      "expanded_url" : "http:\/\/thenextweb.com\/socialmedia\/2010\/10\/17\/throwback-to-the-90s-how-social-networking-is-moving-back-to-private\/",
      "display_url" : "thenextweb.com\/socialmedia\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "29122535876",
  "text" : "Throwback to the 90s: How Social Networking is Moving Back to Private http:\/\/t.co\/hX1m1mT via @tnwsocialmedia #fb",
  "id" : 29122535876,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 132, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28953777607",
  "text" : "BBC News - Dream recording device 'possible' researcher claims http:\/\/www.bbc.co.uk\/news\/science-environment-11635625 sweet dreams! #fb",
  "id" : 28953777607,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28569941534",
  "text" : "http:\/\/arachnode.net\/",
  "id" : 28569941534,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28570037239",
  "text" : "http:\/\/www.amazon.com\/Free-Web-Crawlers-Dataparksearch-Arachnode-net\/dp\/1155196147",
  "id" : 28570037239,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28570214734",
  "text" : "http:\/\/nutch.apache.org\/",
  "id" : 28570214734,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.TechHit.com\/TwInbox\/\" rel=\"nofollow\"\u003ETwInbox\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 40, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28066955011",
  "text" : "The HTC Surround WP7 is out on the 8th! #fb",
  "id" : 28066955011,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 119, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28357172229",
  "text" : "BBC News - Dozens dead in Haiti from suspected cholera outbreak http:\/\/www.bbc.co.uk\/news\/world-latin-america-11599777 #fb",
  "id" : 28357172229,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.TechHit.com\/TwInbox\/\" rel=\"nofollow\"\u003ETwInbox\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 29, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27984300515",
  "text" : "having fun with c# delegates #fb",
  "id" : 27984300515,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CHRIS VOSS",
      "screen_name" : "CHRISVOSS",
      "indices" : [ 3, 13 ],
      "id_str" : "23172966",
      "id" : 23172966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27782977469",
  "text" : "RT @CHRISVOSS: I honestly think it is better to be a failure at something you love than to be a success at something you hate...George Burns",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27782841870",
    "text" : "I honestly think it is better to be a failure at something you love than to be a success at something you hate...George Burns",
    "id" : 27782841870,
    "created_at" : "2010-10-18 23:59:40 +0000",
    "user" : {
      "name" : "CHRIS VOSS",
      "screen_name" : "CHRISVOSS",
      "protected" : false,
      "id_str" : "23172966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765461483526299648\/ngMOcyPP_normal.jpg",
      "id" : 23172966,
      "verified" : false
    }
  },
  "id" : 27782977469,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laptop Mag",
      "screen_name" : "laptopmag",
      "indices" : [ 3, 13 ],
      "id_str" : "14835752",
      "id" : 14835752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 115, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27809823789",
  "text" : "RT @laptopmag Smart Phone Video Calls: Are Consumers and Networks Ready for the Implications? http:\/\/bit.ly\/9h35Vs #fb",
  "id" : 27809823789,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ambrose Little",
      "screen_name" : "ambroselittle",
      "indices" : [ 0, 14 ],
      "id_str" : "10696752",
      "id" : 10696752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27566395052",
  "geo" : { },
  "id_str" : "27567430757",
  "in_reply_to_user_id" : 10696752,
  "text" : "@ambroselittle I'm having the same problem with MSDN right now.",
  "id" : 27567430757,
  "in_reply_to_status_id" : 27566395052,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ambroselittle",
  "in_reply_to_user_id_str" : "10696752",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ambrose Little",
      "screen_name" : "ambroselittle",
      "indices" : [ 0, 14 ],
      "id_str" : "10696752",
      "id" : 10696752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27566486314",
  "geo" : { },
  "id_str" : "27567721231",
  "in_reply_to_user_id" : 10696752,
  "text" : "@ambroselittle It's just maintenance on msdn. Says so on their site.",
  "id" : 27567721231,
  "in_reply_to_status_id" : 27566486314,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ambroselittle",
  "in_reply_to_user_id_str" : "10696752",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26716839245",
  "text" : "Seesmic Works On 2008 R2! w \/HPC",
  "id" : 26716839245,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26219295899",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor thanks. hey,http:\/\/7dv.me\/cUklde",
  "id" : 26219295899,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26227173837",
  "text" : "favorite or bookmark.... hell just cache it all",
  "id" : 26227173837,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26138148736",
  "text" : "finished builing os suse-based, now just listening to coil",
  "id" : 26138148736,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 87, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http:\/\/t.co\/LbFrqNV",
      "expanded_url" : "http:\/\/singularityhub.com\/2010\/09\/21\/did-a-russian-scientist-really-cure-aging-or-is-it-just-a-fluke-video\/",
      "display_url" : "singularityhub.com\/2010\/09\/21\/did\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "26195823332",
  "text" : "Did+A+Russian+Scientist+Really+'Cure+Aging'+or+Is+It+Just+a+Fluke? http:\/\/t.co\/LbFrqNV #fb",
  "id" : 26195823332,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26215324229",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor do you know when http:\/\/atinylittledot.com\/ is going to distribute the show? I would love to help!",
  "id" : 26215324229,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "atinylittledot",
      "screen_name" : "atinylittledot",
      "indices" : [ 0, 15 ],
      "id_str" : "43640931",
      "id" : 43640931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26216427742",
  "in_reply_to_user_id" : 43640931,
  "text" : "@atinylittledot need any help? I have server room.",
  "id" : 26216427742,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "atinylittledot",
  "in_reply_to_user_id_str" : "43640931",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]