Grailbird.data.tweets_2011_07 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 90, 95 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http:\/\/t.co\/wIew5YJ",
      "expanded_url" : "http:\/\/www.nasa.gov\/topics\/universe\/features\/universe20110722.html#.TirvIpUSjYM.tweet",
      "display_url" : "nasa.gov\/topics\/univers\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "94798901005127682",
  "text" : "NASA - Astronomers Find Largest, Most Distant Reservoir of Water: http:\/\/t.co\/wIew5YJ via @NASA",
  "id" : 94798901005127682,
  "created_at" : "2011-07-23 15:59:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 47 ],
      "url" : "http:\/\/t.co\/unCarx3",
      "expanded_url" : "http:\/\/www.metrotwit.com\/show\/",
      "display_url" : "metrotwit.com\/show\/"
    } ]
  },
  "geo" : { },
  "id_str" : "93815553524903936",
  "text" : "Checking out MetroTwit Show http:\/\/t.co\/unCarx3",
  "id" : 93815553524903936,
  "created_at" : "2011-07-20 22:52:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 51, 62 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TechCrunch",
      "indices" : [ 35, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 82 ],
      "url" : "http:\/\/t.co\/fgkBA02",
      "expanded_url" : "http:\/\/techcrunch.com\/2011\/07\/15\/techcrunch-giveaway-motorola-xoom-techcrunch\/",
      "display_url" : "techcrunch.com\/2011\/07\/15\/tec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "92351800040108032",
  "text" : "TechCrunch Giveaway: Motorola Xoom\u00A0#TechCrunch via @techcrunch http:\/\/t.co\/fgkBA02",
  "id" : 92351800040108032,
  "created_at" : "2011-07-16 21:55:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]