Grailbird.data.tweets_2009_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 41, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5911889058",
  "text" : "thanks everyone for the direct messages! #fb",
  "id" : 5911889058,
  "created_at" : "2009-11-21 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Heuer",
      "screen_name" : "timheuer",
      "indices" : [ 3, 12 ],
      "id_str" : "782329",
      "id" : 782329
    }, {
      "name" : "Loic Le Meur",
      "screen_name" : "loic",
      "indices" : [ 48, 53 ],
      "id_str" : "740983",
      "id" : 740983
    }, {
      "name" : "Scott Guthrie",
      "screen_name" : "scottgu",
      "indices" : [ 58, 66 ],
      "id_str" : "41754227",
      "id" : 41754227
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "undergroundpdc",
      "indices" : [ 27, 42 ]
    }, {
      "text" : "ugpdc",
      "indices" : [ 67, 73 ]
    }, {
      "text" : "pdc09",
      "indices" : [ 74, 80 ]
    }, {
      "text" : "fb",
      "indices" : [ 107, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5847939209",
  "text" : "RT @timheuer: Backstage at #undergroundpdc with @loic and @scottgu #ugpdc #pdc09  http:\/\/twitpic.com\/q2cwn #fb",
  "id" : 5847939209,
  "created_at" : "2009-11-19 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5848562370",
  "text" : "TimHeur",
  "id" : 5848562370,
  "created_at" : "2009-11-19 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Abrams",
      "screen_name" : "brada",
      "indices" : [ 18, 24 ],
      "id_str" : "5356242",
      "id" : 5356242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 81, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5859997048",
  "text" : "getting ready for @brada's talk on WCF RIA Services formerly (.NET RIA Services) #fb",
  "id" : 5859997048,
  "created_at" : "2009-11-19 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Powers",
      "screen_name" : "stayyoungernow",
      "indices" : [ 3, 18 ],
      "id_str" : "39831197",
      "id" : 39831197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5829656854",
  "text" : "RT @stayyoungernow: Senate health care reform bill expected soon http:\/\/bit.ly\/rlR5C http:\/\/bit.ly\/OuUHe",
  "id" : 5829656854,
  "created_at" : "2009-11-18 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScotGu",
      "screen_name" : "ScotGu",
      "indices" : [ 48, 55 ],
      "id_str" : "1046934643",
      "id" : 1046934643
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 57, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5834587554",
  "text" : "Silverlight 4 beta just accounced at the PDC by @scotgu! #fb",
  "id" : 5834587554,
  "created_at" : "2009-11-18 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iconic88",
      "screen_name" : "Iconic88",
      "indices" : [ 3, 12 ],
      "id_str" : "17401289",
      "id" : 17401289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5836255939",
  "text" : "RT @Iconic88: Twitter to scrap controversial 'suggested users' list   http:\/\/bit.ly\/4lwCCS",
  "id" : 5836255939,
  "created_at" : "2009-11-18 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iconic88",
      "screen_name" : "Iconic88",
      "indices" : [ 3, 12 ],
      "id_str" : "17401289",
      "id" : 17401289
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 91, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5836260849",
  "text" : "RT @Iconic88: Twitter to scrap controversial 'suggested users' list   http:\/\/bit.ly\/4lwCCS #fb",
  "id" : 5836260849,
  "created_at" : "2009-11-18 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Guthrie",
      "screen_name" : "scottgu",
      "indices" : [ 3, 11 ],
      "id_str" : "41754227",
      "id" : 41754227
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 104, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5836281663",
  "text" : "RT @scottgu: Don't be afraid of my new Twitter avatar - you have to watch the keynote to understand ;-) #fb",
  "id" : 5836281663,
  "created_at" : "2009-11-18 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]