Grailbird.data.tweets_2013_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400007519289892865",
  "text" : "I won",
  "id" : 400007519289892865,
  "created_at" : "2013-11-11 21:09:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/Lm2VClziIa",
      "expanded_url" : "http:\/\/www.sceil.com\/",
      "display_url" : "sceil.com"
    } ]
  },
  "geo" : { },
  "id_str" : "399479080501776384",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne Stem cell breakthrough http:\/\/t.co\/Lm2VClziIa",
  "id" : 399479080501776384,
  "created_at" : "2013-11-10 10:10:09 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/fQBGSd4G3L",
      "expanded_url" : "http:\/\/drugtopics.modernmedicine.com\/drug-topics\/news\/jj-fined-22-billion-fraudulently-marketing-risperdal-invega",
      "display_url" : "drugtopics.modernmedicine.com\/drug-topics\/ne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "399225116820664320",
  "text" : "Johnson and Johnson Fined http:\/\/t.co\/fQBGSd4G3L",
  "id" : 399225116820664320,
  "created_at" : "2013-11-09 17:20:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/lOWjbrIVgC",
      "expanded_url" : "http:\/\/singularityhub.com\/2013\/10\/01\/cody-wilsons-war-saving-the-world-from-3d-printed-guns\/",
      "display_url" : "singularityhub.com\/2013\/10\/01\/cod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398577343054102528",
  "text" : "War on 3d printed guns http:\/\/t.co\/lOWjbrIVgC",
  "id" : 398577343054102528,
  "created_at" : "2013-11-07 22:26:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wholesale",
      "screen_name" : "wholesale",
      "indices" : [ 86, 96 ],
      "id_str" : "14075899",
      "id" : 14075899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kL0T9toGQb",
      "expanded_url" : "http:\/\/www.alibaba.com\/product-gs\/773050957\/Retro_design_heat_proof_phone_case.html",
      "display_url" : "alibaba.com\/product-gs\/773\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398117155268354048",
  "text" : "http:\/\/t.co\/kL0T9toGQb - Retro design heat proof phone case for Samsung GALAXY Y (via @wholesale.alibaba.com)",
  "id" : 398117155268354048,
  "created_at" : "2013-11-06 15:58:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/HjDRyRiIaF",
      "expanded_url" : "http:\/\/www.spacex.com\/news\/2013\/10\/16\/grasshopper-completes-half-mile-flight-last-test",
      "display_url" : "spacex.com\/news\/2013\/10\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397859109011091456",
  "text" : "http:\/\/t.co\/HjDRyRiIaF. Reported a few Asteroid tasks to my SpaceX team.",
  "id" : 397859109011091456,
  "created_at" : "2013-11-05 22:52:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/HRySmeMNc8",
      "expanded_url" : "http:\/\/www.space.com\/20631-north-korea-missile-rocket-technology.html",
      "display_url" : "space.com\/20631-north-ko\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397494288558215168",
  "text" : "North Korea Rocket Rundown http:\/\/t.co\/HRySmeMNc8",
  "id" : 397494288558215168,
  "created_at" : "2013-11-04 22:43:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/ZC5S00IqeA",
      "expanded_url" : "http:\/\/bit.ly\/17C7XTl",
      "display_url" : "bit.ly\/17C7XTl"
    } ]
  },
  "geo" : { },
  "id_str" : "397434999424548864",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne http:\/\/t.co\/ZC5S00IqeA IIS Smooth Streaming",
  "id" : 397434999424548864,
  "created_at" : "2013-11-04 18:47:42 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/login.slashdot.org\/\" rel=\"nofollow\"\u003ESlashdot login\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slashdot",
      "screen_name" : "slashdot",
      "indices" : [ 49, 58 ],
      "id_str" : "1068831",
      "id" : 1068831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/ib5Mfu6WZD",
      "expanded_url" : "http:\/\/rpx.me\/AbWq",
      "display_url" : "rpx.me\/AbWq"
    } ]
  },
  "geo" : { },
  "id_str" : "397426232100655105",
  "text" : "Finnish Team Makes Diabetes Vaccine Breakthrough @slashdot http:\/\/t.co\/ib5Mfu6WZD",
  "id" : 397426232100655105,
  "created_at" : "2013-11-04 18:12:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397425488471154689",
  "text" : "The AGE-breaker ALT-711 restores high blood flow-dependent remodeling in mesenteric resistance arteries in a rat model of type 2 diabetes.",
  "id" : 397425488471154689,
  "created_at" : "2013-11-04 18:09:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IxQ3ZKhFBu",
      "expanded_url" : "http:\/\/www.news-medical.net\/health\/What-is-Oxidative-Stress.aspx",
      "display_url" : "news-medical.net\/health\/What-is\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397419013686325249",
  "text" : "http:\/\/t.co\/IxQ3ZKhFBu What is Oxidative Stress",
  "id" : 397419013686325249,
  "created_at" : "2013-11-04 17:44:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]