Grailbird.data.tweets_2016_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/7aKKKF5lC8",
      "expanded_url" : "http:\/\/goo.gl\/ZMJPqd",
      "display_url" : "goo.gl\/ZMJPqd"
    } ]
  },
  "geo" : { },
  "id_str" : "726586674449244160",
  "text" : "Earth will survive about 5 billion more years if we don't become overpopulated and kill ourselves. From the BBC https:\/\/t.co\/7aKKKF5lC8",
  "id" : 726586674449244160,
  "created_at" : "2016-05-01 01:38:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/kWOcMLZRp7",
      "expanded_url" : "http:\/\/goo.gl\/AeI4yQ",
      "display_url" : "goo.gl\/AeI4yQ"
    } ]
  },
  "geo" : { },
  "id_str" : "726018442059481088",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne Are musical instruments becoming obsolete? https:\/\/t.co\/kWOcMLZRp7",
  "id" : 726018442059481088,
  "created_at" : "2016-04-29 12:01:00 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moog Synthesizers",
      "screen_name" : "moogmusicinc",
      "indices" : [ 3, 16 ],
      "id_str" : "26779967",
      "id" : 26779967
    }, {
      "name" : "cloudsabove",
      "screen_name" : "cloudsabove79",
      "indices" : [ 106, 120 ],
      "id_str" : "4275772282",
      "id" : 4275772282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "switchedonkids",
      "indices" : [ 87, 102 ]
    }, {
      "text" : "moog",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725514870750347264",
  "text" : "RT @moogmusicinc: May you have a lifetime of rich synthesizer experiences, little one. #switchedonkids \uD83D\uDCF7: @cloudsabove79 #moog https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "cloudsabove",
        "screen_name" : "cloudsabove79",
        "indices" : [ 88, 102 ],
        "id_str" : "4275772282",
        "id" : 4275772282
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/moogmusicinc\/status\/725505028144943104\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/OmlDTai2il",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChGC-RtU4AArMzu.jpg",
        "id_str" : "725505021400375296",
        "id" : 725505021400375296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChGC-RtU4AArMzu.jpg",
        "sizes" : [ {
          "h" : 719,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 326,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 719,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/OmlDTai2il"
      } ],
      "hashtags" : [ {
        "text" : "switchedonkids",
        "indices" : [ 69, 84 ]
      }, {
        "text" : "moog",
        "indices" : [ 103, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725505028144943104",
    "text" : "May you have a lifetime of rich synthesizer experiences, little one. #switchedonkids \uD83D\uDCF7: @cloudsabove79 #moog https:\/\/t.co\/OmlDTai2il",
    "id" : 725505028144943104,
    "created_at" : "2016-04-28 02:00:52 +0000",
    "user" : {
      "name" : "Moog Synthesizers",
      "screen_name" : "moogmusicinc",
      "protected" : false,
      "id_str" : "26779967",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736287958584721409\/JcZWLecp_normal.jpg",
      "id" : 26779967,
      "verified" : true
    }
  },
  "id" : 725514870750347264,
  "created_at" : "2016-04-28 02:39:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/jhzNaPkf9p",
      "expanded_url" : "http:\/\/jdm7dv.blogspot.com\/",
      "display_url" : "jdm7dv.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "725431029171888128",
  "text" : "My latest blog posts. https:\/\/t.co\/jhzNaPkf9p",
  "id" : 725431029171888128,
  "created_at" : "2016-04-27 21:06:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DeutscheBank Service",
      "screen_name" : "DeuBaService",
      "indices" : [ 0, 13 ],
      "id_str" : "526425130",
      "id" : 526425130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725366686761754626",
  "geo" : { },
  "id_str" : "725408910220349440",
  "in_reply_to_user_id" : 526425130,
  "text" : "@DeuBaService How? and where? do I open up an online HBCI account if I'm in the U.S.",
  "id" : 725408910220349440,
  "in_reply_to_status_id" : 725366686761754626,
  "created_at" : "2016-04-27 19:38:56 +0000",
  "in_reply_to_screen_name" : "DeuBaService",
  "in_reply_to_user_id_str" : "526425130",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DeutscheBank Service",
      "screen_name" : "DeuBaService",
      "indices" : [ 0, 13 ],
      "id_str" : "526425130",
      "id" : 526425130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723932613182889984",
  "geo" : { },
  "id_str" : "725363645199343618",
  "in_reply_to_user_id" : 526425130,
  "text" : "@DeuBaService I tried to contact the US directly but they only handle investments. Is there a way I can email my passport and open up HBCI?",
  "id" : 725363645199343618,
  "in_reply_to_status_id" : 723932613182889984,
  "created_at" : "2016-04-27 16:39:04 +0000",
  "in_reply_to_screen_name" : "DeuBaService",
  "in_reply_to_user_id_str" : "526425130",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/U1Z1ZxXohV",
      "expanded_url" : "http:\/\/goo.gl\/K4AHYJ",
      "display_url" : "goo.gl\/K4AHYJ"
    }, {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/GSNXgZUcAM",
      "expanded_url" : "http:\/\/goo.gl\/9NXiy9",
      "display_url" : "goo.gl\/9NXiy9"
    } ]
  },
  "geo" : { },
  "id_str" : "724786574647541763",
  "text" : "Proving defamation of character and marking lies.https:\/\/t.co\/U1Z1ZxXohV  \nhttps:\/\/t.co\/GSNXgZUcAM",
  "id" : 724786574647541763,
  "created_at" : "2016-04-26 02:25:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/dggsR4m4Pj",
      "expanded_url" : "http:\/\/sustainabletravel.org\/",
      "display_url" : "sustainabletravel.org"
    } ]
  },
  "geo" : { },
  "id_str" : "724438829126529024",
  "text" : "Sustainable Travel https:\/\/t.co\/dggsR4m4Pj",
  "id" : 724438829126529024,
  "created_at" : "2016-04-25 03:24:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/ObsCS6Axng",
      "expanded_url" : "http:\/\/goo.gl\/ueLeC7",
      "display_url" : "goo.gl\/ueLeC7"
    } ]
  },
  "geo" : { },
  "id_str" : "724429151273377792",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor Sustainable Travel.https:\/\/t.co\/ObsCS6Axng",
  "id" : 724429151273377792,
  "created_at" : "2016-04-25 02:45:43 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pearl Jam",
      "screen_name" : "PearlJam",
      "indices" : [ 3, 12 ],
      "id_str" : "15155074",
      "id" : 15155074
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PearlJam\/status\/724030040959131648\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/IjvvUINIrU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgxFPTRU0AAvUE0.jpg",
      "id_str" : "724029769273102336",
      "id" : 724029769273102336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgxFPTRU0AAvUE0.jpg",
      "sizes" : [ {
        "h" : 937,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 937,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IjvvUINIrU"
    } ],
    "hashtags" : [ {
      "text" : "jazzfest2016",
      "indices" : [ 27, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724416503714557953",
  "text" : "RT @PearlJam: The Big Easy #jazzfest2016 https:\/\/t.co\/IjvvUINIrU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PearlJam\/status\/724030040959131648\/photo\/1",
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/IjvvUINIrU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgxFPTRU0AAvUE0.jpg",
        "id_str" : "724029769273102336",
        "id" : 724029769273102336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgxFPTRU0AAvUE0.jpg",
        "sizes" : [ {
          "h" : 937,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 937,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/IjvvUINIrU"
      } ],
      "hashtags" : [ {
        "text" : "jazzfest2016",
        "indices" : [ 13, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "724030040959131648",
    "text" : "The Big Easy #jazzfest2016 https:\/\/t.co\/IjvvUINIrU",
    "id" : 724030040959131648,
    "created_at" : "2016-04-24 00:19:48 +0000",
    "user" : {
      "name" : "Pearl Jam",
      "screen_name" : "PearlJam",
      "protected" : false,
      "id_str" : "15155074",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689493162906095618\/5MzO7n3J_normal.png",
      "id" : 15155074,
      "verified" : true
    }
  },
  "id" : 724416503714557953,
  "created_at" : "2016-04-25 01:55:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/No40pCIZ11",
      "expanded_url" : "http:\/\/goo.gl\/arI2HT",
      "display_url" : "goo.gl\/arI2HT"
    } ]
  },
  "geo" : { },
  "id_str" : "724409365512499200",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne Gerson treatment for Lyme.https:\/\/t.co\/No40pCIZ11",
  "id" : 724409365512499200,
  "created_at" : "2016-04-25 01:27:06 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/JaieVBOSP3",
      "expanded_url" : "http:\/\/storm.apache.org\/",
      "display_url" : "storm.apache.org"
    } ]
  },
  "geo" : { },
  "id_str" : "724320219271946240",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor Apache Storm. Spotify uses this https:\/\/t.co\/JaieVBOSP3",
  "id" : 724320219271946240,
  "created_at" : "2016-04-24 19:32:52 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/FhfBUw2CD2",
      "expanded_url" : "http:\/\/ecowatch.com\/2015\/12\/14\/end-of-fossil-fuels-cop21\/",
      "display_url" : "ecowatch.com\/2015\/12\/14\/end\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724309176013447168",
  "text" : "Fossil fuels are near an end. https:\/\/t.co\/FhfBUw2CD2",
  "id" : 724309176013447168,
  "created_at" : "2016-04-24 18:48:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724307855885651968",
  "text" : "I was born in Atlanta and I don't have a country accent even though I live in Virginia.",
  "id" : 724307855885651968,
  "created_at" : "2016-04-24 18:43:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/ghbo0baPE4",
      "expanded_url" : "http:\/\/goo.gl\/XfR1na",
      "display_url" : "goo.gl\/XfR1na"
    } ]
  },
  "geo" : { },
  "id_str" : "724302531443200002",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor My latest blog posts.https:\/\/t.co\/ghbo0baPE4",
  "id" : 724302531443200002,
  "created_at" : "2016-04-24 18:22:35 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/cgwE566cDy",
      "expanded_url" : "https:\/\/goo.gl\/1gaIEE",
      "display_url" : "goo.gl\/1gaIEE"
    } ]
  },
  "geo" : { },
  "id_str" : "724297601269510144",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor M.I.T. Review anti aging pill https:\/\/t.co\/cgwE566cDy. Just don't play 'Demon Seed' live I do stutter a little.",
  "id" : 724297601269510144,
  "created_at" : "2016-04-24 18:02:59 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/FukiOi9FG0",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=njG7p6CSbCU",
      "display_url" : "youtube.com\/watch?v=njG7p6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724183681221443586",
  "text" : "John Lennon 'Working Class Hero' https:\/\/t.co\/FukiOi9FG0",
  "id" : 724183681221443586,
  "created_at" : "2016-04-24 10:30:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/ZGBy1J48Od",
      "expanded_url" : "http:\/\/goo.gl\/0KkDrh",
      "display_url" : "goo.gl\/0KkDrh"
    } ]
  },
  "geo" : { },
  "id_str" : "724181485239066625",
  "text" : "Also ordered this Willams-Sonoma Mediterranean cookbook. Forget Dr.Oz. https:\/\/t.co\/ZGBy1J48Od",
  "id" : 724181485239066625,
  "created_at" : "2016-04-24 10:21:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Williams-Sonoma",
      "screen_name" : "WilliamsSonoma",
      "indices" : [ 3, 18 ],
      "id_str" : "29247574",
      "id" : 29247574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/4P1PhvWSV9",
      "expanded_url" : "http:\/\/blog.williams-sonoma.com\/salmon-farfalle\/",
      "display_url" : "blog.williams-sonoma.com\/salmon-farfall\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724174835606278145",
  "text" : "RT @WilliamsSonoma: Feel good about eating this pasta feat. heart-healthy salmon.\n\nSalmon w\/ Farfalle + Leeks: https:\/\/t.co\/4P1PhvWSV9 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WilliamsSonoma\/status\/722545497353895936\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/hDVjs2EBL0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgb_TSLWQAAW3R5.jpg",
        "id_str" : "722545497001574400",
        "id" : 722545497001574400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgb_TSLWQAAW3R5.jpg",
        "sizes" : [ {
          "h" : 652,
          "resize" : "fit",
          "w" : 652
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 652,
          "resize" : "fit",
          "w" : 652
        } ],
        "display_url" : "pic.twitter.com\/hDVjs2EBL0"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/4P1PhvWSV9",
        "expanded_url" : "http:\/\/blog.williams-sonoma.com\/salmon-farfalle\/",
        "display_url" : "blog.williams-sonoma.com\/salmon-farfall\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "722545497353895936",
    "text" : "Feel good about eating this pasta feat. heart-healthy salmon.\n\nSalmon w\/ Farfalle + Leeks: https:\/\/t.co\/4P1PhvWSV9 https:\/\/t.co\/hDVjs2EBL0",
    "id" : 722545497353895936,
    "created_at" : "2016-04-19 22:00:45 +0000",
    "user" : {
      "name" : "Williams-Sonoma",
      "screen_name" : "WilliamsSonoma",
      "protected" : false,
      "id_str" : "29247574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1148307110\/pineapple_normal.jpg",
      "id" : 29247574,
      "verified" : true
    }
  },
  "id" : 724174835606278145,
  "created_at" : "2016-04-24 09:55:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/DnhzFbXXEk",
      "expanded_url" : "http:\/\/goo.gl\/YhS7Wl",
      "display_url" : "goo.gl\/YhS7Wl"
    } ]
  },
  "geo" : { },
  "id_str" : "724173706017292289",
  "text" : "Just ordered some new dinner plates from Williams-Sonama https:\/\/t.co\/DnhzFbXXEk",
  "id" : 724173706017292289,
  "created_at" : "2016-04-24 09:50:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DeutscheBankAmericas",
      "screen_name" : "DBAmericas",
      "indices" : [ 0, 11 ],
      "id_str" : "700073039",
      "id" : 700073039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724034661245181952",
  "in_reply_to_user_id" : 700073039,
  "text" : "@DBAmericas How do I open up a HBCI(Home Banking Computer interface) account. In the U.S. like in Germany with my source code as a reserve.",
  "id" : 724034661245181952,
  "created_at" : "2016-04-24 00:38:09 +0000",
  "in_reply_to_screen_name" : "DBAmericas",
  "in_reply_to_user_id_str" : "700073039",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/HcIWEt8S4W",
      "expanded_url" : "http:\/\/goo.gl\/4nZ5WV",
      "display_url" : "goo.gl\/4nZ5WV"
    } ]
  },
  "geo" : { },
  "id_str" : "723959916864655361",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne Here are some of my blog posts. https:\/\/t.co\/HcIWEt8S4W",
  "id" : 723959916864655361,
  "created_at" : "2016-04-23 19:41:09 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DeutscheBank Service",
      "screen_name" : "DeuBaService",
      "indices" : [ 0, 13 ],
      "id_str" : "526425130",
      "id" : 526425130
    }, {
      "name" : "Deutsche Bank",
      "screen_name" : "DeutscheBank",
      "indices" : [ 14, 27 ],
      "id_str" : "41330603",
      "id" : 41330603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717703018607689728",
  "geo" : { },
  "id_str" : "723930193207910400",
  "in_reply_to_user_id" : 526425130,
  "text" : "@DeuBaService @DeutscheBank I'm in the U.S. how do I open up an HBCI account in the U.S.",
  "id" : 723930193207910400,
  "in_reply_to_status_id" : 717703018607689728,
  "created_at" : "2016-04-23 17:43:02 +0000",
  "in_reply_to_screen_name" : "DeuBaService",
  "in_reply_to_user_id_str" : "526425130",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Earth",
      "indices" : [ 39, 45 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 68, 77 ]
    }, {
      "text" : "24Seven",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/lvVKZG1Hhb",
      "expanded_url" : "http:\/\/www.nasa.gov\/24seven",
      "display_url" : "nasa.gov\/24seven"
    } ]
  },
  "geo" : { },
  "id_str" : "723890674932813824",
  "text" : "RT @NASA: Get an insider's look at our #Earth work &amp; share your #EarthDay story with us using #24Seven https:\/\/t.co\/lvVKZG1Hhb https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/723522928562843648\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/cc1DN1ovy4",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cgp4RHwU4AAmeWS.jpg",
        "id_str" : "723522925681238016",
        "id" : 723522925681238016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cgp4RHwU4AAmeWS.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 608,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/cc1DN1ovy4"
      } ],
      "hashtags" : [ {
        "text" : "Earth",
        "indices" : [ 29, 35 ]
      }, {
        "text" : "EarthDay",
        "indices" : [ 58, 67 ]
      }, {
        "text" : "24Seven",
        "indices" : [ 88, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/lvVKZG1Hhb",
        "expanded_url" : "http:\/\/www.nasa.gov\/24seven",
        "display_url" : "nasa.gov\/24seven"
      } ]
    },
    "geo" : { },
    "id_str" : "723522928562843648",
    "text" : "Get an insider's look at our #Earth work &amp; share your #EarthDay story with us using #24Seven https:\/\/t.co\/lvVKZG1Hhb https:\/\/t.co\/cc1DN1ovy4",
    "id" : 723522928562843648,
    "created_at" : "2016-04-22 14:44:43 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 723890674932813824,
  "created_at" : "2016-04-23 15:06:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/1oP8HbQqoG",
      "expanded_url" : "http:\/\/goo.gl\/Mdceal",
      "display_url" : "goo.gl\/Mdceal"
    } ]
  },
  "geo" : { },
  "id_str" : "723878099729965057",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne Here is another possible cure for Lyme with milk. Just ask a doctor. https:\/\/t.co\/1oP8HbQqoG",
  "id" : 723878099729965057,
  "created_at" : "2016-04-23 14:16:02 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/1udamEP3G4",
      "expanded_url" : "http:\/\/goo.gl\/XwMxrJ",
      "display_url" : "goo.gl\/XwMxrJ"
    } ]
  },
  "geo" : { },
  "id_str" : "723653847374286848",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne An Organic cure for Lyme but keep taking all of your medication while trying this. Ask your doctor. https:\/\/t.co\/1udamEP3G4",
  "id" : 723653847374286848,
  "created_at" : "2016-04-22 23:24:56 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 3, 6 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/UN\/status\/723548897361190912\/video\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/EGSSHorRrx",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/723548767190978560\/pu\/img\/4ZWpop194Rjovbuy.jpg",
      "id_str" : "723548767190978560",
      "id" : 723548767190978560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/723548767190978560\/pu\/img\/4ZWpop194Rjovbuy.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/EGSSHorRrx"
    } ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 46, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723550000337268740",
  "text" : "RT @UN: Ban Ki-moon says record-breaking # of #ParisAgreement signatures sends a powerful message to the world. https:\/\/t.co\/EGSSHorRrx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter Challenger\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/UN\/status\/723548897361190912\/video\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/EGSSHorRrx",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/723548767190978560\/pu\/img\/4ZWpop194Rjovbuy.jpg",
        "id_str" : "723548767190978560",
        "id" : 723548767190978560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/723548767190978560\/pu\/img\/4ZWpop194Rjovbuy.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/EGSSHorRrx"
      } ],
      "hashtags" : [ {
        "text" : "ParisAgreement",
        "indices" : [ 38, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "723548897361190912",
    "text" : "Ban Ki-moon says record-breaking # of #ParisAgreement signatures sends a powerful message to the world. https:\/\/t.co\/EGSSHorRrx",
    "id" : 723548897361190912,
    "created_at" : "2016-04-22 16:27:54 +0000",
    "user" : {
      "name" : "United Nations",
      "screen_name" : "UN",
      "protected" : false,
      "id_str" : "14159148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538328216729968642\/SdfeQXSM_normal.png",
      "id" : 14159148,
      "verified" : true
    }
  },
  "id" : 723550000337268740,
  "created_at" : "2016-04-22 16:32:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/wsxAGKsbPI",
      "expanded_url" : "http:\/\/goo.gl\/J8Ckdh",
      "display_url" : "goo.gl\/J8Ckdh"
    } ]
  },
  "geo" : { },
  "id_str" : "723548305070891009",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne Possible cure for Lyme disease. https:\/\/t.co\/wsxAGKsbPI",
  "id" : 723548305070891009,
  "created_at" : "2016-04-22 16:25:33 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/jhzNaPkf9p",
      "expanded_url" : "http:\/\/jdm7dv.blogspot.com\/",
      "display_url" : "jdm7dv.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "723493825134628865",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne Here are some of my latest blog posts https:\/\/t.co\/jhzNaPkf9p enjoy!",
  "id" : 723493825134628865,
  "created_at" : "2016-04-22 12:49:04 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/jhzNaP2DKP",
      "expanded_url" : "http:\/\/jdm7dv.blogspot.com\/",
      "display_url" : "jdm7dv.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "722836248545460224",
  "text" : "Some of my recent blog posts. https:\/\/t.co\/jhzNaP2DKP",
  "id" : 722836248545460224,
  "created_at" : "2016-04-20 17:16:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/jhzNaPkf9p",
      "expanded_url" : "http:\/\/jdm7dv.blogspot.com\/",
      "display_url" : "jdm7dv.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "722777625526157316",
  "text" : "Some of my new blog posts. https:\/\/t.co\/jhzNaPkf9p",
  "id" : 722777625526157316,
  "created_at" : "2016-04-20 13:23:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "indices" : [ 3, 9 ],
      "id_str" : "3819701",
      "id" : 3819701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/JBSA3WGb9u",
      "expanded_url" : "http:\/\/zd.net\/1SshTpi",
      "display_url" : "zd.net\/1SshTpi"
    } ]
  },
  "geo" : { },
  "id_str" : "722453396066869248",
  "text" : "RT @ZDNet: Bash on Windows, Powershell and Docker: Why Microsoft is calling time on the server GUI https:\/\/t.co\/JBSA3WGb9u https:\/\/t.co\/N1e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ZDNet\/status\/722449416943230976\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/N1egDaLSdI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgan6qMWsAA44zj.jpg",
        "id_str" : "722449416439902208",
        "id" : 722449416439902208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgan6qMWsAA44zj.jpg",
        "sizes" : [ {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 582,
          "resize" : "fit",
          "w" : 770
        }, {
          "h" : 582,
          "resize" : "fit",
          "w" : 770
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/N1egDaLSdI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/JBSA3WGb9u",
        "expanded_url" : "http:\/\/zd.net\/1SshTpi",
        "display_url" : "zd.net\/1SshTpi"
      } ]
    },
    "geo" : { },
    "id_str" : "722449416943230976",
    "text" : "Bash on Windows, Powershell and Docker: Why Microsoft is calling time on the server GUI https:\/\/t.co\/JBSA3WGb9u https:\/\/t.co\/N1egDaLSdI",
    "id" : 722449416943230976,
    "created_at" : "2016-04-19 15:38:58 +0000",
    "user" : {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "protected" : false,
      "id_str" : "3819701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706961982545473536\/Ibj46-DX_normal.jpg",
      "id" : 3819701,
      "verified" : true
    }
  },
  "id" : 722453396066869248,
  "created_at" : "2016-04-19 15:54:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722451761064251392",
  "text" : "There seems to be some confusion about my Linked in profile picture. That's not grey hair, but washed out blue highlights.",
  "id" : 722451761064251392,
  "created_at" : "2016-04-19 15:48:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/IY4D9daQO7",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=rR4pf6pp1kQ",
      "display_url" : "youtube.com\/watch?v=rR4pf6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721812918761861120",
  "text" : "Stanley Krubrick confesses the moon landings were fake.https:\/\/t.co\/IY4D9daQO7",
  "id" : 721812918761861120,
  "created_at" : "2016-04-17 21:29:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Crimes Unit",
      "screen_name" : "MicrosoftDCU",
      "indices" : [ 3, 16 ],
      "id_str" : "95524371",
      "id" : 95524371
    }, {
      "name" : "The Irish Times",
      "screen_name" : "IrishTimes",
      "indices" : [ 96, 107 ],
      "id_str" : "15084853",
      "id" : 15084853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberCrime",
      "indices" : [ 84, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/IpnA3NXz2L",
      "expanded_url" : "http:\/\/www.irishtimes.com\/business\/technology\/microsoft-leading-the-fight-to-counter-cybercrime-1.2566206",
      "display_url" : "irishtimes.com\/business\/techn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721665863485636609",
  "text" : "RT @MicrosoftDCU: At Microsoft, big data and the cloud are key in the fight against #CyberCrime @IrishTimes https:\/\/t.co\/IpnA3NXz2L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Irish Times",
        "screen_name" : "IrishTimes",
        "indices" : [ 78, 89 ],
        "id_str" : "15084853",
        "id" : 15084853
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CyberCrime",
        "indices" : [ 66, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/IpnA3NXz2L",
        "expanded_url" : "http:\/\/www.irishtimes.com\/business\/technology\/microsoft-leading-the-fight-to-counter-cybercrime-1.2566206",
        "display_url" : "irishtimes.com\/business\/techn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "708024316579815424",
    "text" : "At Microsoft, big data and the cloud are key in the fight against #CyberCrime @IrishTimes https:\/\/t.co\/IpnA3NXz2L",
    "id" : 708024316579815424,
    "created_at" : "2016-03-10 20:18:46 +0000",
    "user" : {
      "name" : "Digital Crimes Unit",
      "screen_name" : "MicrosoftDCU",
      "protected" : false,
      "id_str" : "95524371",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478967922367283200\/8D2GxW5K_normal.png",
      "id" : 95524371,
      "verified" : false
    }
  },
  "id" : 721665863485636609,
  "created_at" : "2016-04-17 11:45:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721089043665133569",
  "text" : "Why did my ancestors come to America in the first place? They should have stayed in Germany.",
  "id" : 721089043665133569,
  "created_at" : "2016-04-15 21:33:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/dfeof2YsG1",
      "expanded_url" : "http:\/\/goo.gl\/sOeQye",
      "display_url" : "goo.gl\/sOeQye"
    } ]
  },
  "geo" : { },
  "id_str" : "721081881916272640",
  "text" : "How Occupy won in one chart. If Occupy won, why are we still paying? https:\/\/t.co\/dfeof2YsG1",
  "id" : 721081881916272640,
  "created_at" : "2016-04-15 21:04:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/5DcCaKYTYJ",
      "expanded_url" : "http:\/\/mailchimp.com\/resources\/guides\/how-to-avoid-spam-filters\/html\/",
      "display_url" : "mailchimp.com\/resources\/guid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721081001166925826",
  "text" : "How to avoid spam filers and follow email laws. https:\/\/t.co\/5DcCaKYTYJ",
  "id" : 721081001166925826,
  "created_at" : "2016-04-15 21:01:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/OfZL4JuQiI",
      "expanded_url" : "http:\/\/goo.gl\/UeG2DL",
      "display_url" : "goo.gl\/UeG2DL"
    } ]
  },
  "geo" : { },
  "id_str" : "720983997430571008",
  "text" : "Why mobile is dead. https:\/\/t.co\/OfZL4JuQiI",
  "id" : 720983997430571008,
  "created_at" : "2016-04-15 14:35:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720956159436439552",
  "text" : "I emailed Apple about separating the other Jonathan Moore. That has  \"The Moore the better\" with me, hopefully they will. I don't sing.",
  "id" : 720956159436439552,
  "created_at" : "2016-04-15 12:45:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/jhzNaPkf9p",
      "expanded_url" : "http:\/\/jdm7dv.blogspot.com\/",
      "display_url" : "jdm7dv.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "720954742223085569",
  "text" : "My most recent posts on Blogger. https:\/\/t.co\/jhzNaPkf9p",
  "id" : 720954742223085569,
  "created_at" : "2016-04-15 12:39:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/Bz84aBLzgH",
      "expanded_url" : "https:\/\/goo.gl\/xhOvr4",
      "display_url" : "goo.gl\/xhOvr4"
    } ]
  },
  "geo" : { },
  "id_str" : "720935379277377536",
  "text" : "A course in asynchronous programming. https:\/\/t.co\/Bz84aBLzgH",
  "id" : 720935379277377536,
  "created_at" : "2016-04-15 11:22:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CERN",
      "screen_name" : "CERN",
      "indices" : [ 3, 8 ],
      "id_str" : "15234407",
      "id" : 15234407
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CERN\/status\/720881877834280961\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/VCgcAntWHb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgEWCoBUYAEaYdF.jpg",
      "id_str" : "720881649714487297",
      "id" : 720881649714487297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgEWCoBUYAEaYdF.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 961,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VCgcAntWHb"
    } ],
    "hashtags" : [ {
      "text" : "InTheory",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/JLQ5lvZAs9",
      "expanded_url" : "http:\/\/cern.ch\/go\/intheory5",
      "display_url" : "cern.ch\/go\/intheory5"
    } ]
  },
  "geo" : { },
  "id_str" : "720934952121024513",
  "text" : "RT @CERN: Which came first? The theorist or the experimentalist? \nFind out: https:\/\/t.co\/JLQ5lvZAs9 \n#InTheory https:\/\/t.co\/VCgcAntWHb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CERN\/status\/720881877834280961\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/VCgcAntWHb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgEWCoBUYAEaYdF.jpg",
        "id_str" : "720881649714487297",
        "id" : 720881649714487297,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgEWCoBUYAEaYdF.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 961,
          "resize" : "fit",
          "w" : 1440
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VCgcAntWHb"
      } ],
      "hashtags" : [ {
        "text" : "InTheory",
        "indices" : [ 91, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/JLQ5lvZAs9",
        "expanded_url" : "http:\/\/cern.ch\/go\/intheory5",
        "display_url" : "cern.ch\/go\/intheory5"
      } ]
    },
    "geo" : { },
    "id_str" : "720881877834280961",
    "text" : "Which came first? The theorist or the experimentalist? \nFind out: https:\/\/t.co\/JLQ5lvZAs9 \n#InTheory https:\/\/t.co\/VCgcAntWHb",
    "id" : 720881877834280961,
    "created_at" : "2016-04-15 07:50:07 +0000",
    "user" : {
      "name" : "CERN",
      "screen_name" : "CERN",
      "protected" : false,
      "id_str" : "15234407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464336727562141696\/RPiEyveo_normal.jpeg",
      "id" : 15234407,
      "verified" : true
    }
  },
  "id" : 720934952121024513,
  "created_at" : "2016-04-15 11:21:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/l5wIShqGeu",
      "expanded_url" : "http:\/\/goo.gl\/nCbsRY",
      "display_url" : "goo.gl\/nCbsRY"
    } ]
  },
  "geo" : { },
  "id_str" : "720790343646593025",
  "text" : "Why musicians hate Spotify. https:\/\/t.co\/l5wIShqGeu",
  "id" : 720790343646593025,
  "created_at" : "2016-04-15 01:46:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720782385911083008",
  "text" : "People do just want to use satellites and look down on you too right Christian? All you have is infrared.",
  "id" : 720782385911083008,
  "created_at" : "2016-04-15 01:14:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/gfH9SyKvJw",
      "expanded_url" : "https:\/\/goo.gl\/w9o7wa",
      "display_url" : "goo.gl\/w9o7wa"
    } ]
  },
  "geo" : { },
  "id_str" : "720780394690441216",
  "text" : "Atomic Email Hunter https:\/\/t.co\/gfH9SyKvJw The best I could find until I find an open source version.",
  "id" : 720780394690441216,
  "created_at" : "2016-04-15 01:06:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720775078670135296",
  "text" : "Net Worth\/ Equity, Opening balance same thing.",
  "id" : 720775078670135296,
  "created_at" : "2016-04-15 00:45:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720774840530112512",
  "text" : "I do have a moderate high NetWorth\/Equity and I'm a little confused in GNUCash when creating a CashFlow statement. See HBCI in Germany.",
  "id" : 720774840530112512,
  "created_at" : "2016-04-15 00:44:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mensa International",
      "screen_name" : "MensaInternatl",
      "indices" : [ 3, 18 ],
      "id_str" : "23770107",
      "id" : 23770107
    }, {
      "name" : "Gifted.",
      "screen_name" : "wggifted",
      "indices" : [ 23, 32 ],
      "id_str" : "57750211",
      "id" : 57750211
    }, {
      "name" : "James L. Moore III",
      "screen_name" : "DrJLMooreIII",
      "indices" : [ 35, 48 ],
      "id_str" : "356854246",
      "id" : 356854246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720375311527862272",
  "text" : "RT @MensaInternatl: RT @wggifted: \u201C@DrJLMooreIII: Study Finds That Academically Gifted Men &amp; Women Have Differing Views on ... Success: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gifted.",
        "screen_name" : "wggifted",
        "indices" : [ 3, 12 ],
        "id_str" : "57750211",
        "id" : 57750211
      }, {
        "name" : "James L. Moore III",
        "screen_name" : "DrJLMooreIII",
        "indices" : [ 15, 28 ],
        "id_str" : "356854246",
        "id" : 356854246
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/vj5jjmIp5P",
        "expanded_url" : "http:\/\/ow.ly\/3uWFn2",
        "display_url" : "ow.ly\/3uWFn2"
      } ]
    },
    "geo" : { },
    "id_str" : "537510328129835010",
    "text" : "RT @wggifted: \u201C@DrJLMooreIII: Study Finds That Academically Gifted Men &amp; Women Have Differing Views on ... Success: http:\/\/t.co\/vj5jjmIp5P\u201D",
    "id" : 537510328129835010,
    "created_at" : "2014-11-26 07:37:03 +0000",
    "user" : {
      "name" : "Mensa International",
      "screen_name" : "MensaInternatl",
      "protected" : false,
      "id_str" : "23770107",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/409586777\/ybg100_normal.gif",
      "id" : 23770107,
      "verified" : false
    }
  },
  "id" : 720375311527862272,
  "created_at" : "2016-04-13 22:17:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ICT-HU",
      "screen_name" : "ICT_Hungary",
      "indices" : [ 3, 15 ],
      "id_str" : "190044397",
      "id" : 190044397
    }, {
      "name" : "Human Brain Project",
      "screen_name" : "HumanBrainProj",
      "indices" : [ 60, 75 ],
      "id_str" : "1112553272",
      "id" : 1112553272
    }, {
      "name" : "FET Flagships",
      "screen_name" : "FETFlagships",
      "indices" : [ 104, 117 ],
      "id_str" : "397117331",
      "id" : 397117331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720247469280534528",
  "text" : "RT @ICT_Hungary: Many young researchers here to learn about @HumanBrainProj platforms at Budapest event @FETFlagships https:\/\/t.co\/dx4QEJlF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Human Brain Project",
        "screen_name" : "HumanBrainProj",
        "indices" : [ 43, 58 ],
        "id_str" : "1112553272",
        "id" : 1112553272
      }, {
        "name" : "FET Flagships",
        "screen_name" : "FETFlagships",
        "indices" : [ 87, 100 ],
        "id_str" : "397117331",
        "id" : 397117331
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ICT_Hungary\/status\/719816137366708224\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/dx4QEJlF5K",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf1M2yFUsAE6SFd.jpg",
        "id_str" : "719816019489894401",
        "id" : 719816019489894401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf1M2yFUsAE6SFd.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/dx4QEJlF5K"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719816137366708224",
    "text" : "Many young researchers here to learn about @HumanBrainProj platforms at Budapest event @FETFlagships https:\/\/t.co\/dx4QEJlF5K",
    "id" : 719816137366708224,
    "created_at" : "2016-04-12 09:15:15 +0000",
    "user" : {
      "name" : "ICT-HU",
      "screen_name" : "ICT_Hungary",
      "protected" : false,
      "id_str" : "190044397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1661121242\/HU_Edina_resize2_normal.jpg",
      "id" : 190044397,
      "verified" : false
    }
  },
  "id" : 720247469280534528,
  "created_at" : "2016-04-13 13:49:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 3, 6 ],
      "id_str" : "14159148",
      "id" : 14159148
    }, {
      "name" : "OnlineVolunteering",
      "screen_name" : "UNVOnline",
      "indices" : [ 61, 71 ],
      "id_str" : "3091665251",
      "id" : 3091665251
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/UN\/status\/720236359173013505\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/GLkYp5YdlX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfw152bVIAABWBY.jpg",
      "id_str" : "719509308451397632",
      "id" : 719509308451397632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfw152bVIAABWBY.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GLkYp5YdlX"
    } ],
    "hashtags" : [ {
      "text" : "UNVOnline",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720246982053199872",
  "text" : "RT @UN: Happening now: Live chat w\/ Elise Bouvet, Manager of @UNVOnline. Send your questions now! #UNVOnline https:\/\/t.co\/GLkYp5YdlX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OnlineVolunteering",
        "screen_name" : "UNVOnline",
        "indices" : [ 53, 63 ],
        "id_str" : "3091665251",
        "id" : 3091665251
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/UN\/status\/720236359173013505\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/GLkYp5YdlX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfw152bVIAABWBY.jpg",
        "id_str" : "719509308451397632",
        "id" : 719509308451397632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfw152bVIAABWBY.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/GLkYp5YdlX"
      } ],
      "hashtags" : [ {
        "text" : "UNVOnline",
        "indices" : [ 90, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720236359173013505",
    "text" : "Happening now: Live chat w\/ Elise Bouvet, Manager of @UNVOnline. Send your questions now! #UNVOnline https:\/\/t.co\/GLkYp5YdlX",
    "id" : 720236359173013505,
    "created_at" : "2016-04-13 13:05:04 +0000",
    "user" : {
      "name" : "United Nations",
      "screen_name" : "UN",
      "protected" : false,
      "id_str" : "14159148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538328216729968642\/SdfeQXSM_normal.png",
      "id" : 14159148,
      "verified" : true
    }
  },
  "id" : 720246982053199872,
  "created_at" : "2016-04-13 13:47:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edi Rama",
      "screen_name" : "ediramaal",
      "indices" : [ 50, 60 ],
      "id_str" : "273410176",
      "id" : 273410176
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Albania",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720246510529679360",
  "text" : "RT @JimKim_WBG: Honor to meet with Prime Minister @ediramaal. He has been a great leader for #Albania &amp; a great champion of reform. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Edi Rama",
        "screen_name" : "ediramaal",
        "indices" : [ 34, 44 ],
        "id_str" : "273410176",
        "id" : 273410176
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JimKim_WBG\/status\/720236276201484288\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/k7LLvDOrjF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf7LE19XIAIPdDE.jpg",
        "id_str" : "720236274490220546",
        "id" : 720236274490220546,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf7LE19XIAIPdDE.jpg",
        "sizes" : [ {
          "h" : 706,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2482,
          "resize" : "fit",
          "w" : 3600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/k7LLvDOrjF"
      } ],
      "hashtags" : [ {
        "text" : "Albania",
        "indices" : [ 77, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720236276201484288",
    "text" : "Honor to meet with Prime Minister @ediramaal. He has been a great leader for #Albania &amp; a great champion of reform. https:\/\/t.co\/k7LLvDOrjF",
    "id" : 720236276201484288,
    "created_at" : "2016-04-13 13:04:44 +0000",
    "user" : {
      "name" : "Jim Yong Kim",
      "screen_name" : "JimYongKim",
      "protected" : false,
      "id_str" : "3239192692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658630359949578240\/pjD-pEMP_normal.jpg",
      "id" : 3239192692,
      "verified" : true
    }
  },
  "id" : 720246510529679360,
  "created_at" : "2016-04-13 13:45:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/IaxfxPhN5k",
      "expanded_url" : "https:\/\/goo.gl\/SjkaQ2",
      "display_url" : "goo.gl\/SjkaQ2"
    } ]
  },
  "geo" : { },
  "id_str" : "720241884669456385",
  "text" : "SugarCRM hosting starting at $4.00\/mo https:\/\/t.co\/IaxfxPhN5k",
  "id" : 720241884669456385,
  "created_at" : "2016-04-13 13:27:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719513950111600640",
  "text" : "I just called Berlin and you do have to visit Germany to open an account.German law forbids opening up an account online with HBCI.",
  "id" : 719513950111600640,
  "created_at" : "2016-04-11 13:14:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/80UolreSbV",
      "expanded_url" : "https:\/\/goo.gl\/s0mPVY",
      "display_url" : "goo.gl\/s0mPVY"
    } ]
  },
  "geo" : { },
  "id_str" : "719513550797082624",
  "text" : "If you are making an album like me and don't want to fly to Germany use Salesforce. https:\/\/t.co\/80UolreSbV",
  "id" : 719513550797082624,
  "created_at" : "2016-04-11 13:12:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/inJMY1YvwC",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pubmed\/3493534",
      "display_url" : "ncbi.nlm.nih.gov\/pubmed\/3493534"
    } ]
  },
  "geo" : { },
  "id_str" : "719239793863958529",
  "text" : "Competition is a disease https:\/\/t.co\/inJMY1YvwC",
  "id" : 719239793863958529,
  "created_at" : "2016-04-10 19:05:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/cm24mYtHhX",
      "expanded_url" : "http:\/\/humansarefree.com\/2015\/07\/scientific-proof-of-reincarnation-yes.html",
      "display_url" : "humansarefree.com\/2015\/07\/scient\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719224381029945344",
  "text" : "Scientific Proof that reincarnation exists. https:\/\/t.co\/cm24mYtHhX",
  "id" : 719224381029945344,
  "created_at" : "2016-04-10 18:03:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Axl Rose",
      "screen_name" : "axlrose",
      "indices" : [ 0, 8 ],
      "id_str" : "95956928",
      "id" : 95956928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718971106892324865",
  "in_reply_to_user_id" : 95956928,
  "text" : "@axlrose Get well soon Axl. :)",
  "id" : 718971106892324865,
  "created_at" : "2016-04-10 01:17:24 +0000",
  "in_reply_to_screen_name" : "axlrose",
  "in_reply_to_user_id_str" : "95956928",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718943199713222656",
  "text" : "There really was never any substance abuse either. Just a little Mary Jane and LSD in high school.",
  "id" : 718943199713222656,
  "created_at" : "2016-04-09 23:26:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/KquhsrgK88",
      "expanded_url" : "http:\/\/goo.gl\/aC76KY",
      "display_url" : "goo.gl\/aC76KY"
    } ]
  },
  "geo" : { },
  "id_str" : "718935982242926592",
  "text" : "Stephen Hawking makes it clear there is no God. https:\/\/t.co\/KquhsrgK88 CNET.",
  "id" : 718935982242926592,
  "created_at" : "2016-04-09 22:57:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718933202019164160",
  "text" : "I own my software copyrights which included Microsoft and Adobe that I've maintained.",
  "id" : 718933202019164160,
  "created_at" : "2016-04-09 22:46:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718932632126562305",
  "text" : "What is the ~1960's definition of \"money\" \"some usually accepted as a medium of exchange\". Find it on the internet archive.",
  "id" : 718932632126562305,
  "created_at" : "2016-04-09 22:44:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/8pd26ZulM8",
      "expanded_url" : "http:\/\/goo.gl\/2FTqYZ",
      "display_url" : "goo.gl\/2FTqYZ"
    } ]
  },
  "geo" : { },
  "id_str" : "718929291724124160",
  "text" : "Google's off shore trick. Forbes. https:\/\/t.co\/8pd26ZulM8",
  "id" : 718929291724124160,
  "created_at" : "2016-04-09 22:31:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/BkAboeCvQl",
      "expanded_url" : "https:\/\/www.divestopedia.com\/14\/4801\/valuation\/divestopedia-valuation-template",
      "display_url" : "divestopedia.com\/14\/4801\/valuat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718928365890248705",
  "text" : "DIY valuation https:\/\/t.co\/BkAboeCvQl.",
  "id" : 718928365890248705,
  "created_at" : "2016-04-09 22:27:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/Sodtmq9SLQ",
      "expanded_url" : "http:\/\/www.investopedia.com\/ask\/answers\/09\/computer-software-intangible-asset.asp",
      "display_url" : "investopedia.com\/ask\/answers\/09\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718926198290714624",
  "text" : "Computer Software assets. https:\/\/t.co\/Sodtmq9SLQ PPE.",
  "id" : 718926198290714624,
  "created_at" : "2016-04-09 22:18:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/G9TkHL9UI0",
      "expanded_url" : "https:\/\/soundcloud.com\/jonathan-moore-122",
      "display_url" : "soundcloud.com\/jonathan-moore\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718920057578004481",
  "text" : "Been recording a lot here are some demos. https:\/\/t.co\/G9TkHL9UI0",
  "id" : 718920057578004481,
  "created_at" : "2016-04-09 21:54:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718918277947371520",
  "text" : "I was born in Atlanta wasn't I? I don't have a country accent do? I am just urban aren't I?",
  "id" : 718918277947371520,
  "created_at" : "2016-04-09 21:47:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/OuO8psx3ey",
      "expanded_url" : "http:\/\/goo.gl\/j8U4C8",
      "display_url" : "goo.gl\/j8U4C8"
    } ]
  },
  "geo" : { },
  "id_str" : "718915997365706754",
  "text" : "People are just getting dumber by what they do with there penises and vaginas aren't they? https:\/\/t.co\/OuO8psx3ey",
  "id" : 718915997365706754,
  "created_at" : "2016-04-09 21:38:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/J9BVRc9dvL",
      "expanded_url" : "http:\/\/people.idsia.ch\/~juergen\/zuse.html",
      "display_url" : "people.idsia.ch\/~juergen\/zuse.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718912759564476421",
  "text" : "Conrad Zuse was German Wasn't he? https:\/\/t.co\/J9BVRc9dvL",
  "id" : 718912759564476421,
  "created_at" : "2016-04-09 21:25:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718911826579308544",
  "text" : "I do start cognitive therapy soon because I try and fix all the worlds problems don't I?",
  "id" : 718911826579308544,
  "created_at" : "2016-04-09 21:21:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718910273894092800",
  "text" : "I'm trying to open an off shore account online. I've already asked the bank all I need to know.I really don't what to fly to save on the CO2",
  "id" : 718910273894092800,
  "created_at" : "2016-04-09 21:15:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718908798300266496",
  "text" : "I am German aren't I? And Mediterranean RZ-28 and H3 rare blood.",
  "id" : 718908798300266496,
  "created_at" : "2016-04-09 21:09:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718907981912530944",
  "text" : "That source code is tangible assets aren't they? I can use GNUCash to move my net worth from my opening balance to checking HBCI in Germany.",
  "id" : 718907981912530944,
  "created_at" : "2016-04-09 21:06:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/W5g7KpIMbD",
      "expanded_url" : "http:\/\/goo.gl\/kkGSPI",
      "display_url" : "goo.gl\/kkGSPI"
    } ]
  },
  "geo" : { },
  "id_str" : "718905531793043456",
  "text" : "Mobile is dead says Google. https:\/\/t.co\/W5g7KpIMbD",
  "id" : 718905531793043456,
  "created_at" : "2016-04-09 20:56:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Community Grid",
      "screen_name" : "WCGrid",
      "indices" : [ 3, 10 ],
      "id_str" : "26388412",
      "id" : 26388412
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wcgrid",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/OX5zq3vSyd",
      "expanded_url" : "https:\/\/secure.worldcommunitygrid.org\/about_us\/viewNewsArticle.do?articleId=474",
      "display_url" : "secure.worldcommunitygrid.org\/about_us\/viewN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718905256407642112",
  "text" : "RT @WCGrid: Site outage for Sunday April 10th  #wcgrid https:\/\/t.co\/OX5zq3vSyd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wcgrid",
        "indices" : [ 35, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/OX5zq3vSyd",
        "expanded_url" : "https:\/\/secure.worldcommunitygrid.org\/about_us\/viewNewsArticle.do?articleId=474",
        "display_url" : "secure.worldcommunitygrid.org\/about_us\/viewN\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718904326756786176",
    "text" : "Site outage for Sunday April 10th  #wcgrid https:\/\/t.co\/OX5zq3vSyd",
    "id" : 718904326756786176,
    "created_at" : "2016-04-09 20:52:02 +0000",
    "user" : {
      "name" : "World Community Grid",
      "screen_name" : "WCGrid",
      "protected" : false,
      "id_str" : "26388412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448919987281866752\/T4oA5jtc_normal.png",
      "id" : 26388412,
      "verified" : false
    }
  },
  "id" : 718905256407642112,
  "created_at" : "2016-04-09 20:55:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/J22OfNpHTQ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=r9-wvOkSmF4",
      "display_url" : "youtube.com\/watch?v=r9-wvO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718896520070873092",
  "text" : "GN'R \"Better\" https:\/\/t.co\/J22OfNpHTQ",
  "id" : 718896520070873092,
  "created_at" : "2016-04-09 20:21:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718895819483717632",
  "text" : "The new album is sounding better than the last. Not relieving the title, but taking the debut and singles out of iTunes adding the new one.",
  "id" : 718895819483717632,
  "created_at" : "2016-04-09 20:18:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/kCks0fo3Y0",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=UqlsVZ1zxMk",
      "display_url" : "youtube.com\/watch?v=UqlsVZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718893244092964865",
  "text" : "Pink Floyd \"Sheep\" BHAAA hold still.https:\/\/t.co\/kCks0fo3Y0",
  "id" : 718893244092964865,
  "created_at" : "2016-04-09 20:08:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718892454997581824",
  "text" : "New album by summer.",
  "id" : 718892454997581824,
  "created_at" : "2016-04-09 20:04:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718890755822116864",
  "text" : "I just did send a request asking stupid Apple to separate me from that other Christian sheep Jonathan Moore \"Moore the Better\" That's not me",
  "id" : 718890755822116864,
  "created_at" : "2016-04-09 19:58:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/e4vy12CqxE",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/album\/four-point-zero\/id936914122",
      "display_url" : "itunes.apple.com\/us\/album\/four-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718887471883399168",
  "text" : "My first album in itunes https:\/\/t.co\/e4vy12CqxE",
  "id" : 718887471883399168,
  "created_at" : "2016-04-09 19:45:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/I5HFBJ0CEu",
      "expanded_url" : "http:\/\/nodejs-jdm7dv.rhcloud.com\/",
      "display_url" : "nodejs-jdm7dv.rhcloud.com"
    } ]
  },
  "geo" : { },
  "id_str" : "718813461153644544",
  "text" : "Working on a new website for 2017. https:\/\/t.co\/I5HFBJ0CEu",
  "id" : 718813461153644544,
  "created_at" : "2016-04-09 14:50:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Hamill",
      "screen_name" : "HamillHimself",
      "indices" : [ 3, 17 ],
      "id_str" : "304679484",
      "id" : 304679484
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RogueWonderful",
      "indices" : [ 73, 88 ]
    }, {
      "text" : "HurryUpDecember",
      "indices" : [ 93, 109 ]
    }, {
      "text" : "ReturnOfTheATATS",
      "indices" : [ 110, 127 ]
    }, {
      "text" : "WOWZA",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718099268842733569",
  "text" : "RT @HamillHimself: Pretty sure I don't have any lines in this one either #RogueWonderful     #HurryUpDecember #ReturnOfTheATATS #WOWZA! htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RogueWonderful",
        "indices" : [ 54, 69 ]
      }, {
        "text" : "HurryUpDecember",
        "indices" : [ 74, 90 ]
      }, {
        "text" : "ReturnOfTheATATS",
        "indices" : [ 91, 108 ]
      }, {
        "text" : "WOWZA",
        "indices" : [ 109, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/FPo7D0fPTT",
        "expanded_url" : "https:\/\/twitter.com\/starwars\/status\/718043194378682373",
        "display_url" : "twitter.com\/starwars\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718073066904018944",
    "text" : "Pretty sure I don't have any lines in this one either #RogueWonderful     #HurryUpDecember #ReturnOfTheATATS #WOWZA! https:\/\/t.co\/FPo7D0fPTT",
    "id" : 718073066904018944,
    "created_at" : "2016-04-07 13:48:54 +0000",
    "user" : {
      "name" : "Mark Hamill",
      "screen_name" : "HamillHimself",
      "protected" : false,
      "id_str" : "304679484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800181980507688960\/U8-Fbx7-_normal.jpg",
      "id" : 304679484,
      "verified" : true
    }
  },
  "id" : 718099268842733569,
  "created_at" : "2016-04-07 15:33:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deutsche Bank",
      "screen_name" : "DeutscheBankAG",
      "indices" : [ 0, 15 ],
      "id_str" : "41331822",
      "id" : 41331822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717405007004442624",
  "in_reply_to_user_id" : 41331822,
  "text" : "@DeutscheBankAG I would like to set up an HBCI private account. And I'm a software engineer using my source code as my reserve. Thanks.",
  "id" : 717405007004442624,
  "created_at" : "2016-04-05 17:34:17 +0000",
  "in_reply_to_screen_name" : "DeutscheBankAG",
  "in_reply_to_user_id_str" : "41331822",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/OLKKcNS5cW",
      "expanded_url" : "http:\/\/www.genepartner.com\/",
      "display_url" : "genepartner.com"
    } ]
  },
  "geo" : { },
  "id_str" : "716367960277966849",
  "text" : "https:\/\/t.co\/OLKKcNS5cW DNA Match Making.",
  "id" : 716367960277966849,
  "created_at" : "2016-04-02 20:53:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/5CcG6Xg2dD",
      "expanded_url" : "https:\/\/www.thevenusproject.com\/",
      "display_url" : "thevenusproject.com"
    } ]
  },
  "geo" : { },
  "id_str" : "716339000152293378",
  "text" : "https:\/\/t.co\/5CcG6Xg2dD The Venus Project",
  "id" : 716339000152293378,
  "created_at" : "2016-04-02 18:58:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/KrayCeRCAD",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/dorieclark\/2013\/01\/04\/why-you-should-be-on-google-plus-even-though-no-one-else-is\/#1970be1d4b8c",
      "display_url" : "forbes.com\/sites\/doriecla\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716236787815948288",
  "text" : "Why you should be on G+ but nobody really is. https:\/\/t.co\/KrayCeRCAD",
  "id" : 716236787815948288,
  "created_at" : "2016-04-02 12:12:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/dj52um3ayz",
      "expanded_url" : "http:\/\/google.com\/+JonathanMoorejdm7dv",
      "display_url" : "google.com\/+JonathanMoore\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716217682991955970",
  "text" : "https:\/\/t.co\/dj52um3ayz",
  "id" : 716217682991955970,
  "created_at" : "2016-04-02 10:56:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/n90LwcQ6sN",
      "expanded_url" : "http:\/\/www.wired.com\/2015\/08\/github-data-shows-changing-software-landscape\/",
      "display_url" : "wired.com\/2015\/08\/github\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716216756298244096",
  "text" : "Open Source has won and I have returned back to my Roots like in 2001 with FreeBSD and Apple. https:\/\/t.co\/n90LwcQ6sN",
  "id" : 716216756298244096,
  "created_at" : "2016-04-02 10:52:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]