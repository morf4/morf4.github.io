Grailbird.data.tweets_2011_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 3, 9 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28081600948346881",
  "text" : "RT @SciAm  http:\/\/bit.ly\/fYU1c3",
  "id" : 28081600948346881,
  "created_at" : "2011-01-20 13:29:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PCWorld",
      "screen_name" : "pcworld",
      "indices" : [ 60, 68 ],
      "id_str" : "6070762",
      "id" : 6070762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 55 ],
      "url" : "http:\/\/t.co\/wGnLjNN",
      "expanded_url" : "http:\/\/www.techworld.com\/",
      "display_url" : "techworld.com"
    } ]
  },
  "geo" : { },
  "id_str" : "26864158452490240",
  "text" : "IPv6 Gets Global Test Day - PCWorld http:\/\/t.co\/wGnLjNN via @PCWorld",
  "id" : 26864158452490240,
  "created_at" : "2011-01-17 04:51:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 63 ],
      "url" : "http:\/\/t.co\/PU4l9Cw",
      "expanded_url" : "http:\/\/singularityhub.com\/2011\/01\/14\/irobots-ava-has-an-ipad-for-a-head-video\/",
      "display_url" : "singularityhub.com\/2011\/01\/14\/iro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "25956526506119169",
  "text" : "iRobot's AVA Has an iPAD for a Head (video) http:\/\/t.co\/PU4l9Cw",
  "id" : 25956526506119169,
  "created_at" : "2011-01-14 16:44:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25339426833965057",
  "text" : "Sundiving Comet Storm http:\/\/7dv.me\/hSOach",
  "id" : 25339426833965057,
  "created_at" : "2011-01-12 23:52:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UXmatters",
      "screen_name" : "uxmatters",
      "indices" : [ 99, 109 ],
      "id_str" : "23922220",
      "id" : 23922220
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24547677874163712",
  "text" : "UXmatters :: Insights and inspiration for the user experience community - http:\/\/bit.ly\/9uTuFp via @uxmatters",
  "id" : 24547677874163712,
  "created_at" : "2011-01-10 19:26:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Witt",
      "screen_name" : "mwittin",
      "indices" : [ 3, 11 ],
      "id_str" : "17489806",
      "id" : 17489806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24476040579522560",
  "text" : "RT @mwittin: MS Zentity 2.0 source release soon; includes new viz (Pivot, Silverlight controls); NET 4, OData, etc; SDK w\/examples; quic ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "or10",
        "indices" : [ 133, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "18114791159",
    "text" : "MS Zentity 2.0 source release soon; includes new viz (Pivot, Silverlight controls); NET 4, OData, etc; SDK w\/examples; quick install #or10",
    "id" : 18114791159,
    "created_at" : "2010-07-09 12:42:20 +0000",
    "user" : {
      "name" : "Michael Witt",
      "screen_name" : "mwittin",
      "protected" : false,
      "id_str" : "17489806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932602779\/witt_corner_normal.jpg",
      "id" : 17489806,
      "verified" : false
    }
  },
  "id" : 24476040579522560,
  "created_at" : "2011-01-10 14:41:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "indices" : [ 80, 88 ],
      "id_str" : "2890961",
      "id" : 2890961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 75 ],
      "url" : "http:\/\/t.co\/j3pIgUz",
      "expanded_url" : "http:\/\/gizmodo.com\/5725699\/",
      "display_url" : "gizmodo.com\/5725699\/"
    } ]
  },
  "geo" : { },
  "id_str" : "24180388783988736",
  "text" : "Samsung's 9 Series Laptop Takes the MacBook Air Head-On http:\/\/t.co\/j3pIgUz via @gizmodo",
  "id" : 24180388783988736,
  "created_at" : "2011-01-09 19:07:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 64 ],
      "url" : "http:\/\/t.co\/YiiZ3ow",
      "expanded_url" : "http:\/\/www.webmd.com\/healthy-aging\/news\/20110107\/mediterranean-diet-may-keep-aging-mind-sharp?ecd=soc_fb",
      "display_url" : "webmd.com\/healthy-aging\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "24174333194674176",
  "text" : "Mediterranean Diet May Keep Aging Mind Sharp http:\/\/t.co\/YiiZ3ow",
  "id" : 24174333194674176,
  "created_at" : "2011-01-09 18:43:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23954568211595265",
  "text" : "had to repair a SQL Server instance which was quite magical.",
  "id" : 23954568211595265,
  "created_at" : "2011-01-09 04:09:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23855251127803904",
  "text" : "getting all research contacts together tomorrow.",
  "id" : 23855251127803904,
  "created_at" : "2011-01-08 21:35:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23854786117902336",
  "text" : "Infer.NET bit.ly\/gxZg6G",
  "id" : 23854786117902336,
  "created_at" : "2011-01-08 21:33:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]