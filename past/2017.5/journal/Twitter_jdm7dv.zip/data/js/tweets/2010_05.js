Grailbird.data.tweets_2010_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Nye",
      "screen_name" : "GlennNye",
      "indices" : [ 0, 9 ],
      "id_str" : "15861717",
      "id" : 15861717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14829239723",
  "in_reply_to_user_id" : 15861717,
  "text" : "@glennnye please protect Net Neutrality and promote universal broadband access. Thank You",
  "id" : 14829239723,
  "created_at" : "2010-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "GlennNye",
  "in_reply_to_user_id_str" : "15861717",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian_Henderson",
      "screen_name" : "brian_henderson",
      "indices" : [ 3, 19 ],
      "id_str" : "14438014",
      "id" : 14438014
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 92, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14168253262",
  "text" : "RT @brian_henderson: Multi-Touch in WPF & Silverlight: by AttachedWpf: http:\/\/bit.ly\/aqHeFc #fb",
  "id" : 14168253262,
  "created_at" : "2010-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNET",
      "screen_name" : "CNET",
      "indices" : [ 3, 8 ],
      "id_str" : "30261067",
      "id" : 30261067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14082712267",
  "text" : "RT @cnet Microsoft takes H.264 stand in Web video debate | Deep Tech - CNET News http:\/\/bit.ly\/9JewWa",
  "id" : 14082712267,
  "created_at" : "2010-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 62, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13440865678",
  "text" : "the surface globe app in awesome in the Windows 7 touch pack! #fb",
  "id" : 13440865678,
  "created_at" : "2010-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 44, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13385625588",
  "text" : "is creatinig a linux distro. pretty easy :) #fb",
  "id" : 13385625588,
  "created_at" : "2010-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 44, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13323260694",
  "text" : "adding collection classes to \"Singularity?\" #fb",
  "id" : 13323260694,
  "created_at" : "2010-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]