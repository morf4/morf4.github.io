Grailbird.data.tweets_2012_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 81, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/gan6YsTJ",
      "expanded_url" : "http:\/\/pop.to\/jl9v",
      "display_url" : "pop.to\/jl9v"
    } ]
  },
  "geo" : { },
  "id_str" : "190914487589666816",
  "text" : "Wastewater Management Challenges Affecting the Shale Gas Industry via PRNewswire #fb http:\/\/t.co\/gan6YsTJ",
  "id" : 190914487589666816,
  "created_at" : "2012-04-13 21:28:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 88, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/nrbRGGRW",
      "expanded_url" : "http:\/\/news.discovery.com\/space\/space-forensics-might-point-to-a-martian-ancestry-110326.html",
      "display_url" : "news.discovery.com\/space\/space-fo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190802796617007104",
  "text" : "Space Forensics Might Point to a Martian Ancestry : Discovery News http:\/\/t.co\/nrbRGGRW #fb",
  "id" : 190802796617007104,
  "created_at" : "2012-04-13 14:05:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 102, 108 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 109, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/tPMrZrG4",
      "expanded_url" : "http:\/\/www.scientificamerican.com\/article.cfm?id=feeding-the-world-while-the-earth-cooks-live-webcast&WT.mc_id=SA_sharetool_Twitter",
      "display_url" : "scientificamerican.com\/article.cfm?id\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190796325569314816",
  "text" : "Feeding the World, While the Earth Cooks [Live Webcast]: Scientific American http:\/\/t.co\/tPMrZrG4 via @sciam #fb",
  "id" : 190796325569314816,
  "created_at" : "2012-04-13 13:39:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 89, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/0lXqR9Gj",
      "expanded_url" : "http:\/\/www.liveinthenow.com\/article\/boost-your-brain-power-with-resveratrol-and-its-lesser-known-cousin",
      "display_url" : "liveinthenow.com\/article\/boost-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190555269523181569",
  "text" : "Boost Your Brain Power with Resveratrol and Its Lesser-Known Cousin http:\/\/t.co\/0lXqR9Gj #fb",
  "id" : 190555269523181569,
  "created_at" : "2012-04-12 21:41:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 66, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/Okgabf81",
      "expanded_url" : "http:\/\/www.liveinthenow.com\/article\/are-your-favorite-beverages-bad-for-your-heart",
      "display_url" : "liveinthenow.com\/article\/are-yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190438167382462464",
  "text" : "Are your favorite drinks bad for your heart? http:\/\/t.co\/Okgabf81 #fb",
  "id" : 190438167382462464,
  "created_at" : "2012-04-12 13:56:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Think",
      "screen_name" : "bigthink",
      "indices" : [ 65, 74 ],
      "id_str" : "18567018",
      "id" : 18567018
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 75, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/erFHFqlx",
      "expanded_url" : "http:\/\/bigthink.com\/ideafeed\/has-earth-seeded-life-on-other-planets",
      "display_url" : "bigthink.com\/ideafeed\/has-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190424532929097728",
  "text" : "Has Earth Seeded Life on Other Planets? http:\/\/t.co\/erFHFqlx via @bigthink #fb",
  "id" : 190424532929097728,
  "created_at" : "2012-04-12 13:02:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ars Technica",
      "screen_name" : "arstechnica",
      "indices" : [ 85, 97 ],
      "id_str" : "717313",
      "id" : 717313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 98, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/Zyfit99G",
      "expanded_url" : "http:\/\/arst.ch\/ka0",
      "display_url" : "arst.ch\/ka0"
    } ]
  },
  "geo" : { },
  "id_str" : "190246256738701313",
  "text" : "Quantum teleportation achieved over ten miles of free space http:\/\/t.co\/Zyfit99G via @arstechnica #fb",
  "id" : 190246256738701313,
  "created_at" : "2012-04-12 01:13:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 130, 136 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/Qovm1Qd5",
      "expanded_url" : "http:\/\/www.scientificamerican.com\/article.cfm?id=universal-quantum-network&WT.mc_id=SA_sharetool_Twitter",
      "display_url" : "scientificamerican.com\/article.cfm?id\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190232684159696897",
  "text" : "Bits of the Future: First Universal Quantum Network Prototype Links 2 Separate Labs: Scientific American http:\/\/t.co\/Qovm1Qd5 via @sciam #fb",
  "id" : 190232684159696897,
  "created_at" : "2012-04-12 00:19:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 91, 97 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 98, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/v3k2PAxd",
      "expanded_url" : "http:\/\/www.scientificamerican.com\/article.cfm?id=double-edged-hormone&WT.mc_id=SA_sharetool_Twitter",
      "display_url" : "scientificamerican.com\/article.cfm?id\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190216902952484865",
  "text" : "Mood Drug Can Both Cause and Relieve Anxiety: Scientific American http:\/\/t.co\/v3k2PAxd via @sciam #fb",
  "id" : 190216902952484865,
  "created_at" : "2012-04-11 23:16:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 38, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190203727406309376",
  "text" : "Upgrading to SQL Server 2012 tomorrow #fb",
  "id" : 190203727406309376,
  "created_at" : "2012-04-11 22:24:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Minott",
      "screen_name" : "KevinMinott",
      "indices" : [ 3, 15 ],
      "id_str" : "18066875",
      "id" : 18066875
    }, {
      "name" : "TNW Top Stories",
      "screen_name" : "TNW",
      "indices" : [ 94, 98 ],
      "id_str" : "105192845",
      "id" : 105192845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/4SPfCnno",
      "expanded_url" : "http:\/\/bit.ly\/ISckX8",
      "display_url" : "bit.ly\/ISckX8"
    } ]
  },
  "geo" : { },
  "id_str" : "190197719682392066",
  "text" : "RT @KevinMinott: Global PC shipments tick up in Q1, raising eyebrows http:\/\/t.co\/4SPfCnno via @TNW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TNW Top Stories",
        "screen_name" : "TNW",
        "indices" : [ 77, 81 ],
        "id_str" : "105192845",
        "id" : 105192845
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/4SPfCnno",
        "expanded_url" : "http:\/\/bit.ly\/ISckX8",
        "display_url" : "bit.ly\/ISckX8"
      } ]
    },
    "geo" : { },
    "id_str" : "190197411350708224",
    "text" : "Global PC shipments tick up in Q1, raising eyebrows http:\/\/t.co\/4SPfCnno via @TNW",
    "id" : 190197411350708224,
    "created_at" : "2012-04-11 21:59:31 +0000",
    "user" : {
      "name" : "Kevin Minott",
      "screen_name" : "KevinMinott",
      "protected" : false,
      "id_str" : "18066875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710825251332968448\/W_YdFRXO_normal.jpg",
      "id" : 18066875,
      "verified" : false
    }
  },
  "id" : 190197719682392066,
  "created_at" : "2012-04-11 22:00:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 107, 113 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 114, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/hH4rwYs1",
      "expanded_url" : "http:\/\/www.scientificamerican.com\/article.cfm?id=cooperative-neural-networks-suggest-how-intelligence-evolved&WT.mc_id=SA_sharetool_Twitter",
      "display_url" : "scientificamerican.com\/article.cfm?id\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190180470393286656",
  "text" : "Cooperative Neural Networks Suggest How Intelligence Evolved: Scientific American http:\/\/t.co\/hH4rwYs1 via @sciam #fb",
  "id" : 190180470393286656,
  "created_at" : "2012-04-11 20:52:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techie Buzz",
      "screen_name" : "techiebuzzer",
      "indices" : [ 103, 116 ],
      "id_str" : "16703017",
      "id" : 16703017
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 117, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/oTlzoG5K",
      "expanded_url" : "http:\/\/techie-buzz.com\/tech-news\/rss-is-not-dead.html",
      "display_url" : "techie-buzz.com\/tech-news\/rss-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190165110126428163",
  "text" : "IS RSS Dead? Well No, It\u2019s Powering Up Things Which Are Supposedly Killing IT http:\/\/t.co\/oTlzoG5K via @techiebuzzer #fb",
  "id" : 190165110126428163,
  "created_at" : "2012-04-11 19:51:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 62, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/233H6No2",
      "expanded_url" : "http:\/\/cdsweb.cern.ch\/journal\/CERNBulletin\/2012\/14\/News%20Articles\/1434428?ln=en",
      "display_url" : "cdsweb.cern.ch\/journal\/CERNBu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190164386869022720",
  "text" : "Different way, same goal - CERN Bulletin http:\/\/t.co\/233H6No2 #fb",
  "id" : 190164386869022720,
  "created_at" : "2012-04-11 19:48:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Think",
      "screen_name" : "bigthink",
      "indices" : [ 74, 83 ],
      "id_str" : "18567018",
      "id" : 18567018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/sWVlriiC",
      "expanded_url" : "http:\/\/www.bigthink.com\/ideafeed\/scientists-watch-as-black-holes-destroy-galaxies",
      "display_url" : "bigthink.com\/ideafeed\/scien\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190163370249424897",
  "text" : "Scientists Watch as Black Holes Destroy Galaxies http:\/\/t.co\/sWVlriiC via @bigthink",
  "id" : 190163370249424897,
  "created_at" : "2012-04-11 19:44:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEDMED",
      "screen_name" : "TEDMED",
      "indices" : [ 3, 10 ],
      "id_str" : "23771696",
      "id" : 23771696
    }, {
      "name" : "Urban Zen",
      "screen_name" : "Urban_Zen",
      "indices" : [ 47, 57 ],
      "id_str" : "21328726",
      "id" : 21328726
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TEDMED",
      "indices" : [ 12, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190154864737796098",
  "text" : "RT @TEDMED: #TEDMED overstimulating your mind? @Urban_Zen is offering aromatherapy, reiki and restorative yoga in the Africa Room",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Urban Zen",
        "screen_name" : "Urban_Zen",
        "indices" : [ 35, 45 ],
        "id_str" : "21328726",
        "id" : 21328726
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TEDMED",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "190153529376251907",
    "text" : "#TEDMED overstimulating your mind? @Urban_Zen is offering aromatherapy, reiki and restorative yoga in the Africa Room",
    "id" : 190153529376251907,
    "created_at" : "2012-04-11 19:05:08 +0000",
    "user" : {
      "name" : "TEDMED",
      "screen_name" : "TEDMED",
      "protected" : false,
      "id_str" : "23771696",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410379290\/a69e140338a4837a75c75a74b86ba1c6_normal.jpeg",
      "id" : 23771696,
      "verified" : false
    }
  },
  "id" : 190154864737796098,
  "created_at" : "2012-04-11 19:10:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 69, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/gvc6UelK",
      "expanded_url" : "http:\/\/bit.ly\/I3GSYm",
      "display_url" : "bit.ly\/I3GSYm"
    } ]
  },
  "geo" : { },
  "id_str" : "190151665708576768",
  "text" : "Tree logging app to help keep our cities green: http:\/\/t.co\/gvc6UelK #fb",
  "id" : 190151665708576768,
  "created_at" : "2012-04-11 18:57:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 39, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/xgXDSzKZ",
      "expanded_url" : "http:\/\/www.bu.edu\/today\/2012\/taking-on-cancer-tackling-liver-cancer-in-the-lab\/",
      "display_url" : "bu.edu\/today\/2012\/tak\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190146362078273536",
  "text" : "Taking on Cancer: http:\/\/t.co\/xgXDSzKZ #fb",
  "id" : 190146362078273536,
  "created_at" : "2012-04-11 18:36:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Think",
      "screen_name" : "bigthink",
      "indices" : [ 63, 72 ],
      "id_str" : "18567018",
      "id" : 18567018
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 73, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/bZUzVPhm",
      "expanded_url" : "http:\/\/bigthink.com\/ideafeed\/search-for-higgs-gets-big-power-boost",
      "display_url" : "bigthink.com\/ideafeed\/searc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190106409608810498",
  "text" : "Search for Higgs Gets Big Power Boost http:\/\/t.co\/bZUzVPhm via @bigthink #fb",
  "id" : 190106409608810498,
  "created_at" : "2012-04-11 15:57:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 130, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/7kLMD5Yp",
      "expanded_url" : "http:\/\/singularityhub.com\/2012\/04\/11\/robots-will-drive-bust-through-a-wall-and-make-repairs-in-darpas-new-robotics-challenge\/",
      "display_url" : "singularityhub.com\/2012\/04\/11\/rob\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190106028937986048",
  "text" : "Robots Will Drive, Bust Through A Wall, And Make Repairs In DARPA\u2019s New Robotics Challenge | Singularity Hub http:\/\/t.co\/7kLMD5Yp #fb",
  "id" : 190106028937986048,
  "created_at" : "2012-04-11 15:56:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/Y0d6gN8D",
      "expanded_url" : "http:\/\/soc.li\/2bczK7U",
      "display_url" : "soc.li\/2bczK7U"
    } ]
  },
  "geo" : { },
  "id_str" : "190101970223251456",
  "text" : "'Universal' cancer vaccine developed  - Telegraph http:\/\/t.co\/Y0d6gN8D",
  "id" : 190101970223251456,
  "created_at" : "2012-04-11 15:40:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 97 ],
      "url" : "http:\/\/t.co\/IFbWpF3",
      "expanded_url" : "http:\/\/www.good.is\/post\/young-people-drive-23-percent-less-than-they-did-in-2001\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+good%2Flbvp+%28GOOD+Main+RSS+Feed%29",
      "display_url" : "good.is\/post\/young-peo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190100903209074691",
  "text" : "Young People Drive 23 Percent Less Than They Did in 2001 - Environment - GOOD http:\/\/t.co\/IFbWpF3",
  "id" : 190100903209074691,
  "created_at" : "2012-04-11 15:36:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jdm7dv",
      "indices" : [ 36, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/JkmcNJkr",
      "expanded_url" : "http:\/\/singularityhub.com\/2012\/04\/09\/the-video-resume-%E2%80%94-modern-necessity-or-domain-of-epic-fail\/",
      "display_url" : "singularityhub.com\/2012\/04\/09\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "189895750531031042",
  "text" : "Video Resumes? http:\/\/t.co\/JkmcNJkr #jdm7dv",
  "id" : 189895750531031042,
  "created_at" : "2012-04-11 02:00:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]