Grailbird.data.tweets_2016_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 0, 6 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759850183085744128",
  "in_reply_to_user_id" : 1536791610,
  "text" : "@POTUS You are of mixed race Mr. President, what is your mother never had you?",
  "id" : 759850183085744128,
  "created_at" : "2016-07-31 20:36:15 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Tim Kaine",
      "screen_name" : "timkaine",
      "indices" : [ 0, 9 ],
      "id_str" : "172858784",
      "id" : 172858784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/ZXM22qixjj",
      "expanded_url" : "https:\/\/bitbucket.org\/jdm7dv\/",
      "display_url" : "bitbucket.org\/jdm7dv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "759846833657118720",
  "in_reply_to_user_id" : 172858784,
  "text" : "@timkaine I have a 140 IQ Mr.Kaine and I stutter I am pro life.Take on Me. https:\/\/t.co\/ZXM22qixjj",
  "id" : 759846833657118720,
  "created_at" : "2016-07-31 20:22:57 +0000",
  "in_reply_to_screen_name" : "timkaine",
  "in_reply_to_user_id_str" : "172858784",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Z7fugnEh7z",
      "expanded_url" : "http:\/\/goo.gl\/TR4jrR",
      "display_url" : "goo.gl\/TR4jrR"
    } ]
  },
  "geo" : { },
  "id_str" : "759761937626431488",
  "text" : "https:\/\/t.co\/Z7fugnEh7z Important tax beak for renters or home owners.",
  "id" : 759761937626431488,
  "created_at" : "2016-07-31 14:45:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/HfySeFhYrz",
      "expanded_url" : "https:\/\/goo.gl\/M3CiUy",
      "display_url" : "goo.gl\/M3CiUy"
    } ]
  },
  "geo" : { },
  "id_str" : "758384809580326912",
  "text" : "'The Ambient Moments of jdm7dv Vol. 1' just released today on Bandcamp. https:\/\/t.co\/HfySeFhYrz",
  "id" : 758384809580326912,
  "created_at" : "2016-07-27 19:33:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 0, 11 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757016466902355969",
  "in_reply_to_user_id" : 30313925,
  "text" : "@WhiteHouse Put the fear of man in them Mr. President. I just overheard my neighbors say they wish I were dead.",
  "id" : 757016466902355969,
  "created_at" : "2016-07-24 00:56:05 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/8UiHgdqISv",
      "expanded_url" : "http:\/\/goo.gl\/ANMWgw",
      "display_url" : "goo.gl\/ANMWgw"
    } ]
  },
  "geo" : { },
  "id_str" : "756283275795132417",
  "text" : "It takes 479 MW to power 4,790,000 homes. Which is = to 1 nuclear reactor. This is how much wind and solar we need.https:\/\/t.co\/8UiHgdqISv",
  "id" : 756283275795132417,
  "created_at" : "2016-07-22 00:22:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756281733637693440",
  "text" : "I emailed Dr. Church about Bioviva he emailed me back and said that the \"success\" would have to go  under peer review and controlled trials.",
  "id" : 756281733637693440,
  "created_at" : "2016-07-22 00:16:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/gG4hsxZ7Xo",
      "expanded_url" : "http:\/\/goo.gl\/Iw9TPf",
      "display_url" : "goo.gl\/Iw9TPf"
    } ]
  },
  "geo" : { },
  "id_str" : "753238130996703232",
  "text" : "Why human's don't have much to do with climate change. https:\/\/t.co\/gG4hsxZ7Xo",
  "id" : 753238130996703232,
  "created_at" : "2016-07-13 14:42:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 0, 11 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/hQmq2ERuZK",
      "expanded_url" : "http:\/\/goo.gl\/1tcGDV",
      "display_url" : "goo.gl\/1tcGDV"
    } ]
  },
  "geo" : { },
  "id_str" : "752990183138684929",
  "in_reply_to_user_id" : 30313925,
  "text" : "@WhiteHouse Humans pay to live and that's not natural. https:\/\/t.co\/hQmq2ERuZK",
  "id" : 752990183138684929,
  "created_at" : "2016-07-12 22:17:04 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751915707407986688",
  "text" : "I'm not deleting ANY of the tech just making it more loud.",
  "id" : 751915707407986688,
  "created_at" : "2016-07-09 23:07:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751913734579294208",
  "text" : "Ever since 2001 the area has kept me from women because of jealousy. I have given my all every day. I really have had enough.",
  "id" : 751913734579294208,
  "created_at" : "2016-07-09 22:59:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 49, 57 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/Ac8mHQt8YW",
      "expanded_url" : "https:\/\/youtu.be\/B9DWS67fMrM",
      "display_url" : "youtu.be\/B9DWS67fMrM"
    } ]
  },
  "geo" : { },
  "id_str" : "751911649603383296",
  "text" : "The Who - Had Enough https:\/\/t.co\/Ac8mHQt8YW via @YouTube",
  "id" : 751911649603383296,
  "created_at" : "2016-07-09 22:51:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751909905297211393",
  "text" : "You can have a kid and say \"awe\" look at what I did. I'm not going to teach it after what your parents have done to me.",
  "id" : 751909905297211393,
  "created_at" : "2016-07-09 22:44:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751904784832167936",
  "text" : "I restricted my G+ profile myself. And I have the power to unrestrict it. I just don't like people.",
  "id" : 751904784832167936,
  "created_at" : "2016-07-09 22:24:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "indices" : [ 3, 9 ],
      "id_str" : "3819701",
      "id" : 3819701
    }, {
      "name" : "Charlie Osborne",
      "screen_name" : "SecurityCharlie",
      "indices" : [ 110, 126 ],
      "id_str" : "302716548",
      "id" : 302716548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/OpFig1x6UX",
      "expanded_url" : "http:\/\/zd.net\/29pUbqI",
      "display_url" : "zd.net\/29pUbqI"
    } ]
  },
  "geo" : { },
  "id_str" : "751904446628687872",
  "text" : "RT @ZDNet: Self-driving robot delivery guys set to take over UK, Switzerland, Germany https:\/\/t.co\/OpFig1x6UX @SecurityCharlie https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charlie Osborne",
        "screen_name" : "SecurityCharlie",
        "indices" : [ 99, 115 ],
        "id_str" : "302716548",
        "id" : 302716548
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ZDNet\/status\/751902561830047744\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/Tx7roVCmQ5",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cm9LY9QWgAADN7H.jpg",
        "id_str" : "751902554926252032",
        "id" : 751902554926252032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cm9LY9QWgAADN7H.jpg",
        "sizes" : [ {
          "h" : 250,
          "resize" : "fit",
          "w" : 448
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 448
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 448
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Tx7roVCmQ5"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/OpFig1x6UX",
        "expanded_url" : "http:\/\/zd.net\/29pUbqI",
        "display_url" : "zd.net\/29pUbqI"
      } ]
    },
    "geo" : { },
    "id_str" : "751902561830047744",
    "text" : "Self-driving robot delivery guys set to take over UK, Switzerland, Germany https:\/\/t.co\/OpFig1x6UX @SecurityCharlie https:\/\/t.co\/Tx7roVCmQ5",
    "id" : 751902561830047744,
    "created_at" : "2016-07-09 22:15:15 +0000",
    "user" : {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "protected" : false,
      "id_str" : "3819701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706961982545473536\/Ibj46-DX_normal.jpg",
      "id" : 3819701,
      "verified" : true
    }
  },
  "id" : 751904446628687872,
  "created_at" : "2016-07-09 22:22:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751899768419409920",
  "text" : "You wouldn't be alive if it weren't for you computer probably.",
  "id" : 751899768419409920,
  "created_at" : "2016-07-09 22:04:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/mJ1ZuniD6B",
      "expanded_url" : "http:\/\/goo.gl\/vO45Ur",
      "display_url" : "goo.gl\/vO45Ur"
    } ]
  },
  "geo" : { },
  "id_str" : "751897248032821249",
  "text" : "Windows 10 killed the Linux desktop. However open source has won just not finished. I do have Windows source. https:\/\/t.co\/mJ1ZuniD6B",
  "id" : 751897248032821249,
  "created_at" : "2016-07-09 21:54:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751888338668363776",
  "text" : "Beach boys and the boys and girls of summer will just name call and bully too.",
  "id" : 751888338668363776,
  "created_at" : "2016-07-09 21:18:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 66, 74 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/AjUVOghPo0",
      "expanded_url" : "https:\/\/youtu.be\/MG-G7pKD5uM",
      "display_url" : "youtu.be\/MG-G7pKD5uM"
    } ]
  },
  "geo" : { },
  "id_str" : "751884627204313088",
  "text" : "[HD] Pearl Jam - Habit [Pinkpop 2000] https:\/\/t.co\/AjUVOghPo0 via @YouTube",
  "id" : 751884627204313088,
  "created_at" : "2016-07-09 21:03:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/LRNCDluwRL",
      "expanded_url" : "http:\/\/www.baystreet.ca\/viewarticle.aspx?id=441767",
      "display_url" : "baystreet.ca\/viewarticle.as\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751883563981803520",
  "text" : "Waves Platform is coming to the internet. Think Bitcoin. https:\/\/t.co\/LRNCDluwRL",
  "id" : 751883563981803520,
  "created_at" : "2016-07-09 20:59:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751879809257574404",
  "text" : "I'm working on my Social Media Moments by deleting some one liners and really creating a good UX on G+. It might be restricted for a while.",
  "id" : 751879809257574404,
  "created_at" : "2016-07-09 20:44:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751863771434549248",
  "text" : "I can just buy fans too like every other performer I'm just not.",
  "id" : 751863771434549248,
  "created_at" : "2016-07-09 19:41:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/uyZaYgilHM",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=TDN-orxoMBg",
      "display_url" : "youtube.com\/watch?v=TDN-or\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751860849388773376",
  "text" : "https:\/\/t.co\/uyZaYgilHM",
  "id" : 751860849388773376,
  "created_at" : "2016-07-09 19:29:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 0, 11 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751857472269410305",
  "in_reply_to_user_id" : 30313925,
  "text" : "@WhiteHouse Mr. President now the area is just trying to scare me with chain saws because I would let anyone view my Linkedin or G+.",
  "id" : 751857472269410305,
  "created_at" : "2016-07-09 19:16:04 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/TgZTG1M8fh",
      "expanded_url" : "http:\/\/www.bechtel.com\/projects\/watts-bar-completion\/",
      "display_url" : "bechtel.com\/projects\/watts\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750997371325218816",
  "text" : "Watts bar completion nuclear carbon free reactor https:\/\/t.co\/TgZTG1M8fh",
  "id" : 750997371325218816,
  "created_at" : "2016-07-07 10:18:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/MIyiHPNwJg",
      "expanded_url" : "http:\/\/goo.gl\/3sBPGF",
      "display_url" : "goo.gl\/3sBPGF"
    } ]
  },
  "geo" : { },
  "id_str" : "750286508591022080",
  "text" : "Say hello to immorality (I hope). https:\/\/t.co\/MIyiHPNwJg",
  "id" : 750286508591022080,
  "created_at" : "2016-07-05 11:13:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749749716167032832",
  "text" : "I am only helping my elders too.",
  "id" : 749749716167032832,
  "created_at" : "2016-07-03 23:40:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 0, 11 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749748602294112256",
  "in_reply_to_user_id" : 30313925,
  "text" : "@WhiteHouse Now this area is just waiting on my body to wear down Mr. President.",
  "id" : 749748602294112256,
  "created_at" : "2016-07-03 23:36:11 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 0, 11 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749369793174798337",
  "in_reply_to_user_id" : 30313925,
  "text" : "@WhiteHouse I did try to call 911 one time and nobody showed.",
  "id" : 749369793174798337,
  "created_at" : "2016-07-02 22:30:55 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 0, 11 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749368093303013376",
  "in_reply_to_user_id" : 30313925,
  "text" : "@WhiteHouse Help Mr. President I think the area is secretly trying to kill my family.",
  "id" : 749368093303013376,
  "created_at" : "2016-07-02 22:24:10 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 0, 11 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749054948470644736",
  "in_reply_to_user_id" : 30313925,
  "text" : "@WhiteHouse sorry Mr President I just didn't know what else to say.",
  "id" : 749054948470644736,
  "created_at" : "2016-07-02 01:39:51 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 0, 11 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749046208308645889",
  "in_reply_to_user_id" : 30313925,
  "text" : "@WhiteHouse I am just one life to you Mr. President but I did score a 140 on my Mensa mobile test &amp; I'm in the national assoc.for the gifted",
  "id" : 749046208308645889,
  "created_at" : "2016-07-02 01:05:07 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minor Planet Center",
      "screen_name" : "MinorPlanetCtr",
      "indices" : [ 46, 61 ],
      "id_str" : "289049839",
      "id" : 289049839
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Asteroid",
      "indices" : [ 21, 30 ]
    }, {
      "text" : "AsteroidExplorers",
      "indices" : [ 62, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/6vIC9MTw8A",
      "expanded_url" : "http:\/\/asteroid-explorers.herokuapp.com\/asteroids\/2010%20RF12",
      "display_url" : "asteroid-explorers.herokuapp.com\/asteroids\/2010\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748843523579875333",
  "text" : "Check out Near Earth #Asteroid 2010 RF12! Via @MinorPlanetCtr #AsteroidExplorers https:\/\/t.co\/6vIC9MTw8A",
  "id" : 748843523579875333,
  "created_at" : "2016-07-01 11:39:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minor Planet Center",
      "screen_name" : "MinorPlanetCtr",
      "indices" : [ 24, 39 ],
      "id_str" : "289049839",
      "id" : 289049839
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "asteroids",
      "indices" : [ 8, 18 ]
    }, {
      "text" : "AsteroidExplorers",
      "indices" : [ 96, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/mDdAstMoWa",
      "expanded_url" : "http:\/\/www.asteroid-explorers.com\/mpc\/",
      "display_url" : "asteroid-explorers.com\/mpc\/"
    } ]
  },
  "geo" : { },
  "id_str" : "748841016308801536",
  "text" : "Explore #asteroids with @MinorPlanetCtr Asteroid Data Explorer Project: https:\/\/t.co\/mDdAstMoWa #AsteroidExplorers",
  "id" : 748841016308801536,
  "created_at" : "2016-07-01 11:29:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/F905xyaWNK",
      "expanded_url" : "http:\/\/goo.gl\/BvoDcL",
      "display_url" : "goo.gl\/BvoDcL"
    } ]
  },
  "geo" : { },
  "id_str" : "748820721808187393",
  "text" : "Nasa confirms earth has second moon. https:\/\/t.co\/F905xyaWNK",
  "id" : 748820721808187393,
  "created_at" : "2016-07-01 10:09:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]