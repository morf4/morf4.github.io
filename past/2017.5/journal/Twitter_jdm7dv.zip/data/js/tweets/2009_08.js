Grailbird.data.tweets_2009_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3491529264",
  "text" : "Free Anti-Virus software from Microsoft code named \"Morro\"",
  "id" : 3491529264,
  "created_at" : "2009-08-23 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 48, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3169641069",
  "text" : "working on .NET RIA Services POCO at the moment #fb",
  "id" : 3169641069,
  "created_at" : "2009-08-06 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 119, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3114958632",
  "text" : "cancer experts have moved tanning beds into the top cancer risk category deeming both to be definite causes of cancer. #fb",
  "id" : 3114958632,
  "created_at" : "2009-08-04 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 50, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3123520042",
  "text" : "starting to create samples for RIA Services talk. #fb",
  "id" : 3123520042,
  "created_at" : "2009-08-04 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crystal",
      "screen_name" : "crystal",
      "indices" : [ 0, 8 ],
      "id_str" : "15",
      "id" : 15
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3105519139",
  "in_reply_to_user_id" : 15,
  "text" : "@crystal can you help my tweets are not showing up in the search results only old ones please help. Thanks.",
  "id" : 3105519139,
  "created_at" : "2009-08-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "crystal",
  "in_reply_to_user_id_str" : "15",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]