Grailbird.data.tweets_2011_08 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 69, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 68 ],
      "url" : "http:\/\/t.co\/l5gzFxK",
      "expanded_url" : "http:\/\/www.thepetitionsite.com\/takeaction\/388\/273\/528\/",
      "display_url" : "thepetitionsite.com\/takeaction\/388\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "105493200562696192",
  "text" : "Support Youth Working for a More Peaceful World: http:\/\/t.co\/l5gzFxK #fb",
  "id" : 105493200562696192,
  "created_at" : "2011-08-22 04:15:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Earth Touch",
      "screen_name" : "EarthTouch",
      "indices" : [ 74, 85 ],
      "id_str" : "20499813",
      "id" : 20499813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 86, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 69 ],
      "url" : "http:\/\/t.co\/5zCQg2V",
      "expanded_url" : "http:\/\/www.earth-touch.com\/result.php?i=Dolphins:-Proficient-predators-of-the-Sardine-Run",
      "display_url" : "earth-touch.com\/result.php?i=D\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "105450745163284481",
  "text" : "Dolphins: Proficient predators of the Sardine Run http:\/\/t.co\/5zCQg2V via @earthtouch #fb",
  "id" : 105450745163284481,
  "created_at" : "2011-08-22 01:26:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 59 ],
      "url" : "http:\/\/t.co\/2CrliG7",
      "expanded_url" : "http:\/\/qik.ly\/IPR9u",
      "display_url" : "qik.ly\/IPR9u"
    } ]
  },
  "geo" : { },
  "id_str" : "105409469248319489",
  "text" : "Qik - Database Layout by Jonathan Moore http:\/\/t.co\/2CrliG7",
  "id" : 105409469248319489,
  "created_at" : "2011-08-21 22:42:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 72, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105347155161657345",
  "text" : "does anyone know a better copy program for windows other than fastcopy? #fb",
  "id" : 105347155161657345,
  "created_at" : "2011-08-21 18:34:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]