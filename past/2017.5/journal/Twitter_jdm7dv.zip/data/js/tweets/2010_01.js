Grailbird.data.tweets_2010_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 76, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8433295799",
  "text" : "This ste is awesome for C# snippets. Plus its a Wiki!  http:\/\/bit.ly\/11Bv74 #fb",
  "id" : 8433295799,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Coast Guard",
      "screen_name" : "uscoastguard",
      "indices" : [ 3, 16 ],
      "id_str" : "17409240",
      "id" : 17409240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 117, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8424315447",
  "text" : "RT @uscoastguard District 5: Coast Guard suspends search for missing fisherman off N.C. coast:  http:\/\/bit.ly\/b3zJoS #fb",
  "id" : 8424315447,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank La Vigne",
      "screen_name" : "Tableteer",
      "indices" : [ 3, 13 ],
      "id_str" : "7888762",
      "id" : 7888762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 94, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8268361433",
  "text" : "RT @Tableteer blogged: \"The Top 10 Treats in Entity Framework 4 Webcast\" http:\/\/bit.ly\/aXyRDX #fb",
  "id" : 8268361433,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian_Henderson",
      "screen_name" : "brian_henderson",
      "indices" : [ 3, 19 ],
      "id_str" : "14438014",
      "id" : 14438014
    }, {
      "name" : "Frank La Vigne",
      "screen_name" : "Tableteer",
      "indices" : [ 23, 33 ],
      "id_str" : "7888762",
      "id" : 7888762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sltip",
      "indices" : [ 106, 112 ]
    }, {
      "text" : "fb",
      "indices" : [ 113, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8222298586",
  "text" : "RT @brian_henderson RT @Tableteer blogged: \"More Silverlight Performance Goodness\": http:\/\/bit.ly\/4x1NHx. #sltip #fb",
  "id" : 8222298586,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian_Henderson",
      "screen_name" : "brian_henderson",
      "indices" : [ 3, 19 ],
      "id_str" : "14438014",
      "id" : 14438014
    }, {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 21, 33 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 84, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8234296244",
  "text" : "RT @brian_henderson: @jongalloway seen http:\/\/bit.ly\/6AnvF8 & http:\/\/bit.ly\/4U7UyW  #fb",
  "id" : 8234296244,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Fajardo",
      "screen_name" : "josefajardo",
      "indices" : [ 3, 15 ],
      "id_str" : "8707192",
      "id" : 8707192
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 78, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8173064075",
  "text" : "RT @josefajardo IE9 Patent for \"Tab Upgrades\", whats that? http:\/\/is.gd\/6XX6W #fb",
  "id" : 8173064075,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8140709592",
  "text" : "I'm testing my algorithms :)",
  "id" : 8140709592,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Davide Zordan",
      "screen_name" : "DavideZordan",
      "indices" : [ 3, 16 ],
      "id_str" : "15252977",
      "id" : 15252977
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 129, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8156823164",
  "text" : "RT @DavideZordan Behaviors, Triggers and Actions in Silverlight And WPF Made Simple \u2013 Part 2 \u2013 Triggers - http:\/\/snurl.com\/u6c2d #fb",
  "id" : 8156823164,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Campbell",
      "screen_name" : "chadcampbell",
      "indices" : [ 3, 16 ],
      "id_str" : "11102952",
      "id" : 11102952
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 122, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7910276583",
  "text" : "RT @chadcampbell: .NET RIA Services is awesome. If you are a Silverlight developer, do yourself a favor and check it out. #fb",
  "id" : 7910276583,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Folles\u00F8",
      "screen_name" : "follesoe",
      "indices" : [ 3, 12 ],
      "id_str" : "10209472",
      "id" : 10209472
    }, {
      "name" : "Tord Fauskanger",
      "screen_name" : "Tordf",
      "indices" : [ 97, 103 ],
      "id_str" : "70352338",
      "id" : 70352338
    }, {
      "name" : "Adit Gupta",
      "screen_name" : "aditgupta",
      "indices" : [ 104, 114 ],
      "id_str" : "33980272",
      "id" : 33980272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 116, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7910956981",
  "text" : "RT @follesoe: Really good read on how to recognize good programmers (http:\/\/bit.ly\/1s29po). (via @Tordf @aditgupta) #fb",
  "id" : 7910956981,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Davide Zordan",
      "screen_name" : "DavideZordan",
      "indices" : [ 3, 16 ],
      "id_str" : "15252977",
      "id" : 15252977
    }, {
      "name" : "SilverlightTV",
      "screen_name" : "SilverlightTV",
      "indices" : [ 20, 34 ],
      "id_str" : "86387084",
      "id" : 86387084
    }, {
      "name" : "Mike Downey",
      "screen_name" : "mdowney",
      "indices" : [ 125, 133 ],
      "id_str" : "72343",
      "id" : 72343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Flash",
      "indices" : [ 98, 104 ]
    }, {
      "text" : "Silverlight",
      "indices" : [ 107, 119 ]
    }, {
      "text" : "fb",
      "indices" : [ 135, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7881087008",
  "text" : "RT @DavideZordan RT @SilverlightTV: Next episode airs tomorrow Mon Jan 18. Episode 2 is all about #Flash & #Silverlight with @mdowney  #fb",
  "id" : 7881087008,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 3, 14 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7810664156",
  "text" : "RT @shanselman Programmer? Bored this weekend? Take 5 min and test .NET 4 via Windows Update for me: http:\/\/goo.gl\/fb\/8Z92",
  "id" : 7810664156,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian_Henderson",
      "screen_name" : "brian_henderson",
      "indices" : [ 3, 19 ],
      "id_str" : "14438014",
      "id" : 14438014
    }, {
      "name" : "SilverlightTV",
      "screen_name" : "SilverlightTV",
      "indices" : [ 23, 37 ],
      "id_str" : "86387084",
      "id" : 86387084
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SLTV",
      "indices" : [ 125, 130 ]
    }, {
      "text" : "fb",
      "indices" : [ 131, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7813419667",
  "text" : "RT @brian_henderson RT @SilverlightTV: Breaking News: Premier of Silverlight TV airing on Channel 9! - http:\/\/bit.ly\/7mI09p  #SLTV #fb",
  "id" : 7813419667,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 30, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7768848304",
  "text" : "learns something new everyday #fb",
  "id" : 7768848304,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Barraza",
      "screen_name" : "rickbarraza",
      "indices" : [ 3, 15 ],
      "id_str" : "14092829",
      "id" : 14092829
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MIX10",
      "indices" : [ 43, 49 ]
    }, {
      "text" : "fb",
      "indices" : [ 129, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7798832913",
  "text" : "RT @rickbarraza Last chance to vote for my #MIX10 talks \"Media, Magic and Code\" and \"sketching in C#\" http:\/\/tinyurl.com\/y958ovo #fb",
  "id" : 7798832913,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 109, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7736035496",
  "text" : "RT Silverlight 4 Beta and MEF \u2013 Experimenting with an alternative Programming Model - http:\/\/snurl.com\/u2oq7 #fb",
  "id" : 7736035496,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Silverlight News",
      "screen_name" : "SilverlightNews",
      "indices" : [ 3, 19 ],
      "id_str" : "12088282",
      "id" : 12088282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 100, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7736115342",
  "text" : "RT @SilverlightNews  Silverlight Visualization of MIX10 Open Call Sessions - http:\/\/snurl.com\/u2orc #fb",
  "id" : 7736115342,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Berry Smith",
      "screen_name" : "Berry_Smith",
      "indices" : [ 3, 15 ],
      "id_str" : "83552794",
      "id" : 83552794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7745715777",
  "text" : "RT @Berry_Smith: Obama to Unveil Plan on Bank Taxes http:\/\/bit.ly\/8Xo1Dk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.sharedby.co\" rel=\"nofollow\"\u003ESharedBy\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7745706772",
    "text" : "Obama to Unveil Plan on Bank Taxes http:\/\/bit.ly\/8Xo1Dk",
    "id" : 7745706772,
    "created_at" : "2010-01-14 12:16:52 +0000",
    "user" : {
      "name" : "Berry Smith",
      "screen_name" : "Berry_Smith",
      "protected" : false,
      "id_str" : "83552794",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_3_normal.png",
      "id" : 83552794,
      "verified" : false
    }
  },
  "id" : 7745715777,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FranceDiplomatie\uD83C\uDDEB\uD83C\uDDF7",
      "screen_name" : "francediplo",
      "indices" : [ 3, 15 ],
      "id_str" : "29701712",
      "id" : 29701712
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Haiti",
      "indices" : [ 17, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7745830198",
  "text" : "RT @francediplo: #Haiti : \u00E0 cette heure, 91 Fran\u00E7ais ont \u00E9t\u00E9 \u00E9vacu\u00E9s en Martinique, dont 7 bless\u00E9s graves.  260 Fran\u00E7ais sont \u00E0 l'Ambass ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Haiti",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7745746867",
    "text" : "#Haiti : \u00E0 cette heure, 91 Fran\u00E7ais ont \u00E9t\u00E9 \u00E9vacu\u00E9s en Martinique, dont 7 bless\u00E9s graves.  260 Fran\u00E7ais sont \u00E0 l'Ambassade et la R\u00E9sidence.",
    "id" : 7745746867,
    "created_at" : "2010-01-14 12:18:36 +0000",
    "user" : {
      "name" : "FranceDiplomatie\uD83C\uDDEB\uD83C\uDDF7",
      "screen_name" : "francediplo",
      "protected" : false,
      "id_str" : "29701712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/804646975090130944\/KmA8mQ6u_normal.jpg",
      "id" : 29701712,
      "verified" : true
    }
  },
  "id" : 7745830198,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sync",
      "screen_name" : "michaelsync",
      "indices" : [ 3, 15 ],
      "id_str" : "8766562",
      "id" : 8766562
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 97, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7746073216",
  "text" : "RT @michaelsync I think Prism team use PresentationModel as MVP. I thought it should be MVVM. :) #fb",
  "id" : 7746073216,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Angel",
      "screen_name" : "JustinAngel",
      "indices" : [ 3, 15 ],
      "id_str" : "15977110",
      "id" : 15977110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 126, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7763351519",
  "text" : "RT @JustinAngel W00t! My Mix10K entry is up! Molecular Biology DNA Visualizer  - http:\/\/mix10k.visitmix.com\/Entry\/Details\/184 #fb",
  "id" : 7763351519,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7765520330",
  "text" : "SL will join the Microsoft ISV Program in the summer of 2010. SL is currently following the ISV roadmap. Good year instore.",
  "id" : 7765520330,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Next Web \uD83D\uDCF1\uD83D\uDCBB\uD83C\uDF0D",
      "screen_name" : "TheNextWeb",
      "indices" : [ 3, 14 ],
      "id_str" : "10876852",
      "id" : 10876852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 129, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7688766615",
  "text" : "RT @TheNextWeb Google Might Leave China Following Cyber-Attacks \u2013 Did They Come From The Chinese Government? http:\/\/tnw.to\/12OwC #fb",
  "id" : 7688766615,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7697337103",
  "text" : "http:\/\/www.microsoft.com\/web\/spotlight\/seo\/ for Windows and Linux for Free",
  "id" : 7697337103,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Abrams",
      "screen_name" : "brada",
      "indices" : [ 3, 9 ],
      "id_str" : "5356242",
      "id" : 5356242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 128, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7706449747",
  "text" : "RT @brada: TwtPoll it is! What is the best user model for a Silverlight application http:\/\/tinyurl.com\/yd9w4lm Please re-tweet! #fb",
  "id" : 7706449747,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Kinney",
      "screen_name" : "adkinn",
      "indices" : [ 3, 10 ],
      "id_str" : "755165",
      "id" : 755165
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "silverlight",
      "indices" : [ 80, 92 ]
    }, {
      "text" : "fb",
      "indices" : [ 93, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7724396086",
  "text" : "RT @adkinn: SilverlightShow Eco Contest \u2013 win a trip to MIX10 http:\/\/ow.ly\/Wb26 #silverlight #fb",
  "id" : 7724396086,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/summitonthesummit-tools.com\" rel=\"nofollow\"\u003ESummit On The Summit\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SUMMIT ON THE SUMMIT",
      "screen_name" : "SOTSK",
      "indices" : [ 31, 37 ],
      "id_str" : "52848021",
      "id" : 52848021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotsk",
      "indices" : [ 129, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7678955139",
  "text" : "I support SUMMIT ON THE SUMMIT @SOTSK - fighting the global clean water crisis. Show your support & GO BLUE at http:\/\/ow.ly\/P29A #sotsk",
  "id" : 7678955139,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Weiss",
      "screen_name" : "davidweiss",
      "indices" : [ 3, 14 ],
      "id_str" : "8025462",
      "id" : 8025462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7466311727",
  "text" : "RT @davidweiss: Bleo ebook reader, over 1 million books! Wow.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7465495342",
    "text" : "Bleo ebook reader, over 1 million books! Wow.",
    "id" : 7465495342,
    "created_at" : "2010-01-07 03:36:20 +0000",
    "user" : {
      "name" : "David Weiss",
      "screen_name" : "davidweiss",
      "protected" : false,
      "id_str" : "8025462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540324019031900160\/-HbJUgCk_normal.jpeg",
      "id" : 8025462,
      "verified" : false
    }
  },
  "id" : 7466311727,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]