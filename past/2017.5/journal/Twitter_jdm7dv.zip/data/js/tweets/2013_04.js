Grailbird.data.tweets_2013_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/SYSu38i8lY",
      "expanded_url" : "http:\/\/rbth.ru\/articles\/2012\/08\/01\/russian_scientists_likely_to_create_the_youth_pill_16939.html",
      "display_url" : "rbth.ru\/articles\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324263756093857793",
  "text" : "Science News: http:\/\/t.co\/SYSu38i8lY",
  "id" : 324263756093857793,
  "created_at" : "2013-04-16 20:51:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]