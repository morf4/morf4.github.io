Grailbird.data.tweets_2010_11 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SitePoint",
      "screen_name" : "sitepointdotcom",
      "indices" : [ 68, 84 ],
      "id_str" : "15743570",
      "id" : 15743570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 85, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 63 ],
      "url" : "http:\/\/t.co\/8AzfoMf",
      "expanded_url" : "http:\/\/blogs.sitepoint.com\/2009\/02\/14\/mozilla-launches-very-slick-cloud-based-ide\/",
      "display_url" : "blogs.sitepoint.com\/2009\/02\/14\/moz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "8551541787066368",
  "text" : "Mozilla Launches Very Slick Cloud-Based IDE http:\/\/t.co\/8AzfoMf via @sitepointdotcom #fb",
  "id" : 8551541787066368,
  "created_at" : "2010-11-27 16:03:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PCWorld",
      "screen_name" : "pcworld",
      "indices" : [ 71, 79 ],
      "id_str" : "6070762",
      "id" : 6070762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 80, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 66 ],
      "url" : "http:\/\/t.co\/PQbF69t",
      "expanded_url" : "http:\/\/www.pcworld.com\/article\/211238\/intel_1000core_processor_possible.html",
      "display_url" : "pcworld.com\/article\/211238\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "7480265857310720",
  "text" : "Intel: 1,000-core Processor Possible - PCWorld http:\/\/t.co\/PQbF69t via @PCWorld #fb",
  "id" : 7480265857310720,
  "created_at" : "2010-11-24 17:06:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 21, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3630752944095232",
  "text" : "http:\/\/7dv.me\/9XSz0T #fb",
  "id" : 3630752944095232,
  "created_at" : "2010-11-14 02:10:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.TechHit.com\/TwInbox\/\" rel=\"nofollow\"\u003ETwInbox\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 44, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2373584865460224",
  "text" : "PDC Session Downloader http:\/\/bit.ly\/a8w44q #fb",
  "id" : 2373584865460224,
  "created_at" : "2010-11-10 14:54:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.TechHit.com\/TwInbox\/\" rel=\"nofollow\"\u003ETwInbox\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2373403973517312",
  "text" : "PDC Sesion Downloader:) http:\/\/bit.ly\/a8w44q",
  "id" : 2373403973517312,
  "created_at" : "2010-11-10 14:53:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 77, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692179794132992",
  "text" : "no plans for future releases of Singularity according to a Microsoft source. #fb",
  "id" : 692179794132992,
  "created_at" : "2010-11-05 23:33:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TNW Social Media",
      "screen_name" : "TNWsocialmedia",
      "indices" : [ 90, 105 ],
      "id_str" : "106418930",
      "id" : 106418930
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 106, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http:\/\/t.co\/fGiyE6z",
      "expanded_url" : "http:\/\/thenextweb.com\/socialmedia\/2010\/10\/25\/how-to-find-out-when-somebody-removes-you-as-a-friend-on-facebook\/",
      "display_url" : "thenextweb.com\/socialmedia\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341649754431488",
  "text" : "How to find out when somebody removes you as a friend on Facebook http:\/\/t.co\/fGiyE6z via @tnwsocialmedia #fb",
  "id" : 341649754431488,
  "created_at" : "2010-11-05 00:20:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gigaom",
      "screen_name" : "gigaom",
      "indices" : [ 82, 89 ],
      "id_str" : "2893971",
      "id" : 2893971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 77 ],
      "url" : "http:\/\/t.co\/GnmwmC1",
      "expanded_url" : "http:\/\/gigaom.com\/2010\/02\/23\/cisco-core-markets-competition\/",
      "display_url" : "gigaom.com\/2010\/02\/23\/cis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "29593830444",
  "text" : "Is Competition Starting to Eat Into Cisco's Core\u00A0Markets? http:\/\/t.co\/GnmwmC1 via @gigaom ophra? really cisco?",
  "id" : 29593830444,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GreenBiz",
      "screen_name" : "GreenBiz",
      "indices" : [ 3, 12 ],
      "id_str" : "15942016",
      "id" : 15942016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 99, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29419411398",
  "text" : "RT @GreenBiz What Can Architecture Learn From Nature? | Design | GreenBiz.com http:\/\/grn.bz\/crP1IR #fb",
  "id" : 29419411398,
  "created_at" : "2010-11-02 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29421823833",
  "text" : "http:\/\/bit.ly\/cabu4D Advice for the young scientist.",
  "id" : 29421823833,
  "created_at" : "2010-11-02 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 37, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29481675970",
  "text" : "just voted, you should too! go vote! #fb",
  "id" : 29481675970,
  "created_at" : "2010-11-02 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Log",
      "screen_name" : "CosmicLog",
      "indices" : [ 59, 69 ],
      "id_str" : "21517540",
      "id" : 21517540
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 70, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 54 ],
      "url" : "http:\/\/t.co\/khFHOm6",
      "expanded_url" : "http:\/\/cosmiclog.msnbc.msn.com\/_news\/2010\/11\/01\/5392035-ride-a-starship-not-for-a-century",
      "display_url" : "cosmiclog.msnbc.msn.com\/_news\/2010\/11\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "29509896674",
  "text" : "Ride a starship? Not for a century http:\/\/t.co\/khFHOm6 via @cosmiclog #fb",
  "id" : 29509896674,
  "created_at" : "2010-11-02 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]