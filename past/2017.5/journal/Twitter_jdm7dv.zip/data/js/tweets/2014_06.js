Grailbird.data.tweets_2014_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/CLfWvgaaPt",
      "expanded_url" : "http:\/\/yle.fi\/uutiset\/finnish_team_makes_diabetes_vaccine_breakthrough\/6893356",
      "display_url" : "yle.fi\/uutiset\/finnis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483655672085483520",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman Scott here is diabetes treatment in finland  http:\/\/t.co\/CLfWvgaaPt",
  "id" : 483655672085483520,
  "created_at" : "2014-06-30 16:57:52 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/RKTT4mVm4e",
      "expanded_url" : "http:\/\/Grumman.today",
      "display_url" : "Grumman.today"
    } ]
  },
  "geo" : { },
  "id_str" : "483452935070707715",
  "text" : "@HurstAlliei was having fun at Northrup http:\/\/t.co\/RKTT4mVm4e and poor little TJ lost forever,it is CERN and a 4.0 GPA that wins and I won.",
  "id" : 483452935070707715,
  "created_at" : "2014-06-30 03:32:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/SoZwc8Z4jU",
      "expanded_url" : "http:\/\/on.wsj.com\/1q5KMWG",
      "display_url" : "on.wsj.com\/1q5KMWG"
    } ]
  },
  "geo" : { },
  "id_str" : "481722868414152706",
  "text" : "Our brains are made for enjoying art http:\/\/t.co\/SoZwc8Z4jU",
  "id" : 481722868414152706,
  "created_at" : "2014-06-25 08:57:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/gMS4tMrtSZ",
      "expanded_url" : "http:\/\/FIFA.com",
      "display_url" : "FIFA.com"
    }, {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/45LZQcPgRd",
      "expanded_url" : "http:\/\/en.fifa.com\/worldcup\/matches\/round=255931\/match=300186469\/index.html?cid=twitter_button",
      "display_url" : "en.fifa.com\/worldcup\/match\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481481372863713280",
  "text" : "2014 FIFA World Cup Brazil\u2122: USA-Germany - Overview - http:\/\/t.co\/gMS4tMrtSZ http:\/\/t.co\/45LZQcPgRd",
  "id" : 481481372863713280,
  "created_at" : "2014-06-24 16:57:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481380103440846849",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie  A 4.0 GPA almost at two colleges. Got kicked out for being to good. Credits at CERN, and Bionic.",
  "id" : 481380103440846849,
  "created_at" : "2014-06-24 10:15:34 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FiveThirtyEight",
      "screen_name" : "FiveThirtyEight",
      "indices" : [ 56, 72 ],
      "id_str" : "2303751216",
      "id" : 2303751216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/qYuOpOEJrX",
      "expanded_url" : "http:\/\/fivethirtyeight.com\/datalab\/world-cup-crib-notes-day-10\/",
      "display_url" : "fivethirtyeight.com\/datalab\/world-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481213365734219777",
  "text" : "World Cup Crib Notes: Day 10 http:\/\/t.co\/qYuOpOEJrX via @fivethirtyeight I do just want Germany to beat the USA. Iran can win too.",
  "id" : 481213365734219777,
  "created_at" : "2014-06-23 23:13:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481204555049603072",
  "text" : "Now I have an Open Bank, If I want one.",
  "id" : 481204555049603072,
  "created_at" : "2014-06-23 22:38:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/iTeTkHGHtE",
      "expanded_url" : "http:\/\/www.fiercewireless.com\/story\/fcc-poised-open-more-5-ghz-band-unlicensed-wireless-use\/2014-03-11?utm_campaign=AddThis&utm_medium=AddThis&utm_source=twitter#.U6dz7HsAos4.twitter",
      "display_url" : "fiercewireless.com\/story\/fcc-pois\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480869230619795456",
  "text" : "FCC poised to open up more of 5 GHz band for unlicensed wireless use - FierceWireless: http:\/\/t.co\/iTeTkHGHtE",
  "id" : 480869230619795456,
  "created_at" : "2014-06-23 00:25:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/cvjcWojUXH",
      "expanded_url" : "http:\/\/twit.tv\/show\/the-tech-guy\/1093",
      "display_url" : "twit.tv\/show\/the-tech-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480860369603162113",
  "text" : "Check out The Tech Guy 1093 http:\/\/t.co\/cvjcWojUXH",
  "id" : 480860369603162113,
  "created_at" : "2014-06-22 23:50:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/E6ihS610my",
      "expanded_url" : "http:\/\/espn.go.com\/blog\/collegebasketballnation\/post\/_\/id\/86183\/the-college-basketball-video-game-is-dead",
      "display_url" : "espn.go.com\/blog\/collegeba\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480849967574040576",
  "text" : "The college basketball video game is dead http:\/\/t.co\/E6ihS610my",
  "id" : 480849967574040576,
  "created_at" : "2014-06-22 23:09:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Hurst",
      "screen_name" : "TJHurst22",
      "indices" : [ 0, 10 ],
      "id_str" : "296399305",
      "id" : 296399305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480824959233970176",
  "in_reply_to_user_id" : 296399305,
  "text" : "@TJHurst22 I might start burying my money they what would you do?",
  "id" : 480824959233970176,
  "created_at" : "2014-06-22 21:29:38 +0000",
  "in_reply_to_screen_name" : "TJHurst22",
  "in_reply_to_user_id_str" : "296399305",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Hurst",
      "screen_name" : "TJHurst22",
      "indices" : [ 0, 10 ],
      "id_str" : "296399305",
      "id" : 296399305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480823206824394752",
  "in_reply_to_user_id" : 296399305,
  "text" : "@TJHurst22 Want the AI for a robot to become self aware? Your not getting it. I have it.",
  "id" : 480823206824394752,
  "created_at" : "2014-06-22 21:22:40 +0000",
  "in_reply_to_screen_name" : "TJHurst22",
  "in_reply_to_user_id_str" : "296399305",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Hurst",
      "screen_name" : "TJHurst22",
      "indices" : [ 0, 10 ],
      "id_str" : "296399305",
      "id" : 296399305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480820016695476225",
  "in_reply_to_user_id" : 296399305,
  "text" : "@TJHurst22 If your lucky I might give your the source to the movie you watch in the theaters.",
  "id" : 480820016695476225,
  "created_at" : "2014-06-22 21:09:59 +0000",
  "in_reply_to_screen_name" : "TJHurst22",
  "in_reply_to_user_id_str" : "296399305",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Hurst",
      "screen_name" : "TJHurst22",
      "indices" : [ 0, 10 ],
      "id_str" : "296399305",
      "id" : 296399305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480815876342808576",
  "in_reply_to_user_id" : 296399305,
  "text" : "@TJHurst22 Stay out of Call of Duty Black ops as all of my online friends will shoot you.",
  "id" : 480815876342808576,
  "created_at" : "2014-06-22 20:53:32 +0000",
  "in_reply_to_screen_name" : "TJHurst22",
  "in_reply_to_user_id_str" : "296399305",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Hurst",
      "screen_name" : "TJHurst22",
      "indices" : [ 0, 10 ],
      "id_str" : "296399305",
      "id" : 296399305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480815371050819584",
  "in_reply_to_user_id" : 296399305,
  "text" : "@TJHurst22 Keep on fucking your wife. You'll turn into me in about five years if you are original and cool. She'll be fucking me anyway.",
  "id" : 480815371050819584,
  "created_at" : "2014-06-22 20:51:32 +0000",
  "in_reply_to_screen_name" : "TJHurst22",
  "in_reply_to_user_id_str" : "296399305",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480781235841937408",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie have fun at the beach eloi while we provide.",
  "id" : 480781235841937408,
  "created_at" : "2014-06-22 18:35:53 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480773401515413504",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie You will be fucking me in five years when TJ get's more cool, original and good ho.",
  "id" : 480773401515413504,
  "created_at" : "2014-06-22 18:04:45 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 104, 112 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/vwr5pkRt8C",
      "expanded_url" : "http:\/\/youtu.be\/IyZzuT9X5U8",
      "display_url" : "youtu.be\/IyZzuT9X5U8"
    } ]
  },
  "geo" : { },
  "id_str" : "480740139254050818",
  "text" : "Audio-generated geometry set to Nine Inch Nails' Even Deeper (Telefon Te...: http:\/\/t.co\/vwr5pkRt8C via @YouTube",
  "id" : 480740139254050818,
  "created_at" : "2014-06-22 15:52:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/NED3eqRU4L",
      "expanded_url" : "http:\/\/dragonbones.github.io\/index.html#.U6b4gI6xEo8.twitter",
      "display_url" : "dragonbones.github.io\/index.html#.U6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480736650431959040",
  "text" : "DragonBones http:\/\/t.co\/NED3eqRU4L",
  "id" : 480736650431959040,
  "created_at" : "2014-06-22 15:38:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/qbPXFUBCgf",
      "expanded_url" : "http:\/\/en.skq-project.ru",
      "display_url" : "en.skq-project.ru"
    } ]
  },
  "geo" : { },
  "id_str" : "480542640492904448",
  "text" : "Thanks for saying hi on my birthday Russia. I know I'm a little rough around the edges. We've been at it for 4 years http:\/\/t.co\/qbPXFUBCgf",
  "id" : 480542640492904448,
  "created_at" : "2014-06-22 02:47:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/d3R6c0KxrY",
      "expanded_url" : "http:\/\/goo.gl\/EaZWFg",
      "display_url" : "goo.gl\/EaZWFg"
    } ]
  },
  "geo" : { },
  "id_str" : "480538336902533120",
  "text" : "Android uses a genetic algorithm to 'train' the playing style towards human GM style.I don't want this chess app.http:\/\/t.co\/d3R6c0KxrY",
  "id" : 480538336902533120,
  "created_at" : "2014-06-22 02:30:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/tMCZGcs3ZR",
      "expanded_url" : "http:\/\/avid.force.com\/pkb\/articles\/en_US\/faq\/Important-Changes-to-Avid-Software-Availability",
      "display_url" : "avid.force.com\/pkb\/articles\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480535075805986817",
  "text" : "Open Source by Avid http:\/\/t.co\/tMCZGcs3ZR",
  "id" : 480535075805986817,
  "created_at" : "2014-06-22 02:17:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/mZlESPXOv6",
      "expanded_url" : "http:\/\/nyti.ms\/1tOo7O5",
      "display_url" : "nyti.ms\/1tOo7O5"
    } ]
  },
  "geo" : { },
  "id_str" : "480533162796130304",
  "text" : "Autodesk Unveils Open-Source 3-D Printing System http:\/\/t.co\/mZlESPXOv6",
  "id" : 480533162796130304,
  "created_at" : "2014-06-22 02:10:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Po.st",
      "screen_name" : "Po_st",
      "indices" : [ 85, 91 ],
      "id_str" : "386270039",
      "id" : 386270039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/8WE2SyXaPi",
      "expanded_url" : "http:\/\/po.st\/OJrEqe",
      "display_url" : "po.st\/OJrEqe"
    } ]
  },
  "geo" : { },
  "id_str" : "480530518077763584",
  "text" : "NASA's Osiris sets sail to comet Bennu in 2016 | TG Daily http:\/\/t.co\/8WE2SyXaPi via @po_st My name is going to this Asteroid in 2016.",
  "id" : 480530518077763584,
  "created_at" : "2014-06-22 01:59:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 3, 6 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WFP\/status\/478854729691561984\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/1mFndfJ4Dp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqU71uMIIAAC6G9.jpg",
      "id_str" : "478854729502826496",
      "id" : 478854729502826496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqU71uMIIAAC6G9.jpg",
      "sizes" : [ {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/1mFndfJ4Dp"
    } ],
    "hashtags" : [ {
      "text" : "WorldCup",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/V6us6CRq4V",
      "expanded_url" : "http:\/\/bit.ly\/1i6Q8kB",
      "display_url" : "bit.ly\/1i6Q8kB"
    } ]
  },
  "geo" : { },
  "id_str" : "480521392245702656",
  "text" : "RT @UN: Football is like fighting hunger...if a few people start, others follow! #WorldCup  http:\/\/t.co\/V6us6CRq4V  http:\/\/t.co\/1mFndfJ4Dp \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "World Food Programme",
        "screen_name" : "WFP",
        "indices" : [ 135, 139 ],
        "id_str" : "27830610",
        "id" : 27830610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WFP\/status\/478854729691561984\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/1mFndfJ4Dp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqU71uMIIAAC6G9.jpg",
        "id_str" : "478854729502826496",
        "id" : 478854729502826496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqU71uMIIAAC6G9.jpg",
        "sizes" : [ {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/1mFndfJ4Dp"
      } ],
      "hashtags" : [ {
        "text" : "WorldCup",
        "indices" : [ 73, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/V6us6CRq4V",
        "expanded_url" : "http:\/\/bit.ly\/1i6Q8kB",
        "display_url" : "bit.ly\/1i6Q8kB"
      } ]
    },
    "geo" : { },
    "id_str" : "480380059694292992",
    "text" : "Football is like fighting hunger...if a few people start, others follow! #WorldCup  http:\/\/t.co\/V6us6CRq4V  http:\/\/t.co\/1mFndfJ4Dp via @WFP",
    "id" : 480380059694292992,
    "created_at" : "2014-06-21 16:01:45 +0000",
    "user" : {
      "name" : "United Nations",
      "screen_name" : "UN",
      "protected" : false,
      "id_str" : "14159148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538328216729968642\/SdfeQXSM_normal.png",
      "id" : 14159148,
      "verified" : true
    }
  },
  "id" : 480521392245702656,
  "created_at" : "2014-06-22 01:23:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "indices" : [ 3, 17 ],
      "id_str" : "34554134",
      "id" : 34554134
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SETIInstitute\/status\/480440283638005760\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/WfjfTVIrri",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqrd5GjIUAAF20d.jpg",
      "id_str" : "480440283348619264",
      "id" : 480440283348619264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqrd5GjIUAAF20d.jpg",
      "sizes" : [ {
        "h" : 347,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1305,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1044,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/WfjfTVIrri"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/koeyiq0EK8",
      "expanded_url" : "http:\/\/buff.ly\/UplibO",
      "display_url" : "buff.ly\/UplibO"
    } ]
  },
  "geo" : { },
  "id_str" : "480521016104726529",
  "text" : "RT @SETIInstitute: City of Stars. Learn more http:\/\/t.co\/koeyiq0EK8 http:\/\/t.co\/WfjfTVIrri",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SETIInstitute\/status\/480440283638005760\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/WfjfTVIrri",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqrd5GjIUAAF20d.jpg",
        "id_str" : "480440283348619264",
        "id" : 480440283348619264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqrd5GjIUAAF20d.jpg",
        "sizes" : [ {
          "h" : 347,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1305,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1044,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/WfjfTVIrri"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/koeyiq0EK8",
        "expanded_url" : "http:\/\/buff.ly\/UplibO",
        "display_url" : "buff.ly\/UplibO"
      } ]
    },
    "geo" : { },
    "id_str" : "480440283638005760",
    "text" : "City of Stars. Learn more http:\/\/t.co\/koeyiq0EK8 http:\/\/t.co\/WfjfTVIrri",
    "id" : 480440283638005760,
    "created_at" : "2014-06-21 20:01:04 +0000",
    "user" : {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "protected" : false,
      "id_str" : "34554134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758705567556743168\/TGjZ9Uwf_normal.jpg",
      "id" : 34554134,
      "verified" : true
    }
  },
  "id" : 480521016104726529,
  "created_at" : "2014-06-22 01:21:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "NASA_SLS",
      "screen_name" : "NASA_SLS",
      "indices" : [ 33, 42 ],
      "id_str" : "467739426",
      "id" : 467739426
    }, {
      "name" : "Orion Spacecraft",
      "screen_name" : "NASA_Orion",
      "indices" : [ 65, 76 ],
      "id_str" : "33602654",
      "id" : 33602654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/8S7gmdWPZi",
      "expanded_url" : "http:\/\/www.nasa.gov\/content\/space-launch-system-model-undergoes-wind-tunnel-testing-at-nasa-langley\/#.U6SnNfldWSp",
      "display_url" : "nasa.gov\/content\/space-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480520958961532930",
  "text" : "RT @NASA: Wind tunnel testing an @NASA_SLS model. SLS will power @NASA_Orion into deep space: http:\/\/t.co\/8S7gmdWPZi\u00A0\u00A0 http:\/\/t.co\/e0bItKQP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA_SLS",
        "screen_name" : "NASA_SLS",
        "indices" : [ 23, 32 ],
        "id_str" : "467739426",
        "id" : 467739426
      }, {
        "name" : "Orion Spacecraft",
        "screen_name" : "NASA_Orion",
        "indices" : [ 55, 66 ],
        "id_str" : "33602654",
        "id" : 33602654
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/480441558215720960\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/e0bItKQPx8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqrfDRaIEAAL2_g.jpg",
        "id_str" : "480441557573963776",
        "id" : 480441557573963776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqrfDRaIEAAL2_g.jpg",
        "sizes" : [ {
          "h" : 710,
          "resize" : "fit",
          "w" : 946
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 946
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/e0bItKQPx8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/8S7gmdWPZi",
        "expanded_url" : "http:\/\/www.nasa.gov\/content\/space-launch-system-model-undergoes-wind-tunnel-testing-at-nasa-langley\/#.U6SnNfldWSp",
        "display_url" : "nasa.gov\/content\/space-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "480441558215720960",
    "text" : "Wind tunnel testing an @NASA_SLS model. SLS will power @NASA_Orion into deep space: http:\/\/t.co\/8S7gmdWPZi\u00A0\u00A0 http:\/\/t.co\/e0bItKQPx8",
    "id" : 480441558215720960,
    "created_at" : "2014-06-21 20:06:08 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 480520958961532930,
  "created_at" : "2014-06-22 01:21:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reid Wiseman",
      "screen_name" : "astro_reid",
      "indices" : [ 3, 14 ],
      "id_str" : "330921167",
      "id" : 330921167
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/astro_reid\/status\/480407504841486336\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/1Qv0oZsWmq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqrAFC7CQAAylOb.jpg",
      "id_str" : "480407503184740352",
      "id" : 480407503184740352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqrAFC7CQAAylOb.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1Qv0oZsWmq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480520699048894465",
  "text" : "RT @astro_reid: Been waiting a while to see the Caribbean. It didn\u2019t disappoint. http:\/\/t.co\/1Qv0oZsWmq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/astro_reid\/status\/480407504841486336\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/1Qv0oZsWmq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqrAFC7CQAAylOb.jpg",
        "id_str" : "480407503184740352",
        "id" : 480407503184740352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqrAFC7CQAAylOb.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/1Qv0oZsWmq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480407504841486336",
    "text" : "Been waiting a while to see the Caribbean. It didn\u2019t disappoint. http:\/\/t.co\/1Qv0oZsWmq",
    "id" : 480407504841486336,
    "created_at" : "2014-06-21 17:50:49 +0000",
    "user" : {
      "name" : "Reid Wiseman",
      "screen_name" : "astro_reid",
      "protected" : false,
      "id_str" : "330921167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1431054149\/image_normal.jpg",
      "id" : 330921167,
      "verified" : true
    }
  },
  "id" : 480520699048894465,
  "created_at" : "2014-06-22 01:20:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FIFA Media",
      "screen_name" : "fifamedia",
      "indices" : [ 3, 13 ],
      "id_str" : "284003990",
      "id" : 284003990
    }, {
      "name" : "Yingli Solar",
      "screen_name" : "YingliSolar",
      "indices" : [ 78, 90 ],
      "id_str" : "1314764664",
      "id" : 1314764664
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fifamedia\/status\/480357119221567489\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/76zLDSHWBh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqqSQKcCYAA16p7.jpg",
      "id_str" : "480357116645892096",
      "id" : 480357116645892096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqqSQKcCYAA16p7.jpg",
      "sizes" : [ {
        "h" : 348,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/76zLDSHWBh"
    } ],
    "hashtags" : [ {
      "text" : "WorldCup",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/yKOeJR6jzf",
      "expanded_url" : "http:\/\/bit.ly\/1poBkMA",
      "display_url" : "bit.ly\/1poBkMA"
    } ]
  },
  "geo" : { },
  "id_str" : "480520398745116672",
  "text" : "RT @fifamedia: Solar energy is featuring at the #WorldCup with the support of @YingliSolar. http:\/\/t.co\/yKOeJR6jzf http:\/\/t.co\/76zLDSHWBh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yingli Solar",
        "screen_name" : "YingliSolar",
        "indices" : [ 63, 75 ],
        "id_str" : "1314764664",
        "id" : 1314764664
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fifamedia\/status\/480357119221567489\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/76zLDSHWBh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqqSQKcCYAA16p7.jpg",
        "id_str" : "480357116645892096",
        "id" : 480357116645892096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqqSQKcCYAA16p7.jpg",
        "sizes" : [ {
          "h" : 348,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/76zLDSHWBh"
      } ],
      "hashtags" : [ {
        "text" : "WorldCup",
        "indices" : [ 33, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/yKOeJR6jzf",
        "expanded_url" : "http:\/\/bit.ly\/1poBkMA",
        "display_url" : "bit.ly\/1poBkMA"
      } ]
    },
    "geo" : { },
    "id_str" : "480357119221567489",
    "text" : "Solar energy is featuring at the #WorldCup with the support of @YingliSolar. http:\/\/t.co\/yKOeJR6jzf http:\/\/t.co\/76zLDSHWBh",
    "id" : 480357119221567489,
    "created_at" : "2014-06-21 14:30:36 +0000",
    "user" : {
      "name" : "FIFA Media",
      "screen_name" : "fifamedia",
      "protected" : false,
      "id_str" : "284003990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654302766127534080\/CC3em06s_normal.jpg",
      "id" : 284003990,
      "verified" : true
    }
  },
  "id" : 480520398745116672,
  "created_at" : "2014-06-22 01:19:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Verizon Latino",
      "screen_name" : "VerizonLatino",
      "indices" : [ 3, 17 ],
      "id_str" : "2400109962",
      "id" : 2400109962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MeAgarroElGol",
      "indices" : [ 65, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480519568700739584",
  "text" : "RT @VerizonLatino: \u00BFQu\u00E9 te pareci\u00F3 este partidazo? Cu\u00E9ntanos con #MeAgarroElGol y ve tambi\u00E9n esta visualizaci\u00F3n de tus tweets:\nhttps:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MeAgarroElGol",
        "indices" : [ 46, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/UMoUqmH1ju",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/5f15711e-3b2a-4c59-8ed8-d6a91157e178",
        "display_url" : "amp.twimg.com\/v\/5f15711e-3b2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "480462883877158913",
    "text" : "\u00BFQu\u00E9 te pareci\u00F3 este partidazo? Cu\u00E9ntanos con #MeAgarroElGol y ve tambi\u00E9n esta visualizaci\u00F3n de tus tweets:\nhttps:\/\/t.co\/UMoUqmH1ju",
    "id" : 480462883877158913,
    "created_at" : "2014-06-21 21:30:52 +0000",
    "user" : {
      "name" : "Verizon Latino",
      "screen_name" : "VerizonLatino",
      "protected" : false,
      "id_str" : "2400109962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642455180596768768\/0eixXUtS_normal.png",
      "id" : 2400109962,
      "verified" : true
    }
  },
  "id" : 480519568700739584,
  "created_at" : "2014-06-22 01:16:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/K9SSiUQsNx",
      "expanded_url" : "http:\/\/youtu.be\/tSsZSBDu9nA",
      "display_url" : "youtu.be\/tSsZSBDu9nA"
    } ]
  },
  "geo" : { },
  "id_str" : "480518008201170944",
  "text" : "Pearl Jam \u00B7 Soon Forget (Live): http:\/\/t.co\/K9SSiUQsNx via @YouTube",
  "id" : 480518008201170944,
  "created_at" : "2014-06-22 01:09:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 43, 51 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/lq4Zag2BLW",
      "expanded_url" : "http:\/\/youtu.be\/mKVfhZoFKX8",
      "display_url" : "youtu.be\/mKVfhZoFKX8"
    } ]
  },
  "geo" : { },
  "id_str" : "480495535627829248",
  "text" : "Lurch gets Itt: http:\/\/t.co\/lq4Zag2BLW via @YouTube",
  "id" : 480495535627829248,
  "created_at" : "2014-06-21 23:40:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oldways",
      "screen_name" : "OldwaysPT",
      "indices" : [ 54, 64 ],
      "id_str" : "22182334",
      "id" : 22182334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/JUbK6kNJyp",
      "expanded_url" : "http:\/\/oldwayspt.org\/resources\/heritage-pyramids\/mediterranean-pyramid\/overview#.U6YTgF2jDFg.twitter",
      "display_url" : "oldwayspt.org\/resources\/heri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480490761490669568",
  "text" : "Mediterranean Diet Pyramid http:\/\/t.co\/JUbK6kNJyp via @Oldwayspt",
  "id" : 480490761490669568,
  "created_at" : "2014-06-21 23:21:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 113, 124 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/oc4l7B9Og8",
      "expanded_url" : "http:\/\/techcrunch.com\/2014\/05\/01\/groupon-goes-after-costco-and-sams-club-with-groupon-basics-a-portal-for-home-goods\/?ncid=twittersocialshare",
      "display_url" : "techcrunch.com\/2014\/05\/01\/gro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480486770979508224",
  "text" : "Groupon Goes After Costco And Sam\u2019s Club With Groupon Basics, A Portal For Home Goods http:\/\/t.co\/oc4l7B9Og8 via @techcrunch",
  "id" : 480486770979508224,
  "created_at" : "2014-06-21 23:05:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/5afO7L3Bg8",
      "expanded_url" : "http:\/\/bit.ly\/1uQy7qG",
      "display_url" : "bit.ly\/1uQy7qG"
    } ]
  },
  "geo" : { },
  "id_str" : "480483963647954944",
  "text" : "POM Wonderful 100% Pomegranate Juice - 60 oz. - Sam's Club http:\/\/t.co\/5afO7L3Bg8",
  "id" : 480483963647954944,
  "created_at" : "2014-06-21 22:54:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/UA5yYnxynO",
      "expanded_url" : "http:\/\/bit.ly\/1m8FM30",
      "display_url" : "bit.ly\/1m8FM30"
    } ]
  },
  "geo" : { },
  "id_str" : "480483100934156288",
  "text" : "Dole\u00C2\u00AE Frozen Blueberries - 64 oz. - Sam's Club http:\/\/t.co\/UA5yYnxynO",
  "id" : 480483100934156288,
  "created_at" : "2014-06-21 22:51:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480475254255800320",
  "text" : "Anyone want Magnus Carlsen chess engine? I just beat him.",
  "id" : 480475254255800320,
  "created_at" : "2014-06-21 22:20:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 45, 53 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/046SSZJ779",
      "expanded_url" : "http:\/\/youtu.be\/M1h_1KTaY8M",
      "display_url" : "youtu.be\/M1h_1KTaY8M"
    } ]
  },
  "geo" : { },
  "id_str" : "480474616423399424",
  "text" : "La Mer (Version): http:\/\/t.co\/046SSZJ779 via @YouTube",
  "id" : 480474616423399424,
  "created_at" : "2014-06-21 22:17:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speakeasy",
      "screen_name" : "WSJspeakeasy",
      "indices" : [ 102, 115 ],
      "id_str" : "41204528",
      "id" : 41204528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/40xxVhy6W6",
      "expanded_url" : "http:\/\/on.wsj.com\/1n6VQC1",
      "display_url" : "on.wsj.com\/1n6VQC1"
    } ]
  },
  "geo" : { },
  "id_str" : "480474372629487616",
  "text" : "Bill Gates Was \u2018Winning\u2019 Against Chess Champ Magnus Carlsen\u2013Before He Lost http:\/\/t.co\/40xxVhy6W6 via @WSJspeakeasy",
  "id" : 480474372629487616,
  "created_at" : "2014-06-21 22:16:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 66, 74 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/PxchYZrQz9",
      "expanded_url" : "http:\/\/youtu.be\/CWH5ZfdWm5o",
      "display_url" : "youtu.be\/CWH5ZfdWm5o"
    } ]
  },
  "geo" : { },
  "id_str" : "480462092709814274",
  "text" : "You Know My Name (Look Up The Number): http:\/\/t.co\/PxchYZrQz9 via @YouTube",
  "id" : 480462092709814274,
  "created_at" : "2014-06-21 21:27:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 78, 86 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/c2uQCmSdaD",
      "expanded_url" : "http:\/\/youtu.be\/QuQeXO5bWAA",
      "display_url" : "youtu.be\/QuQeXO5bWAA"
    } ]
  },
  "geo" : { },
  "id_str" : "480461644657459200",
  "text" : "The Beatles You Know My Name (Look Up The Number): http:\/\/t.co\/c2uQCmSdaD via @YouTube",
  "id" : 480461644657459200,
  "created_at" : "2014-06-21 21:25:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CBS Sports",
      "screen_name" : "CBSSports",
      "indices" : [ 76, 86 ],
      "id_str" : "14885860",
      "id" : 14885860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/A0MvS51cHs",
      "expanded_url" : "http:\/\/cbsprt.co\/1pu1Hme",
      "display_url" : "cbsprt.co\/1pu1Hme"
    } ]
  },
  "geo" : { },
  "id_str" : "480451145630887936",
  "text" : "2014 FIFA World Cup: Ghana vs. Germany LIVE blog http:\/\/t.co\/A0MvS51cHs via @cbssports USA your going down",
  "id" : 480451145630887936,
  "created_at" : "2014-06-21 20:44:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480430278306181120",
  "text" : "America does just say baby and the hell with everyone else. I buy Attitude carcinogenic free body wash for kids.",
  "id" : 480430278306181120,
  "created_at" : "2014-06-21 19:21:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/BZH4eDLh75",
      "expanded_url" : "http:\/\/www.cnn.com\/2014\/03\/06\/health\/hiv-baby-cured\/index.html?sr=sharebar_twitter",
      "display_url" : "cnn.com\/2014\/03\/06\/hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480429567090229249",
  "text" : "Second baby possibly 'cured' of HIV http:\/\/t.co\/BZH4eDLh75",
  "id" : 480429567090229249,
  "created_at" : "2014-06-21 19:18:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BeverageDaily.com",
      "screen_name" : "beveragedaily",
      "indices" : [ 100, 114 ],
      "id_str" : "106425549",
      "id" : 106425549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/EtgZwZKX56",
      "expanded_url" : "http:\/\/www.beveragedaily.com\/Markets\/Coke-won-t-kick-the-can-in-Bolivia-but-must-dance-diplomatic-can-can?utm_source=AddThis_twitter&utm_medium=twitter&utm_campaign=SocialMedia#.U6XU0eD2TIk.twitter",
      "display_url" : "beveragedaily.com\/Markets\/Coke-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480423530568245248",
  "text" : "Coke won\u2019t kick the can in Bolivia, but must dance diplomatic can-can... http:\/\/t.co\/EtgZwZKX56 via @BeverageDaily",
  "id" : 480423530568245248,
  "created_at" : "2014-06-21 18:54:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KurzweilAINews",
      "screen_name" : "KurzweilAINews",
      "indices" : [ 70, 85 ],
      "id_str" : "16838443",
      "id" : 16838443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/V1tast9OzG",
      "expanded_url" : "http:\/\/www.kurzweilai.net\/robot-learns-self-awareness",
      "display_url" : "kurzweilai.net\/robot-learns-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480396552465174528",
  "text" : "Robot learns \u2018self-awareness\u2019 | KurzweilAI http:\/\/t.co\/V1tast9OzG via @kurzweilainews I posted this on Facebook in 2012",
  "id" : 480396552465174528,
  "created_at" : "2014-06-21 17:07:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Hurst",
      "screen_name" : "TJHurst22",
      "indices" : [ 0, 10 ],
      "id_str" : "296399305",
      "id" : 296399305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480379330733023234",
  "in_reply_to_user_id" : 296399305,
  "text" : "@TJHurst22 Go ahead act all cool with your woman at my casino. You will lose. C You didn't make the programming grade.",
  "id" : 480379330733023234,
  "created_at" : "2014-06-21 15:58:52 +0000",
  "in_reply_to_screen_name" : "TJHurst22",
  "in_reply_to_user_id_str" : "296399305",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft Channel 9",
      "screen_name" : "ch9",
      "indices" : [ 113, 117 ],
      "id_str" : "9460682",
      "id" : 9460682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/e5fR7UB6px",
      "expanded_url" : "http:\/\/channel9.msdn.com\/Series\/C9-Lectures-Stephan-T-Lavavej-Standard-Template-Library-STL-\/C9-Lectures-Stephan-T-Lavavej-Standard-Template-Library-STL-6-of-n",
      "display_url" : "channel9.msdn.com\/Series\/C9-Lect\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480376361849077760",
  "text" : "C9 Lectures: Stephan T. Lavavej - Standard Template Library (STL), 6 of n (Channel 9) http:\/\/t.co\/e5fR7UB6px via @ch9",
  "id" : 480376361849077760,
  "created_at" : "2014-06-21 15:47:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480067577729650688",
  "text" : "Get in line? I'll sue for how long I've waited kid.",
  "id" : 480067577729650688,
  "created_at" : "2014-06-20 19:20:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480065582763487232",
  "text" : "I want millions in capital formation or nothing at all it is a fixed investment not fixed income. I'm high.",
  "id" : 480065582763487232,
  "created_at" : "2014-06-20 19:12:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 90, 98 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/xcAUIEMBlr",
      "expanded_url" : "http:\/\/youtu.be\/aJCCUdK7PiU",
      "display_url" : "youtu.be\/aJCCUdK7PiU"
    } ]
  },
  "geo" : { },
  "id_str" : "480063588980105217",
  "text" : "Men in Black (5\/8) The Galaxy Is on Orion's Belt -  (1997) HD: http:\/\/t.co\/xcAUIEMBlr via @YouTube and I'm broke. What a galaxy?",
  "id" : 480063588980105217,
  "created_at" : "2014-06-20 19:04:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/udWgn12AwY",
      "expanded_url" : "http:\/\/nydn.us\/1r2AI0j",
      "display_url" : "nydn.us\/1r2AI0j"
    } ]
  },
  "geo" : { },
  "id_str" : "479846068998246400",
  "text" : "Brian Williams raps to \u2018Baby Got Back\u2019 in latest \u2018Tonight Show\u2019 mash-up http:\/\/t.co\/udWgn12AwY",
  "id" : 479846068998246400,
  "created_at" : "2014-06-20 04:39:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open at Microsoft",
      "screen_name" : "OpenAtMicrosoft",
      "indices" : [ 3, 19 ],
      "id_str" : "45036289",
      "id" : 45036289
    }, {
      "name" : "openFrameworks",
      "screen_name" : "openframeworks",
      "indices" : [ 59, 74 ],
      "id_str" : "28180275",
      "id" : 28180275
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cinder",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/trlitreNTF",
      "expanded_url" : "http:\/\/aka.ms\/KCBv2Ready",
      "display_url" : "aka.ms\/KCBv2Ready"
    } ]
  },
  "geo" : { },
  "id_str" : "479844036727951362",
  "text" : "RT @OpenAtMicrosoft: Kinect Common Bridge v2 Beta is here. @openframeworks and #Cinder already adopted it! http:\/\/t.co\/trlitreNTF #msopente\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openFrameworks",
        "screen_name" : "openframeworks",
        "indices" : [ 38, 53 ],
        "id_str" : "28180275",
        "id" : 28180275
      }, {
        "name" : "EricMitt",
        "screen_name" : "EricMitt",
        "indices" : [ 131, 140 ],
        "id_str" : "53983942",
        "id" : 53983942
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cinder",
        "indices" : [ 58, 65 ]
      }, {
        "text" : "msopentech",
        "indices" : [ 109, 120 ]
      }, {
        "text" : "kinectv2",
        "indices" : [ 121, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/trlitreNTF",
        "expanded_url" : "http:\/\/aka.ms\/KCBv2Ready",
        "display_url" : "aka.ms\/KCBv2Ready"
      } ]
    },
    "geo" : { },
    "id_str" : "476850350662504448",
    "text" : "Kinect Common Bridge v2 Beta is here. @openframeworks and #Cinder already adopted it! http:\/\/t.co\/trlitreNTF #msopentech #kinectv2 @ericmitt",
    "id" : 476850350662504448,
    "created_at" : "2014-06-11 22:15:57 +0000",
    "user" : {
      "name" : "Open at Microsoft",
      "screen_name" : "OpenAtMicrosoft",
      "protected" : false,
      "id_str" : "45036289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623264825465040896\/aUzLHrCL_normal.png",
      "id" : 45036289,
      "verified" : true
    }
  },
  "id" : 479844036727951362,
  "created_at" : "2014-06-20 04:31:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "indices" : [ 3, 9 ],
      "id_str" : "3819701",
      "id" : 3819701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/I7TvsmnQyj",
      "expanded_url" : "http:\/\/zd.net\/1rdypaZ",
      "display_url" : "zd.net\/1rdypaZ"
    } ]
  },
  "geo" : { },
  "id_str" : "479841316592177153",
  "text" : "RT @ZDNet: Private cloud is here to stay: Cisco http:\/\/t.co\/I7TvsmnQyj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.zdnet.com\" rel=\"nofollow\"\u003Ezdnet API\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/I7TvsmnQyj",
        "expanded_url" : "http:\/\/zd.net\/1rdypaZ",
        "display_url" : "zd.net\/1rdypaZ"
      } ]
    },
    "geo" : { },
    "id_str" : "479839063290023936",
    "text" : "Private cloud is here to stay: Cisco http:\/\/t.co\/I7TvsmnQyj",
    "id" : 479839063290023936,
    "created_at" : "2014-06-20 04:12:02 +0000",
    "user" : {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "protected" : false,
      "id_str" : "3819701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706961982545473536\/Ibj46-DX_normal.jpg",
      "id" : 3819701,
      "verified" : true
    }
  },
  "id" : 479841316592177153,
  "created_at" : "2014-06-20 04:20:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479826665116164097",
  "text" : "Looking forward to working in my (A) engineering system tomorrow.",
  "id" : 479826665116164097,
  "created_at" : "2014-06-20 03:22:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479812811716296704",
  "text" : "Upgraded to Enterprise Architect 9.",
  "id" : 479812811716296704,
  "created_at" : "2014-06-20 02:27:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479802254313021441",
  "text" : "Tool would just look for the tools in the book and not even read it I got a B in engineering.",
  "id" : 479802254313021441,
  "created_at" : "2014-06-20 01:45:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479799128898035713",
  "text" : "This engineering book even gives me software tools for each modeling layer.",
  "id" : 479799128898035713,
  "created_at" : "2014-06-20 01:33:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 88, 96 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/CVL1K3jtpV",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=lvflRr9e3z4&sns=tw",
      "display_url" : "youtube.com\/watch?v=lvflRr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479796738652254208",
  "text" : "Avril Lavigne ft Marilyn Manson -  Bad Girl (Official Video) http:\/\/t.co\/CVL1K3jtpV via @youtube spank her",
  "id" : 479796738652254208,
  "created_at" : "2014-06-20 01:23:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 49, 57 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/OS1BI9YOLg",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=nAjdXZDPwfI&sns=tw",
      "display_url" : "youtube.com\/watch?v=nAjdXZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479793800546488320",
  "text" : "Mike Watt - Big Train http:\/\/t.co\/OS1BI9YOLg via @youtube",
  "id" : 479793800546488320,
  "created_at" : "2014-06-20 01:12:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479792012648923136",
  "text" : "Jenny's special isn't she forest with the buzz cut fuck her forest",
  "id" : 479792012648923136,
  "created_at" : "2014-06-20 01:05:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 51, 59 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/DabFa3y4HK",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=5nhyhlzLwIw&sns=tw",
      "display_url" : "youtube.com\/watch?v=5nhyhl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479788198059470848",
  "text" : "Pearl Jam - Bushleaguer http:\/\/t.co\/DabFa3y4HK via @youtube",
  "id" : 479788198059470848,
  "created_at" : "2014-06-20 00:49:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479785919445094400",
  "text" : "That hooker I mean book was free",
  "id" : 479785919445094400,
  "created_at" : "2014-06-20 00:40:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479784408161857536",
  "text" : "Come on country boy do something",
  "id" : 479784408161857536,
  "created_at" : "2014-06-20 00:34:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479781739946971136",
  "text" : "Do more Bush at Elizabeth's port.",
  "id" : 479781739946971136,
  "created_at" : "2014-06-20 00:24:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479780062619660288",
  "text" : "Don't install square they will just listen to your microphone.",
  "id" : 479780062619660288,
  "created_at" : "2014-06-20 00:17:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Square",
      "screen_name" : "Square",
      "indices" : [ 3, 10 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/WuR2V3z7ii",
      "expanded_url" : "https:\/\/cards.twitter.com\/cards\/1jdp3t\/bb1",
      "display_url" : "cards.twitter.com\/cards\/1jdp3t\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479778821994868736",
  "text" : "RT @Square: It's easy to accept credit cards with the Square card reader! Get your FREE card reader today! https:\/\/t.co\/WuR2V3z7ii",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/WuR2V3z7ii",
        "expanded_url" : "https:\/\/cards.twitter.com\/cards\/1jdp3t\/bb1",
        "display_url" : "cards.twitter.com\/cards\/1jdp3t\/b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "477175879055835136",
    "text" : "It's easy to accept credit cards with the Square card reader! Get your FREE card reader today! https:\/\/t.co\/WuR2V3z7ii",
    "id" : 477175879055835136,
    "created_at" : "2014-06-12 19:49:29 +0000",
    "user" : {
      "name" : "Square",
      "screen_name" : "Square",
      "protected" : false,
      "id_str" : "93017945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774297805116407808\/NhxKlL4B_normal.jpg",
      "id" : 93017945,
      "verified" : true
    }
  },
  "id" : 479778821994868736,
  "created_at" : "2014-06-20 00:12:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 71, 79 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/lR69XZG8Lc",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=SJyHIeplIJs&sns=tw",
      "display_url" : "youtube.com\/watch?v=SJyHIe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479776052336525313",
  "text" : "Nine Inch Nails - The Greater Good (Lyrics) http:\/\/t.co\/lR69XZG8Lc via @youtube",
  "id" : 479776052336525313,
  "created_at" : "2014-06-20 00:01:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479772031961931777",
  "text" : "When is UBS going to call? Are they doing Moore?",
  "id" : 479772031961931777,
  "created_at" : "2014-06-19 23:45:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/8zyfg12eYN",
      "expanded_url" : "http:\/\/www.sens.org\/outreach\/conferences\/rejuvenation-biotechnology-conference-2014#.U6Nz1CuTAvs.twitter",
      "display_url" : "sens.org\/outreach\/confe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479769586712051712",
  "text" : "Rejuvenation Biotechnology Conference 2014 | SENS Research Foundation http:\/\/t.co\/8zyfg12eYN",
  "id" : 479769586712051712,
  "created_at" : "2014-06-19 23:35:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 58, 66 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/7OOSrEcrmZ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=HMrcq6ROM58&sns=tw",
      "display_url" : "youtube.com\/watch?v=HMrcq6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479766058958471168",
  "text" : "Nine Inch Nails, All Time Low. http:\/\/t.co\/7OOSrEcrmZ via @youtube",
  "id" : 479766058958471168,
  "created_at" : "2014-06-19 23:21:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479763397685161984",
  "text" : "Looking forward to see what NIN's does with the \"nothing\" domain if any.",
  "id" : 479763397685161984,
  "created_at" : "2014-06-19 23:11:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "indices" : [ 64, 70 ],
      "id_str" : "3819701",
      "id" : 3819701
    }, {
      "name" : "Larry Dignan",
      "screen_name" : "ldignan",
      "indices" : [ 72, 80 ],
      "id_str" : "12460982",
      "id" : 12460982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/8AMaBMcZK5",
      "expanded_url" : "http:\/\/zd.net\/1e4srWH",
      "display_url" : "zd.net\/1e4srWH"
    } ]
  },
  "geo" : { },
  "id_str" : "479757646514233345",
  "text" : "Fusion-io partners with Quanta, eyes Open Compute bandwagon via @ZDNet, @ldignan http:\/\/t.co\/8AMaBMcZK5",
  "id" : 479757646514233345,
  "created_at" : "2014-06-19 22:48:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fUr0fLuCYs",
      "expanded_url" : "http:\/\/google.org\/publicalerts\/alert?aid=41262ef0840a026&source=tw",
      "display_url" : "google.org\/publicalerts\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479757021290303488",
  "text" : "http:\/\/t.co\/fUr0fLuCYs",
  "id" : 479757021290303488,
  "created_at" : "2014-06-19 22:46:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479746584746676224",
  "text" : "I would follow JavaForge or Sourceforge too.",
  "id" : 479746584746676224,
  "created_at" : "2014-06-19 22:04:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerushia",
      "screen_name" : "udaughtersofeve",
      "indices" : [ 3, 19 ],
      "id_str" : "75113294",
      "id" : 75113294
    }, {
      "name" : "Marlene Phillips",
      "screen_name" : "m_pmeme",
      "indices" : [ 21, 29 ],
      "id_str" : "2178618330",
      "id" : 2178618330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479746133426982912",
  "text" : "RT @udaughtersofeve: @m_pmeme $1,000 Victoria's Secret Gift Card! 5-min Survey http:\/\/bit.ly\/hnRJaz?=mtc2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marlene Phillips",
        "screen_name" : "m_pmeme",
        "indices" : [ 0, 8 ],
        "id_str" : "2178618330",
        "id" : 2178618330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60102895823101952",
    "in_reply_to_user_id" : 40799920,
    "text" : "@m_pmeme $1,000 Victoria's Secret Gift Card! 5-min Survey http:\/\/bit.ly\/hnRJaz?=mtc2",
    "id" : 60102895823101952,
    "created_at" : "2011-04-18 22:10:21 +0000",
    "in_reply_to_screen_name" : "jdm7dv",
    "in_reply_to_user_id_str" : "40799920",
    "user" : {
      "name" : "Jerushia",
      "screen_name" : "udaughtersofeve",
      "protected" : false,
      "id_str" : "75113294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/420996015\/jerushia2_normal.jpg",
      "id" : 75113294,
      "verified" : false
    }
  },
  "id" : 479746133426982912,
  "created_at" : "2014-06-19 22:02:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479737867824934912",
  "text" : "Reading an engineering book this evening.",
  "id" : 479737867824934912,
  "created_at" : "2014-06-19 21:29:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 58, 66 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/BaguFOg1N7",
      "expanded_url" : "http:\/\/youtu.be\/6ju8xO_Zvfo",
      "display_url" : "youtu.be\/6ju8xO_Zvfo"
    } ]
  },
  "geo" : { },
  "id_str" : "479732312494465024",
  "text" : "10. Motion Picture Soundtrack: http:\/\/t.co\/BaguFOg1N7 via @YouTube",
  "id" : 479732312494465024,
  "created_at" : "2014-06-19 21:07:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Healthline",
      "screen_name" : "Healthline",
      "indices" : [ 74, 85 ],
      "id_str" : "14985126",
      "id" : 14985126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/I6GY6KxgVj",
      "expanded_url" : "http:\/\/www.healthline.com\/health\/dextrose",
      "display_url" : "healthline.com\/health\/dextrose"
    } ]
  },
  "geo" : { },
  "id_str" : "479729177281585152",
  "text" : "What Is Dextrose and How Is It Used Medically? http:\/\/t.co\/I6GY6KxgVj via @healthline",
  "id" : 479729177281585152,
  "created_at" : "2014-06-19 20:55:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479728346021244929",
  "text" : "I had a mathematical count of twelve fish sticks and low sodium kidney beans while reading the ingredients.",
  "id" : 479728346021244929,
  "created_at" : "2014-06-19 20:52:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 104, 112 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/StEgRl8bYi",
      "expanded_url" : "http:\/\/youtu.be\/s81gPb5JyGs",
      "display_url" : "youtu.be\/s81gPb5JyGs"
    } ]
  },
  "geo" : { },
  "id_str" : "479725983021297664",
  "text" : "Guns N' Roses - Knockin' On Heaven's Door (Use Your Illusion II studio v...: http:\/\/t.co\/StEgRl8bYi via @YouTube \"Corporate Version\"",
  "id" : 479725983021297664,
  "created_at" : "2014-06-19 20:42:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/aNmp68uyov",
      "expanded_url" : "http:\/\/www.wdc.com\/en\/products\/products.aspx?id=1140",
      "display_url" : "wdc.com\/en\/products\/pr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479722831392296960",
  "text" : "Here's your universe, it uses NAS http:\/\/t.co\/aNmp68uyov",
  "id" : 479722831392296960,
  "created_at" : "2014-06-19 20:30:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 83, 91 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/ye8iS7oBLR",
      "expanded_url" : "http:\/\/youtu.be\/lOAGG5zvTt8",
      "display_url" : "youtu.be\/lOAGG5zvTt8"
    } ]
  },
  "geo" : { },
  "id_str" : "479713986598801408",
  "text" : "Nine Inch Nails- Happiness In Slavery - Woodstock 1994: http:\/\/t.co\/ye8iS7oBLR via @YouTube",
  "id" : 479713986598801408,
  "created_at" : "2014-06-19 19:55:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neowin",
      "screen_name" : "NeowinFeed",
      "indices" : [ 95, 106 ],
      "id_str" : "14357338",
      "id" : 14357338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/BwLDUYKTbP",
      "expanded_url" : "http:\/\/www.neowin.net\/news\/xbox-one-has-a-kinect-problem-but-can-cortana-fix-that",
      "display_url" : "neowin.net\/news\/xbox-one-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479712102563594241",
  "text" : "Xbox One has a Kinect problem, but can 'Cortana' fix that? - Neowin http:\/\/t.co\/BwLDUYKTbP via @neowinfeed",
  "id" : 479712102563594241,
  "created_at" : "2014-06-19 19:47:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 77, 85 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/CjzzAXOp9T",
      "expanded_url" : "http:\/\/youtu.be\/C2pvQcuRzWY",
      "display_url" : "youtu.be\/C2pvQcuRzWY"
    } ]
  },
  "geo" : { },
  "id_str" : "479710949968846848",
  "text" : "The Doors Break on Through Live at \"Boston\" 1970: http:\/\/t.co\/CjzzAXOp9T via @YouTube That world is a DirectX isn't Microsoft.",
  "id" : 479710949968846848,
  "created_at" : "2014-06-19 19:42:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 66, 74 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/UpQZe4f85Z",
      "expanded_url" : "http:\/\/youtu.be\/U9QkHEzRW2Y",
      "display_url" : "youtu.be\/U9QkHEzRW2Y"
    } ]
  },
  "geo" : { },
  "id_str" : "479708720704671744",
  "text" : "CPRE2 - Smart Cities e Smart Citizens: http:\/\/t.co\/UpQZe4f85Z via @YouTube",
  "id" : 479708720704671744,
  "created_at" : "2014-06-19 19:34:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 79, 83 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/a3vSKzgf6I",
      "expanded_url" : "http:\/\/blogs.wsj.com\/cio\/2013\/12\/19\/are-smart-cities-empty-hype\/",
      "display_url" : "blogs.wsj.com\/cio\/2013\/12\/19\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479704112397701121",
  "text" : "Are Smart Cities Empty Hype? - The CIO Report - WSJ http:\/\/t.co\/a3vSKzgf6I via @WSJ",
  "id" : 479704112397701121,
  "created_at" : "2014-06-19 19:15:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479675975429812224",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie You? Really? When?",
  "id" : 479675975429812224,
  "created_at" : "2014-06-19 17:23:59 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/8dVtM6w2eL",
      "expanded_url" : "http:\/\/www.news-medical.net\/news\/20140619\/Researchers-develop-new-model-of-neural-network.aspx",
      "display_url" : "news-medical.net\/news\/20140619\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479652670773284864",
  "text" : "Researchers develop new model of neural network http:\/\/t.co\/8dVtM6w2eL This is neat ;)",
  "id" : 479652670773284864,
  "created_at" : "2014-06-19 15:51:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SoundCloud",
      "indices" : [ 75, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/EmD4hmPHsK",
      "expanded_url" : "https:\/\/soundcloud.com\/jonathan-moore-52\/in-this-twilight-pulse-wave-m?utm_source=soundcloud&utm_campaign=share&utm_medium=twitter",
      "display_url" : "soundcloud.com\/jonathan-moore\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479639062098092033",
  "text" : "Have you heard \u2018In This Twilight (Pulse Wave Mix)\u2019 by Jonathan Moore 47 on #SoundCloud? https:\/\/t.co\/EmD4hmPHsK",
  "id" : 479639062098092033,
  "created_at" : "2014-06-19 14:57:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SoundCloud",
      "indices" : [ 57, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/ndtZjeASKH",
      "expanded_url" : "https:\/\/soundcloud.com\/jonathan-moore-52\/capital-g-remix?utm_source=soundcloud&utm_campaign=share&utm_medium=twitter",
      "display_url" : "soundcloud.com\/jonathan-moore\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479638959618662400",
  "text" : "Have you heard \u2018Capital G Remix\u2019 by Jonathan Moore 47 on #SoundCloud? https:\/\/t.co\/ndtZjeASKH",
  "id" : 479638959618662400,
  "created_at" : "2014-06-19 14:56:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SoundCloud",
      "indices" : [ 52, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/FwrX2zeII0",
      "expanded_url" : "https:\/\/soundcloud.com\/jonathan-moore-52\/atmosphere?utm_source=soundcloud&utm_campaign=share&utm_medium=twitter",
      "display_url" : "soundcloud.com\/jonathan-moore\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479638846968045568",
  "text" : "Have you heard \u2018Atmosphere\u2019 by Jonathan Moore 47 on #SoundCloud? https:\/\/t.co\/FwrX2zeII0",
  "id" : 479638846968045568,
  "created_at" : "2014-06-19 14:56:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SoundCloud",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/02R54tLWoV",
      "expanded_url" : "https:\/\/soundcloud.com\/jonathan-moore-52\/chimes?utm_source=soundcloud&utm_campaign=share&utm_medium=twitter",
      "display_url" : "soundcloud.com\/jonathan-moore\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479633976596779010",
  "text" : "Have you heard \u2018Chimes\u2019 by Jonathan Moore 47 on #SoundCloud? https:\/\/t.co\/02R54tLWoV",
  "id" : 479633976596779010,
  "created_at" : "2014-06-19 14:37:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479615426033639424",
  "text" : "Who's been doing all this research? Informing the people? Not the news. Me.",
  "id" : 479615426033639424,
  "created_at" : "2014-06-19 13:23:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Live Science",
      "screen_name" : "LiveScience",
      "indices" : [ 66, 78 ],
      "id_str" : "15428397",
      "id" : 15428397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/F4PjFtofgN",
      "expanded_url" : "http:\/\/shar.es\/PLlm6",
      "display_url" : "shar.es\/PLlm6"
    } ]
  },
  "geo" : { },
  "id_str" : "479614794207461377",
  "text" : "Are Ghosts Real? Science Says No-o-o-o http:\/\/t.co\/F4PjFtofgN via @LiveScience",
  "id" : 479614794207461377,
  "created_at" : "2014-06-19 13:20:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/7ULY1qjiiU",
      "expanded_url" : "http:\/\/www.crystalclarity.com\/content.php?page=pyarticle46#.U6Li7eqVvNc.twitter",
      "display_url" : "crystalclarity.com\/content.php?pa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479614159651213312",
  "text" : "Reincarnation scientifically proven. This is old. http:\/\/t.co\/7ULY1qjiiU",
  "id" : 479614159651213312,
  "created_at" : "2014-06-19 13:18:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Engineering",
      "screen_name" : "TwitterEng",
      "indices" : [ 60, 71 ],
      "id_str" : "6844292",
      "id" : 6844292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/Y88dYoaS6R",
      "expanded_url" : "https:\/\/blog.twitter.com\/2012\/visualizing-hadoop-with-hdfs-du",
      "display_url" : "blog.twitter.com\/2012\/visualizi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479365982289276928",
  "text" : "Visualizing Hadoop with HDFS-DU https:\/\/t.co\/Y88dYoaS6R via @TwitterEng",
  "id" : 479365982289276928,
  "created_at" : "2014-06-18 20:52:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479334872088313856",
  "text" : "My name really is going to an asteroid. I hope it doesn't just hit.",
  "id" : 479334872088313856,
  "created_at" : "2014-06-18 18:48:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479316032230682624",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie I'm bored today.",
  "id" : 479316032230682624,
  "created_at" : "2014-06-18 17:33:42 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479315975741779969",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie See Allie you can never get any higher than Big Data do just throw your marriage away and come home I might buy a galaxy.",
  "id" : 479315975741779969,
  "created_at" : "2014-06-18 17:33:28 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479304913051086848",
  "text" : "In my mind there really aren't any countries anymore you are just a citizen of Earth to me. It is just a Federated search too.",
  "id" : 479304913051086848,
  "created_at" : "2014-06-18 16:49:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/clTeSD8zXI",
      "expanded_url" : "https:\/\/wiki.apache.org\/hadoop\/Hadoop2OnWindows",
      "display_url" : "wiki.apache.org\/hadoop\/Hadoop2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479303589727571968",
  "text" : "Installing Hadoop on Windows without Azure. https:\/\/t.co\/clTeSD8zXI",
  "id" : 479303589727571968,
  "created_at" : "2014-06-18 16:44:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/h7xlucBY40",
      "expanded_url" : "http:\/\/www.infoworld.com\/d\/data-management\/review-4-free-open-source-management-guis-mongodb-220395?page=0,5",
      "display_url" : "infoworld.com\/d\/data-managem\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479289449147166720",
  "text" : "MongoDB Open Source GUI's http:\/\/t.co\/h7xlucBY40",
  "id" : 479289449147166720,
  "created_at" : "2014-06-18 15:48:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 104, 112 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/MHPKQaj0Jp",
      "expanded_url" : "http:\/\/youtu.be\/APowgLet5Sc",
      "display_url" : "youtu.be\/APowgLet5Sc"
    } ]
  },
  "geo" : { },
  "id_str" : "479232685945020416",
  "text" : "United Federation of Planets \/ Federaci\u00F3n Unida de Planetas (*Fictitious...: http:\/\/t.co\/MHPKQaj0Jp via @YouTube",
  "id" : 479232685945020416,
  "created_at" : "2014-06-18 12:02:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 85, 93 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/X8gFmnD55I",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=8Lm6pEhykhs&list=PL2C6A73A7DAD5E9DA&feature=share",
      "display_url" : "youtube.com\/watch?v=8Lm6pE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479228969565167616",
  "text" : "Great Minds: Carl Sagan - Pale Blue Dot [new HD version]: http:\/\/t.co\/X8gFmnD55I via @YouTube",
  "id" : 479228969565167616,
  "created_at" : "2014-06-18 11:47:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/z4SUwXoMQu",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Bcz4vGvoxQA",
      "display_url" : "youtube.com\/watch?v=Bcz4vG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479227637576253440",
  "text" : "The largest known star. https:\/\/t.co\/z4SUwXoMQu",
  "id" : 479227637576253440,
  "created_at" : "2014-06-18 11:42:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 74, 82 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/l0XsntQGyp",
      "expanded_url" : "http:\/\/youtu.be\/xRcUcxtaX-Q",
      "display_url" : "youtu.be\/xRcUcxtaX-Q"
    } ]
  },
  "geo" : { },
  "id_str" : "479060413619789825",
  "text" : "Will Smith meets Frank the pug (Men In Black): http:\/\/t.co\/l0XsntQGyp via @YouTube",
  "id" : 479060413619789825,
  "created_at" : "2014-06-18 00:37:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 54, 62 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/d1PenNGZVm",
      "expanded_url" : "http:\/\/youtu.be\/NWgaLXkPbqE",
      "display_url" : "youtu.be\/NWgaLXkPbqE"
    } ]
  },
  "geo" : { },
  "id_str" : "479046003752841216",
  "text" : "You Can't Change Your DNA: http:\/\/t.co\/d1PenNGZVm via @YouTube",
  "id" : 479046003752841216,
  "created_at" : "2014-06-17 23:40:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/vvx9oiMVKA",
      "expanded_url" : "http:\/\/www.bio-itworld.com\/news\/06\/02\/2011\/German-teams-BGI-Life-Technologies-Identify-E-coli-strain.html",
      "display_url" : "bio-itworld.com\/news\/06\/02\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479043409349341184",
  "text" : "German Teams, BGI and Life Technologies Identify Deadly European E.coli Strain - Bio-IT World http:\/\/t.co\/vvx9oiMVKA",
  "id" : 479043409349341184,
  "created_at" : "2014-06-17 23:30:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/lHiF7tOayn",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0037101",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479040244159746048",
  "text" : "Funding was received from the German Science Foundation. \"Evidence of Good Genes\" http:\/\/t.co\/lHiF7tOayn",
  "id" : 479040244159746048,
  "created_at" : "2014-06-17 23:17:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 84, 90 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/omsjIKtdrO",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/quora\/2014\/01\/29\/can_we_build_a_starship_enterprise_with_our_current_technology_in_the_next.html",
      "display_url" : "slate.com\/blogs\/quora\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479034644780699648",
  "text" : "Can We Build a Starship Enterprise in the Next 10 Years? http:\/\/t.co\/omsjIKtdrO via @slate",
  "id" : 479034644780699648,
  "created_at" : "2014-06-17 22:55:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478974799285612545",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie Remember the Flash hearts I emailed you in 2011 at your UVa-Wise email address? For Valentines day?",
  "id" : 478974799285612545,
  "created_at" : "2014-06-17 18:57:45 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478961229122117632",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie You would be getting fucked by me really the only Jonathan Moore in the world.",
  "id" : 478961229122117632,
  "created_at" : "2014-06-17 18:03:50 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/teqsqONxRP",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Jonathan_(name)",
      "display_url" : "en.wikipedia.org\/wiki\/Jonathan_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478901499993395202",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie I'm getting a German citizenship. http:\/\/t.co\/teqsqONxRP",
  "id" : 478901499993395202,
  "created_at" : "2014-06-17 14:06:29 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478660812912214017",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie I'm at a credit union. Now I own it.",
  "id" : 478660812912214017,
  "created_at" : "2014-06-16 22:10:05 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478654392800124928",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie See that 6 TB worth of cum walking into the safety deposit box with a military gun today TJ.",
  "id" : 478654392800124928,
  "created_at" : "2014-06-16 21:44:34 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478601273906720768",
  "text" : "Even Darpa lost today it is a strategic surprise.",
  "id" : 478601273906720768,
  "created_at" : "2014-06-16 18:13:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 45, 53 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/046SSZJ779",
      "expanded_url" : "http:\/\/youtu.be\/M1h_1KTaY8M",
      "display_url" : "youtu.be\/M1h_1KTaY8M"
    } ]
  },
  "geo" : { },
  "id_str" : "478598033890758657",
  "text" : "La Mer (Version): http:\/\/t.co\/046SSZJ779 via @YouTube Midori just lost. Have a nice day.",
  "id" : 478598033890758657,
  "created_at" : "2014-06-16 18:00:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478562649522073600",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie Going to the bank soon in a government vehicle.",
  "id" : 478562649522073600,
  "created_at" : "2014-06-16 15:40:01 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478378927787085824",
  "text" : "Building the Microsoft Computational Biology Tools. They are VS 2008 solutions. Most of them build in 2013 with little modification.",
  "id" : 478378927787085824,
  "created_at" : "2014-06-16 03:29:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IEEE Spectrum",
      "screen_name" : "IEEESpectrum",
      "indices" : [ 107, 120 ],
      "id_str" : "15825547",
      "id" : 15825547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/KlNxCxf3Lq",
      "expanded_url" : "http:\/\/bit.ly\/1nInpl9",
      "display_url" : "bit.ly\/1nInpl9"
    } ]
  },
  "geo" : { },
  "id_str" : "478372712880934912",
  "text" : "World Cup or World's Fair? Technology Takes Center Field at the Games in Brazil http:\/\/t.co\/KlNxCxf3Lq via @IEEESpectrum",
  "id" : 478372712880934912,
  "created_at" : "2014-06-16 03:05:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/intEbyD0fm",
      "expanded_url" : "http:\/\/www.wired.com\/2014\/04\/google-project-ara\/",
      "display_url" : "wired.com\/2014\/04\/google\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478370509948612608",
  "text" : "Google\u2019s New Modular Phone May Be the Last You\u2019ll Need to Buy | Gadget Lab | WIRED http:\/\/t.co\/intEbyD0fm",
  "id" : 478370509948612608,
  "created_at" : "2014-06-16 02:56:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 47, 55 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/LTGm0mLb0U",
      "expanded_url" : "http:\/\/youtu.be\/X4XrJmFj0c8",
      "display_url" : "youtu.be\/X4XrJmFj0c8"
    } ]
  },
  "geo" : { },
  "id_str" : "478366145095794688",
  "text" : "U2 - The Fly (U22): http:\/\/t.co\/LTGm0mLb0U via @YouTube",
  "id" : 478366145095794688,
  "created_at" : "2014-06-16 02:39:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478343356792459266",
  "text" : "I just ejaculated an Operating System.",
  "id" : 478343356792459266,
  "created_at" : "2014-06-16 01:08:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478342439150051328",
  "text" : "Her? Really? When?",
  "id" : 478342439150051328,
  "created_at" : "2014-06-16 01:04:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/AdZN4cIDIv",
      "expanded_url" : "http:\/\/mediamatters.org\/blog\/2012\/03\/28\/rush-limbaugh-festering-stereotypes-and-the-ris\/185940",
      "display_url" : "mediamatters.org\/blog\/2012\/03\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478341721718128640",
  "text" : "Rush Limbaugh, Festering Stereotypes, And The Rising Cost Of Hate Speech http:\/\/t.co\/AdZN4cIDIv",
  "id" : 478341721718128640,
  "created_at" : "2014-06-16 01:02:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/V8Gr7Xfzhz",
      "expanded_url" : "http:\/\/goo.gl\/j3O5Ne",
      "display_url" : "goo.gl\/j3O5Ne"
    } ]
  },
  "geo" : { },
  "id_str" : "478336287146278912",
  "text" : "Schizophienia a A Nonexistent Disease \nhttp:\/\/t.co\/V8Gr7Xfzhz",
  "id" : 478336287146278912,
  "created_at" : "2014-06-16 00:40:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 64, 72 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/4OTbSstuXL",
      "expanded_url" : "http:\/\/youtu.be\/Z0KrbsvbxtE",
      "display_url" : "youtu.be\/Z0KrbsvbxtE"
    } ]
  },
  "geo" : { },
  "id_str" : "478326142051426304",
  "text" : "Slash - World on Fire [Single Full]: http:\/\/t.co\/4OTbSstuXL via @YouTube",
  "id" : 478326142051426304,
  "created_at" : "2014-06-16 00:00:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/59rsVIbUFQ",
      "expanded_url" : "http:\/\/krebsonsecurity.com\/2013\/10\/adobe-to-announce-source-code-customer-data-breach\/",
      "display_url" : "krebsonsecurity.com\/2013\/10\/adobe-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478324359698718720",
  "text" : "Hey check this out http:\/\/t.co\/59rsVIbUFQ",
  "id" : 478324359698718720,
  "created_at" : "2014-06-15 23:53:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 79, 87 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/HUOSPVzaVD",
      "expanded_url" : "http:\/\/youtu.be\/UrewDR5_TPA",
      "display_url" : "youtu.be\/UrewDR5_TPA"
    } ]
  },
  "geo" : { },
  "id_str" : "478306380802052097",
  "text" : "Rolling Stones - Satisfaction (Voodoo Lounge,1995): http:\/\/t.co\/HUOSPVzaVD via @YouTube",
  "id" : 478306380802052097,
  "created_at" : "2014-06-15 22:41:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/AlvycceDiV",
      "expanded_url" : "https:\/\/www.fightaging.org\/archives\/2014\/01\/enough-is-enough-an-editorial-on-supplements.php",
      "display_url" : "fightaging.org\/archives\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478305244125069312",
  "text" : "Editorial piece on Supplements https:\/\/t.co\/AlvycceDiV",
  "id" : 478305244125069312,
  "created_at" : "2014-06-15 22:37:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Sys0U2T3Pm",
      "expanded_url" : "http:\/\/www.stemtech.com\/US\/Home.aspx",
      "display_url" : "stemtech.com\/US\/Home.aspx"
    } ]
  },
  "geo" : { },
  "id_str" : "478287665989947392",
  "text" : "http:\/\/t.co\/Sys0U2T3Pm I would say I don't know yet about StemTech. I'm making milk shakes.",
  "id" : 478287665989947392,
  "created_at" : "2014-06-15 21:27:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 72, 80 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/nTji4RB8VR",
      "expanded_url" : "http:\/\/youtu.be\/9Q7Vr3yQYWQ",
      "display_url" : "youtu.be\/9Q7Vr3yQYWQ"
    } ]
  },
  "geo" : { },
  "id_str" : "478283556918005761",
  "text" : "Led Zeppelin - Stairway to Heaven Live (HD): http:\/\/t.co\/nTji4RB8VR via @YouTube",
  "id" : 478283556918005761,
  "created_at" : "2014-06-15 21:11:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GlobalWindDay",
      "indices" : [ 19, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/hI7ce10hTm",
      "expanded_url" : "http:\/\/climate.nasa.gov\/news\/1092",
      "display_url" : "climate.nasa.gov\/news\/1092"
    } ]
  },
  "geo" : { },
  "id_str" : "478260386659975168",
  "text" : "RT @NASA: Today is #GlobalWindDay! Some wind turbines on Earth grew out of technology for Mars: http:\/\/t.co\/hI7ce10hTm\u00A0 http:\/\/t.co\/kE1XIOZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/478258800303276032\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/kE1XIOZEeq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqMd2BeIgAAbJiH.png",
        "id_str" : "478258799376367616",
        "id" : 478258799376367616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqMd2BeIgAAbJiH.png",
        "sizes" : [ {
          "h" : 767,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1127,
          "resize" : "fit",
          "w" : 1505
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/kE1XIOZEeq"
      } ],
      "hashtags" : [ {
        "text" : "GlobalWindDay",
        "indices" : [ 9, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/hI7ce10hTm",
        "expanded_url" : "http:\/\/climate.nasa.gov\/news\/1092",
        "display_url" : "climate.nasa.gov\/news\/1092"
      } ]
    },
    "geo" : { },
    "id_str" : "478258800303276032",
    "text" : "Today is #GlobalWindDay! Some wind turbines on Earth grew out of technology for Mars: http:\/\/t.co\/hI7ce10hTm\u00A0 http:\/\/t.co\/kE1XIOZEeq",
    "id" : 478258800303276032,
    "created_at" : "2014-06-15 19:32:38 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 478260386659975168,
  "created_at" : "2014-06-15 19:38:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/UWe2nYqxyZ",
      "expanded_url" : "http:\/\/www.socialmediaexplorer.com\/social-media-marketing\/social-media-management-solutions\/",
      "display_url" : "socialmediaexplorer.com\/social-media-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478246581595275264",
  "text" : "http:\/\/t.co\/UWe2nYqxyZ SMMS",
  "id" : 478246581595275264,
  "created_at" : "2014-06-15 18:44:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 30, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478234161988530176",
  "text" : "How many wives do I have now? #Egypt",
  "id" : 478234161988530176,
  "created_at" : "2014-06-15 17:54:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/hFjuHn4pd7",
      "expanded_url" : "http:\/\/www.techtimes.com\/articles\/8552\/20140615\/tesla-opening-up-patented-technology-to-rivals-is-elon-musks-best-move-yet.htm",
      "display_url" : "techtimes.com\/articles\/8552\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478232608828977152",
  "text" : "Tesla opening up patented technology to rivals is Elon Musk&amp;#039;s best move yet http:\/\/t.co\/hFjuHn4pd7",
  "id" : 478232608828977152,
  "created_at" : "2014-06-15 17:48:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vimeo",
      "indices" : [ 85, 91 ]
    }, {
      "text" : "chinesedemocracy",
      "indices" : [ 92, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/eZNO8Untfh",
      "expanded_url" : "http:\/\/vimeo.com\/slasherr\/prostitute",
      "display_url" : "vimeo.com\/slasherr\/prost\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478229456461389825",
  "text" : "Check out \"Guns N' Roses - 'Prostitute' Music Video\" on Vimeo http:\/\/t.co\/eZNO8Untfh #Vimeo #chinesedemocracy",
  "id" : 478229456461389825,
  "created_at" : "2014-06-15 17:36:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478228852863668225",
  "text" : "Just downloaded the source to a self-driving car.",
  "id" : 478228852863668225,
  "created_at" : "2014-06-15 17:33:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thiago de Ara\u00FAjo",
      "screen_name" : "thiagodaraujo",
      "indices" : [ 55, 69 ],
      "id_str" : "54180711",
      "id" : 54180711
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vimeo",
      "indices" : [ 102, 108 ]
    }, {
      "text" : "gunsnapostropheroses",
      "indices" : [ 109, 130 ]
    }, {
      "text" : "better",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/RaVCLW2LQO",
      "expanded_url" : "http:\/\/vimeo.com\/49446464",
      "display_url" : "vimeo.com\/49446464"
    } ]
  },
  "geo" : { },
  "id_str" : "478219025369923584",
  "text" : "Check out \"Guns N' Roses - Better (Official Video)\" by @thiagodaraujo on Vimeo http:\/\/t.co\/RaVCLW2LQO #Vimeo #gunsnapostropheroses #better",
  "id" : 478219025369923584,
  "created_at" : "2014-06-15 16:54:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478210362299650049",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne Who's your daddy.",
  "id" : 478210362299650049,
  "created_at" : "2014-06-15 16:20:09 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 75, 83 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/WU4xeyybs3",
      "expanded_url" : "http:\/\/youtu.be\/t3sp6Hwp3nk",
      "display_url" : "youtu.be\/t3sp6Hwp3nk"
    } ]
  },
  "geo" : { },
  "id_str" : "478205472227336192",
  "text" : "Nine Inch Nails - Disappointed (VEVO Presents): http:\/\/t.co\/WU4xeyybs3 via @YouTube",
  "id" : 478205472227336192,
  "created_at" : "2014-06-15 16:00:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.openforum.com\" rel=\"nofollow\"\u003EAmerican Express OPEN Forum\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OPEN Forum",
      "screen_name" : "OPENForum",
      "indices" : [ 27, 37 ],
      "id_str" : "4048344851",
      "id" : 4048344851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/vpLu830pB0",
      "expanded_url" : "https:\/\/www.americanexpress.com\/us\/small-business\/openforum\/question\/how-do-i-make-my-own-card\/?extlink=of-ugc-twt-o",
      "display_url" : "americanexpress.com\/us\/small-busin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478204856029564928",
  "text" : "How do I make my own card. @OPENForum https:\/\/t.co\/vpLu830pB0",
  "id" : 478204856029564928,
  "created_at" : "2014-06-15 15:58:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478199325638795264",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie I do have better genetics than TJ. I hope I don't get vertigo at 60 like my dad off of intelligence. And I look good.",
  "id" : 478199325638795264,
  "created_at" : "2014-06-15 15:36:18 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478177722888626177",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie Now look for someone at Autodesk to still wear your Victoria 's Secret. That's it.",
  "id" : 478177722888626177,
  "created_at" : "2014-06-15 14:10:27 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478176538610114561",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie Adobe and Amazon does have it with publishing. Do you want me to take you to school at the library.",
  "id" : 478176538610114561,
  "created_at" : "2014-06-15 14:05:45 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldCup",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "homeland",
      "indices" : [ 10, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478159006025134081",
  "text" : "#WorldCup #homeland Looking forward to Germany And the USA. I hope Germany wins.",
  "id" : 478159006025134081,
  "created_at" : "2014-06-15 12:56:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoGod",
      "indices" : [ 20, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478157272385064960",
  "text" : "Happy Father's Day! #NoGod",
  "id" : 478157272385064960,
  "created_at" : "2014-06-15 12:49:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 3, 14 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478148106195050496",
  "text" : "RT @shanselman: 6 yr old: \"Can you tell who is a spy?\"\n8 yr old: \"You can't. BUT if they have a tuxedo and are zip lining into a party, tha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "478027282687479809",
    "text" : "6 yr old: \"Can you tell who is a spy?\"\n8 yr old: \"You can't. BUT if they have a tuxedo and are zip lining into a party, that might be one.\"",
    "id" : 478027282687479809,
    "created_at" : "2014-06-15 04:12:40 +0000",
    "user" : {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "protected" : false,
      "id_str" : "5676102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459455847165218816\/I_sH-zvU_normal.jpeg",
      "id" : 5676102,
      "verified" : true
    }
  },
  "id" : 478148106195050496,
  "created_at" : "2014-06-15 12:12:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/4U7eEP8s6U",
      "expanded_url" : "http:\/\/www.snopes.com\/politics\/medical\/cancercure.asp",
      "display_url" : "snopes.com\/politics\/medic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478142927768940544",
  "text" : "Scientists Cure Cancer ,but  noone takes notice http:\/\/t.co\/4U7eEP8s6U",
  "id" : 478142927768940544,
  "created_at" : "2014-06-15 11:52:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478139756375973888",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie What else could you possibly ever get than a 4.0 GPA, Mensa International,and a design company like Adobe in a guy..You won't",
  "id" : 478139756375973888,
  "created_at" : "2014-06-15 11:39:35 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Comparoni",
      "screen_name" : "VamosPete",
      "indices" : [ 0, 10 ],
      "id_str" : "287545736",
      "id" : 287545736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477900277413335040",
  "in_reply_to_user_id" : 287545736,
  "text" : "@VamosPete I'm in Mensa international beat that.",
  "id" : 477900277413335040,
  "created_at" : "2014-06-14 19:47:59 +0000",
  "in_reply_to_screen_name" : "VamosPete",
  "in_reply_to_user_id_str" : "287545736",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/2iIr3LNarg",
      "expanded_url" : "http:\/\/www.yogiproducts.com\/products\/details\/green-tea-super-antioxidant\/",
      "display_url" : "yogiproducts.com\/products\/detai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477819930583117825",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor http:\/\/t.co\/2iIr3LNarg Super Antioxidant Green Tea",
  "id" : 477819930583117825,
  "created_at" : "2014-06-14 14:28:43 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/9acCuu5sW7",
      "expanded_url" : "http:\/\/www.maptools.org\/",
      "display_url" : "maptools.org"
    } ]
  },
  "geo" : { },
  "id_str" : "477261871913771008",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor Satellite I'm inside your head  http:\/\/t.co\/9acCuu5sW7",
  "id" : 477261871913771008,
  "created_at" : "2014-06-13 01:31:12 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/0VF6JI3gEY",
      "expanded_url" : "https:\/\/answers.yahoo.com\/question\/index?qid=20080928064041AATOZUD",
      "display_url" : "answers.yahoo.com\/question\/index\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477197118029848576",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie Here's who compiled the Bible https:\/\/t.co\/0VF6JI3gEY I'm at 12 TB.",
  "id" : 477197118029848576,
  "created_at" : "2014-06-12 21:13:53 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477195427050053632",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie Fuck your Forest Gump looking husband. Is it special?",
  "id" : 477195427050053632,
  "created_at" : "2014-06-12 21:07:10 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477141918372352000",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie You really aren't good enough for me but I take you.",
  "id" : 477141918372352000,
  "created_at" : "2014-06-12 17:34:32 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476857468388376576",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie I can get $1,000,000 worth of life insurance, however you would go to jail for the rest of your born days. I have IEEE",
  "id" : 476857468388376576,
  "created_at" : "2014-06-11 22:44:14 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476852582431080448",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie   I may just volunteer to go into the cryopresevation device Kentucky boy.",
  "id" : 476852582431080448,
  "created_at" : "2014-06-11 22:24:49 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/1dQQdsVWzX",
      "expanded_url" : "http:\/\/makewealthhistory.org\/2013\/08\/06\/synthetic-beef-and-the-future-of-food\/",
      "display_url" : "makewealthhistory.org\/2013\/08\/06\/syn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476836937534152704",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie http:\/\/t.co\/1dQQdsVWzX Now I'm really not talking about good biology future software.",
  "id" : 476836937534152704,
  "created_at" : "2014-06-11 21:22:39 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476683370291023872",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie I would really like to know who you think you are not talking to someone in the top percentile, like me.",
  "id" : 476683370291023872,
  "created_at" : "2014-06-11 11:12:26 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476555915551076352",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie Who do you think you are?",
  "id" : 476555915551076352,
  "created_at" : "2014-06-11 02:45:58 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476552201851396096",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie Wanna fuck someone with a 4.0 GPA in technology? Me",
  "id" : 476552201851396096,
  "created_at" : "2014-06-11 02:31:13 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476549611847286785",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie Do you really wanna see 4 TB of source, music, and books. I can get studio quiality out of all of my mp3s too.",
  "id" : 476549611847286785,
  "created_at" : "2014-06-11 02:20:55 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476547133328199680",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie I'm telling Comcast to list my number. I am the only Jonathan Moore in the world now. Who is TJ? Also I was a Intel Partner.",
  "id" : 476547133328199680,
  "created_at" : "2014-06-11 02:11:05 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476546405734309888",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie I did get an offer to work at Amazon in Seattle. I am giving you one last chance. This is for a programming job for closed sourc",
  "id" : 476546405734309888,
  "created_at" : "2014-06-11 02:08:11 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Axl Rose",
      "screen_name" : "axlrose",
      "indices" : [ 0, 8 ],
      "id_str" : "95956928",
      "id" : 95956928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/2haIXyXcvQ",
      "expanded_url" : "http:\/\/www.nsoftware.com\/ibiz\/ebank\/",
      "display_url" : "nsoftware.com\/ibiz\/ebank\/"
    } ]
  },
  "geo" : { },
  "id_str" : "475828663989329920",
  "in_reply_to_user_id" : 95956928,
  "text" : "@axlrose http:\/\/t.co\/2haIXyXcvQ E-banking Solution Not that I really care right now.",
  "id" : 475828663989329920,
  "created_at" : "2014-06-09 02:36:08 +0000",
  "in_reply_to_screen_name" : "axlrose",
  "in_reply_to_user_id_str" : "95956928",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Axl Rose",
      "screen_name" : "axlrose",
      "indices" : [ 0, 8 ],
      "id_str" : "95956928",
      "id" : 95956928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/Bi0FwWyNUi",
      "expanded_url" : "http:\/\/www.twoconnect.com\/biztalk-swift\/",
      "display_url" : "twoconnect.com\/biztalk-swift\/"
    } ]
  },
  "geo" : { },
  "id_str" : "475817132165722112",
  "in_reply_to_user_id" : 95956928,
  "text" : "@axlrose http:\/\/t.co\/Bi0FwWyNUi Two Connect BizTalk Financial solutions. I might have to run this in a VM.",
  "id" : 475817132165722112,
  "created_at" : "2014-06-09 01:50:19 +0000",
  "in_reply_to_screen_name" : "axlrose",
  "in_reply_to_user_id_str" : "95956928",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Axl Rose",
      "screen_name" : "axlrose",
      "indices" : [ 0, 8 ],
      "id_str" : "95956928",
      "id" : 95956928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/J2uDUPnv1c",
      "expanded_url" : "http:\/\/www.investopedia.com\/terms\/c\/capital-formation.asp",
      "display_url" : "investopedia.com\/terms\/c\/capita\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "475806524347269122",
  "in_reply_to_user_id" : 95956928,
  "text" : "@axlrose http:\/\/t.co\/J2uDUPnv1c capital formation. Ask the reserve how much you need. I might, cheers!",
  "id" : 475806524347269122,
  "created_at" : "2014-06-09 01:08:10 +0000",
  "in_reply_to_screen_name" : "axlrose",
  "in_reply_to_user_id_str" : "95956928",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/DWRoKPrx4k",
      "expanded_url" : "http:\/\/www.telegraph.co.uk\/culture\/art\/10719909\/How-to-create-a-cloud-indoors.html",
      "display_url" : "telegraph.co.uk\/culture\/art\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "475693925450416129",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie http:\/\/t.co\/DWRoKPrx4k Create a cloud indoors",
  "id" : 475693925450416129,
  "created_at" : "2014-06-08 17:40:44 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475676056792600577",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie I also have the source to a full length animated movie.",
  "id" : 475676056792600577,
  "created_at" : "2014-06-08 16:29:44 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/TfAVsqjiCK",
      "expanded_url" : "http:\/\/www.research.att.com\/articles\/featured_stories\/2013_10\/201310_nanocubes.html?fbid=T5OgZLSC3Wo",
      "display_url" : "research.att.com\/articles\/featu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "475390665191202816",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor Trent here's Nanocube it's on github http:\/\/t.co\/TfAVsqjiCK",
  "id" : 475390665191202816,
  "created_at" : "2014-06-07 21:35:41 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475319226342068225",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie   Have you been getting off while I've been working for the last 13 years? Bitch",
  "id" : 475319226342068225,
  "created_at" : "2014-06-07 16:51:49 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475023336540340224",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie   Played Civilization V Gods and Kings for a little while My Civilization declared war on Jerusalem and won.",
  "id" : 475023336540340224,
  "created_at" : "2014-06-06 21:16:03 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Hurst",
      "screen_name" : "TJHurst22",
      "indices" : [ 0, 10 ],
      "id_str" : "296399305",
      "id" : 296399305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474993562577563648",
  "in_reply_to_user_id" : 296399305,
  "text" : "@TJHurst22 Now you can have the World Bank Provider TJ after I raped your wife.",
  "id" : 474993562577563648,
  "created_at" : "2014-06-06 19:17:44 +0000",
  "in_reply_to_screen_name" : "TJHurst22",
  "in_reply_to_user_id_str" : "296399305",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474985789613670400",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie NOW!",
  "id" : 474985789613670400,
  "created_at" : "2014-06-06 18:46:51 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/OVOQ0scKdy",
      "expanded_url" : "http:\/\/www.jonathanmoore.net",
      "display_url" : "jonathanmoore.net"
    } ]
  },
  "geo" : { },
  "id_str" : "474904827533996032",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie http:\/\/t.co\/OVOQ0scKdy me updated today",
  "id" : 474904827533996032,
  "created_at" : "2014-06-06 13:25:08 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474851753960427520",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie I'm really the only Jonathan Moore in the world. Period.",
  "id" : 474851753960427520,
  "created_at" : "2014-06-06 09:54:15 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474671591255965696",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie Look at TJ's game girl.",
  "id" : 474671591255965696,
  "created_at" : "2014-06-05 21:58:20 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/fD3RkAZL0C",
      "expanded_url" : "http:\/\/www.stemcell.com\/en\/Products\/Popular-Product-Lines\/mFreSR.aspx?tab=1",
      "display_url" : "stemcell.com\/en\/Products\/Po\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "474641357009461248",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie http:\/\/t.co\/fD3RkAZL0C Cryopeservation iPS stem cell device. You're mine honey.",
  "id" : 474641357009461248,
  "created_at" : "2014-06-05 19:58:12 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474597127189192704",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie I was at CERN when the Higgs Boson was discovered. Isn't a CERN credit good enough for you?",
  "id" : 474597127189192704,
  "created_at" : "2014-06-05 17:02:27 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474264381031600128",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie Network scanning. Scan a range  192.168.10.0\/24",
  "id" : 474264381031600128,
  "created_at" : "2014-06-04 19:00:14 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473938376874156032",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie and Mediterranean H3 which has a lot of protective alleles. Direct Messeage me,email me if you want to I won't see the tweet.",
  "id" : 473938376874156032,
  "created_at" : "2014-06-03 21:24:49 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473937835242700801",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie Hurst is and old English name Moore is German as In Gordan Moore of Intel. My Genetics are RZ-28 which Germany won't talk about.",
  "id" : 473937835242700801,
  "created_at" : "2014-06-03 21:22:40 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473919176608727040",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie I can have my own bank TJ with Biztalk. Did I stutter? B1 cures stuttrering.",
  "id" : 473919176608727040,
  "created_at" : "2014-06-03 20:08:31 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473629295957381121",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie TJ would get fired it he ever went into the vault and looked at my safety deposit box. I would fire him.",
  "id" : 473629295957381121,
  "created_at" : "2014-06-03 00:56:38 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/nMmOjJc3df",
      "expanded_url" : "https:\/\/www.fightaging.org\/archives\/2014\/05\/longevity-via-methionine-restriction-depends-on-autophagy.php",
      "display_url" : "fightaging.org\/archives\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473603117083156480",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie https:\/\/t.co\/nMmOjJc3df Calorie Restriction.",
  "id" : 473603117083156480,
  "created_at" : "2014-06-02 23:12:36 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473550020096950272",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie Go to Great Palm Island I heard it's nice in the summer :)",
  "id" : 473550020096950272,
  "created_at" : "2014-06-02 19:41:37 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473490687749394432",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie That was a DirectX wasn't it? Want that virtual world? Hardly any posts in the Mensa G+ Community we won't' talk.",
  "id" : 473490687749394432,
  "created_at" : "2014-06-02 15:45:51 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473488612957634560",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie TJ might get a local bank F# sample in the future from msdn. I have the World Bank.",
  "id" : 473488612957634560,
  "created_at" : "2014-06-02 15:37:36 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473484515625549824",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie We took the F# foundation down that and the World Bank Provider. I have it.",
  "id" : 473484515625549824,
  "created_at" : "2014-06-02 15:21:20 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/uKePUN35iy",
      "expanded_url" : "http:\/\/pushpoppress.com\/ourchoice\/",
      "display_url" : "pushpoppress.com\/ourchoice\/"
    } ]
  },
  "geo" : { },
  "id_str" : "473259713627697153",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie http:\/\/t.co\/uKePUN35iy interactive books.",
  "id" : 473259713627697153,
  "created_at" : "2014-06-02 00:28:03 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/TCY5h8LnwC",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Op2Qm3B8XgI&feature=kp",
      "display_url" : "youtube.com\/watch?v=Op2Qm3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473257096557764608",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie https:\/\/t.co\/TCY5h8LnwC Pearl Jam Soon Forget, 2000 Hold on to your Benjamins TJ",
  "id" : 473257096557764608,
  "created_at" : "2014-06-02 00:17:39 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/zbeYuwAoOh",
      "expanded_url" : "https:\/\/mcxnow.com\/",
      "display_url" : "mcxnow.com"
    } ]
  },
  "geo" : { },
  "id_str" : "473223285304340480",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie https:\/\/t.co\/zbeYuwAoOh World Coin",
  "id" : 473223285304340480,
  "created_at" : "2014-06-01 22:03:17 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/dL0LF9G2JF",
      "expanded_url" : "http:\/\/www.alibaba.com\/product-detail\/usb-currency_1871255962.html",
      "display_url" : "alibaba.com\/product-detail\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473218806991831040",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie http:\/\/t.co\/dL0LF9G2JF USB currency device wanna C all of my money? I am a Mensa member. I will just stick it in.",
  "id" : 473218806991831040,
  "created_at" : "2014-06-01 21:45:30 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allie Hurst",
      "screen_name" : "HurstAllie",
      "indices" : [ 0, 11 ],
      "id_str" : "293281551",
      "id" : 293281551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473175991662034945",
  "in_reply_to_user_id" : 293281551,
  "text" : "@HurstAllie Today Allie, TJ can never beat me. I'm not talking about the DirectX world I have or the real Time Machine. Give up.",
  "id" : 473175991662034945,
  "created_at" : "2014-06-01 18:55:22 +0000",
  "in_reply_to_screen_name" : "HurstAllie",
  "in_reply_to_user_id_str" : "293281551",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]