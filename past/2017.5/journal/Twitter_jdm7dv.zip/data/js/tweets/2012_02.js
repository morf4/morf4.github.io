Grailbird.data.tweets_2012_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jdm7dv",
      "indices" : [ 35, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/7D2ZWhFu",
      "expanded_url" : "http:\/\/code.msdn.microsoft.com\/Hadoop-Streaming-and-F-f2e76850",
      "display_url" : "code.msdn.microsoft.com\/Hadoop-Streami\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "174361168184487936",
  "text" : "Hadoop and F# http:\/\/t.co\/7D2ZWhFu #jdm7dv",
  "id" : 174361168184487936,
  "created_at" : "2012-02-28 05:11:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]