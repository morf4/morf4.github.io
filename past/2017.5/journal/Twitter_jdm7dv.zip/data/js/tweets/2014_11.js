Grailbird.data.tweets_2014_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/XtdXn7f136",
      "expanded_url" : "http:\/\/www.amazon.com\/Four-Point-Zero-Jonathan-Moore\/dp\/B00P7MZ9SY",
      "display_url" : "amazon.com\/Four-Point-Zer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534819396594966528",
  "text" : "Released today. Four Point Zero. Buy or stream.http:\/\/t.co\/XtdXn7f136",
  "id" : 534819396594966528,
  "created_at" : "2014-11-18 21:24:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]