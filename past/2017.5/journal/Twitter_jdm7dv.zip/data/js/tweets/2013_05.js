Grailbird.data.tweets_2013_05 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ONE",
      "screen_name" : "ONECampaign",
      "indices" : [ 73, 85 ],
      "id_str" : "16348549",
      "id" : 16348549
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ONEfood",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/NlrLWgBdrR",
      "expanded_url" : "http:\/\/www.one.org\/us\/action\/food_revolution\/",
      "display_url" : "one.org\/us\/action\/food\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "333645730478702592",
  "text" : "This year 2m will die of malnutrition while 2m will die of obesity. Join @ONECampaign &amp; act now #ONEfood http:\/\/t.co\/NlrLWgBdrR",
  "id" : 333645730478702592,
  "created_at" : "2013-05-12 18:11:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "indices" : [ 118, 129 ],
      "id_str" : "15438913",
      "id" : 15438913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/oE10bueT9h",
      "expanded_url" : "http:\/\/bit.ly\/13HbYQl",
      "display_url" : "bit.ly\/13HbYQl"
    } ]
  },
  "geo" : { },
  "id_str" : "332785147764158464",
  "text" : "The vampire treatment that 'rejuvenates' ageing hearts: Dose of young blood can reverse... http:\/\/t.co\/oE10bueT9h via @MailOnline",
  "id" : 332785147764158464,
  "created_at" : "2013-05-10 09:12:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]