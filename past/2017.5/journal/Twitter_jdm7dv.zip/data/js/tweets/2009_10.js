Grailbird.data.tweets_2009_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ONE",
      "screen_name" : "ONECampaign",
      "indices" : [ 43, 55 ],
      "id_str" : "16348549",
      "id" : 16348549
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "standup09",
      "indices" : [ 77, 87 ]
    }, {
      "text" : "fb",
      "indices" : [ 88, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4944000265",
  "text" : "I\u2019m Standing Up against poverty today with @onecampaign. Pls RT and join me. #standup09 #fb",
  "id" : 4944000265,
  "created_at" : "2009-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]