Grailbird.data.tweets_2011_06 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/vN9uYoU",
      "expanded_url" : "http:\/\/OFA.BO\/1gbd7n",
      "display_url" : "OFA.BO\/1gbd7n"
    } ]
  },
  "geo" : { },
  "id_str" : "78279471223930880",
  "text" : "My donation to Obama for America just got matched by another grassroots supporter. Want to double your impact too? http:\/\/t.co\/vN9uYoU",
  "id" : 78279471223930880,
  "created_at" : "2011-06-08 01:57:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]