Grailbird.data.tweets_2012_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/1GkvOSra",
      "expanded_url" : "http:\/\/www.bloomberg.com\/news\/2012-08-08\/diabetes-may-be-reversed-by-long-used-vaccine-for-tb.html",
      "display_url" : "bloomberg.com\/news\/2012-08-0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "251069801655574528",
  "text" : "diabetes news http:\/\/t.co\/1GkvOSra",
  "id" : 251069801655574528,
  "created_at" : "2012-09-26 21:24:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/Vw8L9Uuq",
      "expanded_url" : "http:\/\/www.marchmontnews.com\/Technology-Innovation\/Central-regions\/18998-Eye-healing-%C3%ABSkulachevs-ions-hit-Russian-pharma-market.html",
      "display_url" : "marchmontnews.com\/Technology-Inn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "249545487424835584",
  "text" : "Vizomitin News http:\/\/t.co\/Vw8L9Uuq",
  "id" : 249545487424835584,
  "created_at" : "2012-09-22 16:27:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 39 ],
      "url" : "https:\/\/t.co\/Jr0gGbmt",
      "expanded_url" : "https:\/\/secure.avaaz.org\/en\/a_ray_of_hope_on_climate\/?fpEMwdb=&pv=41",
      "display_url" : "secure.avaaz.org\/en\/a_ray_of_ho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "244094115048992768",
  "text" : "Save Solar Energy https:\/\/t.co\/Jr0gGbmt",
  "id" : 244094115048992768,
  "created_at" : "2012-09-07 15:25:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]