Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/omoFJCBq",
      "expanded_url" : "http:\/\/www.freeworldcharter.org\/en",
      "display_url" : "freeworldcharter.org\/en"
    } ]
  },
  "geo" : { },
  "id_str" : "235135056132308993",
  "text" : "Let's make everything Free :) http:\/\/t.co\/omoFJCBq",
  "id" : 235135056132308993,
  "created_at" : "2012-08-13 22:05:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]