Grailbird.data.tweets_2010_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Brown",
      "screen_name" : "Pete_Brown",
      "indices" : [ 0, 11 ],
      "id_str" : "5718162",
      "id" : 5718162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WPF",
      "indices" : [ 45, 49 ]
    }, {
      "text" : "fb",
      "indices" : [ 50, 53 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19750399926",
  "geo" : { },
  "id_str" : "19879204844",
  "in_reply_to_user_id" : 5718162,
  "text" : "@Pete_Brown sure it just imports the DWM api #WPF #fb",
  "id" : 19879204844,
  "in_reply_to_status_id" : 19750399926,
  "created_at" : "2010-07-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "Pete_Brown",
  "in_reply_to_user_id_str" : "5718162",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft Channel 9",
      "screen_name" : "ch9",
      "indices" : [ 3, 7 ],
      "id_str" : "9460682",
      "id" : 9460682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 56, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19855859106",
  "text" : "RT @ch9 Introduction to Project Hilo http:\/\/ch9.ms\/C2DG #fb",
  "id" : 19855859106,
  "created_at" : "2010-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 38, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19705313013",
  "text" : "Perceptive Pixel http:\/\/bit.ly\/dxH8dX #fb",
  "id" : 19705313013,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HarryB",
      "screen_name" : "HarryBurls",
      "indices" : [ 3, 14 ],
      "id_str" : "67604958",
      "id" : 67604958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 111, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19747778773",
  "text" : "RT @HarryBurls: Make believe your mistakes are only a five second blip, an anomaly that is totally unlike you. #fb",
  "id" : 19747778773,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vaidhya Nathan",
      "screen_name" : "Vaidhyanathan",
      "indices" : [ 3, 17 ],
      "id_str" : "27284242",
      "id" : 27284242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 72, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19747910761",
  "text" : "RT @Vaidhyanathan: Boeing profits slump by a fifth http:\/\/bit.ly\/bx6irn #fb",
  "id" : 19747910761,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WPF",
      "indices" : [ 27, 31 ]
    }, {
      "text" : "fb",
      "indices" : [ 32, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19750260046",
  "text" : "polishing up a DWM wrapper #WPF #fb",
  "id" : 19750260046,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "techdirt",
      "screen_name" : "techdirt",
      "indices" : [ 3, 12 ],
      "id_str" : "11382292",
      "id" : 11382292
    }, {
      "name" : "BackType",
      "screen_name" : "BackType",
      "indices" : [ 92, 101 ],
      "id_str" : "15087414",
      "id" : 15087414
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 103, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19751986108",
  "text" : "RT @Techdirt Forget Vinyl, Now Cassette Tapes Are Making A Comeback? http:\/\/bt.io\/FiKg (via @backtype) #fb",
  "id" : 19751986108,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 114, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19755225795",
  "text" : "RT @TechCrunch As Mobile Advertising Heats Up, Millennial Media Prepares For An IPO In 2011 http:\/\/tcrn.ch\/9j3NEm #fb",
  "id" : 19755225795,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 32, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19776009535",
  "text" : "Nano tech http:\/\/bit.ly\/aoxYGv  #fb",
  "id" : 19776009535,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 66, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19776779701",
  "text" : "HOUSE Second Solar Spaceship Design for Kids http:\/\/bit.ly\/8ex63W #fb",
  "id" : 19776779701,
  "created_at" : "2010-07-28 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 96, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19653065244",
  "text" : "Chrome Canary Build Provides Bleeding-Edge Updates Alongside Stable Chrome http:\/\/bit.ly\/9pasGn #fb",
  "id" : 19653065244,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "j",
      "screen_name" : "jafonso",
      "indices" : [ 3, 11 ],
      "id_str" : "14511863",
      "id" : 14511863
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 62, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19663864065",
  "text" : "RT @jafonso: .NET Links of the Week #29 http:\/\/bit.ly\/8XsKds  #fb",
  "id" : 19663864065,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 89, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19666171934",
  "text" : "Toshiba Smart Pad tablet prototype shown; due before October 2010 - http:\/\/bit.ly\/bccd1N #fb",
  "id" : 19666171934,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew",
      "screen_name" : "mcb3k",
      "indices" : [ 0, 6 ],
      "id_str" : "17745140",
      "id" : 17745140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18085169526",
  "geo" : { },
  "id_str" : "19666745200",
  "in_reply_to_user_id" : 17745140,
  "text" : "@mcb3k  when are you coming back to college?",
  "id" : 19666745200,
  "in_reply_to_status_id" : 18085169526,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mcb3k",
  "in_reply_to_user_id_str" : "17745140",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 70, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19667680417",
  "text" : "UVa-Wise  Amoung the great colleges to work for http:\/\/bit.ly\/c8uRbp  #fb",
  "id" : 19667680417,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 65, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19668331097",
  "text" : "UVa-Wise among \u2018Great Colleges to Work For\u2019 http:\/\/bit.ly\/c8uRbp #fb",
  "id" : 19668331097,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "indices" : [ 3, 10 ],
      "id_str" : "428333",
      "id" : 428333
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 115, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19669066425",
  "text" : "RT @cnnbrk: Outgoing BP executive Tony Hayward blames \"many companies\" for Gulf disaster. http:\/\/on.cnn.com\/cxLDv3 #fb",
  "id" : 19669066425,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Ogletree",
      "screen_name" : "ogletree",
      "indices" : [ 3, 12 ],
      "id_str" : "3592961",
      "id" : 3592961
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 122, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19670885713",
  "text" : "RT @ogletree: Apple Mac Pro line overhauled with 12 processing cores, arriving in August for $4,999 http:\/\/bit.ly\/aq4CvH  #fb",
  "id" : 19670885713,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Hanes",
      "screen_name" : "mikehanes",
      "indices" : [ 3, 13 ],
      "id_str" : "17187418",
      "id" : 17187418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19677235661",
  "text" : "RT @mikehanes: Sprint HTC EVO truncated my Outlook data - bought my EVO Jun 4 and synced it with Outlook - it appeared to work just... h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "19676988145",
    "text" : "Sprint HTC EVO truncated my Outlook data - bought my EVO Jun 4 and synced it with Outlook - it appeared to work just... http:\/\/dld.bz\/kHpb",
    "id" : 19676988145,
    "created_at" : "2010-07-27 18:28:14 +0000",
    "user" : {
      "name" : "Mike Hanes",
      "screen_name" : "mikehanes",
      "protected" : false,
      "id_str" : "17187418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/116452144\/Me__Taken_by_Natasha__Mar29_2009_048_normal.jpg",
      "id" : 17187418,
      "verified" : false
    }
  },
  "id" : 19677235661,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19677320522",
  "text" : "\"Sprint HTC EVO truncated my Outlook data bought my EVO Jun 4 and synced it with Outlook it appeared to work just... http:\/\/dld.bz\/kHpb\" #fb",
  "id" : 19677320522,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19681545036",
  "text" : "http:\/\/bit.ly\/9XeZEz",
  "id" : 19681545036,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 21, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19681569836",
  "text" : "http:\/\/bit.ly\/9XeZEz #fb",
  "id" : 19681569836,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 44, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19682663944",
  "text" : "notepad++ open source! http:\/\/bit.ly\/b4ziMR #fb",
  "id" : 19682663944,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 47, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19684030695",
  "text" : "SharpClaw http:\/\/bit.ly\/cN5v3I  has promise :) #fb",
  "id" : 19684030695,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 36, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19684268082",
  "text" : "MSDN MAG 7\/10 http:\/\/bit.ly\/aqPuIJ  #fb",
  "id" : 19684268082,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 21, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19688284026",
  "text" : "http:\/\/bit.ly\/ahQgtA #fb",
  "id" : 19688284026,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 22, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19688942841",
  "text" : "http:\/\/bit.ly\/bj6KZ4  #fb",
  "id" : 19688942841,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 21, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19689347131",
  "text" : "http:\/\/bit.ly\/9MRlZL #fb",
  "id" : 19689347131,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 34, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19694545182",
  "text" : "2020 Science http:\/\/bit.ly\/bgRjXW #fb",
  "id" : 19694545182,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 21, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19473225631",
  "text" : "http:\/\/bit.ly\/3zomjX #fb",
  "id" : 19473225631,
  "created_at" : "2010-07-25 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BP America",
      "screen_name" : "BP_America",
      "indices" : [ 3, 14 ],
      "id_str" : "15829003",
      "id" : 15829003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18552552272",
  "text" : "RT @BP_America: We took advantage of last 24 hr period to closely review the seismic reports & they currently show no problems. -Kent Wells",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "18552306530",
    "text" : "We took advantage of last 24 hr period to closely review the seismic reports & they currently show no problems. -Kent Wells",
    "id" : 18552306530,
    "created_at" : "2010-07-14 22:13:40 +0000",
    "user" : {
      "name" : "BP America",
      "screen_name" : "BP_America",
      "protected" : false,
      "id_str" : "15829003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459036597954949120\/SYikO_g-_normal.png",
      "id" : 15829003,
      "verified" : true
    }
  },
  "id" : 18552552272,
  "created_at" : "2010-07-14 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 37, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17827075241",
  "text" : "Fight Diabetes http:\/\/bit.ly\/aMbbGv  #fb",
  "id" : 17827075241,
  "created_at" : "2010-07-06 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]