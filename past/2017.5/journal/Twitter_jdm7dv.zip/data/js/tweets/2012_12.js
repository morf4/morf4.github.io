Grailbird.data.tweets_2012_12 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 66 ],
      "url" : "http:\/\/t.co\/DOdoUHG",
      "expanded_url" : "http:\/\/www.ishani.org\/web\/articles\/code\/clangvsx\/#.UNW9oKkCR_l.twitter",
      "display_url" : "ishani.org\/web\/articles\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "282486662053896193",
  "text" : "Clang in Visual Studio Mery Cristmas. ClangVSx http:\/\/t.co\/DOdoUHG",
  "id" : 282486662053896193,
  "created_at" : "2012-12-22 14:04:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 59 ],
      "url" : "http:\/\/t.co\/EVetPRr",
      "expanded_url" : "http:\/\/www.reactos.org\/en\/index.html",
      "display_url" : "reactos.org\/en\/index.html"
    } ]
  },
  "geo" : { },
  "id_str" : "277726787813912576",
  "text" : "Please Donate to the ReactOS Project :) http:\/\/t.co\/EVetPRr",
  "id" : 277726787813912576,
  "created_at" : "2012-12-09 10:50:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]