Grailbird.data.tweets_2010_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22203491047",
  "text" : "should be getting my Alcor bracelet by the end of the year.",
  "id" : 22203491047,
  "created_at" : "2010-08-26 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ReadWrite",
      "screen_name" : "RWW",
      "indices" : [ 3, 7 ],
      "id_str" : "4641021",
      "id" : 4641021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 97, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21627603986",
  "text" : "RT @rww Did Mark Zuckerberg's Inspiration for Facebook Come Before Harvard? http:\/\/rww.tw\/19svuX #fb",
  "id" : 21627603986,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 50, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21535157117",
  "text" : "is moving back to TFS. Git is not my cup of tea.  #fb",
  "id" : 21535157117,
  "created_at" : "2010-08-19 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nasa",
      "indices" : [ 27, 32 ]
    }, {
      "text" : "fb",
      "indices" : [ 33, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21447216829",
  "text" : "http:\/\/7dv.me\/cP8OcI nasa  #nasa #fb",
  "id" : 21447216829,
  "created_at" : "2010-08-18 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddToAny",
      "screen_name" : "AddToAny",
      "indices" : [ 64, 73 ],
      "id_str" : "21849140",
      "id" : 21849140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 74, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20502099065",
  "text" : "in skeptical defense of transhumanism\u2026 http:\/\/bit.ly\/atJ98a via @AddToAny #fb",
  "id" : 20502099065,
  "created_at" : "2010-08-06 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pichuka",
      "screen_name" : "pichuka",
      "indices" : [ 3, 11 ],
      "id_str" : "14393861",
      "id" : 14393861
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 88, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20319268206",
  "text" : "RT @pichuka Over-communication is as bad as poor communcation http:\/\/amplify.com\/u\/1ih7 #fb",
  "id" : 20319268206,
  "created_at" : "2010-08-04 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft Channel 9",
      "screen_name" : "ch9",
      "indices" : [ 3, 7 ],
      "id_str" : "9460682",
      "id" : 9460682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 90, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20242958900",
  "text" : "RT @ch9 BTC: David Heckerman - Biology, Machines, Medicine and Physics http:\/\/ch9.ms\/C0AE #fb",
  "id" : 20242958900,
  "created_at" : "2010-08-03 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]