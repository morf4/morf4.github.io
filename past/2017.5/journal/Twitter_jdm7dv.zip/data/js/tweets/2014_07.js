Grailbird.data.tweets_2014_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "indices" : [ 3, 17 ],
      "id_str" : "34554134",
      "id" : 34554134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/4yxg7xCw0O",
      "expanded_url" : "http:\/\/buff.ly\/1oE5on0",
      "display_url" : "buff.ly\/1oE5on0"
    } ]
  },
  "geo" : { },
  "id_str" : "487388044392030208",
  "text" : "RT @SETIInstitute: Where did the water on Mars come from &amp; where did it go? A new map shows something unexpected: http:\/\/t.co\/4yxg7xCw0O ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SETIInstitute\/status\/487355884247719938\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/a58AEQIgqt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsNvmCJIcAA-PbC.jpg",
        "id_str" : "487355883887030272",
        "id" : 487355883887030272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsNvmCJIcAA-PbC.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 266,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 580
        } ],
        "display_url" : "pic.twitter.com\/a58AEQIgqt"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/4yxg7xCw0O",
        "expanded_url" : "http:\/\/buff.ly\/1oE5on0",
        "display_url" : "buff.ly\/1oE5on0"
      } ]
    },
    "geo" : { },
    "id_str" : "487355884247719938",
    "text" : "Where did the water on Mars come from &amp; where did it go? A new map shows something unexpected: http:\/\/t.co\/4yxg7xCw0O http:\/\/t.co\/a58AEQIgqt",
    "id" : 487355884247719938,
    "created_at" : "2014-07-10 22:01:12 +0000",
    "user" : {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "protected" : false,
      "id_str" : "34554134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758705567556743168\/TGjZ9Uwf_normal.jpg",
      "id" : 34554134,
      "verified" : true
    }
  },
  "id" : 487388044392030208,
  "created_at" : "2014-07-11 00:09:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487297866721796096",
  "text" : "Just renewed my memberships to the gifted associations.",
  "id" : 487297866721796096,
  "created_at" : "2014-07-10 18:10:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ECCS 2014",
      "screen_name" : "eccs14",
      "indices" : [ 0, 7 ],
      "id_str" : "2348642744",
      "id" : 2348642744
    }, {
      "name" : "Human Brain Project",
      "screen_name" : "HumanBrainProj",
      "indices" : [ 8, 23 ],
      "id_str" : "1112553272",
      "id" : 1112553272
    }, {
      "name" : "Pepe Fernandez",
      "screen_name" : "PepeBruselas",
      "indices" : [ 24, 37 ],
      "id_str" : "360537923",
      "id" : 360537923
    }, {
      "name" : "Guido Caldarelli \u8D35\u591A",
      "screen_name" : "GuidoCaldarelli",
      "indices" : [ 38, 54 ],
      "id_str" : "304928205",
      "id" : 304928205
    }, {
      "name" : "FET Flagships",
      "screen_name" : "FETFlagships",
      "indices" : [ 55, 68 ],
      "id_str" : "397117331",
      "id" : 397117331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484295423851769856",
  "geo" : { },
  "id_str" : "485337683577679872",
  "in_reply_to_user_id" : 2348642744,
  "text" : "@eccs14 @HumanBrainProj @PepeBruselas @GuidoCaldarelli @FETFlagships",
  "id" : 485337683577679872,
  "in_reply_to_status_id" : 484295423851769856,
  "created_at" : "2014-07-05 08:21:35 +0000",
  "in_reply_to_screen_name" : "eccs14",
  "in_reply_to_user_id_str" : "2348642744",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Die Mannschaft",
      "screen_name" : "DFB_Team",
      "indices" : [ 3, 12 ],
      "id_str" : "78270570",
      "id" : 78270570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldCup",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/GscLJzOQJ9",
      "expanded_url" : "https:\/\/twitter.com\/i\/t\/worldcup",
      "display_url" : "twitter.com\/i\/t\/worldcup"
    } ]
  },
  "geo" : { },
  "id_str" : "484904516949516288",
  "text" : "Go @DFB_TEAM! #WorldCup Who are you supporting? https:\/\/t.co\/GscLJzOQJ9",
  "id" : 484904516949516288,
  "created_at" : "2014-07-04 03:40:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]