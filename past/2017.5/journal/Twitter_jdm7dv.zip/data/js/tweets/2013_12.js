Grailbird.data.tweets_2013_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Ligman",
      "screen_name" : "EricLigman",
      "indices" : [ 0, 11 ],
      "id_str" : "22529317",
      "id" : 22529317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416159822120095744",
  "in_reply_to_user_id" : 22529317,
  "text" : "@EricLigman I need additional information about open licences please.",
  "id" : 416159822120095744,
  "created_at" : "2013-12-26 10:53:28 +0000",
  "in_reply_to_screen_name" : "EricLigman",
  "in_reply_to_user_id_str" : "22529317",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/U89kpjb24t",
      "expanded_url" : "http:\/\/www.medicalnewstoday.com\/articles\/270100.php",
      "display_url" : "medicalnewstoday.com\/articles\/27010\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412845306015801344",
  "text" : "nanoparticles to cure cancer http:\/\/t.co\/U89kpjb24t",
  "id" : 412845306015801344,
  "created_at" : "2013-12-17 07:22:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/uX6PIU171X",
      "expanded_url" : "http:\/\/www.medicalnewstoday.com\/articles\/270100.php#.Uq_7Yvknc68.twitter",
      "display_url" : "medicalnewstoday.com\/articles\/27010\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412844975412346880",
  "text" : "Magnetic nanoparticles to cure cancer - Medical News Today: http:\/\/t.co\/uX6PIU171X",
  "id" : 412844975412346880,
  "created_at" : "2013-12-17 07:21:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Live in the Now",
      "screen_name" : "Live_inthe_Now",
      "indices" : [ 79, 94 ],
      "id_str" : "26314247",
      "id" : 26314247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/atJMwKLh8Y",
      "expanded_url" : "http:\/\/www.liveinthenow.com\/article\/b-vitamins-may-help-ward-off-this-aggressive-cancer",
      "display_url" : "liveinthenow.com\/article\/b-vita\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412700282863095809",
  "text" : "B Vitamins May Help Ward Off This Aggressive Cancer http:\/\/t.co\/atJMwKLh8Y via @Live_inthe_Now",
  "id" : 412700282863095809,
  "created_at" : "2013-12-16 21:46:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 98, 107 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/peMfGO3txn",
      "expanded_url" : "http:\/\/gu.com\/p\/2ydje\/tw",
      "display_url" : "gu.com\/p\/2ydje\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "412342311893217280",
  "text" : "Harvard scientists reverse the ageing process in mice \u2013 now for humans http:\/\/t.co\/peMfGO3txn via @guardian",
  "id" : 412342311893217280,
  "created_at" : "2013-12-15 22:04:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Bvt3fUPX42",
      "expanded_url" : "http:\/\/reviews.cnet.com\/windows\/microsoft-windows-server-for\/4505-3672_7-32877603.html",
      "display_url" : "reviews.cnet.com\/windows\/micros\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412321609026781184",
  "text" : "http:\/\/t.co\/Bvt3fUPX42 Open license Software assurance",
  "id" : 412321609026781184,
  "created_at" : "2013-12-15 20:41:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]