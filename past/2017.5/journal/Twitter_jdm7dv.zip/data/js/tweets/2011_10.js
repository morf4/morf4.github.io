Grailbird.data.tweets_2011_10 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jdm7dv",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/MwJoRWLF",
      "expanded_url" : "http:\/\/bit.ly\/bpr1A3",
      "display_url" : "bit.ly\/bpr1A3"
    } ]
  },
  "geo" : { },
  "id_str" : "125718021711998976",
  "text" : "http:\/\/t.co\/MwJoRWLF Gliese 581g Most Earth like planet ever found #jdm7dv",
  "id" : 125718021711998976,
  "created_at" : "2011-10-16 23:41:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]