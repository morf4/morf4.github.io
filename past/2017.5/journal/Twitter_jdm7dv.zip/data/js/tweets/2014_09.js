Grailbird.data.tweets_2014_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/X2pJQJdkL0",
      "expanded_url" : "http:\/\/www.amazon.com\/Up-to-Speed\/dp\/B00NN3IYDG",
      "display_url" : "amazon.com\/Up-to-Speed\/dp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514136682372005888",
  "text" : "Up to Speed? on sale now. http:\/\/t.co\/X2pJQJdkL0",
  "id" : 514136682372005888,
  "created_at" : "2014-09-22 19:38:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Axl Rose",
      "screen_name" : "axlrose",
      "indices" : [ 0, 8 ],
      "id_str" : "95956928",
      "id" : 95956928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513045816630845441",
  "in_reply_to_user_id" : 95956928,
  "text" : "@axlrose Hi Axl, looking forward to the new albums.",
  "id" : 513045816630845441,
  "created_at" : "2014-09-19 19:23:49 +0000",
  "in_reply_to_screen_name" : "axlrose",
  "in_reply_to_user_id_str" : "95956928",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]