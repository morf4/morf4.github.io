Grailbird.data.tweets_2014_08 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MoveOn.org",
      "screen_name" : "MoveOn",
      "indices" : [ 66, 73 ],
      "id_str" : "26657119",
      "id" : 26657119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/7RWbe3zbKS",
      "expanded_url" : "http:\/\/petitions.moveon.org\/s\/SMf_Q0",
      "display_url" : "petitions.moveon.org\/s\/SMf_Q0"
    } ]
  },
  "geo" : { },
  "id_str" : "496708469622198272",
  "text" : "Remove economics courses from universities http:\/\/t.co\/7RWbe3zbKS @moveon",
  "id" : 496708469622198272,
  "created_at" : "2014-08-05 17:25:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]