Grailbird.data.tweets_2010_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hands Across Sand",
      "screen_name" : "HandsAcrossSand",
      "indices" : [ 80, 96 ],
      "id_str" : "98924487",
      "id" : 98924487
    }, {
      "name" : "CNN iReport",
      "screen_name" : "cnnireport",
      "indices" : [ 129, 140 ],
      "id_str" : "9411482",
      "id" : 9411482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17284379091",
  "text" : "\"Gulf Journals:  Joining hands on pristine beaches of Seaside, Florida, another @HandsAcrossSand: http:\/\/on.cnn.com\/cspOTw\" \/via @cnnireport",
  "id" : 17284379091,
  "created_at" : "2010-06-28 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve",
      "screen_name" : "ceoSteveJobs",
      "indices" : [ 3, 16 ],
      "id_str" : "259829550",
      "id" : 259829550
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 118, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17008447806",
  "text" : "RT @ceoSteveJobs: I heard the CEO of AT&T got married recently. The service was great but the reception was terrible. #fb",
  "id" : 17008447806,
  "created_at" : "2010-06-25 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16624629768",
  "text" : "happy fathers day :)",
  "id" : 16624629768,
  "created_at" : "2010-06-20 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".toolbox",
      "screen_name" : "designtoolbox",
      "indices" : [ 28, 42 ],
      "id_str" : "106833956",
      "id" : 106833956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16049964969",
  "text" : "I'm a Principles Starter in @designtoolbox! Race me to the head of the class! http:\/\/www.microsoft.com\/design\/p\/?bUHFYcpcmEuWTQPc3bO0ZQ",
  "id" : 16049964969,
  "created_at" : "2010-06-13 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".toolbox",
      "screen_name" : "designtoolbox",
      "indices" : [ 26, 40 ],
      "id_str" : "106833956",
      "id" : 106833956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16010296553",
  "text" : "I'm a Scenarios Player in @designtoolbox! Race me to the head of the class! http:\/\/www.microsoft.com\/design\/p\/?bUHFYcpcmEuWTQPc3bO0ZQ",
  "id" : 16010296553,
  "created_at" : "2010-06-12 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".toolbox",
      "screen_name" : "designtoolbox",
      "indices" : [ 26, 40 ],
      "id_str" : "106833956",
      "id" : 106833956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15951762530",
  "text" : "I'm a Scenarios Rookie in @designtoolbox! Race me to the head of the class! http:\/\/www.microsoft.com\/design\/p\/?bUHFYcpcmEuWTQPc3bO0ZQ",
  "id" : 15951762530,
  "created_at" : "2010-06-11 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Silverlight News",
      "screen_name" : "SilverlightNews",
      "indices" : [ 81, 97 ],
      "id_str" : "12088282",
      "id" : 12088282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 98, 101 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15561212466",
  "geo" : { },
  "id_str" : "15561865785",
  "in_reply_to_user_id" : 12088282,
  "text" : "\"Windows Phone 7: Lists, Page Animation and oData - http:\/\/snurl.com\/x5nml\" \/via @SilverlightNews #fb",
  "id" : 15561865785,
  "in_reply_to_status_id" : 15561212466,
  "created_at" : "2010-06-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "SilverlightNews",
  "in_reply_to_user_id_str" : "12088282",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Downey",
      "screen_name" : "mdowney",
      "indices" : [ 97, 105 ],
      "id_str" : "72343",
      "id" : 72343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 106, 109 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15352607969",
  "geo" : { },
  "id_str" : "15356342883",
  "in_reply_to_user_id" : 72343,
  "text" : "\"is there any way to pull an RSS feed from your own Facebook stream (your own posts only)?\" \/via @mdowney #fb",
  "id" : 15356342883,
  "in_reply_to_status_id" : 15352607969,
  "created_at" : "2010-06-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "mdowney",
  "in_reply_to_user_id_str" : "72343",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]