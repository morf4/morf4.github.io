Grailbird.data.tweets_2011_02 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 109, 113 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http:\/\/t.co\/Cy5VFRs",
      "expanded_url" : "http:\/\/news.blogs.cnn.com\/2011\/02\/21\/live-blogging-north-africa-middle-east-protests\/",
      "display_url" : "news.blogs.cnn.com\/2011\/02\/21\/liv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "39856101621104641",
  "text" : "N. Africa, Mideast protests \u2013 Gadhafi: I'm still here \u2013 This Just In - CNN.com Blogs http:\/\/t.co\/Cy5VFRs via @cnn",
  "id" : 39856101621104641,
  "created_at" : "2011-02-22 01:16:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CREDO Mobile",
      "screen_name" : "CREDOMobile",
      "indices" : [ 97, 109 ],
      "id_str" : "14630443",
      "id" : 14630443
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "p2",
      "indices" : [ 110, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36449303325048832",
  "text" : "Tell Congress: Don't pull the plug on NPR and PBS. Defend public media! http:\/\/bit.ly\/eQ0u9z via @CREDOMobile #p2",
  "id" : 36449303325048832,
  "created_at" : "2011-02-12 15:39:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34114083657621506",
  "text" : "http:\/\/www.youtube.com\/watch?v=zORv8wwiadQ",
  "id" : 34114083657621506,
  "created_at" : "2011-02-06 05:00:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33725314211393536",
  "text" : "http:\/\/7dv.me\/i3jbMm Reflector",
  "id" : 33725314211393536,
  "created_at" : "2011-02-05 03:15:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 101, 109 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http:\/\/t.co\/p3qJxST",
      "expanded_url" : "http:\/\/bigthink.com\/ideas\/17836",
      "display_url" : "bigthink.com\/ideas\/17836"
    } ]
  },
  "geo" : { },
  "id_str" : "33422174769381377",
  "text" : "Onion Editor Shares Expertise on What\u2019s Not Funny | Joe Randazzo | Big Think http:\/\/t.co\/p3qJxST via @AddThis",
  "id" : 33422174769381377,
  "created_at" : "2011-02-04 07:10:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Think",
      "screen_name" : "bigthink",
      "indices" : [ 24, 33 ],
      "id_str" : "18567018",
      "id" : 18567018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/zVvQal7",
      "expanded_url" : "http:\/\/bigthink.com\/ideas\/26593",
      "display_url" : "bigthink.com\/ideas\/26593"
    } ]
  },
  "geo" : { },
  "id_str" : "33419936126738432",
  "text" : "http:\/\/t.co\/zVvQal7 via @bigthink",
  "id" : 33419936126738432,
  "created_at" : "2011-02-04 07:01:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33418876536627200",
  "text" : "better day already :)",
  "id" : 33418876536627200,
  "created_at" : "2011-02-04 06:57:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]