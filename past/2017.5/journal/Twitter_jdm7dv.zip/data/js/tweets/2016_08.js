Grailbird.data.tweets_2016_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/770957647306776582\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/7orusZvA3F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrL95OQW8AE-A72.jpg",
      "id_str" : "770957645754855425",
      "id" : 770957645754855425,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrL95OQW8AE-A72.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/7orusZvA3F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770957647306776582",
  "text" : "https:\/\/t.co\/7orusZvA3F",
  "id" : 770957647306776582,
  "created_at" : "2016-08-31 12:13:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/770728678569443329\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/fhNw2XMUyA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrItpbSWYAARrSZ.jpg",
      "id_str" : "770728675956383744",
      "id" : 770728675956383744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrItpbSWYAARrSZ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/fhNw2XMUyA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770728678569443329",
  "text" : "https:\/\/t.co\/fhNw2XMUyA",
  "id" : 770728678569443329,
  "created_at" : "2016-08-30 21:03:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/q5uuT0dpK7",
      "expanded_url" : "https:\/\/youtu.be\/5R682M3ZEyk",
      "display_url" : "youtu.be\/5R682M3ZEyk"
    } ]
  },
  "geo" : { },
  "id_str" : "770680548293484544",
  "text" : "Marilyn Manson - The Dope Show https:\/\/t.co\/q5uuT0dpK7 via @YouTube leave followers",
  "id" : 770680548293484544,
  "created_at" : "2016-08-30 17:52:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 0, 12 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/N6YZIU6TwA",
      "expanded_url" : "http:\/\/goo.gl\/1wLg0T",
      "display_url" : "goo.gl\/1wLg0T"
    } ]
  },
  "geo" : { },
  "id_str" : "770675243128086528",
  "in_reply_to_user_id" : 813286,
  "text" : "@BarackObama https:\/\/t.co\/N6YZIU6TwA The drug could help you live to be 120. Plus there is Basis. I've known since 2015.",
  "id" : 770675243128086528,
  "created_at" : "2016-08-30 17:31:11 +0000",
  "in_reply_to_screen_name" : "BarackObama",
  "in_reply_to_user_id_str" : "813286",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/770626358401794048\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/9FAiezWnUg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrHQlpLWAAABL8P.jpg",
      "id_str" : "770626356384235520",
      "id" : 770626356384235520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrHQlpLWAAABL8P.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/9FAiezWnUg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770626358401794048",
  "text" : "https:\/\/t.co\/9FAiezWnUg",
  "id" : 770626358401794048,
  "created_at" : "2016-08-30 14:16:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 0, 6 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770406807554621440",
  "in_reply_to_user_id" : 1536791610,
  "text" : "@POTUS Thank You for the letter. My family has endured. This area does just want me to go to jail over possessions freedom of speech and inc",
  "id" : 770406807554621440,
  "created_at" : "2016-08-29 23:44:31 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/4wqFEE8n2K",
      "expanded_url" : "http:\/\/www.foxnews.com\/health\/2015\/12\/02\/new-anti-aging-drug-could-extend-human-life-span-to-120-years.html",
      "display_url" : "foxnews.com\/health\/2015\/12\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770065740376449025",
  "text" : "https:\/\/t.co\/4wqFEE8n2K Live to be 120.",
  "id" : 770065740376449025,
  "created_at" : "2016-08-29 01:09:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Fsc9q7K4Sg",
      "expanded_url" : "http:\/\/www.californiaearinstitute.com\/ear-disorders-microtia-bay-area.php",
      "display_url" : "californiaearinstitute.com\/ear-disorders-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770064473151434752",
  "text" : "https:\/\/t.co\/Fsc9q7K4Sg Come at my back teeth I will come at their small ear disorders.",
  "id" : 770064473151434752,
  "created_at" : "2016-08-29 01:04:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 76, 84 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/a6rEdWuVCZ",
      "expanded_url" : "https:\/\/youtu.be\/UhC7M8KF7AE",
      "display_url" : "youtu.be\/UhC7M8KF7AE"
    } ]
  },
  "geo" : { },
  "id_str" : "770060528031064065",
  "text" : "The All-American Rejects - Beekeeper's Daughter https:\/\/t.co\/a6rEdWuVCZ via @YouTube",
  "id" : 770060528031064065,
  "created_at" : "2016-08-29 00:48:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huffington Post Blog",
      "screen_name" : "HuffPostBlog",
      "indices" : [ 54, 67 ],
      "id_str" : "131500972",
      "id" : 131500972
    }, {
      "name" : "HuffPost Politics",
      "screen_name" : "HuffPostPol",
      "indices" : [ 96, 108 ],
      "id_str" : "15458694",
      "id" : 15458694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/ZebBqyx6b2",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/kwame-rose\/defeating-trump-doesnt-eliminate-the-evil-of-clinton_b_10665344.html",
      "display_url" : "huffingtonpost.com\/kwame-rose\/def\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770059307924746245",
  "text" : "Defeating Trump doesn't eliminate the evil of Clinton @HuffPostBlog https:\/\/t.co\/ZebBqyx6b2 via @HuffPostPol",
  "id" : 770059307924746245,
  "created_at" : "2016-08-29 00:43:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 52, 60 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/4PBeImTcxI",
      "expanded_url" : "https:\/\/youtu.be\/JVZfoFn7UiY",
      "display_url" : "youtu.be\/JVZfoFn7UiY"
    } ]
  },
  "geo" : { },
  "id_str" : "770058577511841792",
  "text" : "It's an Evil Evil World https:\/\/t.co\/4PBeImTcxI via @YouTube",
  "id" : 770058577511841792,
  "created_at" : "2016-08-29 00:40:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770053118377750528",
  "text" : "This area is just trying to set me off too So I'll go to jail. NO! I don't like America anymore.",
  "id" : 770053118377750528,
  "created_at" : "2016-08-29 00:19:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/inJMY1YvwC",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pubmed\/3493534",
      "display_url" : "ncbi.nlm.nih.gov\/pubmed\/3493534"
    } ]
  },
  "geo" : { },
  "id_str" : "770048700962004992",
  "text" : "https:\/\/t.co\/inJMY1YvwC Competition is a disease.",
  "id" : 770048700962004992,
  "created_at" : "2016-08-29 00:01:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769975390349750277",
  "text" : "You can probably have a company email address if you set up Exchange or Mailman. I did have a Microsoft email once.I would want a Stienberg.",
  "id" : 769975390349750277,
  "created_at" : "2016-08-28 19:10:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769972703025586176",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne Who's Chad Kroeger to me did he even go to college?",
  "id" : 769972703025586176,
  "created_at" : "2016-08-28 18:59:32 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769971392657907717",
  "text" : "I do have a BMI account. I can register the works myself.",
  "id" : 769971392657907717,
  "created_at" : "2016-08-28 18:54:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769970835369132033",
  "text" : "Should I really have a CD distribution release? I might call CDBaby and see if the plastic is recycled.",
  "id" : 769970835369132033,
  "created_at" : "2016-08-28 18:52:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/xjUV3Gkbea",
      "expanded_url" : "http:\/\/www.scientificamerican.com\/article\/how-coal-kills\/",
      "display_url" : "scientificamerican.com\/article\/how-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769968312017121282",
  "text" : "https:\/\/t.co\/xjUV3Gkbea Coal Kills. I'm done with Trump and Hillary.",
  "id" : 769968312017121282,
  "created_at" : "2016-08-28 18:42:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/uONhz7cwAz",
      "expanded_url" : "http:\/\/jdm7dv.github.io\/",
      "display_url" : "jdm7dv.github.io"
    } ]
  },
  "geo" : { },
  "id_str" : "769961480192155652",
  "text" : "https:\/\/t.co\/uONhz7cwAz It's still up.",
  "id" : 769961480192155652,
  "created_at" : "2016-08-28 18:14:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/9po8QPxsva",
      "expanded_url" : "https:\/\/twitter.com\/KirkDBorne\/status\/765333384122003456",
      "display_url" : "twitter.com\/KirkDBorne\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769959473213505540",
  "text" : "Learned about this when I made and ENCODE Mirror. https:\/\/t.co\/9po8QPxsva",
  "id" : 769959473213505540,
  "created_at" : "2016-08-28 18:06:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/VpOoNOCtli",
      "expanded_url" : "http:\/\/feelincontrol.org\/wp-content\/uploads\/2012\/12\/How-do-you-fund-a-living-trust.pdf",
      "display_url" : "feelincontrol.org\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769957038210375680",
  "text" : "https:\/\/t.co\/VpOoNOCtli You can \"fund\" a trust but the assets aren't liquid.",
  "id" : 769957038210375680,
  "created_at" : "2016-08-28 17:57:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769953550797602816",
  "text" : "Are dead souls calling for you are you age? Take a basis.",
  "id" : 769953550797602816,
  "created_at" : "2016-08-28 17:43:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/WzCi3D6uIs",
      "expanded_url" : "http:\/\/smallbusiness.chron.com\/shareholder-distribution-vs-payroll-59898.html",
      "display_url" : "smallbusiness.chron.com\/shareholder-di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769952666000711680",
  "text" : "https:\/\/t.co\/WzCi3D6uIs Shareholder distribution vs payroll.",
  "id" : 769952666000711680,
  "created_at" : "2016-08-28 17:39:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/0NWvfcbeLK",
      "expanded_url" : "http:\/\/www.faolaw.com\/articles\/fao_eps7.htm",
      "display_url" : "faolaw.com\/articles\/fao_e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769952317932208128",
  "text" : "https:\/\/t.co\/0NWvfcbeLK Estate planning strategies.",
  "id" : 769952317932208128,
  "created_at" : "2016-08-28 17:38:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769951557173542912",
  "text" : "Are you a 'God' wearing your mask? I'm not If you are you can start a company. If you develop a standard I'm not on you.",
  "id" : 769951557173542912,
  "created_at" : "2016-08-28 17:35:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769950150143909888",
  "text" : "These people will pay for there sins.",
  "id" : 769950150143909888,
  "created_at" : "2016-08-28 17:29:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Ks4tITStU7",
      "expanded_url" : "http:\/\/energyfanatics.com\/2014\/09\/19\/accessing-high-frequency-energy-using-your-pineal-gland\/",
      "display_url" : "energyfanatics.com\/2014\/09\/19\/acc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769949408381308928",
  "text" : "https:\/\/t.co\/Ks4tITStU7 Not sure yet.",
  "id" : 769949408381308928,
  "created_at" : "2016-08-28 17:26:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769947481933316097",
  "text" : "Beat straight A's in God's land. I'm done.",
  "id" : 769947481933316097,
  "created_at" : "2016-08-28 17:19:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769946172916133888",
  "text" : "Beat a 140 IQ SWVA. I'm done.",
  "id" : 769946172916133888,
  "created_at" : "2016-08-28 17:14:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/tPuAeFnis6",
      "expanded_url" : "https:\/\/www.fightaging.org\/archives\/2011\/04\/klotho-in-humans\/",
      "display_url" : "fightaging.org\/archives\/2011\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769945634275221504",
  "text" : "https:\/\/t.co\/tPuAeFnis6 Klotho is something you can never have. Found in Tuscany.",
  "id" : 769945634275221504,
  "created_at" : "2016-08-28 17:11:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/FW0k1q2psP",
      "expanded_url" : "https:\/\/www.psychologytoday.com\/blog\/paper-souls\/201503\/what-schizophrenia-teaches-us-about-perception",
      "display_url" : "psychologytoday.com\/blog\/paper-sou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769944106793590784",
  "text" : "What Schizophrenia Teaches Us About Perception | Psychology Today https:\/\/t.co\/FW0k1q2psP",
  "id" : 769944106793590784,
  "created_at" : "2016-08-28 17:05:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universe Today",
      "screen_name" : "universetoday",
      "indices" : [ 53, 67 ],
      "id_str" : "24129206",
      "id" : 24129206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/G6utdgFpne",
      "expanded_url" : "http:\/\/www.universetoday.com\/127086\/what-is-the-higgs-boson\/",
      "display_url" : "universetoday.com\/127086\/what-is\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769940711886229504",
  "text" : "What is the Higgs Boson? https:\/\/t.co\/G6utdgFpne via @universetoday",
  "id" : 769940711886229504,
  "created_at" : "2016-08-28 16:52:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 27, 34 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/svjSAb1UHI",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/stevenrosenbaum\/2014\/01\/28\/why-television-is-dead\/#7873f10f2b6d",
      "display_url" : "forbes.com\/sites\/stevenro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769932879975579648",
  "text" : "Why Television Is Dead via @forbes https:\/\/t.co\/svjSAb1UHI",
  "id" : 769932879975579648,
  "created_at" : "2016-08-28 16:21:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769692871339507712",
  "text" : "In America you will make the news one way or another., rape, fame, suicide.or murder.",
  "id" : 769692871339507712,
  "created_at" : "2016-08-28 00:27:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/IRtu2bG9Il",
      "expanded_url" : "http:\/\/www.albert-einstein.org\/article_handicap.html",
      "display_url" : "albert-einstein.org\/article_handic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769691794464440320",
  "text" : "https:\/\/t.co\/IRtu2bG9Il By today's standard's Einstein would've had schizophrenia",
  "id" : 769691794464440320,
  "created_at" : "2016-08-28 00:23:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 60, 68 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/YemSuQaqa7",
      "expanded_url" : "https:\/\/youtu.be\/dMrImMedYRo",
      "display_url" : "youtu.be\/dMrImMedYRo"
    } ]
  },
  "geo" : { },
  "id_str" : "769682329023422464",
  "text" : "The Who - Behind Blue Eyes (HQ) https:\/\/t.co\/YemSuQaqa7 via @YouTube",
  "id" : 769682329023422464,
  "created_at" : "2016-08-27 23:45:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769679894917808133",
  "text" : "Wanna fuck outside so everybody can 'watch' ladies like we did in high school? We can. I really don't like the smart watch.",
  "id" : 769679894917808133,
  "created_at" : "2016-08-27 23:36:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769678420347420672",
  "text" : "The media and other people will always want to know where you get off.",
  "id" : 769678420347420672,
  "created_at" : "2016-08-27 23:30:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Community Grid",
      "screen_name" : "WCGrid",
      "indices" : [ 3, 10 ],
      "id_str" : "26388412",
      "id" : 26388412
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cancer",
      "indices" : [ 41, 48 ]
    }, {
      "text" : "tuberculosis",
      "indices" : [ 50, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/pGeJxIQvPa",
      "expanded_url" : "http:\/\/www.worldcommunitygrid.org\/discover.action",
      "display_url" : "worldcommunitygrid.org\/discover.action"
    } ]
  },
  "geo" : { },
  "id_str" : "769605528951595009",
  "text" : "RT @WCGrid: Your computer can help fight #cancer, #tuberculosis, and other diseases. Join us! https:\/\/t.co\/pGeJxIQvPa https:\/\/t.co\/vXAHVD8Q\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WCGrid\/status\/769548838550077444\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/vXAHVD8Qdh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq0bbPXWAAEvyEK.jpg",
        "id_str" : "769301266145083393",
        "id" : 769301266145083393,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq0bbPXWAAEvyEK.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/vXAHVD8Qdh"
      } ],
      "hashtags" : [ {
        "text" : "cancer",
        "indices" : [ 29, 36 ]
      }, {
        "text" : "tuberculosis",
        "indices" : [ 38, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/pGeJxIQvPa",
        "expanded_url" : "http:\/\/www.worldcommunitygrid.org\/discover.action",
        "display_url" : "worldcommunitygrid.org\/discover.action"
      } ]
    },
    "geo" : { },
    "id_str" : "769548838550077444",
    "text" : "Your computer can help fight #cancer, #tuberculosis, and other diseases. Join us! https:\/\/t.co\/pGeJxIQvPa https:\/\/t.co\/vXAHVD8Qdh",
    "id" : 769548838550077444,
    "created_at" : "2016-08-27 14:55:15 +0000",
    "user" : {
      "name" : "World Community Grid",
      "screen_name" : "WCGrid",
      "protected" : false,
      "id_str" : "26388412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448919987281866752\/T4oA5jtc_normal.png",
      "id" : 26388412,
      "verified" : false
    }
  },
  "id" : 769605528951595009,
  "created_at" : "2016-08-27 18:40:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 88, 96 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/FGjoUAA8Fh",
      "expanded_url" : "https:\/\/youtu.be\/MZnO54HHshs",
      "display_url" : "youtu.be\/MZnO54HHshs"
    } ]
  },
  "geo" : { },
  "id_str" : "769566935428235265",
  "text" : "P. Diddy &amp; The Family - Victory (Nine Inch Nails remix) https:\/\/t.co\/FGjoUAA8Fh via @YouTube",
  "id" : 769566935428235265,
  "created_at" : "2016-08-27 16:07:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 100, 107 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/mO1heDbIUa",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/quora\/2016\/02\/17\/stanford-physics-prof-explains-why-gravitational-waves-are-among-mankinds-greatest-discoveries\/#6f6bd7c14144",
      "display_url" : "forbes.com\/sites\/quora\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769565573567156224",
  "text" : "Stanford Physics Prof Explains Why Gravitational Waves Are Among Mankind's Greatest Discoveries via @forbes https:\/\/t.co\/mO1heDbIUa",
  "id" : 769565573567156224,
  "created_at" : "2016-08-27 16:01:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/PAU1R7KuL0",
      "expanded_url" : "https:\/\/www.theguardian.com\/science\/2016\/feb\/11\/gravitational-waves-discovery-hailed-as-breakthrough-of-the-century?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/science\/2016\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769565320747024386",
  "text" : "Gravitational waves: breakthrough discovery after a century of expectation https:\/\/t.co\/PAU1R7KuL0",
  "id" : 769565320747024386,
  "created_at" : "2016-08-27 16:00:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/ASez81q176",
      "expanded_url" : "http:\/\/www.bbc.com\/news\/science-environment-24436781",
      "display_url" : "bbc.com\/news\/science-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769509276008185857",
  "text" : "BBC News - Higgs boson scientists win Nobel prize in physics https:\/\/t.co\/ASez81q176 And I helped with Atlas@home in 2011-present.",
  "id" : 769509276008185857,
  "created_at" : "2016-08-27 12:18:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769332914786107392",
  "text" : "No matter what your man accomplishes he can never have the klotho gene variant. Like I probably have.",
  "id" : 769332914786107392,
  "created_at" : "2016-08-27 00:37:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769331042012557312",
  "text" : "I'm going back to G+ I'm smarter there.",
  "id" : 769331042012557312,
  "created_at" : "2016-08-27 00:29:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769326065093341185",
  "text" : "SWVA you will just never admit that I'm better I've already gone through it I don't have to talk it. Goodnight.",
  "id" : 769326065093341185,
  "created_at" : "2016-08-27 00:10:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/zTo5lHZMt1",
      "expanded_url" : "https:\/\/www.psychologytoday.com\/blog\/pieces-mind\/201309\/revenge-will-you-feel-better",
      "display_url" : "psychologytoday.com\/blog\/pieces-mi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769323674465923072",
  "text" : "https:\/\/t.co\/zTo5lHZMt1 Revenge? you will feel better Goodnight.",
  "id" : 769323674465923072,
  "created_at" : "2016-08-27 00:00:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/769316748352970756\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ETnaLQI4wH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq0pgVNXYAAjfmw.jpg",
      "id_str" : "769316746775977984",
      "id" : 769316746775977984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq0pgVNXYAAjfmw.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/ETnaLQI4wH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769316748352970756",
  "text" : "https:\/\/t.co\/ETnaLQI4wH",
  "id" : 769316748352970756,
  "created_at" : "2016-08-26 23:33:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/XuvMcEGYts",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/List_of_awards_and_nominations_received_by_Nine_Inch_Nails",
      "display_url" : "en.wikipedia.org\/wiki\/List_of_a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769311537425178624",
  "text" : "https:\/\/t.co\/XuvMcEGYts The Grammys.",
  "id" : 769311537425178624,
  "created_at" : "2016-08-26 23:12:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 96, 104 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/vcGDj7P4h2",
      "expanded_url" : "https:\/\/youtu.be\/3lbFfiLAj_A",
      "display_url" : "youtu.be\/3lbFfiLAj_A"
    } ]
  },
  "geo" : { },
  "id_str" : "769307353309122560",
  "text" : "Nine Inch Nails - Full Concert - 08\/13\/94 - Woodstock 94 (OFFICIAL) https:\/\/t.co\/vcGDj7P4h2 via @YouTube",
  "id" : 769307353309122560,
  "created_at" : "2016-08-26 22:55:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 75, 83 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/ODMRfASAe5",
      "expanded_url" : "https:\/\/youtu.be\/rPEmNVCWxFI",
      "display_url" : "youtu.be\/rPEmNVCWxFI"
    } ]
  },
  "geo" : { },
  "id_str" : "769306461423935488",
  "text" : "An Cat Dubh-Into the Heart (Chicago 2005) - U2 https:\/\/t.co\/ODMRfASAe5 via @YouTube",
  "id" : 769306461423935488,
  "created_at" : "2016-08-26 22:52:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769306192199970816",
  "text" : "Hi 6 year old your a millionaire.",
  "id" : 769306192199970816,
  "created_at" : "2016-08-26 22:51:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769305307688345600",
  "text" : "Will they let the girl make the deposit first. After all I've accomplished see I'm sick.",
  "id" : 769305307688345600,
  "created_at" : "2016-08-26 22:47:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769302308316442624",
  "text" : "I am one click away from depositing my equity or \" net worth\" into the bank with Timetrex too.But can't it, might be a shareholders distrb.",
  "id" : 769302308316442624,
  "created_at" : "2016-08-26 22:35:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769299854212431874",
  "text" : "All because of one accounting rule the \"fixed asset\".",
  "id" : 769299854212431874,
  "created_at" : "2016-08-26 22:25:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769298207767658496",
  "text" : "If I have to tell you the ~1960 definition of \"cash\" and \"money\" I will. All the bank has is \"greenback\" and that word has no origin.",
  "id" : 769298207767658496,
  "created_at" : "2016-08-26 22:19:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769297167806791682",
  "text" : "What I have will cost you at least 5 million buyout.",
  "id" : 769297167806791682,
  "created_at" : "2016-08-26 22:15:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newsmax",
      "screen_name" : "newsmax",
      "indices" : [ 69, 77 ],
      "id_str" : "20545835",
      "id" : 20545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/ovFDR39Xig",
      "expanded_url" : "http:\/\/www.newsmax.com\/Finance\/StreetTalk\/Millionaires-Collecting-Food-Stamps\/2011\/06\/23\/id\/401095\/",
      "display_url" : "newsmax.com\/Finance\/Street\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769296385908871168",
  "text" : "WSJ: Millionaires Collecting Food Stamps https:\/\/t.co\/ovFDR39Xig via @Newsmax",
  "id" : 769296385908871168,
  "created_at" : "2016-08-26 22:12:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/TlTm1yeH6R",
      "expanded_url" : "https:\/\/cointelegraph.com\/news\/the-open-source-world-is-worth-billions",
      "display_url" : "cointelegraph.com\/news\/the-open-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769294972403212288",
  "text" : "https:\/\/t.co\/TlTm1yeH6R Open source is worth billions.",
  "id" : 769294972403212288,
  "created_at" : "2016-08-26 22:06:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/2RWA2TEnW7",
      "expanded_url" : "https:\/\/twitter.com\/github\/status\/769274567218954240",
      "display_url" : "twitter.com\/github\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769293680503091200",
  "text" : "See Tech is arts and entertainment https:\/\/t.co\/2RWA2TEnW7",
  "id" : 769293680503091200,
  "created_at" : "2016-08-26 22:01:20 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 64, 72 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/cWWKAQfKzL",
      "expanded_url" : "https:\/\/youtu.be\/T3zetfiRBsg",
      "display_url" : "youtu.be\/T3zetfiRBsg"
    } ]
  },
  "geo" : { },
  "id_str" : "769291704956555264",
  "text" : "Guns'n'Roses - Prostitute [ Lyric ] https:\/\/t.co\/cWWKAQfKzL via @YouTube",
  "id" : 769291704956555264,
  "created_at" : "2016-08-26 21:53:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 55, 63 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/IQzfbQy9Oc",
      "expanded_url" : "https:\/\/youtu.be\/VGuF_8q3qYc",
      "display_url" : "youtu.be\/VGuF_8q3qYc"
    } ]
  },
  "geo" : { },
  "id_str" : "769290514311028737",
  "text" : "Women Want Control - MGTOW https:\/\/t.co\/IQzfbQy9Oc via @YouTube",
  "id" : 769290514311028737,
  "created_at" : "2016-08-26 21:48:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769290001838403584",
  "text" : "I never was psychotic it was being denied by women and them choosing lesser that made me angry.",
  "id" : 769290001838403584,
  "created_at" : "2016-08-26 21:46:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769289544193769472",
  "text" : "All the medication does is make me nice. I began to realize the true nature of people when it wears off.",
  "id" : 769289544193769472,
  "created_at" : "2016-08-26 21:44:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769288887126597632",
  "text" : "Does SWVA want to put want to put up \"No trespassing\" signs to protect their women agaist the better man? Me.",
  "id" : 769288887126597632,
  "created_at" : "2016-08-26 21:42:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769285630039846912",
  "text" : "Thank You everyone for the likes and mentions today.",
  "id" : 769285630039846912,
  "created_at" : "2016-08-26 21:29:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/LgaRGP85Hw",
      "expanded_url" : "https:\/\/cwiki.apache.org\/confluence\/display\/FLEX\/Falcon+and+FalconJX+Compilers",
      "display_url" : "cwiki.apache.org\/confluence\/dis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769283604241416192",
  "text" : "https:\/\/t.co\/LgaRGP85Hw Apache on Confluence.",
  "id" : 769283604241416192,
  "created_at" : "2016-08-26 21:21:18 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769281623682584576",
  "text" : "Twitter is site even adaptable? Just pushed  A 'Find Maximum\" small algorithm to my bitbucket. I added OpenMP(CPU). For signed ints.",
  "id" : 769281623682584576,
  "created_at" : "2016-08-26 21:13:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769278564730568704",
  "text" : "They do just want my computer to go bad for a couple of days so that women could show off too. I'm not.",
  "id" : 769278564730568704,
  "created_at" : "2016-08-26 21:01:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SalesforceIQ",
      "screen_name" : "salesforceiq",
      "indices" : [ 3, 16 ],
      "id_str" : "358013667",
      "id" : 358013667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/UVR4oHeX6Y",
      "expanded_url" : "https:\/\/cards.twitter.com\/cards\/5x5h43\/1hmlj",
      "display_url" : "cards.twitter.com\/cards\/5x5h43\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769276511870386176",
  "text" : "RT @salesforceiq: Smart. Simple. CRM. Try SalesforceIQ, free for 14 days. https:\/\/t.co\/UVR4oHeX6Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/UVR4oHeX6Y",
        "expanded_url" : "https:\/\/cards.twitter.com\/cards\/5x5h43\/1hmlj",
        "display_url" : "cards.twitter.com\/cards\/5x5h43\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702239556792250368",
    "text" : "Smart. Simple. CRM. Try SalesforceIQ, free for 14 days. https:\/\/t.co\/UVR4oHeX6Y",
    "id" : 702239556792250368,
    "created_at" : "2016-02-23 21:12:11 +0000",
    "user" : {
      "name" : "SalesforceIQ",
      "screen_name" : "salesforceiq",
      "protected" : false,
      "id_str" : "358013667",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643754340348329984\/8EOKaH7A_normal.png",
      "id" : 358013667,
      "verified" : true
    }
  },
  "id" : 769276511870386176,
  "created_at" : "2016-08-26 20:53:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/5fvu36bDvC",
      "expanded_url" : "http:\/\/investorplace.com\/2016\/08\/facebook-stock-fb-great-retirement\/",
      "display_url" : "investorplace.com\/2016\/08\/facebo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769276134907191296",
  "text" : "https:\/\/t.co\/5fvu36bDvC Facebook is for 50+ year olds.",
  "id" : 769276134907191296,
  "created_at" : "2016-08-26 20:51:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/cecOYobs9r",
      "expanded_url" : "https:\/\/www.linkedin.com\/in\/jdm7dv",
      "display_url" : "linkedin.com\/in\/jdm7dv"
    } ]
  },
  "geo" : { },
  "id_str" : "769271668594343936",
  "text" : "These people do just want to discredit my talents. https:\/\/t.co\/cecOYobs9r",
  "id" : 769271668594343936,
  "created_at" : "2016-08-26 20:33:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/3mYLCubcYr",
      "expanded_url" : "http:\/\/goo.gl\/BHGfy9",
      "display_url" : "goo.gl\/BHGfy9"
    } ]
  },
  "geo" : { },
  "id_str" : "769270050155003904",
  "text" : "https:\/\/t.co\/3mYLCubcYr Talentism is the new capitalism.",
  "id" : 769270050155003904,
  "created_at" : "2016-08-26 20:27:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769265000795996160",
  "text" : "Got a call from Penn Stuart he asked me to email him. With what I had. I did. It might take some time to research my profile which is fine.",
  "id" : 769265000795996160,
  "created_at" : "2016-08-26 20:07:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/UKGlniVS4a",
      "expanded_url" : "http:\/\/goo.gl\/gt8Z76",
      "display_url" : "goo.gl\/gt8Z76"
    } ]
  },
  "geo" : { },
  "id_str" : "769264008092348416",
  "text" : "https:\/\/t.co\/UKGlniVS4a Who will buy Twitter? Google or Facebook. I'm just mad that these women have chosen lesser.I hope it's not Facebook.",
  "id" : 769264008092348416,
  "created_at" : "2016-08-26 20:03:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MVP Award Program",
      "screen_name" : "MVPAward",
      "indices" : [ 3, 12 ],
      "id_str" : "16547411",
      "id" : 16547411
    }, {
      "name" : "Janak Shrestha",
      "screen_name" : "janaks09",
      "indices" : [ 44, 53 ],
      "id_str" : "1937627990",
      "id" : 1937627990
    }, {
      "name" : "damir dobric",
      "screen_name" : "ddobric",
      "indices" : [ 54, 62 ],
      "id_str" : "90668260",
      "id" : 90668260
    }, {
      "name" : "Jason Milgram",
      "screen_name" : "jmilgram",
      "indices" : [ 63, 72 ],
      "id_str" : "16689463",
      "id" : 16689463
    }, {
      "name" : "Donna Edwards",
      "screen_name" : "edwardsdna",
      "indices" : [ 73, 84 ],
      "id_str" : "18049540",
      "id" : 18049540
    }, {
      "name" : "SuperTekBoy",
      "screen_name" : "SuperTekBoy",
      "indices" : [ 85, 97 ],
      "id_str" : "2320005890",
      "id" : 2320005890
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FridayFive",
      "indices" : [ 29, 40 ]
    }, {
      "text" : "MVPBuzz",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/wiXIafHDCc",
      "expanded_url" : "http:\/\/bit.ly\/2bvdPCh",
      "display_url" : "bit.ly\/2bvdPCh"
    } ]
  },
  "geo" : { },
  "id_str" : "769260489574612996",
  "text" : "RT @MVPAward: Hello weekend! #FridayFive w\/ @janaks09 @ddobric @jmilgram @edwardsdna @SuperTekBoy #MVPBuzz https:\/\/t.co\/wiXIafHDCc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Janak Shrestha",
        "screen_name" : "janaks09",
        "indices" : [ 30, 39 ],
        "id_str" : "1937627990",
        "id" : 1937627990
      }, {
        "name" : "damir dobric",
        "screen_name" : "ddobric",
        "indices" : [ 40, 48 ],
        "id_str" : "90668260",
        "id" : 90668260
      }, {
        "name" : "Jason Milgram",
        "screen_name" : "jmilgram",
        "indices" : [ 49, 58 ],
        "id_str" : "16689463",
        "id" : 16689463
      }, {
        "name" : "Donna Edwards",
        "screen_name" : "edwardsdna",
        "indices" : [ 59, 70 ],
        "id_str" : "18049540",
        "id" : 18049540
      }, {
        "name" : "SuperTekBoy",
        "screen_name" : "SuperTekBoy",
        "indices" : [ 71, 83 ],
        "id_str" : "2320005890",
        "id" : 2320005890
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FridayFive",
        "indices" : [ 15, 26 ]
      }, {
        "text" : "MVPBuzz",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/wiXIafHDCc",
        "expanded_url" : "http:\/\/bit.ly\/2bvdPCh",
        "display_url" : "bit.ly\/2bvdPCh"
      } ]
    },
    "geo" : { },
    "id_str" : "769228326137323520",
    "text" : "Hello weekend! #FridayFive w\/ @janaks09 @ddobric @jmilgram @edwardsdna @SuperTekBoy #MVPBuzz https:\/\/t.co\/wiXIafHDCc",
    "id" : 769228326137323520,
    "created_at" : "2016-08-26 17:41:39 +0000",
    "user" : {
      "name" : "MVP Award Program",
      "screen_name" : "MVPAward",
      "protected" : false,
      "id_str" : "16547411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729712917319438337\/l7DUa8At_normal.jpg",
      "id" : 16547411,
      "verified" : false
    }
  },
  "id" : 769260489574612996,
  "created_at" : "2016-08-26 19:49:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life Extension",
      "screen_name" : "LifeExtension",
      "indices" : [ 3, 17 ],
      "id_str" : "27188645",
      "id" : 27188645
    }, {
      "name" : "LiveScienceHealth",
      "screen_name" : "LiveSciHealth",
      "indices" : [ 22, 36 ],
      "id_str" : "172873571",
      "id" : 172873571
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lymedisease",
      "indices" : [ 58, 70 ]
    }, {
      "text" : "health",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/mpmANWrTWy",
      "expanded_url" : "http:\/\/trib.al\/WUDprIF",
      "display_url" : "trib.al\/WUDprIF"
    } ]
  },
  "geo" : { },
  "id_str" : "769260058966384640",
  "text" : "RT @LifeExtension: MT @LiveSciHealth: Mystery solved: How #lymedisease bacteria spread around the body: https:\/\/t.co\/mpmANWrTWy #health",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LiveScienceHealth",
        "screen_name" : "LiveSciHealth",
        "indices" : [ 3, 17 ],
        "id_str" : "172873571",
        "id" : 172873571
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lymedisease",
        "indices" : [ 39, 51 ]
      }, {
        "text" : "health",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/mpmANWrTWy",
        "expanded_url" : "http:\/\/trib.al\/WUDprIF",
        "display_url" : "trib.al\/WUDprIF"
      } ]
    },
    "geo" : { },
    "id_str" : "769245045543362560",
    "text" : "MT @LiveSciHealth: Mystery solved: How #lymedisease bacteria spread around the body: https:\/\/t.co\/mpmANWrTWy #health",
    "id" : 769245045543362560,
    "created_at" : "2016-08-26 18:48:05 +0000",
    "user" : {
      "name" : "Life Extension",
      "screen_name" : "LifeExtension",
      "protected" : false,
      "id_str" : "27188645",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466584195842592768\/C9ajd_Y__normal.jpeg",
      "id" : 27188645,
      "verified" : false
    }
  },
  "id" : 769260058966384640,
  "created_at" : "2016-08-26 19:47:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/TL9UYBYSIp",
      "expanded_url" : "https:\/\/bhrcenter.com\/hormone-replacement-therapy\/",
      "display_url" : "bhrcenter.com\/hormone-replac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769258653362839552",
  "text" : "https:\/\/t.co\/TL9UYBYSIp Hormone Replacement therapy another way to gain back the years.",
  "id" : 769258653362839552,
  "created_at" : "2016-08-26 19:42:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IEEE",
      "screen_name" : "IEEEorg",
      "indices" : [ 3, 11 ],
      "id_str" : "54290504",
      "id" : 54290504
    }, {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "indices" : [ 132, 139 ],
      "id_str" : "19722699",
      "id" : 19722699
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Earth",
      "indices" : [ 56, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/z2C8e5GB71",
      "expanded_url" : "http:\/\/bit.ly\/2bZHuX6",
      "display_url" : "bit.ly\/2bZHuX6"
    } ]
  },
  "geo" : { },
  "id_str" : "769257572046106624",
  "text" : "RT @IEEEorg: The nearest neighboring star system has an #Earth-sized planet and it could be our Plan B: https:\/\/t.co\/z2C8e5GB71 via @PopSci",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Popular Science",
        "screen_name" : "PopSci",
        "indices" : [ 119, 126 ],
        "id_str" : "19722699",
        "id" : 19722699
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Earth",
        "indices" : [ 43, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/z2C8e5GB71",
        "expanded_url" : "http:\/\/bit.ly\/2bZHuX6",
        "display_url" : "bit.ly\/2bZHuX6"
      } ]
    },
    "geo" : { },
    "id_str" : "769182879913947136",
    "text" : "The nearest neighboring star system has an #Earth-sized planet and it could be our Plan B: https:\/\/t.co\/z2C8e5GB71 via @PopSci",
    "id" : 769182879913947136,
    "created_at" : "2016-08-26 14:41:03 +0000",
    "user" : {
      "name" : "IEEE",
      "screen_name" : "IEEEorg",
      "protected" : false,
      "id_str" : "54290504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474591466749034496\/2-H1zqWf_normal.jpeg",
      "id" : 54290504,
      "verified" : false
    }
  },
  "id" : 769257572046106624,
  "created_at" : "2016-08-26 19:37:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pitchfork",
      "screen_name" : "pitchfork",
      "indices" : [ 3, 13 ],
      "id_str" : "14089195",
      "id" : 14089195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/8h34caDRM1",
      "expanded_url" : "http:\/\/p4k.in\/fHQOp74",
      "display_url" : "p4k.in\/fHQOp74"
    } ]
  },
  "geo" : { },
  "id_str" : "769257400884989956",
  "text" : "RT @pitchfork: Kicking it off with 24-track recording, which became the rule, not the exception, throughout the '70s https:\/\/t.co\/8h34caDRM1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/8h34caDRM1",
        "expanded_url" : "http:\/\/p4k.in\/fHQOp74",
        "display_url" : "p4k.in\/fHQOp74"
      } ]
    },
    "geo" : { },
    "id_str" : "768997413923139584",
    "text" : "Kicking it off with 24-track recording, which became the rule, not the exception, throughout the '70s https:\/\/t.co\/8h34caDRM1",
    "id" : 768997413923139584,
    "created_at" : "2016-08-26 02:24:05 +0000",
    "user" : {
      "name" : "Pitchfork",
      "screen_name" : "pitchfork",
      "protected" : false,
      "id_str" : "14089195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615703473678585856\/6DxJO5o0_normal.jpg",
      "id" : 14089195,
      "verified" : true
    }
  },
  "id" : 769257400884989956,
  "created_at" : "2016-08-26 19:37:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Community Grid",
      "screen_name" : "WCGrid",
      "indices" : [ 3, 10 ],
      "id_str" : "26388412",
      "id" : 26388412
    }, {
      "name" : "World Community Grid",
      "screen_name" : "WCGrid",
      "indices" : [ 18, 25 ],
      "id_str" : "26388412",
      "id" : 26388412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/4LqLBzt7rT",
      "expanded_url" : "https:\/\/secure.worldcommunitygrid.org\/about_us\/viewNewsArticle.do?articleId=494",
      "display_url" : "secure.worldcommunitygrid.org\/about_us\/viewN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769256564939223040",
  "text" : "RT @WCGrid: Which @WCGrid employee can be considered our \"chief detective?\" Meet her in this article. https:\/\/t.co\/4LqLBzt7rT https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "World Community Grid",
        "screen_name" : "WCGrid",
        "indices" : [ 6, 13 ],
        "id_str" : "26388412",
        "id" : 26388412
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WCGrid\/status\/769247682745556992\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/X233Ee0RcB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqzqkz4XgAALTMF.jpg",
        "id_str" : "769247554496331776",
        "id" : 769247554496331776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqzqkz4XgAALTMF.jpg",
        "sizes" : [ {
          "h" : 320,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 350
        } ],
        "display_url" : "pic.twitter.com\/X233Ee0RcB"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/4LqLBzt7rT",
        "expanded_url" : "https:\/\/secure.worldcommunitygrid.org\/about_us\/viewNewsArticle.do?articleId=494",
        "display_url" : "secure.worldcommunitygrid.org\/about_us\/viewN\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "769247682745556992",
    "text" : "Which @WCGrid employee can be considered our \"chief detective?\" Meet her in this article. https:\/\/t.co\/4LqLBzt7rT https:\/\/t.co\/X233Ee0RcB",
    "id" : 769247682745556992,
    "created_at" : "2016-08-26 18:58:34 +0000",
    "user" : {
      "name" : "World Community Grid",
      "screen_name" : "WCGrid",
      "protected" : false,
      "id_str" : "26388412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448919987281866752\/T4oA5jtc_normal.png",
      "id" : 26388412,
      "verified" : false
    }
  },
  "id" : 769256564939223040,
  "created_at" : "2016-08-26 19:33:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/HMfyGU6Lag",
      "expanded_url" : "http:\/\/projects.wsj.com\/campaign2012\/candidates\/view\/joe-donnelly--IN-S",
      "display_url" : "projects.wsj.com\/campaign2012\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769254975142760449",
  "text" : "https:\/\/t.co\/HMfyGU6Lag Joe Donnelly ran in 2012. He is Pro-Life and against guns. I'm writing him in.",
  "id" : 769254975142760449,
  "created_at" : "2016-08-26 19:27:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/LzTOgqPJUH",
      "expanded_url" : "http:\/\/pennyborn.com\/smallbusiness\/needforliquidity.html",
      "display_url" : "pennyborn.com\/smallbusiness\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769246563550068736",
  "text" : "https:\/\/t.co\/LzTOgqPJUH Why You Need Liquidity In Your Estate Plan When You Own A Business, you may not need a corporation either.",
  "id" : 769246563550068736,
  "created_at" : "2016-08-26 18:54:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769244733231210496",
  "text" : "I can download free expansion packs, but I've never used them. They came with my keyboard. I might sometime.",
  "id" : 769244733231210496,
  "created_at" : "2016-08-26 18:46:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akai Professional",
      "screen_name" : "Akai_Pro",
      "indices" : [ 3, 12 ],
      "id_str" : "29266575",
      "id" : 29266575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/8MoJTIfc3m",
      "expanded_url" : "http:\/\/goo.gl\/RGBkCF",
      "display_url" : "goo.gl\/RGBkCF"
    } ]
  },
  "geo" : { },
  "id_str" : "769243443159785476",
  "text" : "RT @Akai_Pro: OUT NOW - New MPC Expansion Pack: Dark Parallax. Preview and download a free demo kit here: https:\/\/t.co\/8MoJTIfc3m https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Akai_Pro\/status\/769232496584077313\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/4RB5KaGQ5p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqzc2_6VUAAx2wg.jpg",
        "id_str" : "769232473800658944",
        "id" : 769232473800658944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqzc2_6VUAAx2wg.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/4RB5KaGQ5p"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/8MoJTIfc3m",
        "expanded_url" : "http:\/\/goo.gl\/RGBkCF",
        "display_url" : "goo.gl\/RGBkCF"
      } ]
    },
    "geo" : { },
    "id_str" : "769232496584077313",
    "text" : "OUT NOW - New MPC Expansion Pack: Dark Parallax. Preview and download a free demo kit here: https:\/\/t.co\/8MoJTIfc3m https:\/\/t.co\/4RB5KaGQ5p",
    "id" : 769232496584077313,
    "created_at" : "2016-08-26 17:58:13 +0000",
    "user" : {
      "name" : "Akai Professional",
      "screen_name" : "Akai_Pro",
      "protected" : false,
      "id_str" : "29266575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598874376201580545\/RnD803H9_normal.png",
      "id" : 29266575,
      "verified" : false
    }
  },
  "id" : 769243443159785476,
  "created_at" : "2016-08-26 18:41:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "indices" : [ 3, 9 ],
      "id_str" : "3819701",
      "id" : 3819701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/du8etxLpnE",
      "expanded_url" : "http:\/\/zd.net\/2bYjVil",
      "display_url" : "zd.net\/2bYjVil"
    } ]
  },
  "geo" : { },
  "id_str" : "769242574007701504",
  "text" : "RT @ZDNet: Parallels Desktop 12 For Mac review: Bringing the Mac and Windows closer than ever https:\/\/t.co\/du8etxLpnE https:\/\/t.co\/NKKeeLjV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ZDNet\/status\/769241837857075202\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/NKKeeLjVK4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqzlXYBWcAIDc36.jpg",
        "id_str" : "769241826121379842",
        "id" : 769241826121379842,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqzlXYBWcAIDc36.jpg",
        "sizes" : [ {
          "h" : 481,
          "resize" : "fit",
          "w" : 770
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 770
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 770
        } ],
        "display_url" : "pic.twitter.com\/NKKeeLjVK4"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/du8etxLpnE",
        "expanded_url" : "http:\/\/zd.net\/2bYjVil",
        "display_url" : "zd.net\/2bYjVil"
      } ]
    },
    "geo" : { },
    "id_str" : "769241837857075202",
    "text" : "Parallels Desktop 12 For Mac review: Bringing the Mac and Windows closer than ever https:\/\/t.co\/du8etxLpnE https:\/\/t.co\/NKKeeLjVK4",
    "id" : 769241837857075202,
    "created_at" : "2016-08-26 18:35:20 +0000",
    "user" : {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "protected" : false,
      "id_str" : "3819701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706961982545473536\/Ibj46-DX_normal.jpg",
      "id" : 3819701,
      "verified" : true
    }
  },
  "id" : 769242574007701504,
  "created_at" : "2016-08-26 18:38:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769242424728231938",
  "text" : "I'm up but in my dream it felt like I was the whole time, no lie.",
  "id" : 769242424728231938,
  "created_at" : "2016-08-26 18:37:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 67, 75 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/0ZF0oGpSDa",
      "expanded_url" : "https:\/\/youtu.be\/lFUIeDjo2dA",
      "display_url" : "youtu.be\/lFUIeDjo2dA"
    } ]
  },
  "geo" : { },
  "id_str" : "769230155596390400",
  "text" : "Radiohead - Kid A (8-bit) [FULL ALBUM] https:\/\/t.co\/0ZF0oGpSDa via @YouTube Nap.",
  "id" : 769230155596390400,
  "created_at" : "2016-08-26 17:48:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/SJo1K0CSiW",
      "expanded_url" : "http:\/\/goo.gl\/E6aFqX",
      "display_url" : "goo.gl\/E6aFqX"
    } ]
  },
  "geo" : { },
  "id_str" : "769229192831635456",
  "text" : "Dreams and the Many Worlds Interpretation of Quantum Physics https:\/\/t.co\/SJo1K0CSiW",
  "id" : 769229192831635456,
  "created_at" : "2016-08-26 17:45:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/arlASUhEx4",
      "expanded_url" : "http:\/\/goo.gl\/9E3gHb",
      "display_url" : "goo.gl\/9E3gHb"
    } ]
  },
  "geo" : { },
  "id_str" : "769225999657603072",
  "text" : "https:\/\/t.co\/arlASUhEx4  Do Schizophrenics Live in Parallel Universes?",
  "id" : 769225999657603072,
  "created_at" : "2016-08-26 17:32:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/XVhIHKuH5M",
      "expanded_url" : "http:\/\/goo.gl\/PLjcQa",
      "display_url" : "goo.gl\/PLjcQa"
    } ]
  },
  "geo" : { },
  "id_str" : "769224685192118272",
  "text" : "https:\/\/t.co\/XVhIHKuH5M Machine learning applications in genetics and genomics.",
  "id" : 769224685192118272,
  "created_at" : "2016-08-26 17:27:11 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/9ad1SinQ1U",
      "expanded_url" : "http:\/\/goo.gl\/lCwQl1",
      "display_url" : "goo.gl\/lCwQl1"
    } ]
  },
  "geo" : { },
  "id_str" : "769221550750990336",
  "text" : "https:\/\/t.co\/9ad1SinQ1U The Renaissance of Rejuvenation Biotechnology",
  "id" : 769221550750990336,
  "created_at" : "2016-08-26 17:14:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 73, 80 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/GCR0YHbT0J",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/medidata\/2016\/01\/25\/is-machine-learning-the-next-big-thing-in-healthcare\/#9b24a9e2f9a9",
      "display_url" : "forbes.com\/sites\/medidata\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769219909645701121",
  "text" : "MedidataVoice: Is Machine Learning the Next Big Thing In Healthcare? via @forbes https:\/\/t.co\/GCR0YHbT0J",
  "id" : 769219909645701121,
  "created_at" : "2016-08-26 17:08:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BioInformant",
      "screen_name" : "StemCellMarket",
      "indices" : [ 89, 104 ],
      "id_str" : "2612311915",
      "id" : 2612311915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/wAnKmEMB4w",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/expanding-opportunities-ipscs-japan-forefront-global-cade-hildreth",
      "display_url" : "linkedin.com\/pulse\/expandin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769218976492781570",
  "text" : "\"Expanding Opportunities for iPSCs, with Japan at the Forefront of Global Innovation\" by @StemCellMarket on@LinkedIn https:\/\/t.co\/wAnKmEMB4w",
  "id" : 769218976492781570,
  "created_at" : "2016-08-26 17:04:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/3GaHCZSR5O",
      "expanded_url" : "http:\/\/profile.jonathanmoore.net",
      "display_url" : "profile.jonathanmoore.net"
    }, {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/hp5mHTNxzF",
      "expanded_url" : "http:\/\/goo.gl\/eZRjnh",
      "display_url" : "goo.gl\/eZRjnh"
    } ]
  },
  "geo" : { },
  "id_str" : "769217647703650305",
  "text" : "I am just overqualified too. https:\/\/t.co\/3GaHCZSR5O  https:\/\/t.co\/hp5mHTNxzF",
  "id" : 769217647703650305,
  "created_at" : "2016-08-26 16:59:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769208826453196800",
  "text" : "If you are 16 years old or younger I have no beef with you.",
  "id" : 769208826453196800,
  "created_at" : "2016-08-26 16:24:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 70, 78 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/zGqlFkXT1N",
      "expanded_url" : "https:\/\/youtu.be\/Cfo83U4AEHQ",
      "display_url" : "youtu.be\/Cfo83U4AEHQ"
    } ]
  },
  "geo" : { },
  "id_str" : "769207216201162753",
  "text" : "Elysium last 5 minutes scence (Best Part) https:\/\/t.co\/zGqlFkXT1N via @YouTube",
  "id" : 769207216201162753,
  "created_at" : "2016-08-26 16:17:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769204886273654784",
  "text" : "I don't need anything but groceries for a long time. And I'm saving my money.",
  "id" : 769204886273654784,
  "created_at" : "2016-08-26 16:08:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 53, 61 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/gOIq1RUtPA",
      "expanded_url" : "https:\/\/youtu.be\/4m2q5Fw8gwI",
      "display_url" : "youtu.be\/4m2q5Fw8gwI"
    } ]
  },
  "geo" : { },
  "id_str" : "769202452121939969",
  "text" : "Audioslave - Revelations https:\/\/t.co\/gOIq1RUtPA via @YouTube",
  "id" : 769202452121939969,
  "created_at" : "2016-08-26 15:58:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769201947580755968",
  "text" : "I challenge anyone to a year alone with only their mind and creativity. Then I'll ask them if they like their friends and social networks.",
  "id" : 769201947580755968,
  "created_at" : "2016-08-26 15:56:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769200972228943873",
  "text" : "When that network admits that they lost I might be nice.",
  "id" : 769200972228943873,
  "created_at" : "2016-08-26 15:52:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 49, 57 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/WMD4RdoAPs",
      "expanded_url" : "https:\/\/youtu.be\/BT9Z_LOKQg4",
      "display_url" : "youtu.be\/BT9Z_LOKQg4"
    } ]
  },
  "geo" : { },
  "id_str" : "769193796361912320",
  "text" : "American Fake Smiles https:\/\/t.co\/WMD4RdoAPs via @YouTube",
  "id" : 769193796361912320,
  "created_at" : "2016-08-26 15:24:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 44, 52 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/UGy3jlWlKz",
      "expanded_url" : "https:\/\/youtu.be\/uAOoiIkFQq4",
      "display_url" : "youtu.be\/uAOoiIkFQq4"
    } ]
  },
  "geo" : { },
  "id_str" : "769191980840747008",
  "text" : "KMFDM - Anarchy https:\/\/t.co\/UGy3jlWlKz via @YouTube  I made a God out of Blood.",
  "id" : 769191980840747008,
  "created_at" : "2016-08-26 15:17:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalDogDay",
      "indices" : [ 30, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769191173533601792",
  "text" : "With something like Basis and #NationalDogDay is trending. I hate society.",
  "id" : 769191173533601792,
  "created_at" : "2016-08-26 15:14:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769188753357283328",
  "text" : "They really don't have an technology industry do they? Just Arts and Entertainment.",
  "id" : 769188753357283328,
  "created_at" : "2016-08-26 15:04:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/5cd64N4yPw",
      "expanded_url" : "http:\/\/www.incforfree.com\/inc-today?gclid=CPjC2fKr384CFUUvgQodyvwJEg",
      "display_url" : "incforfree.com\/inc-today?gcli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769187594655637504",
  "text" : "https:\/\/t.co\/5cd64N4yPw I am just free from suffering aren't I prostitute.",
  "id" : 769187594655637504,
  "created_at" : "2016-08-26 14:59:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769181099314540544",
  "text" : "I got through to the head of one of the largest lawyers in the state. And an associate is going to call about an S-Corp on Monday.",
  "id" : 769181099314540544,
  "created_at" : "2016-08-26 14:33:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769174203778134017",
  "text" : "I do have a year supply of Basis. I might save my money and order a Princeton math book today. I'll order again when it's time.",
  "id" : 769174203778134017,
  "created_at" : "2016-08-26 14:06:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/KBbl5QDCEn",
      "expanded_url" : "http:\/\/journal.jonathanmoore.net\/",
      "display_url" : "journal.jonathanmoore.net"
    } ]
  },
  "geo" : { },
  "id_str" : "769170475201290240",
  "text" : "https:\/\/t.co\/KBbl5QDCEn Recent updates.",
  "id" : 769170475201290240,
  "created_at" : "2016-08-26 13:51:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 60, 68 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/pb0bPIuze0",
      "expanded_url" : "https:\/\/youtu.be\/LtT6Xkk-kzk",
      "display_url" : "youtu.be\/LtT6Xkk-kzk"
    } ]
  },
  "geo" : { },
  "id_str" : "769169608481857538",
  "text" : "DMT: The Spirit Molecule (2010) https:\/\/t.co\/pb0bPIuze0 via @YouTube I bought this from iTunes in 2010.",
  "id" : 769169608481857538,
  "created_at" : "2016-08-26 13:48:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 56, 64 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/1oib1eqoOJ",
      "expanded_url" : "https:\/\/youtu.be\/w7U_c1_EmV8",
      "display_url" : "youtu.be\/w7U_c1_EmV8"
    } ]
  },
  "geo" : { },
  "id_str" : "769168533225873408",
  "text" : "Nirvana - Even In His Youth https:\/\/t.co\/1oib1eqoOJ via @YouTube See what DMT does.",
  "id" : 769168533225873408,
  "created_at" : "2016-08-26 13:44:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/p2mw64lzQ0",
      "expanded_url" : "http:\/\/www.juvenon.com\/",
      "display_url" : "juvenon.com"
    } ]
  },
  "geo" : { },
  "id_str" : "769167352151891968",
  "text" : "https:\/\/t.co\/p2mw64lzQ0 This is Juveron and they have come down in price to compete with Basis.",
  "id" : 769167352151891968,
  "created_at" : "2016-08-26 13:39:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Women@NASA",
      "screen_name" : "WomenNASA",
      "indices" : [ 54, 64 ],
      "id_str" : "492253390",
      "id" : 492253390
    }, {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 109, 123 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyBirthdayKatherineJohnson",
      "indices" : [ 10, 40 ]
    }, {
      "text" : "AstroKate",
      "indices" : [ 80, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769165656369557504",
  "text" : "RT @NASA: #HappyBirthdayKatherineJohnson, a legendary @WomenNASA mathematician. #AstroKate sends wishes from @Space_Station:\nhttps:\/\/t.co\/C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Women@NASA",
        "screen_name" : "WomenNASA",
        "indices" : [ 44, 54 ],
        "id_str" : "492253390",
        "id" : 492253390
      }, {
        "name" : "Intl. Space Station",
        "screen_name" : "Space_Station",
        "indices" : [ 99, 113 ],
        "id_str" : "1451773004",
        "id" : 1451773004
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HappyBirthdayKatherineJohnson",
        "indices" : [ 0, 30 ]
      }, {
        "text" : "AstroKate",
        "indices" : [ 70, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/C7APlRMF14",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/8ca07419-b220-45d9-9537-8ccfb6c48634",
        "display_url" : "amp.twimg.com\/v\/8ca07419-b22\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "769161364644372481",
    "text" : "#HappyBirthdayKatherineJohnson, a legendary @WomenNASA mathematician. #AstroKate sends wishes from @Space_Station:\nhttps:\/\/t.co\/C7APlRMF14",
    "id" : 769161364644372481,
    "created_at" : "2016-08-26 13:15:34 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 769165656369557504,
  "created_at" : "2016-08-26 13:32:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/uLkG0mVx4B",
      "expanded_url" : "http:\/\/goo.gl\/OGl6Qg",
      "display_url" : "goo.gl\/OGl6Qg"
    } ]
  },
  "geo" : { },
  "id_str" : "769164192314187776",
  "text" : "Gravitational Waves which I helped with earlier this year is a shoo-in for a Nobel. Help with my 3rd Nobel. https:\/\/t.co\/uLkG0mVx4B",
  "id" : 769164192314187776,
  "created_at" : "2016-08-26 13:26:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/Im0UDNUPiK",
      "expanded_url" : "https:\/\/twitter.com\/ZDNet\/status\/769154614663012352",
      "display_url" : "twitter.com\/ZDNet\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769159705654620160",
  "text" : "I'm updating to Windows 10 when it is more stable and Final Fantasy 15 comes to the PC.I already have LTSB. https:\/\/t.co\/Im0UDNUPiK",
  "id" : 769159705654620160,
  "created_at" : "2016-08-26 13:08:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769158145172209664",
  "text" : "I'm making another bank deposit and I'm buying some more Basis.",
  "id" : 769158145172209664,
  "created_at" : "2016-08-26 13:02:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769156504025006085",
  "text" : "I might just call lawyers today. It is an S Corp. Technology is stock. And those are hardship distributions.",
  "id" : 769156504025006085,
  "created_at" : "2016-08-26 12:56:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science of Us",
      "screen_name" : "thescienceofus",
      "indices" : [ 92, 107 ],
      "id_str" : "2244290719",
      "id" : 2244290719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/E7irMQu7dN",
      "expanded_url" : "http:\/\/nymag.com\/scienceofus\/2016\/08\/is-elysium-healths-basis-the-fountain-of-youth.html?mid=twitter-share-scienceofus",
      "display_url" : "nymag.com\/scienceofus\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769153716159217664",
  "text" : "An MIT Scientist Claims That This Pill Is the Fountain of Youth https:\/\/t.co\/E7irMQu7dN via @thescienceofus",
  "id" : 769153716159217664,
  "created_at" : "2016-08-26 12:45:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769148077580099584",
  "text" : "I know this is a pre-order album but I may not release it until I see some revenge and justice in the BMI case and in the social networks.",
  "id" : 769148077580099584,
  "created_at" : "2016-08-26 12:22:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769147146620788737",
  "text" : "Wrote a song and took a Basis. These millennials probably don't even have their youth to get back at the neglected Gen X.",
  "id" : 769147146620788737,
  "created_at" : "2016-08-26 12:19:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SoundCloud",
      "indices" : [ 59, 70 ]
    }, {
      "text" : "np",
      "indices" : [ 72, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/wvr1YISrOP",
      "expanded_url" : "https:\/\/soundcloud.com\/jdm7dv\/ghost-in-the-machine?utm_source=soundcloud&utm_campaign=share&utm_medium=twitter",
      "display_url" : "soundcloud.com\/jdm7dv\/ghost-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769141895457017857",
  "text" : "Have you heard \u2018Ghost in the Machine\u2019 by Jonathan Moore on #SoundCloud? #np https:\/\/t.co\/wvr1YISrOP",
  "id" : 769141895457017857,
  "created_at" : "2016-08-26 11:58:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769023915008126977",
  "text" : "I started with Windows at version 1.0 and I've had it.",
  "id" : 769023915008126977,
  "created_at" : "2016-08-26 04:09:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769022107007287299",
  "text" : "I released my album and submitted it to magnatune in July didn't I bitch? I got in. Submit your genius Nick. Idiot.",
  "id" : 769022107007287299,
  "created_at" : "2016-08-26 04:02:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769019593079808000",
  "text" : "I have a cognitive therapy session next month and she better just put out. Goodnight.",
  "id" : 769019593079808000,
  "created_at" : "2016-08-26 03:52:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769015110111203333",
  "text" : "Nobody helped me with the albums, websites or projects in bitbucket and that is just a drop in the bucket what I have at the bank.",
  "id" : 769015110111203333,
  "created_at" : "2016-08-26 03:34:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/C4hLiCcH9E",
      "expanded_url" : "http:\/\/boinc.berkeley.edu\/wiki\/Installing_BOINC",
      "display_url" : "boinc.berkeley.edu\/wiki\/Installin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769012842544660484",
  "text" : "https:\/\/t.co\/C4hLiCcH9E Installing BOINC and I don't use the screensaver anymore it is an option. Let it run in your system tray at startup.",
  "id" : 769012842544660484,
  "created_at" : "2016-08-26 03:25:23 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 69, 77 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/L1CFhkoXOR",
      "expanded_url" : "https:\/\/youtu.be\/y0betLmOYhk",
      "display_url" : "youtu.be\/y0betLmOYhk"
    } ]
  },
  "geo" : { },
  "id_str" : "769008834111299585",
  "text" : "Berkeley SETI Research Center Highlights https:\/\/t.co\/L1CFhkoXOR via @YouTube",
  "id" : 769008834111299585,
  "created_at" : "2016-08-26 03:09:28 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 44, 52 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/x90rw2TBdJ",
      "expanded_url" : "https:\/\/youtu.be\/EiR1hmpk-x4",
      "display_url" : "youtu.be\/EiR1hmpk-x4"
    } ]
  },
  "geo" : { },
  "id_str" : "769003972212428800",
  "text" : "Tool The Grudge https:\/\/t.co\/x90rw2TBdJ via @YouTube",
  "id" : 769003972212428800,
  "created_at" : "2016-08-26 02:50:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/769003538701778944\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Ok4t7BXL95",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqwMip0WYAEQ4JS.jpg",
      "id_str" : "769003425854021633",
      "id" : 769003425854021633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqwMip0WYAEQ4JS.jpg",
      "sizes" : [ {
        "h" : 489,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 584,
        "resize" : "fit",
        "w" : 1433
      }, {
        "h" : 277,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 584,
        "resize" : "fit",
        "w" : 1433
      } ],
      "display_url" : "pic.twitter.com\/Ok4t7BXL95"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769003538701778944",
  "text" : "https:\/\/t.co\/Ok4t7BXL95",
  "id" : 769003538701778944,
  "created_at" : "2016-08-26 02:48:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/XJHhN1fvmZ",
      "expanded_url" : "https:\/\/www.technologyreview.com\/s\/542371\/a-tale-of-do-it-yourself-gene-therapy\/",
      "display_url" : "technologyreview.com\/s\/542371\/a-tal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769001159919071232",
  "text" : "https:\/\/t.co\/XJHhN1fvmZ Get married in July after I posted this? On my blog?",
  "id" : 769001159919071232,
  "created_at" : "2016-08-26 02:38:58 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/768999606625640448\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/hKFTxubZMy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqwJEJ8WYAA-kSc.jpg",
      "id_str" : "768999603366682624",
      "id" : 768999603366682624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqwJEJ8WYAA-kSc.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hKFTxubZMy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768999606625640448",
  "text" : "https:\/\/t.co\/hKFTxubZMy",
  "id" : 768999606625640448,
  "created_at" : "2016-08-26 02:32:48 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768999063035535360",
  "text" : "I've know about basis since 2015. And I take it regularly.",
  "id" : 768999063035535360,
  "created_at" : "2016-08-26 02:30:38 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768995666299383808",
  "text" : "I paid for a year supply of Basis. Goodnight",
  "id" : 768995666299383808,
  "created_at" : "2016-08-26 02:17:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/VW1orhHZhM",
      "expanded_url" : "https:\/\/www.technologyreview.com\/s\/534636\/the-anti-aging-pill\/",
      "display_url" : "technologyreview.com\/s\/534636\/the-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768993638676307968",
  "text" : "https:\/\/t.co\/VW1orhHZhM There is so much more. All they ever say to me is thanks for talking and go fuck their men.",
  "id" : 768993638676307968,
  "created_at" : "2016-08-26 02:09:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 78, 86 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/u23OvRIDsp",
      "expanded_url" : "https:\/\/youtu.be\/QILNSgou5BY",
      "display_url" : "youtu.be\/QILNSgou5BY"
    } ]
  },
  "geo" : { },
  "id_str" : "768991127437512704",
  "text" : "ELYSIUM - Official Full Trailer - In Theaters 8\/9 https:\/\/t.co\/u23OvRIDsp via @YouTube",
  "id" : 768991127437512704,
  "created_at" : "2016-08-26 01:59:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768989098577190913",
  "text" : "The genetic algorithms are in beta and open and I'm not even telling you what language.",
  "id" : 768989098577190913,
  "created_at" : "2016-08-26 01:51:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768986740287758337",
  "text" : "I may get into genetic algorithms tomorrow.",
  "id" : 768986740287758337,
  "created_at" : "2016-08-26 01:41:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768983446454689793",
  "text" : "I built boost and pushed code to my bitbucket.A templated C++ linked list.",
  "id" : 768983446454689793,
  "created_at" : "2016-08-26 01:28:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768977197373816832",
  "text" : "Zuckerberg fuck you and your VR.",
  "id" : 768977197373816832,
  "created_at" : "2016-08-26 01:03:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768975934892412932",
  "text" : "I can't sleep this started in 2003 after college the first time because these women chose lesser. Has anything changed?",
  "id" : 768975934892412932,
  "created_at" : "2016-08-26 00:58:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768972239123410944",
  "text" : "Call the National Association for Gifted Children and ask if I'm a member Nick. I'm calling you out.",
  "id" : 768972239123410944,
  "created_at" : "2016-08-26 00:44:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/768959617409904642\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ICQm8TXQU6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqvksihXgAE1pwD.jpg",
      "id_str" : "768959615228936193",
      "id" : 768959615228936193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqvksihXgAE1pwD.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/ICQm8TXQU6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768959617409904642",
  "text" : "https:\/\/t.co\/ICQm8TXQU6",
  "id" : 768959617409904642,
  "created_at" : "2016-08-25 23:53:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768958571073724416",
  "text" : "I do have her old pictures if she lost them.",
  "id" : 768958571073724416,
  "created_at" : "2016-08-25 23:49:44 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768953227819814912",
  "text" : "We he admits I'm the better man to my face I may stop. Full steam ahead.",
  "id" : 768953227819814912,
  "created_at" : "2016-08-25 23:28:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 61, 69 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/2VO1ENDRqD",
      "expanded_url" : "https:\/\/youtu.be\/z1k1s9n16fs",
      "display_url" : "youtu.be\/z1k1s9n16fs"
    } ]
  },
  "geo" : { },
  "id_str" : "768951857716658180",
  "text" : "Smashing Pumpkins Doomsday Clock https:\/\/t.co\/2VO1ENDRqD via @YouTube",
  "id" : 768951857716658180,
  "created_at" : "2016-08-25 23:23:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/768949464442802176\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/dW2k7LEWSY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqvbdkEWgAE6lzS.jpg",
      "id_str" : "768949462341419009",
      "id" : 768949462341419009,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqvbdkEWgAE6lzS.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/dW2k7LEWSY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768949464442802176",
  "text" : "https:\/\/t.co\/dW2k7LEWSY",
  "id" : 768949464442802176,
  "created_at" : "2016-08-25 23:13:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768948776740483072",
  "text" : "I can't quit I have to keep on letting you have it.",
  "id" : 768948776740483072,
  "created_at" : "2016-08-25 23:10:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768942094027284481",
  "text" : "Wanna see the source to some of that proprietary software nick?",
  "id" : 768942094027284481,
  "created_at" : "2016-08-25 22:44:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768938566877609984",
  "text" : "C that Nick.",
  "id" : 768938566877609984,
  "created_at" : "2016-08-25 22:30:15 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768937649629437952",
  "text" : "I learned C programming in God's country.",
  "id" : 768937649629437952,
  "created_at" : "2016-08-25 22:26:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768936366587740161",
  "text" : "I did tell the Doctor Nick not a drop of blood until I get want I want. Beat straight A's.",
  "id" : 768936366587740161,
  "created_at" : "2016-08-25 22:21:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768927320358789121",
  "text" : "1968 article \"Patterns of Survival and Reproduction in the United States: Implications for Selection\"  this was academically determined.",
  "id" : 768927320358789121,
  "created_at" : "2016-08-25 21:45:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/768902574267179008\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/1wufpKFeBf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cquw0NSVMAAPdJE.jpg",
      "id_str" : "768902572363034624",
      "id" : 768902572363034624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cquw0NSVMAAPdJE.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/1wufpKFeBf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768902574267179008",
  "text" : "https:\/\/t.co\/1wufpKFeBf",
  "id" : 768902574267179008,
  "created_at" : "2016-08-25 20:07:13 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/768900140816105472\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/t2U7YghQre",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CquumjdWYAA08KB.jpg",
      "id_str" : "768900138773405696",
      "id" : 768900138773405696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CquumjdWYAA08KB.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/t2U7YghQre"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768900140816105472",
  "text" : "https:\/\/t.co\/t2U7YghQre",
  "id" : 768900140816105472,
  "created_at" : "2016-08-25 19:57:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/768898436825427968\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/3Yqos882Ci",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqutDYdUsAEfYUj.jpg",
      "id_str" : "768898435013455873",
      "id" : 768898435013455873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqutDYdUsAEfYUj.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/3Yqos882Ci"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768898436825427968",
  "text" : "https:\/\/t.co\/3Yqos882Ci",
  "id" : 768898436825427968,
  "created_at" : "2016-08-25 19:50:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/768895890312560640\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Pc0DONFla6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CquqvKTW8AQsxhd.jpg",
      "id_str" : "768895888592924676",
      "id" : 768895888592924676,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CquqvKTW8AQsxhd.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/Pc0DONFla6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768895890312560640",
  "text" : "https:\/\/t.co\/Pc0DONFla6",
  "id" : 768895890312560640,
  "created_at" : "2016-08-25 19:40:40 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768885883256864768",
  "text" : "Simple auditory hallucinations, if that is what humans call them now is not criteria for a hospitalization.",
  "id" : 768885883256864768,
  "created_at" : "2016-08-25 19:00:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/HY8fvpE39M",
      "expanded_url" : "https:\/\/twitter.com\/applenws\/status\/768867258294599680",
      "display_url" : "twitter.com\/applenws\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768884336909246465",
  "text" : "Just updated my iOS devices to 9.35 https:\/\/t.co\/HY8fvpE39M",
  "id" : 768884336909246465,
  "created_at" : "2016-08-25 18:54:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 60, 68 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/YJuADqGpIW",
      "expanded_url" : "https:\/\/youtu.be\/oFBxUIzsrTg",
      "display_url" : "youtu.be\/oFBxUIzsrTg"
    } ]
  },
  "geo" : { },
  "id_str" : "768871084192108545",
  "text" : "Pearl Jam- Animal (with Lyrics) https:\/\/t.co\/YJuADqGpIW via @YouTube",
  "id" : 768871084192108545,
  "created_at" : "2016-08-25 18:02:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/5XfVHOu43O",
      "expanded_url" : "http:\/\/goo.gl\/c4oxEX",
      "display_url" : "goo.gl\/c4oxEX"
    } ]
  },
  "geo" : { },
  "id_str" : "768867876732370944",
  "text" : "Virtual Reality is Dead and Pok\u00E9mon Go Killed it. https:\/\/t.co\/5XfVHOu43O",
  "id" : 768867876732370944,
  "created_at" : "2016-08-25 17:49:21 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/1ZtjIFmLMm",
      "expanded_url" : "http:\/\/goo.gl\/OYCPPt",
      "display_url" : "goo.gl\/OYCPPt"
    } ]
  },
  "geo" : { },
  "id_str" : "768864295434260480",
  "text" : "Making life fair. https:\/\/t.co\/1ZtjIFmLMm",
  "id" : 768864295434260480,
  "created_at" : "2016-08-25 17:35:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/nhRcEmd7Z1",
      "expanded_url" : "http:\/\/goo.gl\/Rm8WGZ",
      "display_url" : "goo.gl\/Rm8WGZ"
    } ]
  },
  "geo" : { },
  "id_str" : "768863735880572928",
  "text" : "Russian scientists find the cure for homosexuality but the U..S. isn't interested. https:\/\/t.co\/nhRcEmd7Z1",
  "id" : 768863735880572928,
  "created_at" : "2016-08-25 17:32:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/jZ8sOgvBEO",
      "expanded_url" : "http:\/\/goo.gl\/H7Gmvq",
      "display_url" : "goo.gl\/H7Gmvq"
    } ]
  },
  "geo" : { },
  "id_str" : "768861623226425344",
  "text" : "Vortex Laser will save Moore's Law. https:\/\/t.co\/jZ8sOgvBEO",
  "id" : 768861623226425344,
  "created_at" : "2016-08-25 17:24:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/2Tlb6YEc7v",
      "expanded_url" : "http:\/\/goo.gl\/95dbSd",
      "display_url" : "goo.gl\/95dbSd"
    } ]
  },
  "geo" : { },
  "id_str" : "768825332015046656",
  "text" : "https:\/\/t.co\/2Tlb6YEc7v 10 solutions for climate change. Starts with fossil fuels. It is coal Virginia.",
  "id" : 768825332015046656,
  "created_at" : "2016-08-25 15:00:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768823459208130560",
  "text" : "With software or music like I'm in all you would have to watch out for are copyrights and patent infringement.And misuse of corporate funds.",
  "id" : 768823459208130560,
  "created_at" : "2016-08-25 14:52:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/F2qwbx46GD",
      "expanded_url" : "http:\/\/goo.gl\/AvjOqE",
      "display_url" : "goo.gl\/AvjOqE"
    } ]
  },
  "geo" : { },
  "id_str" : "768820639306223616",
  "text" : "LLC vs SCorp. LLC's can't sell stock thus can't use software assets. https:\/\/t.co\/F2qwbx46GD",
  "id" : 768820639306223616,
  "created_at" : "2016-08-25 14:41:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "indices" : [ 3, 17 ],
      "id_str" : "34554134",
      "id" : 34554134
    }, {
      "name" : "NASA NExSS",
      "screen_name" : "nexssinfo",
      "indices" : [ 93, 103 ],
      "id_str" : "3172405367",
      "id" : 3172405367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/aUnUCeaJEl",
      "expanded_url" : "http:\/\/buff.ly\/2bhS5Lj",
      "display_url" : "buff.ly\/2bhS5Lj"
    } ]
  },
  "geo" : { },
  "id_str" : "768817551174430721",
  "text" : "RT @SETIInstitute: Found: Our Nearest Exoplanet Neighbor - Proxima Centauri b | Many Worlds (@nexssinfo) https:\/\/t.co\/aUnUCeaJEl https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA NExSS",
        "screen_name" : "nexssinfo",
        "indices" : [ 74, 84 ],
        "id_str" : "3172405367",
        "id" : 3172405367
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SETIInstitute\/status\/768813941929676800\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/fHME5xPK1Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqtgNFhWAAAOENN.jpg",
        "id_str" : "768813939333398528",
        "id" : 768813939333398528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqtgNFhWAAAOENN.jpg",
        "sizes" : [ {
          "h" : 700,
          "resize" : "fit",
          "w" : 660
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 660
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 660
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 641
        } ],
        "display_url" : "pic.twitter.com\/fHME5xPK1Y"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/aUnUCeaJEl",
        "expanded_url" : "http:\/\/buff.ly\/2bhS5Lj",
        "display_url" : "buff.ly\/2bhS5Lj"
      } ]
    },
    "geo" : { },
    "id_str" : "768813941929676800",
    "text" : "Found: Our Nearest Exoplanet Neighbor - Proxima Centauri b | Many Worlds (@nexssinfo) https:\/\/t.co\/aUnUCeaJEl https:\/\/t.co\/fHME5xPK1Y",
    "id" : 768813941929676800,
    "created_at" : "2016-08-25 14:15:02 +0000",
    "user" : {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "protected" : false,
      "id_str" : "34554134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758705567556743168\/TGjZ9Uwf_normal.jpg",
      "id" : 34554134,
      "verified" : true
    }
  },
  "id" : 768817551174430721,
  "created_at" : "2016-08-25 14:29:22 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768816678796877825",
  "text" : "That dirty lawyer in Abingdon won't return my calls maybe if I get my manager to call he'll return hers.",
  "id" : 768816678796877825,
  "created_at" : "2016-08-25 14:25:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768810824710238208",
  "text" : "To use software assets for your business at the smallest level it does have to be a S-Corp and you will be able to but shares in an IRA(SEP)",
  "id" : 768810824710238208,
  "created_at" : "2016-08-25 14:02:39 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768578277078339584",
  "text" : "They are probably treating me like the Kurt Cobain of this town wanting me to commit suicide. Who's the Eddie Vedder shrink.",
  "id" : 768578277078339584,
  "created_at" : "2016-08-24 22:38:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 83, 91 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/sggOlUgdzX",
      "expanded_url" : "https:\/\/youtu.be\/7ImvlS8PLIo",
      "display_url" : "youtu.be\/7ImvlS8PLIo"
    } ]
  },
  "geo" : { },
  "id_str" : "768562885194817540",
  "text" : "'A Universe From Nothing' by Lawrence Krauss, AAI 2009 https:\/\/t.co\/sggOlUgdzX via @YouTube",
  "id" : 768562885194817540,
  "created_at" : "2016-08-24 21:37:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768556341615001601",
  "text" : "Bernnie the hospitals are calling for money. That's really the only  people that are giving me a hard time. It's either money or your life.",
  "id" : 768556341615001601,
  "created_at" : "2016-08-24 21:11:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Williams-Sonoma",
      "screen_name" : "WilliamsSonoma",
      "indices" : [ 3, 18 ],
      "id_str" : "29247574",
      "id" : 29247574
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WilliamsSonoma\/status\/768508426808885248\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/RaJov8gd7j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqpKVqDXgAgOut-.jpg",
      "id_str" : "768508422346211336",
      "id" : 768508422346211336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqpKVqDXgAgOut-.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 964
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 483,
        "resize" : "fit",
        "w" : 964
      }, {
        "h" : 483,
        "resize" : "fit",
        "w" : 964
      } ],
      "display_url" : "pic.twitter.com\/RaJov8gd7j"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/z6HjZVzYEa",
      "expanded_url" : "http:\/\/wsono.ma\/6018BNub2",
      "display_url" : "wsono.ma\/6018BNub2"
    } ]
  },
  "geo" : { },
  "id_str" : "768549679021907968",
  "text" : "RT @WilliamsSonoma: Heat wave? Don't sweat. Here's 6 no-cook dishes for summer: https:\/\/t.co\/z6HjZVzYEa https:\/\/t.co\/RaJov8gd7j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WilliamsSonoma\/status\/768508426808885248\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/RaJov8gd7j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqpKVqDXgAgOut-.jpg",
        "id_str" : "768508422346211336",
        "id" : 768508422346211336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqpKVqDXgAgOut-.jpg",
        "sizes" : [ {
          "h" : 483,
          "resize" : "fit",
          "w" : 964
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 483,
          "resize" : "fit",
          "w" : 964
        }, {
          "h" : 483,
          "resize" : "fit",
          "w" : 964
        } ],
        "display_url" : "pic.twitter.com\/RaJov8gd7j"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/z6HjZVzYEa",
        "expanded_url" : "http:\/\/wsono.ma\/6018BNub2",
        "display_url" : "wsono.ma\/6018BNub2"
      } ]
    },
    "geo" : { },
    "id_str" : "768508426808885248",
    "text" : "Heat wave? Don't sweat. Here's 6 no-cook dishes for summer: https:\/\/t.co\/z6HjZVzYEa https:\/\/t.co\/RaJov8gd7j",
    "id" : 768508426808885248,
    "created_at" : "2016-08-24 18:01:01 +0000",
    "user" : {
      "name" : "Williams-Sonoma",
      "screen_name" : "WilliamsSonoma",
      "protected" : false,
      "id_str" : "29247574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1148307110\/pineapple_normal.jpg",
      "id" : 29247574,
      "verified" : true
    }
  },
  "id" : 768549679021907968,
  "created_at" : "2016-08-24 20:44:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apple News",
      "screen_name" : "applenws",
      "indices" : [ 3, 12 ],
      "id_str" : "37019708",
      "id" : 37019708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/F3gRly6Urq",
      "expanded_url" : "http:\/\/applenws.com\/how-to-use-your-iphone-to-see-what-political-affiliation-facebook-thinks-you-have\/2016\/apple-insider",
      "display_url" : "applenws.com\/how-to-use-you\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768549210211901440",
  "text" : "RT @applenws: How to use your iPhone to see what political affiliation Facebook thinks you\u00A0have https:\/\/t.co\/F3gRly6Urq https:\/\/t.co\/sAJZBj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/applenws\/status\/768524016726396928\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/sAJZBjf4Ob",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqpYhMsUEAEjmwI.jpg",
        "id_str" : "768524013786107905",
        "id" : 768524013786107905,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqpYhMsUEAEjmwI.jpg",
        "sizes" : [ {
          "h" : 492,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 492,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 492,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 327,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/sAJZBjf4Ob"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/F3gRly6Urq",
        "expanded_url" : "http:\/\/applenws.com\/how-to-use-your-iphone-to-see-what-political-affiliation-facebook-thinks-you-have\/2016\/apple-insider",
        "display_url" : "applenws.com\/how-to-use-you\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768524016726396928",
    "text" : "How to use your iPhone to see what political affiliation Facebook thinks you\u00A0have https:\/\/t.co\/F3gRly6Urq https:\/\/t.co\/sAJZBjf4Ob",
    "id" : 768524016726396928,
    "created_at" : "2016-08-24 19:02:58 +0000",
    "user" : {
      "name" : "Apple News",
      "screen_name" : "applenws",
      "protected" : false,
      "id_str" : "37019708",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639785559225954304\/XtQnsHHI_normal.jpg",
      "id" : 37019708,
      "verified" : false
    }
  },
  "id" : 768549210211901440,
  "created_at" : "2016-08-24 20:43:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/PCKyke4RXG",
      "expanded_url" : "http:\/\/goo.gl\/GG0GeK",
      "display_url" : "goo.gl\/GG0GeK"
    } ]
  },
  "geo" : { },
  "id_str" : "768514989011439616",
  "text" : "https:\/\/t.co\/PCKyke4RXG Paying with plan assets. The IRS index of retirement plans. Please use as a reference only don't get into trouble.",
  "id" : 768514989011439616,
  "created_at" : "2016-08-24 18:27:06 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/uNlW42yhur",
      "expanded_url" : "http:\/\/goo.gl\/Vi0VXC",
      "display_url" : "goo.gl\/Vi0VXC"
    } ]
  },
  "geo" : { },
  "id_str" : "768512906916982785",
  "text" : "https:\/\/t.co\/uNlW42yhur Recycling plastic.",
  "id" : 768512906916982785,
  "created_at" : "2016-08-24 18:18:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768511369121521666",
  "text" : "I released and published my July album with Bandcamp and BMI called \"Ambient Moments Vol 1.\" Soon to be released by CDBaby. Next one soon.",
  "id" : 768511369121521666,
  "created_at" : "2016-08-24 18:12:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nature News&Comment",
      "screen_name" : "NatureNews",
      "indices" : [ 3, 14 ],
      "id_str" : "15862891",
      "id" : 15862891
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Proximab",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/VPIHQiw3mZ",
      "expanded_url" : "http:\/\/go.nature.com\/2c7gN3L",
      "display_url" : "go.nature.com\/2c7gN3L"
    } ]
  },
  "geo" : { },
  "id_str" : "768510183085641728",
  "text" : "RT @NatureNews: A guided tour of #Proximab, a potentially habitable world close enough for humans visit https:\/\/t.co\/VPIHQiw3mZ\nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Proximab",
        "indices" : [ 17, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/VPIHQiw3mZ",
        "expanded_url" : "http:\/\/go.nature.com\/2c7gN3L",
        "display_url" : "go.nature.com\/2c7gN3L"
      }, {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/uV6I7vbayg",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/4bf3f460-6d14-4be1-a291-bcebbf585f03",
        "display_url" : "amp.twimg.com\/v\/4bf3f460-6d1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768499673132699649",
    "text" : "A guided tour of #Proximab, a potentially habitable world close enough for humans visit https:\/\/t.co\/VPIHQiw3mZ\nhttps:\/\/t.co\/uV6I7vbayg",
    "id" : 768499673132699649,
    "created_at" : "2016-08-24 17:26:14 +0000",
    "user" : {
      "name" : "Nature News&Comment",
      "screen_name" : "NatureNews",
      "protected" : false,
      "id_str" : "15862891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1158019862\/nature-header.ed_normal.png",
      "id" : 15862891,
      "verified" : true
    }
  },
  "id" : 768510183085641728,
  "created_at" : "2016-08-24 18:08:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768509304756469761",
  "text" : "If more Americans bought American cars that would ease the shipping freight too. I have a Nissan but might buy American next.",
  "id" : 768509304756469761,
  "created_at" : "2016-08-24 18:04:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/kNKrnUPtiS",
      "expanded_url" : "http:\/\/goo.gl\/siUXrA",
      "display_url" : "goo.gl\/siUXrA"
    } ]
  },
  "geo" : { },
  "id_str" : "768507961392136192",
  "text" : "University of Michigan Reports That Cars are the Most Inefficient Form of Transportation. https:\/\/t.co\/kNKrnUPtiS  Stay on your computer.",
  "id" : 768507961392136192,
  "created_at" : "2016-08-24 17:59:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768501957438926848",
  "text" : "Walgreens lied to me about having flu shots when Prince died earlier this year. I am a BMI recording artist too.",
  "id" : 768501957438926848,
  "created_at" : "2016-08-24 17:35:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768499820596236288",
  "text" : "I can't get a lawyer to answer the phone about an S-Corp in Abingdon they all want me to go to jail when I'm in the right. LeagalZoom it is.",
  "id" : 768499820596236288,
  "created_at" : "2016-08-24 17:26:49 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768471964922937344",
  "text" : "When I went before a judge in Russel Co. for treatment I wasn't even given a chance to speak. They violated my human rights.",
  "id" : 768471964922937344,
  "created_at" : "2016-08-24 15:36:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768204673123778561",
  "text" : "I have to pay everyone to say hi.",
  "id" : 768204673123778561,
  "created_at" : "2016-08-23 21:54:01 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/alKVYsgP1h",
      "expanded_url" : "http:\/\/www.datacenterjournal.com\/some-data-centers-are-getting-smaller\/",
      "display_url" : "datacenterjournal.com\/some-data-cent\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768192881718796292",
  "text" : "https:\/\/t.co\/alKVYsgP1h Some data Centers are getting smaller.",
  "id" : 768192881718796292,
  "created_at" : "2016-08-23 21:07:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ggGAUILqiv",
      "expanded_url" : "http:\/\/www.datacenterknowledge.com\/archives\/2009\/12\/22\/the-data-crunching-powerhouse-behind-avatar\/",
      "display_url" : "datacenterknowledge.com\/archives\/2009\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768191547095515136",
  "text" : "https:\/\/t.co\/ggGAUILqiv Geek?",
  "id" : 768191547095515136,
  "created_at" : "2016-08-23 21:01:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768190348388470784",
  "text" : "One California wildfire last year leads to another California wildfire from drought and dead trees this year I go back to one arson case.",
  "id" : 768190348388470784,
  "created_at" : "2016-08-23 20:57:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768113794211913728",
  "text" : "I had a nice talk with my mom who died when I was 18. You may want to watch Blackstar by David Bowie and the movie Contact.",
  "id" : 768113794211913728,
  "created_at" : "2016-08-23 15:52:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768102712374333445",
  "text" : "Talk to Shakespeare Abingdon. All the world is a stage.",
  "id" : 768102712374333445,
  "created_at" : "2016-08-23 15:08:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768094948310781954",
  "text" : "Abingdon isn't really big enough for me . They do just want to put me in jail. I called 911 once and nobody showed.",
  "id" : 768094948310781954,
  "created_at" : "2016-08-23 14:38:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768090825481981952",
  "text" : "Those Cardinals stay hot don't they?",
  "id" : 768090825481981952,
  "created_at" : "2016-08-23 14:21:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jdm7dv\/status\/768064389417148416\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/v4ln0joXWf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqi2fa_XgAATP5-.jpg",
      "id_str" : "768064387403972608",
      "id" : 768064387403972608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqi2fa_XgAATP5-.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/v4ln0joXWf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768064389417148416",
  "text" : "https:\/\/t.co\/v4ln0joXWf",
  "id" : 768064389417148416,
  "created_at" : "2016-08-23 12:36:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768060488597008389",
  "text" : "Cardinals do mate for life.",
  "id" : 768060488597008389,
  "created_at" : "2016-08-23 12:21:05 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 78, 86 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/GPWYRjMvVF",
      "expanded_url" : "https:\/\/youtu.be\/sDHqywS6un0",
      "display_url" : "youtu.be\/sDHqywS6un0"
    } ]
  },
  "geo" : { },
  "id_str" : "768055617911132160",
  "text" : "Nine Inch Nails - Dead Souls (Joy Division cover) https:\/\/t.co\/GPWYRjMvVF via @YouTube",
  "id" : 768055617911132160,
  "created_at" : "2016-08-23 12:01:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768054946583437313",
  "text" : "I listen when I'm mad it's probably because the universe is as well. Those are needs even the smallest organism would tell you that.",
  "id" : 768054946583437313,
  "created_at" : "2016-08-23 11:59:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768053535841845248",
  "text" : "The universe is angry about unfair life If you want me to go deeper I can.",
  "id" : 768053535841845248,
  "created_at" : "2016-08-23 11:53:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/I5cfsIVpbe",
      "expanded_url" : "http:\/\/goo.gl\/Bc2kH6",
      "display_url" : "goo.gl\/Bc2kH6"
    } ]
  },
  "geo" : { },
  "id_str" : "768051679518461956",
  "text" : "Klotho gene variant found in 20% of the global population also found in Tuscany population where I'm from. https:\/\/t.co\/I5cfsIVpbe",
  "id" : 768051679518461956,
  "created_at" : "2016-08-23 11:46:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/t7AlHBeEKY",
      "expanded_url" : "http:\/\/goo.gl\/d1CV85",
      "display_url" : "goo.gl\/d1CV85"
    } ]
  },
  "geo" : { },
  "id_str" : "768043369671122944",
  "text" : "Could schizophrenia be proof that parallel universes actually exist?\nhttps:\/\/t.co\/t7AlHBeEKY",
  "id" : 768043369671122944,
  "created_at" : "2016-08-23 11:13:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/otc2hI4nNv",
      "expanded_url" : "https:\/\/goo.gl\/tTROsr",
      "display_url" : "goo.gl\/tTROsr"
    } ]
  },
  "geo" : { },
  "id_str" : "767836535827861504",
  "text" : "Dreams and the Many Worlds Interpretation of Quantum Physics. https:\/\/t.co\/otc2hI4nNv",
  "id" : 767836535827861504,
  "created_at" : "2016-08-22 21:31:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweepsmap.com\" rel=\"nofollow\"\u003ETweepsmap\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/32sB04i96I",
      "expanded_url" : "http:\/\/tweepsmap.com",
      "display_url" : "tweepsmap.com"
    } ]
  },
  "geo" : { },
  "id_str" : "767681875980742656",
  "text" : "Where in the world are your followers? Tweepsmap maps them by country, state or city.  https:\/\/t.co\/32sB04i96I",
  "id" : 767681875980742656,
  "created_at" : "2016-08-22 11:16:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Discover Magazine",
      "screen_name" : "DiscoverMag",
      "indices" : [ 0, 12 ],
      "id_str" : "23962323",
      "id" : 23962323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767474771026214912",
  "in_reply_to_user_id" : 23962323,
  "text" : "@DiscoverMag You really don't have it. The Singularity is old. And I'm not telling you.",
  "id" : 767474771026214912,
  "created_at" : "2016-08-21 21:33:39 +0000",
  "in_reply_to_screen_name" : "DiscoverMag",
  "in_reply_to_user_id_str" : "23962323",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Discover Magazine",
      "screen_name" : "DiscoverMag",
      "indices" : [ 0, 12 ],
      "id_str" : "23962323",
      "id" : 23962323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767472814907686912",
  "in_reply_to_user_id" : 23962323,
  "text" : "@DiscoverMag Bioviva is POPular now aren't they? There are better companies. I hate you.",
  "id" : 767472814907686912,
  "created_at" : "2016-08-21 21:25:52 +0000",
  "in_reply_to_screen_name" : "DiscoverMag",
  "in_reply_to_user_id_str" : "23962323",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Discover Magazine",
      "screen_name" : "DiscoverMag",
      "indices" : [ 0, 12 ],
      "id_str" : "23962323",
      "id" : 23962323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767472208419627008",
  "in_reply_to_user_id" : 23962323,
  "text" : "@DiscoverMag No matter what you do in the future you can never have my cloths or genetics I have klotho.",
  "id" : 767472208419627008,
  "created_at" : "2016-08-21 21:23:28 +0000",
  "in_reply_to_screen_name" : "DiscoverMag",
  "in_reply_to_user_id_str" : "23962323",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Discover Magazine",
      "screen_name" : "DiscoverMag",
      "indices" : [ 0, 12 ],
      "id_str" : "23962323",
      "id" : 23962323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767471597477330949",
  "in_reply_to_user_id" : 23962323,
  "text" : "@DiscoverMag I hate you.",
  "id" : 767471597477330949,
  "created_at" : "2016-08-21 21:21:02 +0000",
  "in_reply_to_screen_name" : "DiscoverMag",
  "in_reply_to_user_id_str" : "23962323",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767392605726470144",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne No matter what your man accomplishes he can never have the Klotho gene variant like me.",
  "id" : 767392605726470144,
  "created_at" : "2016-08-21 16:07:09 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aphex Twin",
      "screen_name" : "AphexTwin",
      "indices" : [ 0, 10 ],
      "id_str" : "178030441",
      "id" : 178030441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/b3Dypw1b0N",
      "expanded_url" : "http:\/\/www.willpirkle.com\/fx-book\/project-gallery\/#MOOG4",
      "display_url" : "willpirkle.com\/fx-book\/projec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767043670294065152",
  "in_reply_to_user_id" : 178030441,
  "text" : "@AphexTwin If you have or ever want to make a Stienberg VST here are some books.https:\/\/t.co\/b3Dypw1b0N",
  "id" : 767043670294065152,
  "created_at" : "2016-08-20 17:00:36 +0000",
  "in_reply_to_screen_name" : "AphexTwin",
  "in_reply_to_user_id_str" : "178030441",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/b3DypvJzCd",
      "expanded_url" : "http:\/\/www.willpirkle.com\/fx-book\/project-gallery\/#MOOG4",
      "display_url" : "willpirkle.com\/fx-book\/projec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767042695856394240",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor If you ever want to make or have made a VST check out these books and I'm looking for a Steinberg book https:\/\/t.co\/b3DypvJzCd",
  "id" : 767042695856394240,
  "created_at" : "2016-08-20 16:56:44 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/r7jQTckESt",
      "expanded_url" : "https:\/\/www.leakedsource.com\/main\/?email=jdm7dv@gmail.com",
      "display_url" : "leakedsource.com\/main\/?email=jd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766375332752437249",
  "text" : "https:\/\/t.co\/r7jQTckESt Adobe busted a UVa-Wise Student probably.",
  "id" : 766375332752437249,
  "created_at" : "2016-08-18 20:44:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vimeo",
      "screen_name" : "Vimeo",
      "indices" : [ 30, 36 ],
      "id_str" : "14718218",
      "id" : 14718218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/TplBkGK73J",
      "expanded_url" : "https:\/\/vimeo.com\/159101425",
      "display_url" : "vimeo.com\/159101425"
    } ]
  },
  "geo" : { },
  "id_str" : "764263592938143744",
  "text" : "Watch \u201CCRYENGINE 5 REVEAL\u201D on @Vimeo https:\/\/t.co\/TplBkGK73J",
  "id" : 764263592938143744,
  "created_at" : "2016-08-13 00:53:34 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/gJwZlbyUIM",
      "expanded_url" : "https:\/\/goo.gl\/ywBr3Z",
      "display_url" : "goo.gl\/ywBr3Z"
    } ]
  },
  "geo" : { },
  "id_str" : "762611113523572736",
  "text" : "https:\/\/t.co\/gJwZlbyUIM Fixed deposit maybe offshore.",
  "id" : 762611113523572736,
  "created_at" : "2016-08-08 11:27:12 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBM",
      "screen_name" : "IBM",
      "indices" : [ 3, 7 ],
      "id_str" : "18994444",
      "id" : 18994444
    }, {
      "name" : "Bloomberg",
      "screen_name" : "business",
      "indices" : [ 17, 26 ],
      "id_str" : "34713362",
      "id" : 34713362
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/IBM\/status\/762535911083028480\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/1aq7TON2Q0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpUSXkqVYAAKuQQ.jpg",
      "id_str" : "762535908096696320",
      "id" : 762535908096696320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpUSXkqVYAAKuQQ.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 454
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/1aq7TON2Q0"
    } ],
    "hashtags" : [ {
      "text" : "ICYMI",
      "indices" : [ 9, 15 ]
    }, {
      "text" : "AI",
      "indices" : [ 70, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/RkxInrkAc6",
      "expanded_url" : "http:\/\/bloom.bg\/2aTuYpF",
      "display_url" : "bloom.bg\/2aTuYpF"
    } ]
  },
  "geo" : { },
  "id_str" : "762573544995848192",
  "text" : "RT @IBM: #ICYMI: @business talks with Ginni Rometty about IBM's past, #AI and reinvention: https:\/\/t.co\/RkxInrkAc6 https:\/\/t.co\/1aq7TON2Q0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/percolate.com\" rel=\"nofollow\"\u003EPercolate\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bloomberg",
        "screen_name" : "business",
        "indices" : [ 8, 17 ],
        "id_str" : "34713362",
        "id" : 34713362
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IBM\/status\/762535911083028480\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/1aq7TON2Q0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpUSXkqVYAAKuQQ.jpg",
        "id_str" : "762535908096696320",
        "id" : 762535908096696320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpUSXkqVYAAKuQQ.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1366
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 454
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1366
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/1aq7TON2Q0"
      } ],
      "hashtags" : [ {
        "text" : "ICYMI",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "AI",
        "indices" : [ 61, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/RkxInrkAc6",
        "expanded_url" : "http:\/\/bloom.bg\/2aTuYpF",
        "display_url" : "bloom.bg\/2aTuYpF"
      } ]
    },
    "geo" : { },
    "id_str" : "762535911083028480",
    "text" : "#ICYMI: @business talks with Ginni Rometty about IBM's past, #AI and reinvention: https:\/\/t.co\/RkxInrkAc6 https:\/\/t.co\/1aq7TON2Q0",
    "id" : 762535911083028480,
    "created_at" : "2016-08-08 06:28:23 +0000",
    "user" : {
      "name" : "IBM",
      "screen_name" : "IBM",
      "protected" : false,
      "id_str" : "18994444",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614802024832610304\/_CZY2puL_normal.jpg",
      "id" : 18994444,
      "verified" : true
    }
  },
  "id" : 762573544995848192,
  "created_at" : "2016-08-08 08:57:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ZXM22qixjj",
      "expanded_url" : "https:\/\/bitbucket.org\/jdm7dv\/",
      "display_url" : "bitbucket.org\/jdm7dv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "762573200962248704",
  "text" : "https:\/\/t.co\/ZXM22qixjj My bitbucket has been active lately now that the album is out, some of my goals include ActionScript4 and Tamarin.",
  "id" : 762573200962248704,
  "created_at" : "2016-08-08 08:56:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "indices" : [ 3, 17 ],
      "id_str" : "34554134",
      "id" : 34554134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761973742260068352",
  "text" : "RT @SETIInstitute: Have you ever said: why don't those SETI researchers just...? We're listening -- send ideas for other approaches. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SETIInstitute\/status\/761971889359183872\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/vufFFKV18j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpMRZNdWYAAZGoC.jpg",
        "id_str" : "761971886762909696",
        "id" : 761971886762909696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpMRZNdWYAAZGoC.jpg",
        "sizes" : [ {
          "h" : 1440,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1440,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/vufFFKV18j"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761971889359183872",
    "text" : "Have you ever said: why don't those SETI researchers just...? We're listening -- send ideas for other approaches. https:\/\/t.co\/vufFFKV18j",
    "id" : 761971889359183872,
    "created_at" : "2016-08-06 17:07:09 +0000",
    "user" : {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "protected" : false,
      "id_str" : "34554134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758705567556743168\/TGjZ9Uwf_normal.jpg",
      "id" : 34554134,
      "verified" : true
    }
  },
  "id" : 761973742260068352,
  "created_at" : "2016-08-06 17:14:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761972140795109376",
  "text" : "I haven't used a printer in two years everything has been digital. I had to print out a document to write in my vote. Joe Donnelly",
  "id" : 761972140795109376,
  "created_at" : "2016-08-06 17:08:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 0, 15 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/72d22IpY1a",
      "expanded_url" : "http:\/\/www.jonathanmoore.net\/",
      "display_url" : "jonathanmoore.net"
    } ]
  },
  "geo" : { },
  "id_str" : "761954926062895104",
  "in_reply_to_user_id" : 1339835893,
  "text" : "@HillaryClinton https:\/\/t.co\/72d22IpY1a 4.0 GPA and I stutter. I'm pro life and against guns and have klotho. I'm voting for Joe Donnelly",
  "id" : 761954926062895104,
  "created_at" : "2016-08-06 15:59:45 +0000",
  "in_reply_to_screen_name" : "HillaryClinton",
  "in_reply_to_user_id_str" : "1339835893",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/dZbuS8bQGS",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Max_Planck",
      "display_url" : "en.wikipedia.org\/wiki\/Max_Planck"
    } ]
  },
  "geo" : { },
  "id_str" : "761927427123798016",
  "text" : "Max Karl Ernst Ludwig Planck https:\/\/t.co\/dZbuS8bQGS The father of quantum theory.",
  "id" : 761927427123798016,
  "created_at" : "2016-08-06 14:10:29 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/hBqq8hABMc",
      "expanded_url" : "http:\/\/goo.gl\/Tep9Fu",
      "display_url" : "goo.gl\/Tep9Fu"
    } ]
  },
  "geo" : { },
  "id_str" : "761925237063712769",
  "text" : "https:\/\/t.co\/hBqq8hABMc German innovations including the computer and quantum theory.",
  "id" : 761925237063712769,
  "created_at" : "2016-08-06 14:01:47 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761915690601308160",
  "text" : "I'm not giving ANY more blood until I get want I want a hot faithful wife and my money.",
  "id" : 761915690601308160,
  "created_at" : "2016-08-06 13:23:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/HuCi1D7koY",
      "expanded_url" : "https:\/\/www.amazon.com\/Russia-Love-Special-Sean-Connery\/dp\/B00004W9CA",
      "display_url" : "amazon.com\/Russia-Love-Sp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761914586530516992",
  "text" : "https:\/\/t.co\/HuCi1D7koY From Russia with love.",
  "id" : 761914586530516992,
  "created_at" : "2016-08-06 13:19:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/OwyV3nxy3f",
      "expanded_url" : "http:\/\/www.theictm.org\/",
      "display_url" : "theictm.org"
    } ]
  },
  "geo" : { },
  "id_str" : "761909618612301828",
  "text" : "https:\/\/t.co\/OwyV3nxy3f International council for truth and medicine. They've been covering up diabetes for 21 years.",
  "id" : 761909618612301828,
  "created_at" : "2016-08-06 12:59:43 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761900947627008000",
  "text" : "Last night I discovered I might (more than likely do) have the Klotho anti-aging hormone or gene. The test was done on Italians.",
  "id" : 761900947627008000,
  "created_at" : "2016-08-06 12:25:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dataiku",
      "screen_name" : "dataiku",
      "indices" : [ 3, 11 ],
      "id_str" : "816825631",
      "id" : 816825631
    }, {
      "name" : "Kirk Borne",
      "screen_name" : "KirkDBorne",
      "indices" : [ 97, 108 ],
      "id_str" : "534563976",
      "id" : 534563976
    }, {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "indices" : [ 113, 129 ],
      "id_str" : "393033324",
      "id" : 393033324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MachineLearning",
      "indices" : [ 20, 36 ]
    }, {
      "text" : "BigData",
      "indices" : [ 70, 78 ]
    }, {
      "text" : "DataScience",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/9j29OrYk0Z",
      "expanded_url" : "http:\/\/buff.ly\/2a4GQ7c",
      "display_url" : "buff.ly\/2a4GQ7c"
    } ]
  },
  "geo" : { },
  "id_str" : "761895723495456768",
  "text" : "RT @dataiku: 7 Free #MachineLearning Courses: https:\/\/t.co\/9j29OrYk0Z #BigData #DataScience | RT @KirkDBorne, by @DataScienceCtrl https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kirk Borne",
        "screen_name" : "KirkDBorne",
        "indices" : [ 84, 95 ],
        "id_str" : "534563976",
        "id" : 534563976
      }, {
        "name" : "Data Science Central",
        "screen_name" : "DataScienceCtrl",
        "indices" : [ 100, 116 ],
        "id_str" : "393033324",
        "id" : 393033324
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dataiku\/status\/758029334187798528\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/6m8eOOsgJS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoUPqOjWAAAU8zh.jpg",
        "id_str" : "758029330417057792",
        "id" : 758029330417057792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoUPqOjWAAAU8zh.jpg",
        "sizes" : [ {
          "h" : 445,
          "resize" : "fit",
          "w" : 455
        }, {
          "h" : 445,
          "resize" : "fit",
          "w" : 455
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 445,
          "resize" : "fit",
          "w" : 455
        }, {
          "h" : 445,
          "resize" : "fit",
          "w" : 455
        } ],
        "display_url" : "pic.twitter.com\/6m8eOOsgJS"
      } ],
      "hashtags" : [ {
        "text" : "MachineLearning",
        "indices" : [ 7, 23 ]
      }, {
        "text" : "BigData",
        "indices" : [ 57, 65 ]
      }, {
        "text" : "DataScience",
        "indices" : [ 66, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/9j29OrYk0Z",
        "expanded_url" : "http:\/\/buff.ly\/2a4GQ7c",
        "display_url" : "buff.ly\/2a4GQ7c"
      } ]
    },
    "geo" : { },
    "id_str" : "758029334187798528",
    "text" : "7 Free #MachineLearning Courses: https:\/\/t.co\/9j29OrYk0Z #BigData #DataScience | RT @KirkDBorne, by @DataScienceCtrl https:\/\/t.co\/6m8eOOsgJS",
    "id" : 758029334187798528,
    "created_at" : "2016-07-26 20:00:51 +0000",
    "user" : {
      "name" : "Dataiku",
      "screen_name" : "dataiku",
      "protected" : false,
      "id_str" : "816825631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703266586933764097\/Xy8eks2C_normal.jpg",
      "id" : 816825631,
      "verified" : true
    }
  },
  "id" : 761895723495456768,
  "created_at" : "2016-08-06 12:04:30 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 0, 11 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/OwyV3nxy3f",
      "expanded_url" : "http:\/\/www.theictm.org\/",
      "display_url" : "theictm.org"
    } ]
  },
  "geo" : { },
  "id_str" : "761758312622882816",
  "in_reply_to_user_id" : 30313925,
  "text" : "@WhiteHouse https:\/\/t.co\/OwyV3nxy3f The International Council for Truth in Medicine.",
  "id" : 761758312622882816,
  "created_at" : "2016-08-06 02:58:29 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761669708353511425",
  "text" : "I have a lot of VST's from my Digidesign days that now might be open. Not sure yet. That was around 2002-04.",
  "id" : 761669708353511425,
  "created_at" : "2016-08-05 21:06:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761667194749091840",
  "text" : "I called 911 once and the local cops didn't even show.",
  "id" : 761667194749091840,
  "created_at" : "2016-08-05 20:56:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761667014733758464",
  "text" : "SWVA doesn't even support their local music scene. My genre is new age\/ambient and I haven't even sold one album in two years.",
  "id" : 761667014733758464,
  "created_at" : "2016-08-05 20:55:42 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BMI",
      "indices" : [ 52, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/pYC2Uq0UPp",
      "expanded_url" : "http:\/\/spectator.org\/36923_deep-corruption-obama-justice-department\/",
      "display_url" : "spectator.org\/36923_deep-cor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761665846225797120",
  "text" : "https:\/\/t.co\/pYC2Uq0UPp Deep Corruption in the DOJ. #BMI",
  "id" : 761665846225797120,
  "created_at" : "2016-08-05 20:51:03 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/NF79Ttdutf",
      "expanded_url" : "http:\/\/www.express.co.uk\/news\/uk\/146138\/100-reasons-why-climate-change-is-natural",
      "display_url" : "express.co.uk\/news\/uk\/146138\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761664607593398272",
  "text" : "https:\/\/t.co\/NF79Ttdutf and it is natural I believe. A computer is better than a car, boat, truck or plane.",
  "id" : 761664607593398272,
  "created_at" : "2016-08-05 20:46:08 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/JjC2RoRkqG",
      "expanded_url" : "https:\/\/goo.gl\/021WWG",
      "display_url" : "goo.gl\/021WWG"
    } ]
  },
  "geo" : { },
  "id_str" : "761663952791212033",
  "text" : "https:\/\/t.co\/JjC2RoRkqG An article on the Guardian about climate change. I don't drive much. I can I just don't want the emissions.",
  "id" : 761663952791212033,
  "created_at" : "2016-08-05 20:43:32 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Verge",
      "screen_name" : "verge",
      "indices" : [ 62, 68 ],
      "id_str" : "275686563",
      "id" : 275686563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/ixlDGUqtBI",
      "expanded_url" : "http:\/\/www.theverge.com\/2013\/2\/5\/3955202\/why-amazon-wants-its-own-currency?utm_campaign=theverge&utm_content=article&utm_medium=social&utm_source=twitter",
      "display_url" : "theverge.com\/2013\/2\/5\/39552\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761011020483682304",
  "text" : "Why Amazon wants its own currency https:\/\/t.co\/ixlDGUqtBI via @verge",
  "id" : 761011020483682304,
  "created_at" : "2016-08-04 01:29:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/xjUV3Gkbea",
      "expanded_url" : "http:\/\/www.scientificamerican.com\/article\/how-coal-kills\/",
      "display_url" : "scientificamerican.com\/article\/how-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760119160995274753",
  "text" : "https:\/\/t.co\/xjUV3Gkbea Coal Kills",
  "id" : 760119160995274753,
  "created_at" : "2016-08-01 14:25:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/9I7Jxln8pj",
      "expanded_url" : "http:\/\/reports.weforum.org\/outlook-2013\/the-future-of-globalization\/",
      "display_url" : "reports.weforum.org\/outlook-2013\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760117195397529600",
  "text" : "https:\/\/t.co\/9I7Jxln8pj The future of globalization is increasing.",
  "id" : 760117195397529600,
  "created_at" : "2016-08-01 14:17:16 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760055472464461824",
  "text" : "Look at what humans have done to this earth. I'm not saying anything about the technology just their miss use of it.",
  "id" : 760055472464461824,
  "created_at" : "2016-08-01 10:12:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 64, 72 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/TwSpEJoSwU",
      "expanded_url" : "https:\/\/youtu.be\/qOhRZffHAw4",
      "display_url" : "youtu.be\/qOhRZffHAw4"
    } ]
  },
  "geo" : { },
  "id_str" : "760054406830297088",
  "text" : "Nine Inch Nails -  In This Twilight https:\/\/t.co\/TwSpEJoSwU via @YouTube",
  "id" : 760054406830297088,
  "created_at" : "2016-08-01 10:07:46 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 80, 88 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/pJxiawT42w",
      "expanded_url" : "https:\/\/youtu.be\/sK50So-yYRU",
      "display_url" : "youtu.be\/sK50So-yYRU"
    } ]
  },
  "geo" : { },
  "id_str" : "760053685313470464",
  "text" : "Explosive Demolition- 2002 Best Building Implosions https:\/\/t.co\/pJxiawT42w via @YouTube",
  "id" : 760053685313470464,
  "created_at" : "2016-08-01 10:04:54 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760046647317565440",
  "text" : "I really don't know why they keep insisting to keep up to date to get the hot girl, It is just game theory and economics too. And I hate it.",
  "id" : 760046647317565440,
  "created_at" : "2016-08-01 09:36:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760045927453294593",
  "text" : "There really isn't anything after social media, but gamifacation and back to developing your own talents.",
  "id" : 760045927453294593,
  "created_at" : "2016-08-01 09:34:04 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBM Research",
      "screen_name" : "IBMResearch",
      "indices" : [ 3, 15 ],
      "id_str" : "16319797",
      "id" : 16319797
    }, {
      "name" : "Alessandro Curioni",
      "screen_name" : "Ale_Curioni",
      "indices" : [ 91, 103 ],
      "id_str" : "1176836821",
      "id" : 1176836821
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VintageElectronics",
      "indices" : [ 18, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/8WmLT9Wlz5",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BIUGzAPjC_c\/",
      "display_url" : "instagram.com\/p\/BIUGzAPjC_c\/"
    } ]
  },
  "geo" : { },
  "id_str" : "760045256222076928",
  "text" : "RT @IBMResearch: \"#VintageElectronics, in my opinion, show craftsmanship of a classic car\" @Ale_Curioni https:\/\/t.co\/8WmLT9Wlz5 https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/percolate.com\" rel=\"nofollow\"\u003EPercolate\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alessandro Curioni",
        "screen_name" : "Ale_Curioni",
        "indices" : [ 74, 86 ],
        "id_str" : "1176836821",
        "id" : 1176836821
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IBMResearch\/status\/759706964347658240\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/3EIfZZpZgO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CosFdGoUsAAT5e3.jpg",
        "id_str" : "759706959696146432",
        "id" : 759706959696146432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CosFdGoUsAAT5e3.jpg",
        "sizes" : [ {
          "h" : 554,
          "resize" : "fit",
          "w" : 601
        }, {
          "h" : 554,
          "resize" : "fit",
          "w" : 601
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 554,
          "resize" : "fit",
          "w" : 601
        }, {
          "h" : 554,
          "resize" : "fit",
          "w" : 601
        } ],
        "display_url" : "pic.twitter.com\/3EIfZZpZgO"
      } ],
      "hashtags" : [ {
        "text" : "VintageElectronics",
        "indices" : [ 1, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/8WmLT9Wlz5",
        "expanded_url" : "https:\/\/www.instagram.com\/p\/BIUGzAPjC_c\/",
        "display_url" : "instagram.com\/p\/BIUGzAPjC_c\/"
      } ]
    },
    "geo" : { },
    "id_str" : "759706964347658240",
    "text" : "\"#VintageElectronics, in my opinion, show craftsmanship of a classic car\" @Ale_Curioni https:\/\/t.co\/8WmLT9Wlz5 https:\/\/t.co\/3EIfZZpZgO",
    "id" : 759706964347658240,
    "created_at" : "2016-07-31 11:07:09 +0000",
    "user" : {
      "name" : "IBM Research",
      "screen_name" : "IBMResearch",
      "protected" : false,
      "id_str" : "16319797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2453018418\/fn1i02hac59i02ccd9c1_normal.jpeg",
      "id" : 16319797,
      "verified" : true
    }
  },
  "id" : 760045256222076928,
  "created_at" : "2016-08-01 09:31:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "indices" : [ 3, 10 ],
      "id_str" : "17471979",
      "id" : 17471979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/CXnC9UHfxc",
      "expanded_url" : "http:\/\/on.natgeo.com\/2aTLW6r",
      "display_url" : "on.natgeo.com\/2aTLW6r"
    } ]
  },
  "geo" : { },
  "id_str" : "760045047861608448",
  "text" : "RT @NatGeo: How can so many sharks exist in a place where there isn\u2019t enough prey?\nhttps:\/\/t.co\/CXnC9UHfxc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/CXnC9UHfxc",
        "expanded_url" : "http:\/\/on.natgeo.com\/2aTLW6r",
        "display_url" : "on.natgeo.com\/2aTLW6r"
      } ]
    },
    "geo" : { },
    "id_str" : "759747967721021440",
    "text" : "How can so many sharks exist in a place where there isn\u2019t enough prey?\nhttps:\/\/t.co\/CXnC9UHfxc",
    "id" : 759747967721021440,
    "created_at" : "2016-07-31 13:50:05 +0000",
    "user" : {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "protected" : false,
      "id_str" : "17471979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798181194202566656\/U8QbCBdH_normal.jpg",
      "id" : 17471979,
      "verified" : true
    }
  },
  "id" : 760045047861608448,
  "created_at" : "2016-08-01 09:30:35 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moog Synthesizers",
      "screen_name" : "moogmusicinc",
      "indices" : [ 3, 16 ],
      "id_str" : "26779967",
      "id" : 26779967
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moogmusicinc\/status\/758303570752073728\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/fH8VjyeNwB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoYJELoWcAAahnV.jpg",
      "id_str" : "758303554704666624",
      "id" : 758303554704666624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoYJELoWcAAahnV.jpg",
      "sizes" : [ {
        "h" : 456,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 730
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 730
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 730
      } ],
      "display_url" : "pic.twitter.com\/fH8VjyeNwB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/T5OuWBN9Ta",
      "expanded_url" : "http:\/\/www.moogmusic.com\/products\/clothing\/its-alive-tee",
      "display_url" : "moogmusic.com\/products\/cloth\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760044940432990208",
  "text" : "RT @moogmusicinc: We are the robots.\n\nhttps:\/\/t.co\/T5OuWBN9Ta https:\/\/t.co\/fH8VjyeNwB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/moogmusicinc\/status\/758303570752073728\/photo\/1",
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/fH8VjyeNwB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoYJELoWcAAahnV.jpg",
        "id_str" : "758303554704666624",
        "id" : 758303554704666624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoYJELoWcAAahnV.jpg",
        "sizes" : [ {
          "h" : 456,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 730
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 730
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 730
        } ],
        "display_url" : "pic.twitter.com\/fH8VjyeNwB"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/T5OuWBN9Ta",
        "expanded_url" : "http:\/\/www.moogmusic.com\/products\/clothing\/its-alive-tee",
        "display_url" : "moogmusic.com\/products\/cloth\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758303570752073728",
    "text" : "We are the robots.\n\nhttps:\/\/t.co\/T5OuWBN9Ta https:\/\/t.co\/fH8VjyeNwB",
    "id" : 758303570752073728,
    "created_at" : "2016-07-27 14:10:34 +0000",
    "user" : {
      "name" : "Moog Synthesizers",
      "screen_name" : "moogmusicinc",
      "protected" : false,
      "id_str" : "26779967",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736287958584721409\/JcZWLecp_normal.jpg",
      "id" : 26779967,
      "verified" : true
    }
  },
  "id" : 760044940432990208,
  "created_at" : "2016-08-01 09:30:09 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 79, 87 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/GkVzIMN7Lh",
      "expanded_url" : "https:\/\/youtu.be\/LcXDn7Hr2gM",
      "display_url" : "youtu.be\/LcXDn7Hr2gM"
    } ]
  },
  "geo" : { },
  "id_str" : "760043504034836481",
  "text" : "Trent Reznor and Atticus Ross - Juno [Music Video] https:\/\/t.co\/GkVzIMN7Lh via @YouTube via NAsa",
  "id" : 760043504034836481,
  "created_at" : "2016-08-01 09:24:26 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 3, 10 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmazonSweepstakes",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/i2lmTZWN3Y",
      "expanded_url" : "http:\/\/amzn.to\/2aoozE5",
      "display_url" : "amzn.to\/2aoozE5"
    }, {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/ZLUkfhTE5Q",
      "expanded_url" : "http:\/\/amzn.to\/2aooLTL",
      "display_url" : "amzn.to\/2aooLTL"
    } ]
  },
  "geo" : { },
  "id_str" : "760043252879876097",
  "text" : "RT @amazon: Follow &amp; RT for a chance to win this book: https:\/\/t.co\/i2lmTZWN3Y Rules: https:\/\/t.co\/ZLUkfhTE5Q #AmazonSweepstakes https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/amazon\/status\/759755499915120640\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/5Dafaoz2nd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CosxmWCWEAAHymZ.jpg",
        "id_str" : "759755496962265088",
        "id" : 759755496962265088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CosxmWCWEAAHymZ.jpg",
        "sizes" : [ {
          "h" : 290,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/5Dafaoz2nd"
      } ],
      "hashtags" : [ {
        "text" : "AmazonSweepstakes",
        "indices" : [ 102, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/i2lmTZWN3Y",
        "expanded_url" : "http:\/\/amzn.to\/2aoozE5",
        "display_url" : "amzn.to\/2aoozE5"
      }, {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/ZLUkfhTE5Q",
        "expanded_url" : "http:\/\/amzn.to\/2aooLTL",
        "display_url" : "amzn.to\/2aooLTL"
      } ]
    },
    "geo" : { },
    "id_str" : "759755499915120640",
    "text" : "Follow &amp; RT for a chance to win this book: https:\/\/t.co\/i2lmTZWN3Y Rules: https:\/\/t.co\/ZLUkfhTE5Q #AmazonSweepstakes https:\/\/t.co\/5Dafaoz2nd",
    "id" : 759755499915120640,
    "created_at" : "2016-07-31 14:20:01 +0000",
    "user" : {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "protected" : false,
      "id_str" : "20793816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786252488223580160\/9-Lwv1sI_normal.jpg",
      "id" : 20793816,
      "verified" : true
    }
  },
  "id" : 760043252879876097,
  "created_at" : "2016-08-01 09:23:27 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBM Big Data",
      "screen_name" : "IBMBigData",
      "indices" : [ 3, 14 ],
      "id_str" : "267283568",
      "id" : 267283568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MachineLearning",
      "indices" : [ 16, 32 ]
    }, {
      "text" : "datascience",
      "indices" : [ 70, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/10DCkuwDT8",
      "expanded_url" : "http:\/\/bit.ly\/2ajkoHv",
      "display_url" : "bit.ly\/2ajkoHv"
    } ]
  },
  "geo" : { },
  "id_str" : "760043121703063552",
  "text" : "RT @IBMbigdata: #MachineLearning has become part and parcel of modern #datascience https:\/\/t.co\/10DCkuwDT8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dynamicsignal.com\/\" rel=\"nofollow\"\u003EVoiceStorm\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MachineLearning",
        "indices" : [ 0, 16 ]
      }, {
        "text" : "datascience",
        "indices" : [ 54, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/10DCkuwDT8",
        "expanded_url" : "http:\/\/bit.ly\/2ajkoHv",
        "display_url" : "bit.ly\/2ajkoHv"
      } ]
    },
    "geo" : { },
    "id_str" : "759773647837929473",
    "text" : "#MachineLearning has become part and parcel of modern #datascience https:\/\/t.co\/10DCkuwDT8",
    "id" : 759773647837929473,
    "created_at" : "2016-07-31 15:32:08 +0000",
    "user" : {
      "name" : "IBM Big Data",
      "screen_name" : "IBMBigData",
      "protected" : false,
      "id_str" : "267283568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795689250129899520\/teG0s8AW_normal.jpg",
      "id" : 267283568,
      "verified" : true
    }
  },
  "id" : 760043121703063552,
  "created_at" : "2016-08-01 09:22:55 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/eiQW8rxemN",
      "expanded_url" : "http:\/\/go.nasa.gov\/2arPnQo",
      "display_url" : "go.nasa.gov\/2arPnQo"
    } ]
  },
  "geo" : { },
  "id_str" : "760042793809182720",
  "text" : "RT @NASA: Milestone! Our Solar Probe Plus mission moves one step closer to its summer 2018 launch: https:\/\/t.co\/eiQW8rxemN https:\/\/t.co\/8db\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/759888123316887552\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/8dbwghAkXM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CouqOCnWIAA5NeT.jpg",
        "id_str" : "759888120338849792",
        "id" : 759888120338849792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CouqOCnWIAA5NeT.jpg",
        "sizes" : [ {
          "h" : 487,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/8dbwghAkXM"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/eiQW8rxemN",
        "expanded_url" : "http:\/\/go.nasa.gov\/2arPnQo",
        "display_url" : "go.nasa.gov\/2arPnQo"
      } ]
    },
    "geo" : { },
    "id_str" : "759888123316887552",
    "text" : "Milestone! Our Solar Probe Plus mission moves one step closer to its summer 2018 launch: https:\/\/t.co\/eiQW8rxemN https:\/\/t.co\/8dbwghAkXM",
    "id" : 759888123316887552,
    "created_at" : "2016-07-31 23:07:01 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 760042793809182720,
  "created_at" : "2016-08-01 09:21:37 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760042394033254400",
  "text" : "All these doctors do have are babies and sex.",
  "id" : 760042394033254400,
  "created_at" : "2016-08-01 09:20:02 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Short",
      "screen_name" : "GregShort302",
      "indices" : [ 3, 16 ],
      "id_str" : "4776547780",
      "id" : 4776547780
    }, {
      "name" : "Propellerhead",
      "screen_name" : "PropellerheadSW",
      "indices" : [ 75, 91 ],
      "id_str" : "22631376",
      "id" : 22631376
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GregShort302\/status\/759204339869253632\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/ziVzYkx3dP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cok8UUcWcAA_9dh.jpg",
      "id_str" : "759204331971309568",
      "id" : 759204331971309568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cok8UUcWcAA_9dh.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/ziVzYkx3dP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760042095897899008",
  "text" : "RT @GregShort302: Andrews Chord! Love this sound added my own tweaks to it @PropellerheadSW \uD83C\uDFB6\uD83D\uDC42\uD83D\uDC40\uD83D\uDE4C reasons 9\uD83D\uDD25 https:\/\/t.co\/ziVzYkx3dP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Propellerhead",
        "screen_name" : "PropellerheadSW",
        "indices" : [ 57, 73 ],
        "id_str" : "22631376",
        "id" : 22631376
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GregShort302\/status\/759204339869253632\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/ziVzYkx3dP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cok8UUcWcAA_9dh.jpg",
        "id_str" : "759204331971309568",
        "id" : 759204331971309568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cok8UUcWcAA_9dh.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/ziVzYkx3dP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "759204339869253632",
    "text" : "Andrews Chord! Love this sound added my own tweaks to it @PropellerheadSW \uD83C\uDFB6\uD83D\uDC42\uD83D\uDC40\uD83D\uDE4C reasons 9\uD83D\uDD25 https:\/\/t.co\/ziVzYkx3dP",
    "id" : 759204339869253632,
    "created_at" : "2016-07-30 01:49:54 +0000",
    "user" : {
      "name" : "Greg Short",
      "screen_name" : "GregShort302",
      "protected" : false,
      "id_str" : "4776547780",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764876537359400960\/lPGrVFID_normal.jpg",
      "id" : 4776547780,
      "verified" : false
    }
  },
  "id" : 760042095897899008,
  "created_at" : "2016-08-01 09:18:51 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/4ZHCFMZFmx",
      "expanded_url" : "http:\/\/goo.gl\/twP4v9",
      "display_url" : "goo.gl\/twP4v9"
    } ]
  },
  "geo" : { },
  "id_str" : "760040110062706688",
  "text" : "https:\/\/t.co\/4ZHCFMZFmx It really doesn't matter who wins the election the federal government does next to nothing.",
  "id" : 760040110062706688,
  "created_at" : "2016-08-01 09:10:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]