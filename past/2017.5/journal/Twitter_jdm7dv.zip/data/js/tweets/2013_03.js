Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GOOD",
      "screen_name" : "good",
      "indices" : [ 3, 8 ],
      "id_str" : "19621110",
      "id" : 19621110
    }, {
      "name" : "Architizer",
      "screen_name" : "Architizer",
      "indices" : [ 65, 76 ],
      "id_str" : "51040617",
      "id" : 51040617
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "architecure",
      "indices" : [ 77, 89 ]
    }, {
      "text" : "goodcitizen",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/WuQFz41eQi",
      "expanded_url" : "http:\/\/bit.ly\/YjBlVZ",
      "display_url" : "bit.ly\/YjBlVZ"
    } ]
  },
  "geo" : { },
  "id_str" : "312252344047923200",
  "text" : "RT @GOOD: 10 modern museums that (Nearly) upstage the art inside @architizer #architecure #goodcitizen http:\/\/t.co\/WuQFz41eQi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.good.is\" rel=\"nofollow\"\u003EGOOD\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Architizer",
        "screen_name" : "Architizer",
        "indices" : [ 55, 66 ],
        "id_str" : "51040617",
        "id" : 51040617
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "architecure",
        "indices" : [ 67, 79 ]
      }, {
        "text" : "goodcitizen",
        "indices" : [ 80, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/WuQFz41eQi",
        "expanded_url" : "http:\/\/bit.ly\/YjBlVZ",
        "display_url" : "bit.ly\/YjBlVZ"
      } ]
    },
    "geo" : { },
    "id_str" : "311606283197358080",
    "text" : "10 modern museums that (Nearly) upstage the art inside @architizer #architecure #goodcitizen http:\/\/t.co\/WuQFz41eQi",
    "id" : 311606283197358080,
    "created_at" : "2013-03-12 22:35:01 +0000",
    "user" : {
      "name" : "GOOD",
      "screen_name" : "good",
      "protected" : false,
      "id_str" : "19621110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788475811498110976\/oKQWUsAP_normal.jpg",
      "id" : 19621110,
      "verified" : true
    }
  },
  "id" : 312252344047923200,
  "created_at" : "2013-03-14 17:22:14 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OkCupid",
      "screen_name" : "okcupid",
      "indices" : [ 90, 98 ],
      "id_str" : "53543144",
      "id" : 53543144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/wj5BH3jlph",
      "expanded_url" : "http:\/\/www.okcupid.com\/tests\/the-masculine-feminine-test",
      "display_url" : "okcupid.com\/tests\/the-masc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312209834672013314",
  "text" : "I got Ying Yang on the The Masculine\/Feminine Test at OkCupid. http:\/\/t.co\/wj5BH3jlph via @OkCupid",
  "id" : 312209834672013314,
  "created_at" : "2013-03-14 14:33:19 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PGbDabdn6n",
      "expanded_url" : "http:\/\/www.planetaryresources.com\/",
      "display_url" : "planetaryresources.com"
    } ]
  },
  "geo" : { },
  "id_str" : "312191411200081920",
  "text" : "http:\/\/t.co\/PGbDabdn6n",
  "id" : 312191411200081920,
  "created_at" : "2013-03-14 13:20:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]