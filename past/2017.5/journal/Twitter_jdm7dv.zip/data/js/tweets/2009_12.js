Grailbird.data.tweets_2009_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "victorgaudioso",
      "screen_name" : "victorgaudioso",
      "indices" : [ 3, 18 ],
      "id_str" : "18006495",
      "id" : 18006495
    }, {
      "name" : "WynApse",
      "screen_name" : "WynApse",
      "indices" : [ 25, 33 ],
      "id_str" : "10728852",
      "id" : 10728852
    }, {
      "name" : "paul emilio yanez",
      "screen_name" : "PaulYanez",
      "indices" : [ 34, 44 ],
      "id_str" : "2948620990",
      "id" : 2948620990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6420272673",
  "text" : "RT @victorgaudioso: Hey  @WynApse @paulyanez you should check out these good SL video tutorials by Paul for the Silveright Cream: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WynApse",
        "screen_name" : "WynApse",
        "indices" : [ 5, 13 ],
        "id_str" : "10728852",
        "id" : 10728852
      }, {
        "name" : "paul emilio yanez",
        "screen_name" : "PaulYanez",
        "indices" : [ 14, 24 ],
        "id_str" : "2948620990",
        "id" : 2948620990
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6419673059",
    "text" : "Hey  @WynApse @paulyanez you should check out these good SL video tutorials by Paul for the Silveright Cream: http:\/\/tw0.us\/5T3 he's good",
    "id" : 6419673059,
    "created_at" : "2009-12-07 03:23:18 +0000",
    "user" : {
      "name" : "victorgaudioso",
      "screen_name" : "victorgaudioso",
      "protected" : false,
      "id_str" : "18006495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1096447480\/victorgaudioso_normal.jpg",
      "id" : 18006495,
      "verified" : false
    }
  },
  "id" : 6420272673,
  "created_at" : "2009-12-07 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]