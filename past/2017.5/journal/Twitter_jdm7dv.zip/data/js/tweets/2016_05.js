Grailbird.data.tweets_2016_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/fk94QtEuvV",
      "expanded_url" : "http:\/\/a.msn.com\/05\/en-us\/BBty3pA?ocid=st",
      "display_url" : "a.msn.com\/05\/en-us\/BBty3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736411159348273152",
  "text" : "Cellphone-Cancer Link Found in Government Study https:\/\/t.co\/fk94QtEuvV",
  "id" : 736411159348273152,
  "created_at" : "2016-05-28 04:17:56 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IEEE",
      "screen_name" : "IEEEorg",
      "indices" : [ 3, 11 ],
      "id_str" : "54290504",
      "id" : 54290504
    }, {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 108, 117 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Google",
      "indices" : [ 13, 20 ]
    }, {
      "text" : "selfdrivingcar",
      "indices" : [ 63, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Uv2jQadmjJ",
      "expanded_url" : "http:\/\/on.mash.to\/22dz26W",
      "display_url" : "on.mash.to\/22dz26W"
    } ]
  },
  "geo" : { },
  "id_str" : "732214150420697092",
  "text" : "RT @IEEEorg: #Google is paying people $20 USD to 'drive' their #selfdrivingcar: https:\/\/t.co\/Uv2jQadmjJ via @mashable",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mashable",
        "screen_name" : "mashable",
        "indices" : [ 95, 104 ],
        "id_str" : "972651",
        "id" : 972651
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Google",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "selfdrivingcar",
        "indices" : [ 50, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/Uv2jQadmjJ",
        "expanded_url" : "http:\/\/on.mash.to\/22dz26W",
        "display_url" : "on.mash.to\/22dz26W"
      } ]
    },
    "geo" : { },
    "id_str" : "732212511592742914",
    "text" : "#Google is paying people $20 USD to 'drive' their #selfdrivingcar: https:\/\/t.co\/Uv2jQadmjJ via @mashable",
    "id" : 732212511592742914,
    "created_at" : "2016-05-16 14:14:01 +0000",
    "user" : {
      "name" : "IEEE",
      "screen_name" : "IEEEorg",
      "protected" : false,
      "id_str" : "54290504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474591466749034496\/2-H1zqWf_normal.jpeg",
      "id" : 54290504,
      "verified" : false
    }
  },
  "id" : 732214150420697092,
  "created_at" : "2016-05-16 14:20:31 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "indices" : [ 3, 17 ],
      "id_str" : "34554134",
      "id" : 34554134
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SETIInstitute\/status\/732165707270619136\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/3FxHSluMJr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ciks1MyW0AA_as2.jpg",
      "id_str" : "732165706901540864",
      "id" : 732165706901540864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ciks1MyW0AA_as2.jpg",
      "sizes" : [ {
        "h" : 829,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 829,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3FxHSluMJr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/JmFuT1TI15",
      "expanded_url" : "http:\/\/buff.ly\/1sqDCTl",
      "display_url" : "buff.ly\/1sqDCTl"
    } ]
  },
  "geo" : { },
  "id_str" : "732213654565834754",
  "text" : "RT @SETIInstitute: APOD: 2016 May 16 - Clouds of the Carina Nebula https:\/\/t.co\/JmFuT1TI15 https:\/\/t.co\/3FxHSluMJr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SETIInstitute\/status\/732165707270619136\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/3FxHSluMJr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ciks1MyW0AA_as2.jpg",
        "id_str" : "732165706901540864",
        "id" : 732165706901540864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ciks1MyW0AA_as2.jpg",
        "sizes" : [ {
          "h" : 829,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 829,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 518,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3FxHSluMJr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/JmFuT1TI15",
        "expanded_url" : "http:\/\/buff.ly\/1sqDCTl",
        "display_url" : "buff.ly\/1sqDCTl"
      } ]
    },
    "geo" : { },
    "id_str" : "732165707270619136",
    "text" : "APOD: 2016 May 16 - Clouds of the Carina Nebula https:\/\/t.co\/JmFuT1TI15 https:\/\/t.co\/3FxHSluMJr",
    "id" : 732165707270619136,
    "created_at" : "2016-05-16 11:08:02 +0000",
    "user" : {
      "name" : "The SETI Institute",
      "screen_name" : "SETIInstitute",
      "protected" : false,
      "id_str" : "34554134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758705567556743168\/TGjZ9Uwf_normal.jpg",
      "id" : 34554134,
      "verified" : true
    }
  },
  "id" : 732213654565834754,
  "created_at" : "2016-05-16 14:18:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Propellerhead",
      "screen_name" : "PropellerheadSW",
      "indices" : [ 3, 19 ],
      "id_str" : "22631376",
      "id" : 22631376
    }, {
      "name" : "AirRaid Audio",
      "screen_name" : "AirRaidAudio",
      "indices" : [ 61, 74 ],
      "id_str" : "2549776159",
      "id" : 2549776159
    }, {
      "name" : "Reasonistas",
      "screen_name" : "reasonistas",
      "indices" : [ 90, 102 ],
      "id_str" : "555686509",
      "id" : 555686509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/oilRJTS913",
      "expanded_url" : "http:\/\/reasonistas.wix.com\/reasonistas#!Reasonistas-Interviews-AirRaid-Audio\/d3qv9\/572a49bf0cf28b370be43692",
      "display_url" : "reasonistas.wix.com\/reasonistas#!R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732213413171085312",
  "text" : "RT @PropellerheadSW: Curious about the Rack Extension makers @AirRaidAudio? Check out the @reasonistas interview  https:\/\/t.co\/oilRJTS913 h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AirRaid Audio",
        "screen_name" : "AirRaidAudio",
        "indices" : [ 40, 53 ],
        "id_str" : "2549776159",
        "id" : 2549776159
      }, {
        "name" : "Reasonistas",
        "screen_name" : "reasonistas",
        "indices" : [ 69, 81 ],
        "id_str" : "555686509",
        "id" : 555686509
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PropellerheadSW\/status\/731944888070197249\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/DiU1tz4eXZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cihj_1MXEAA1aww.jpg",
        "id_str" : "731944887709536256",
        "id" : 731944887709536256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cihj_1MXEAA1aww.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 495,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 187,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 495,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/DiU1tz4eXZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/oilRJTS913",
        "expanded_url" : "http:\/\/reasonistas.wix.com\/reasonistas#!Reasonistas-Interviews-AirRaid-Audio\/d3qv9\/572a49bf0cf28b370be43692",
        "display_url" : "reasonistas.wix.com\/reasonistas#!R\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "731944888070197249",
    "text" : "Curious about the Rack Extension makers @AirRaidAudio? Check out the @reasonistas interview  https:\/\/t.co\/oilRJTS913 https:\/\/t.co\/DiU1tz4eXZ",
    "id" : 731944888070197249,
    "created_at" : "2016-05-15 20:30:34 +0000",
    "user" : {
      "name" : "Propellerhead",
      "screen_name" : "PropellerheadSW",
      "protected" : false,
      "id_str" : "22631376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558288234363367424\/qChNU38G_normal.png",
      "id" : 22631376,
      "verified" : true
    }
  },
  "id" : 732213413171085312,
  "created_at" : "2016-05-16 14:17:36 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Google Car",
      "screen_name" : "thegooglecar",
      "indices" : [ 3, 16 ],
      "id_str" : "575310592",
      "id" : 575310592
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "technews",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/QH6T0zzL9Q",
      "expanded_url" : "http:\/\/dlvr.it\/LKNhP2",
      "display_url" : "dlvr.it\/LKNhP2"
    } ]
  },
  "geo" : { },
  "id_str" : "732213200360493056",
  "text" : "RT @thegooglecar: Technology: GCHQ intelligence agency joins Twitter https:\/\/t.co\/QH6T0zzL9Q #technews",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "technews",
        "indices" : [ 75, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/QH6T0zzL9Q",
        "expanded_url" : "http:\/\/dlvr.it\/LKNhP2",
        "display_url" : "dlvr.it\/LKNhP2"
      } ]
    },
    "geo" : { },
    "id_str" : "732173797474738176",
    "text" : "Technology: GCHQ intelligence agency joins Twitter https:\/\/t.co\/QH6T0zzL9Q #technews",
    "id" : 732173797474738176,
    "created_at" : "2016-05-16 11:40:11 +0000",
    "user" : {
      "name" : "The Google Car",
      "screen_name" : "thegooglecar",
      "protected" : false,
      "id_str" : "575310592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2211469309\/OhKoo_hroBK-MC9LHPQ2vTl72eJkfbmt4t8yenImKBVaiQDB_Rd1H6kmuBWtceBJ_normal.jpg",
      "id" : 575310592,
      "verified" : false
    }
  },
  "id" : 732213200360493056,
  "created_at" : "2016-05-16 14:16:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBM Watson",
      "screen_name" : "IBMWatson",
      "indices" : [ 3, 13 ],
      "id_str" : "29735775",
      "id" : 29735775
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HackDisrupt",
      "indices" : [ 53, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/2TWpjuUbZO",
      "expanded_url" : "http:\/\/ibm.co\/1shVqju",
      "display_url" : "ibm.co\/1shVqju"
    } ]
  },
  "geo" : { },
  "id_str" : "732212802908258305",
  "text" : "RT @IBMWatson: 34 Watson-fueled apps were created at #HackDisrupt!  Read more about them on the blog: https:\/\/t.co\/2TWpjuUbZO https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IBMWatson\/status\/732210440864858113\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/bVhztScd9g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CilVg5rXEAAzk4Z.jpg",
        "id_str" : "732210438151278592",
        "id" : 732210438151278592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CilVg5rXEAAzk4Z.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 3024,
          "resize" : "fit",
          "w" : 4032
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/bVhztScd9g"
      } ],
      "hashtags" : [ {
        "text" : "HackDisrupt",
        "indices" : [ 38, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/2TWpjuUbZO",
        "expanded_url" : "http:\/\/ibm.co\/1shVqju",
        "display_url" : "ibm.co\/1shVqju"
      } ]
    },
    "geo" : { },
    "id_str" : "732210440864858113",
    "text" : "34 Watson-fueled apps were created at #HackDisrupt!  Read more about them on the blog: https:\/\/t.co\/2TWpjuUbZO https:\/\/t.co\/bVhztScd9g",
    "id" : 732210440864858113,
    "created_at" : "2016-05-16 14:05:47 +0000",
    "user" : {
      "name" : "IBM Watson",
      "screen_name" : "IBMWatson",
      "protected" : false,
      "id_str" : "29735775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799709755623309312\/VieAIRsg_normal.jpg",
      "id" : 29735775,
      "verified" : true
    }
  },
  "id" : 732212802908258305,
  "created_at" : "2016-05-16 14:15:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732212613879332864",
  "text" : "I'm glad to hear about the phase out of Flash on Chrome. Flash has had it's troubles on the internet, but still good for animated movies.",
  "id" : 732212613879332864,
  "created_at" : "2016-05-16 14:14:25 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/QN65Ml75iI",
      "expanded_url" : "http:\/\/jonathanmoore.com",
      "display_url" : "jonathanmoore.com"
    }, {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/FG6BTlXoBN",
      "expanded_url" : "http:\/\/jonathanmoore.net",
      "display_url" : "jonathanmoore.net"
    } ]
  },
  "geo" : { },
  "id_str" : "732173467668348928",
  "text" : "I've asked https:\/\/t.co\/QN65Ml75iI to sell me his domain I do have him beat. He just hasn't responded. I'm https:\/\/t.co\/FG6BTlXoBN",
  "id" : 732173467668348928,
  "created_at" : "2016-05-16 11:38:52 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IPCC",
      "screen_name" : "IPCC_CH",
      "indices" : [ 3, 11 ],
      "id_str" : "192942213",
      "id" : 192942213
    }, {
      "name" : "IDDRI",
      "screen_name" : "iddrilefil",
      "indices" : [ 89, 100 ],
      "id_str" : "1548953197",
      "id" : 1548953197
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/IPCC_CH\/status\/730398364966211584\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/f7ZDvGKYdn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiLlbEIWEAA0wD_.jpg",
      "id_str" : "730398342715412480",
      "id" : 730398342715412480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiLlbEIWEAA0wD_.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/f7ZDvGKYdn"
    } ],
    "hashtags" : [ {
      "text" : "IPCC",
      "indices" : [ 13, 18 ]
    }, {
      "text" : "climatechange",
      "indices" : [ 74, 88 ]
    }, {
      "text" : "2016itstime",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730398474454372352",
  "text" : "RT @IPCC_CH: #IPCC chair: new reports needed to close information gaps on #climatechange @iddrilefil #2016itstime https:\/\/t.co\/f7ZDvGKYdn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IDDRI",
        "screen_name" : "iddrilefil",
        "indices" : [ 76, 87 ],
        "id_str" : "1548953197",
        "id" : 1548953197
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IPCC_CH\/status\/730398364966211584\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/f7ZDvGKYdn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiLlbEIWEAA0wD_.jpg",
        "id_str" : "730398342715412480",
        "id" : 730398342715412480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiLlbEIWEAA0wD_.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/f7ZDvGKYdn"
      } ],
      "hashtags" : [ {
        "text" : "IPCC",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "climatechange",
        "indices" : [ 61, 75 ]
      }, {
        "text" : "2016itstime",
        "indices" : [ 88, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730398364966211584",
    "text" : "#IPCC chair: new reports needed to close information gaps on #climatechange @iddrilefil #2016itstime https:\/\/t.co\/f7ZDvGKYdn",
    "id" : 730398364966211584,
    "created_at" : "2016-05-11 14:05:15 +0000",
    "user" : {
      "name" : "IPCC",
      "screen_name" : "IPCC_CH",
      "protected" : false,
      "id_str" : "192942213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514319155747487744\/g-t9yu5u_normal.png",
      "id" : 192942213,
      "verified" : false
    }
  },
  "id" : 730398474454372352,
  "created_at" : "2016-05-11 14:05:41 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Gates",
      "screen_name" : "BillGates",
      "indices" : [ 0, 10 ],
      "id_str" : "50393960",
      "id" : 50393960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/uNFEFJyxnc",
      "expanded_url" : "http:\/\/goo.gl\/1gaIEE",
      "display_url" : "goo.gl\/1gaIEE"
    } ]
  },
  "geo" : { },
  "id_str" : "729689925566779392",
  "in_reply_to_user_id" : 50393960,
  "text" : "@BillGates Anti aging pill reviewed from M.I.T. https:\/\/t.co\/uNFEFJyxnc",
  "id" : 729689925566779392,
  "created_at" : "2016-05-09 15:10:09 +0000",
  "in_reply_to_screen_name" : "BillGates",
  "in_reply_to_user_id_str" : "50393960",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garbage",
      "screen_name" : "garbage",
      "indices" : [ 0, 8 ],
      "id_str" : "246639380",
      "id" : 246639380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/uNFEFJyxnc",
      "expanded_url" : "http:\/\/goo.gl\/1gaIEE",
      "display_url" : "goo.gl\/1gaIEE"
    } ]
  },
  "geo" : { },
  "id_str" : "729630200712048640",
  "in_reply_to_user_id" : 246639380,
  "text" : "@garbage Here is an Anti aging review form M.I.T Technology review https:\/\/t.co\/uNFEFJyxnc",
  "id" : 729630200712048640,
  "created_at" : "2016-05-09 11:12:50 +0000",
  "in_reply_to_screen_name" : "garbage",
  "in_reply_to_user_id_str" : "246639380",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garbage",
      "screen_name" : "garbage",
      "indices" : [ 0, 8 ],
      "id_str" : "246639380",
      "id" : 246639380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/OTd7ftZpvj",
      "expanded_url" : "http:\/\/goo.gl\/o8Faa6",
      "display_url" : "goo.gl\/o8Faa6"
    } ]
  },
  "geo" : { },
  "id_str" : "729629766903533568",
  "in_reply_to_user_id" : 246639380,
  "text" : "@garbage Here is OpenACH https:\/\/t.co\/OTd7ftZpvj",
  "id" : 729629766903533568,
  "created_at" : "2016-05-09 11:11:06 +0000",
  "in_reply_to_screen_name" : "garbage",
  "in_reply_to_user_id_str" : "246639380",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenACH",
      "screen_name" : "OpenACH",
      "indices" : [ 3, 11 ],
      "id_str" : "377009369",
      "id" : 377009369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729394901583056897",
  "text" : "RT @OpenACH: Completed testing of NACHA file reading and building, including International ACH batches as well as standard PPD batches!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116265504808775680",
    "text" : "Completed testing of NACHA file reading and building, including International ACH batches as well as standard PPD batches!",
    "id" : 116265504808775680,
    "created_at" : "2011-09-20 21:40:31 +0000",
    "user" : {
      "name" : "OpenACH",
      "screen_name" : "OpenACH",
      "protected" : false,
      "id_str" : "377009369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2328802586\/0io2895xf4w6d78ynfge_normal.png",
      "id" : 377009369,
      "verified" : false
    }
  },
  "id" : 729394901583056897,
  "created_at" : "2016-05-08 19:37:50 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Graffin",
      "screen_name" : "DoctorGraffin",
      "indices" : [ 0, 14 ],
      "id_str" : "54780669",
      "id" : 54780669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/uNFEFJyxnc",
      "expanded_url" : "http:\/\/goo.gl\/1gaIEE",
      "display_url" : "goo.gl\/1gaIEE"
    } ]
  },
  "geo" : { },
  "id_str" : "729373901965430786",
  "in_reply_to_user_id" : 54780669,
  "text" : "@DoctorGraffin Here is An Anti Aging Pill review in M.I.T technology review https:\/\/t.co\/uNFEFJyxnc",
  "id" : 729373901965430786,
  "created_at" : "2016-05-08 18:14:23 +0000",
  "in_reply_to_screen_name" : "DoctorGraffin",
  "in_reply_to_user_id_str" : "54780669",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Graffin",
      "screen_name" : "DoctorGraffin",
      "indices" : [ 0, 14 ],
      "id_str" : "54780669",
      "id" : 54780669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/OTd7ftZpvj",
      "expanded_url" : "http:\/\/goo.gl\/o8Faa6",
      "display_url" : "goo.gl\/o8Faa6"
    } ]
  },
  "geo" : { },
  "id_str" : "729373558317658112",
  "in_reply_to_user_id" : 54780669,
  "text" : "@DoctorGraffin Here is OpenACH https:\/\/t.co\/OTd7ftZpvj",
  "id" : 729373558317658112,
  "created_at" : "2016-05-08 18:13:02 +0000",
  "in_reply_to_screen_name" : "DoctorGraffin",
  "in_reply_to_user_id_str" : "54780669",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Axl Rose",
      "screen_name" : "axlrose",
      "indices" : [ 0, 8 ],
      "id_str" : "95956928",
      "id" : 95956928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/OTd7ftZpvj",
      "expanded_url" : "http:\/\/goo.gl\/o8Faa6",
      "display_url" : "goo.gl\/o8Faa6"
    } ]
  },
  "geo" : { },
  "id_str" : "729358001644146688",
  "in_reply_to_user_id" : 95956928,
  "text" : "@axlrose Here is OpenACH https:\/\/t.co\/OTd7ftZpvj",
  "id" : 729358001644146688,
  "created_at" : "2016-05-08 17:11:13 +0000",
  "in_reply_to_screen_name" : "axlrose",
  "in_reply_to_user_id_str" : "95956928",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avril Lavigne",
      "screen_name" : "AvrilLavigne",
      "indices" : [ 0, 13 ],
      "id_str" : "73992972",
      "id" : 73992972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/OTd7ftZpvj",
      "expanded_url" : "http:\/\/goo.gl\/o8Faa6",
      "display_url" : "goo.gl\/o8Faa6"
    } ]
  },
  "geo" : { },
  "id_str" : "729357539788390400",
  "in_reply_to_user_id" : 73992972,
  "text" : "@AvrilLavigne Here is OpenACH https:\/\/t.co\/OTd7ftZpvj",
  "id" : 729357539788390400,
  "created_at" : "2016-05-08 17:09:22 +0000",
  "in_reply_to_screen_name" : "AvrilLavigne",
  "in_reply_to_user_id_str" : "73992972",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Reznor",
      "screen_name" : "trent_reznor",
      "indices" : [ 0, 13 ],
      "id_str" : "15901190",
      "id" : 15901190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/OTd7ftZpvj",
      "expanded_url" : "http:\/\/goo.gl\/o8Faa6",
      "display_url" : "goo.gl\/o8Faa6"
    } ]
  },
  "geo" : { },
  "id_str" : "729356561483743237",
  "in_reply_to_user_id" : 15901190,
  "text" : "@trent_reznor Here is OpenACH https:\/\/t.co\/OTd7ftZpvj",
  "id" : 729356561483743237,
  "created_at" : "2016-05-08 17:05:29 +0000",
  "in_reply_to_screen_name" : "trent_reznor",
  "in_reply_to_user_id_str" : "15901190",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/ReT4RCo6Nf",
      "expanded_url" : "https:\/\/jdm7dv.blogspot.com\/",
      "display_url" : "jdm7dv.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "729232902479872000",
  "text" : "My latest blog posts https:\/\/t.co\/ReT4RCo6Nf",
  "id" : 729232902479872000,
  "created_at" : "2016-05-08 08:54:07 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DeutscheBank Service",
      "screen_name" : "DeuBaService",
      "indices" : [ 0, 13 ],
      "id_str" : "526425130",
      "id" : 526425130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725583141814067200",
  "geo" : { },
  "id_str" : "729027912238796800",
  "in_reply_to_user_id" : 526425130,
  "text" : "@DeuBaService  Then How do I open up an account abroad since I'm in the U.S. and make a deposit from my computer. If that is allowed.",
  "id" : 729027912238796800,
  "in_reply_to_status_id" : 725583141814067200,
  "created_at" : "2016-05-07 19:19:33 +0000",
  "in_reply_to_screen_name" : "DeuBaService",
  "in_reply_to_user_id_str" : "526425130",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728917038471757824",
  "text" : "I tried to hack a facebook and twitter animated GIF, but no luck only works on G+",
  "id" : 728917038471757824,
  "created_at" : "2016-05-07 11:58:59 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/72d22IpY1a",
      "expanded_url" : "http:\/\/www.jonathanmoore.net\/",
      "display_url" : "jonathanmoore.net"
    } ]
  },
  "geo" : { },
  "id_str" : "728238894806913024",
  "text" : "https:\/\/t.co\/72d22IpY1a",
  "id" : 728238894806913024,
  "created_at" : "2016-05-05 15:04:17 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN International",
      "screen_name" : "cnni",
      "indices" : [ 3, 8 ],
      "id_str" : "2097571",
      "id" : 2097571
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/cnni\/status\/728141880374890496\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/dTRlArsmyN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChrhDVrUkAESACx.jpg",
      "id_str" : "728141737248460801",
      "id" : 728141737248460801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChrhDVrUkAESACx.jpg",
      "sizes" : [ {
        "h" : 438,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/dTRlArsmyN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/OLIhp00NDV",
      "expanded_url" : "http:\/\/cnn.it\/1VKW3hs",
      "display_url" : "cnn.it\/1VKW3hs"
    } ]
  },
  "geo" : { },
  "id_str" : "728159148731404288",
  "text" : "RT @cnni: California raises smoking age to 21: https:\/\/t.co\/OLIhp00NDV https:\/\/t.co\/dTRlArsmyN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cnni\/status\/728141880374890496\/photo\/1",
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/dTRlArsmyN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChrhDVrUkAESACx.jpg",
        "id_str" : "728141737248460801",
        "id" : 728141737248460801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChrhDVrUkAESACx.jpg",
        "sizes" : [ {
          "h" : 438,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 438,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/dTRlArsmyN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/OLIhp00NDV",
        "expanded_url" : "http:\/\/cnn.it\/1VKW3hs",
        "display_url" : "cnn.it\/1VKW3hs"
      } ]
    },
    "geo" : { },
    "id_str" : "728141880374890496",
    "text" : "California raises smoking age to 21: https:\/\/t.co\/OLIhp00NDV https:\/\/t.co\/dTRlArsmyN",
    "id" : 728141880374890496,
    "created_at" : "2016-05-05 08:38:47 +0000",
    "user" : {
      "name" : "CNN International",
      "screen_name" : "cnni",
      "protected" : false,
      "id_str" : "2097571",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/617738860857061376\/75F3HUoe_normal.png",
      "id" : 2097571,
      "verified" : true
    }
  },
  "id" : 728159148731404288,
  "created_at" : "2016-05-05 09:47:24 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/ReT4RCo6Nf",
      "expanded_url" : "https:\/\/jdm7dv.blogspot.com\/",
      "display_url" : "jdm7dv.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "728158734833356800",
  "text" : "My latest blog posts https:\/\/t.co\/ReT4RCo6Nf",
  "id" : 728158734833356800,
  "created_at" : "2016-05-05 09:45:45 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bio is changed",
      "screen_name" : "BioIsChanged",
      "indices" : [ 0, 13 ],
      "id_str" : "385683871",
      "id" : 385683871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728011166870589440",
  "in_reply_to_user_id" : 385683871,
  "text" : "@BioIsChanged Please remove me please jdm7dv",
  "id" : 728011166870589440,
  "created_at" : "2016-05-04 23:59:22 +0000",
  "in_reply_to_screen_name" : "BioIsChanged",
  "in_reply_to_user_id_str" : "385683871",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Smith",
      "screen_name" : "BradSmi",
      "indices" : [ 0, 8 ],
      "id_str" : "14505546",
      "id" : 14505546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/6j3GDQjKA3",
      "expanded_url" : "https:\/\/github.com\/hacksysteam",
      "display_url" : "github.com\/hacksysteam"
    } ]
  },
  "geo" : { },
  "id_str" : "727891405209800705",
  "in_reply_to_user_id" : 14505546,
  "text" : "@BradSmi Hi Mr Smith I recently saw this on github (not mine) https:\/\/t.co\/6j3GDQjKA3 with the Windows Research Kernel. I would like removed",
  "id" : 727891405209800705,
  "created_at" : "2016-05-04 16:03:29 +0000",
  "in_reply_to_screen_name" : "BradSmi",
  "in_reply_to_user_id_str" : "14505546",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/CeQXyvbEBc",
      "expanded_url" : "https:\/\/jdm7dvfreebsd.blogspot.com\/",
      "display_url" : "jdm7dvfreebsd.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "727881104313753600",
  "text" : "My latest BSD blog posts: https:\/\/t.co\/CeQXyvbEBc",
  "id" : 727881104313753600,
  "created_at" : "2016-05-04 15:22:33 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/Gnt8OOetgo",
      "expanded_url" : "https:\/\/jdm7dvwindows.blogspot.com\/",
      "display_url" : "jdm7dvwindows.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "727880937602682880",
  "text" : "My latest Windows blog posts: https:\/\/t.co\/Gnt8OOetgo",
  "id" : 727880937602682880,
  "created_at" : "2016-05-04 15:21:53 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]