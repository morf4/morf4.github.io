Grailbird.data.tweets_2010_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 45, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13214927939",
  "text" : "Is now a official Telomerase Researcher ! :) #fb",
  "id" : 13214927939,
  "created_at" : "2010-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Wildermuth",
      "screen_name" : "ShawnWildermuth",
      "indices" : [ 63, 79 ],
      "id_str" : "1388411",
      "id" : 1388411
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wp7",
      "indices" : [ 52, 56 ]
    }, {
      "text" : "fb",
      "indices" : [ 80, 83 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13107741878",
  "geo" : { },
  "id_str" : "13109017197",
  "in_reply_to_user_id" : 1388411,
  "text" : "\"Windows Phone 7 Tools update! \u0006 http:\/\/is.gd\/bNWYJ #wp7\" \/via @ShawnWildermuth #fb",
  "id" : 13109017197,
  "in_reply_to_status_id" : 13107741878,
  "created_at" : "2010-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "ShawnWildermuth",
  "in_reply_to_user_id_str" : "1388411",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 21, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13110575576",
  "text" : "http:\/\/bit.ly\/9XuOSb #fb",
  "id" : 13110575576,
  "created_at" : "2010-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 36, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13131775652",
  "text" : "T4 screencast  http:\/\/bit.ly\/9XdsIw #fb",
  "id" : 13131775652,
  "created_at" : "2010-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 64, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13135737652",
  "text" : "http:\/\/bit.ly\/39zLeh OutSync  Plus changes in Outlook 2010 soon #fb",
  "id" : 13135737652,
  "created_at" : "2010-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12116501968",
  "text" : "@ch9live the LinqtoSql classes will only be in the WCF Ria toolkit right?  and what about sl4 in in the Biology Foundation?",
  "id" : 12116501968,
  "created_at" : "2010-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 79, 90 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 91, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11973951058",
  "text" : "\"Plane Crash May Strain Poland\u2019s Ties With Russia http:\/\/s.nyt.com\/u\/_Lp\" \/via @shanselman #fb",
  "id" : 11973951058,
  "created_at" : "2010-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Cockfield",
      "screen_name" : "philcockfield",
      "indices" : [ 32, 46 ],
      "id_str" : "13752402",
      "id" : 13752402
    }, {
      "name" : "Brad Abrams",
      "screen_name" : "brada",
      "indices" : [ 97, 103 ],
      "id_str" : "5356242",
      "id" : 5356242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 104, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11800676588",
  "text" : "\"How could I not RT this ;-) RT @philcockfield: God damn!  RIA Services is powerful stuff.\" \/via @brada #fb",
  "id" : 11800676588,
  "created_at" : "2010-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian_Henderson",
      "screen_name" : "brian_henderson",
      "indices" : [ 3, 19 ],
      "id_str" : "14438014",
      "id" : 14438014
    }, {
      "name" : "Pete Brown",
      "screen_name" : "Pete_Brown",
      "indices" : [ 72, 83 ],
      "id_str" : "5718162",
      "id" : 5718162
    }, {
      "name" : "Microsoft Channel 9",
      "screen_name" : "ch9",
      "indices" : [ 96, 100 ],
      "id_str" : "9460682",
      "id" : 9460682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11655808147",
  "text" : "RT @brian_henderson: Silverlight Manic Miner for Windows Phone 7: catch @Pete_Brown at MIX10 on @ch9: w\/ Richard Costall: http:\/\/ch9.ms\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pete Brown",
        "screen_name" : "Pete_Brown",
        "indices" : [ 51, 62 ],
        "id_str" : "5718162",
        "id" : 5718162
      }, {
        "name" : "Microsoft Channel 9",
        "screen_name" : "ch9",
        "indices" : [ 75, 79 ],
        "id_str" : "9460682",
        "id" : 9460682
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wp7",
        "indices" : [ 121, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "11655448877",
    "text" : "Silverlight Manic Miner for Windows Phone 7: catch @Pete_Brown at MIX10 on @ch9: w\/ Richard Costall: http:\/\/ch9.ms\/BKCP  #wp7",
    "id" : 11655448877,
    "created_at" : "2010-04-05 19:02:58 +0000",
    "user" : {
      "name" : "Brian_Henderson",
      "screen_name" : "brian_henderson",
      "protected" : false,
      "id_str" : "14438014",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1790327493\/brian_henderson_normal.png",
      "id" : 14438014,
      "verified" : false
    }
  },
  "id" : 11655808147,
  "created_at" : "2010-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Heuer",
      "screen_name" : "timheuer",
      "indices" : [ 17, 26 ],
      "id_str" : "782329",
      "id" : 782329
    }, {
      "name" : "John Papa",
      "screen_name" : "John_Papa",
      "indices" : [ 125, 135 ],
      "id_str" : "14660297",
      "id" : 14660297
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Silverlight",
      "indices" : [ 85, 97 ]
    }, {
      "text" : "fb",
      "indices" : [ 136, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11655915461",
  "text" : "\"Nice writeup by @timheuer  on handling WCF services in test\/staging\/production  for #Silverlight http:\/\/bit.ly\/b1Csdq\" \/via @John_Papa #fb",
  "id" : 11655915461,
  "created_at" : "2010-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]