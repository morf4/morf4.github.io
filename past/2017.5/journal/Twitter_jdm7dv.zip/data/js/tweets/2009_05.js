Grailbird.data.tweets_2009_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1874875586",
  "text" : "working with Visual Studo 2010 Beta 1 !",
  "id" : 1874875586,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]