Grailbird.data.tweets_2014_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/sOU1DZ6lPu",
      "expanded_url" : "http:\/\/gulfnews.com\/news\/gulf\/oman\/oman-researchers-find-cancer-treatment-in-frankincense-1.1251940",
      "display_url" : "gulfnews.com\/news\/gulf\/oman\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419626034015662080",
  "text" : "New Treatment for cancer http:\/\/t.co\/sOU1DZ6lPu",
  "id" : 419626034015662080,
  "created_at" : "2014-01-05 00:26:57 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 83, 91 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "interactive",
      "indices" : [ 66, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/3MxWDqK2cY",
      "expanded_url" : "http:\/\/twitter.github.io\/interactive\/newyear2014\/",
      "display_url" : "twitter.github.io\/interactive\/ne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419613254764089344",
  "text" : "Tweeting \"Happy New Year\" around the world http:\/\/t.co\/3MxWDqK2cY #interactive via @twitter",
  "id" : 419613254764089344,
  "created_at" : "2014-01-04 23:36:10 +0000",
  "user" : {
    "name" : "Jonathan Moore",
    "screen_name" : "jdm7dv",
    "protected" : false,
    "id_str" : "40799920",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778209068590698496\/ANy6AmwV_normal.jpg",
    "id" : 40799920,
    "verified" : false
  }
} ]