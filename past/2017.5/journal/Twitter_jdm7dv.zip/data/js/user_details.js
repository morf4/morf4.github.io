var user_details =  {
  "screen_name" : "jdm7dv",
  "location" : "Everywhere",
  "full_name" : "Jonathan Moore",
  "bio" : "Adobe, Microsoft, Amazon, Mensa International Community and Researcher since 2003.https:\/\/t.co\/NDRvc2nx7H",
  "id" : "40799920",
  "created_at" : "2009-05-18 03:03:04 +0000"
}