<?php
require_once("config.php");
require_once("include.php");
require_once("template_index.php");
header("Content-Type: text/html; charset=utf-8"); 

$dir = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
if (!strpos($dir,"?") === false) $dir = substr($dir,0,strpos($dir,"?"));
$dir = substr($dir,0,strrpos($dir,"/"))."/";
if ($c){
	$c = substr($_SERVER['REQUEST_URI'],strpos($_SERVER['REQUEST_URI'],"index.php?c=")+12);
	$c2 = $c;
	$c2 = str_replace("%83%C2","",$c2);
	$c2 = str_replace("&%3b","%26",$c2);
	$c2 = preg_replace("/(%..)/e","strtolower('\\1')",$c2);
	if (substr($c2,strlen($c2)-1,1) == "/") $c2 = substr($c2,0,strlen($c2)-1);
	if (substr($c2,0,1) == "/") $c2 = substr($c2,1,strlen($c2)-1);
	if ($c != $c2){
		header("HTTP/1.1 301 Moved Permanently"); 
		header("status 301 Moved Permanently"); 
		header("Location: {$dir}index.php?c={$c2}");
		exit();
	};
};
$c_title_array = urldecode($c);
if (get_magic_quotes_gpc()) $c_title_array = stripslashes($c_title_array);
$c_title_array = str_replace("_"," ",$c_title_array);
$c_title_array = explode("/",$c_title_array);
if (substr($home_path,strlen($home_path)-1,1) == "/") $home_path = substr($home_path,0,strlen($home_path)-1);
if (substr($home_path,0,1) == "/") $home_path = substr($home_path,1,strlen($home_path)-1);
$path = $home_path;
if ($home_path & $c) $path .= "/";
$path .= $c;

function encode_utf8($string){
	$string = html_entity_decode($string,ENT_COMPAT,"UTF-8");
	$string = htmlentities($string,2,"UTF-8");
	return $string;
};
function shorten_path($path){
	global $home_path;
	if (substr($path,0,1) == "/") $path = substr($path,1,strlen($path)-1);
	if (substr($path,strlen($path)-1,1) == "/") $path = substr($path,0,strlen($path)-1);
	if ($home_path){
		if (strpos($path,$home_path."/") === 0){
			$path = substr($path,strlen($home_path)+1);
		};
	};
	return $path;
};

$category_name = ($c)? $c_title_array[count($c_title_array)-1] : $site_title;
if ($c){
	$category_path = urldecode($c);
	$category_path = str_replace("/"," : ",$category_path);
	$category_path = str_replace("_"," ",$category_path);
	$category_path = $site_title." : ".$category_path;
	$reversed_category_path = implode("/",array_reverse(explode("/",$c)));
	$reversed_category_path = urldecode($reversed_category_path);
	$reversed_category_path = str_replace("/"," : ",$reversed_category_path);
	$reversed_category_path = str_replace("_"," ",$reversed_category_path);
	$reversed_category_path = $reversed_category_path." : ".$site_title;
}else{
	$category_path = $site_title;
	$reversed_category_path = $site_title;
};
$replace = array("[CATEGORY_NAME]" => encode_utf8($category_name), "[CATEGORY_PATH]" => encode_utf8($category_path), "[REVERSED_CATEGORY_PATH]" => encode_utf8($reversed_category_path));
echo strtr($TEMPLATE["HEADING"],$replace);

$c_array = explode("/",$c);
echo $TEMPLATE["PATH"]["HEADING"];
if (!$c){
	$replace = array("[CATEGORY_NAME]" => $site_title);
	echo strtr($TEMPLATE["PATH"]["CURRENT_CATEGORY"],$replace);
}else{
	$replace = array("[CATEGORY_URL]" => $dir, "[CATEGORY_NAME]" => $site_title);
	echo strtr($TEMPLATE["PATH"]["CATEGORY"],$replace);
	if (count($c_array) > 1){
		for ($x = 0; $x <= count($c_array)-2; $x++){
			if ($slash) $accumulated_path .= "/";
			$slash = true;
			$accumulated_path .= $c_array[$x];
			$replace = array("[CATEGORY_URL]" => $dir."index.php?c=".$accumulated_path, "[CATEGORY_NAME]" => encode_utf8($c_title_array[$x]));
			echo $TEMPLATE["PATH"]["SEPARATOR"].strtr($TEMPLATE["PATH"]["CATEGORY"],$replace);
		};
	};
	$replace = array("[CATEGORY_NAME]" => encode_utf8($category_name));
	echo $TEMPLATE["PATH"]["SEPARATOR"].strtr($TEMPLATE["PATH"]["CURRENT_CATEGORY"],$replace);
};
echo $TEMPLATE["PATH"]["FOOTER"];
flush();

if ($use_cache){
	$filename = "{$cache_directory}/browse".md5($path);
	if (file_exists($filename)){
		if (time()- filemtime($filename) < $cache_expiration){
			$cache = true;
		};
	};
};
if (!$cache){
	$url = "http://dmoz.org/{$path}";
	if (strlen($path) > 0 & strpos($path,".html") === false) $url .= "/";
	if((@$fp = fopen($url,"r")) != false){
		$file = "";
		while(!feof($fp)) {
			$file = $file . fread($fp, 1024);
		};
		fclose($fp);
	}else{
		$error = true;
		if ($cached){
			$cache = true;
		}else{
			$access_error = true;
		};
	};
	if (!$error){
		if (!$path){
			$n_blocks += 1;
			if ($adult_directory){
				$n_categories += 1;
				$odp["categories"][$n_blocks][$n_categories]["category"] = "Adult";
				$odp["categories"][$n_blocks][$n_categories]["path"] = "/Adult/";
			};
			while (eregi("(<span><a href=\")([^\"]+)(\">)([^\n]+)(</a></span>)",$file,$out)){
				$n_categories += 1;
				$odp["categories"][$n_blocks][$n_categories]["category"] = ereg_replace("(<[^>]+>)","",$out[4]);
				$odp["categories"][$n_blocks][$n_categories]["path"] = $out[2];
				$file = substr($file,strpos($file,$out[0])+strlen($out[0]));
			};
		}else{
			while (eregi("(<a id='_)([^']+)(' href=')([^']+)('>)([^<]+)(</a>)",$file,$out)){
				$n_bar += 1;
				$odp["bar"][$n_bar]["category"] = $out[6];
				$odp["bar"][$n_bar]["path"] = $out[4];
				$file = substr($file,strpos($file,$out[0])+strlen($out[0]));
			};
			while (eregi("<li class=\"\">[^<]+(<a href=\")([^\"]+)(\">)([^<]+)(</a>)([^<]+)(<em>\()([^\)]+)",$file,$out)){
				$crossed = false;
				if (!strpos($out[6],"@") === false) $crossed = "@";
				if (strpos($file,$out[0]) > strpos($file,"<div class=\"clear\"></div>")){
					$n_blocks += 1;
					$n_categories = 0;
				};
				if ($c_title_array[0] != "Adult" || $out[5] != "World"){
					$n_categories += 1;
					$odp["categories"][$n_blocks][$n_categories]["category"] = $out[4];
					$odp["categories"][$n_blocks][$n_categories]["path"] = $out[2];
					$odp["categories"][$n_blocks][$n_categories]["pages"] = $out[8];
					if ($crossed) $odp["categories"][$n_blocks][$n_categories]["crossed"] = $crossed;
				};
				$file = substr($file,strpos($file,$out[0])+strlen($out[0]));
			};
			while (eregi("(<li>)([^<]+)(<a href=\")([^\"]+)(\" class=\"listinglink\">)([^<]+)(</a>)([^<]+)-([^<]+)(<div class=\"flag\">)",$file,$out)){
				$n_pages += 1;
				$odp["pages"][$n_pages]["url"] = $out[4];
				$odp["pages"][$n_pages]["title"] = $out[6];
				$odp["pages"][$n_pages]["description"] = $out[9];
				$file = substr($file,strpos($file,$out[0])+strlen($out[0]));
			};
		};
		if ($use_cache){
			if ((@$cf = fopen($filename,"w")) != false){
				fwrite($cf,serialize($odp));
				fclose($cf);
			};
		};
	};
};
if ($use_cache){
	if ($cache){
		if((@$fp = fopen($filename,"r")) != false){
			$odp = unserialize(stripslashes(fread($fp,filesize($filename))));
			fclose($fp);
		};
	};
};
if ($access_error){
	echo $TEMPLATE["ERROR"];
}else{
	if ($odp["bar"]){
		echo $TEMPLATE["BAR"]["HEADING"];
		for ($x = 1; $x <= count($odp["bar"]); $x++){
			$replace = array("[ITEM_NAME]" => encode_utf8($odp["bar"][$x]["category"]), "[ITEM_URL]" => $dir."index.php?c=".shorten_path($odp["bar"][$x]["path"]));
			echo strtr($TEMPLATE["BAR"]["ITEM"],$replace);
		};
		echo $TEMPLATE["BAR"]["FOOTER"];
	};
	if ($home_path){
		for ($x = 1; $x <= count($odp["categories"]); $x++){
			for ($y = 1; $y <= count($odp["categories"][$x]); $y++){
				if (strpos($odp["categories"][$x][$y]["path"],"/".$home_path."/") !== 0){
					array_splice($odp["categories"][$x],$y-1,1);
					array_unshift($odp["categories"][$x],"");
					unset($odp["categories"][$x][0]);
					$y--;
				};
			};
		};
		for ($x = 1; $x <= count($odp["categories"]); $x++){
			if (!count($odp["categories"][$x])){
				array_splice($odp["categories"],$x-1,1);
				array_unshift($odp["categories"],"");
				unset($odp["categories"][0]);
				$x--;
			};
		};
	};
	if (count($odp["categories"])){
		for ($x = 1; $x <= count($odp["categories"]); $x++){
			echo $TEMPLATE["SUBCATEGORIES"]["HEADING"];
			for ($y = 1; $y <= ceil(count($odp["categories"][$x])/2); $y++){
				$category_pages = ($odp["categories"][$x][$y]["pages"])? "(".$odp["categories"][$x][$y]["pages"].")" : "";
				$replace = array("[CATEGORY_NAME]" => encode_utf8($odp["categories"][$x][$y]["category"]), "[CATEGORY_URL]" => $dir."index.php?c=".shorten_path($odp["categories"][$x][$y]["path"]), "[@]" => $odp["categories"][$x][$y]["crossed"], "[CATEGORY_PAGES]" => $category_pages);
				echo strtr($TEMPLATE["SUBCATEGORIES"]["CATEGORY"],$replace);
			};
			echo $TEMPLATE["SUBCATEGORIES"]["BETWEEN_COLUMNS"];
			for ($y = ceil(count($odp["categories"][$x])/2)+1; $y <= count($odp["categories"][$x]); $y++){
				$category_pages = ($odp["categories"][$x][$y]["pages"])? "(".$odp["categories"][$x][$y]["pages"].")" : "";
				$replace = array("[CATEGORY_NAME]" => encode_utf8($odp["categories"][$x][$y]["category"]), "[CATEGORY_URL]" => $dir."index.php?c=".shorten_path($odp["categories"][$x][$y]["path"]), "[@]" => $odp["categories"][$x][$y]["crossed"], "[CATEGORY_PAGES]" => $category_pages);
				echo strtr($TEMPLATE["SUBCATEGORIES"]["CATEGORY"],$replace);
			};
			echo $TEMPLATE["SUBCATEGORIES"]["FOOTER"];
		};
	};
	if (count($odp["pages"])){
		$replace = array("[TOTAL_PAGES]" => count($odp["pages"]), "[CATEGORY_NAME]" => encode_utf8($category_name));
		echo strtr($TEMPLATE["PAGES"]["HEADING"],$replace);
		for ($x = 1; $x <= count($odp["pages"]); $x++){
			$replace = array("[PAGE_TITLE]" => encode_utf8($odp["pages"][$x]["title"]), "[PAGE_DESCRIPTION]" => encode_utf8($odp["pages"][$x]["description"]), "[PAGE_URL]" => $odp["pages"][$x]["url"]);
			echo strtr($TEMPLATE["PAGES"]["PAGE"],$replace);
		};
		echo $TEMPLATE["PAGES"]["FOOTER"];
	};
};
echo <<<EOF
<!--//
DON'T REMOVE THIS. READ http://dmoz.org/become_an_editor/
//-->
<div class="block">
<p><table border="0" bgcolor="#dddddd" cellpadding="1" cellspacing="0"><tr><td>
<table width="100%" cellpadding="2" cellspacing="0" border="0"><tr align="center">
<td>&nbsp; &nbsp; Help build the largest human-edited directory on the web. &nbsp; &nbsp;</td>
</tr><tr bgcolor="#ffffff" align="center">
<td>&nbsp; &nbsp; <a href="http://dmoz.org/cgi-bin/add.cgi?where={$path}">Submit a site</a> - <a href="http://dmoz.org/about.html">Open Directory Project</a> - <a href="http://dmoz.org/cgi-bin/apply.cgi?where={$path}">Become an editor</a> &nbsp; &nbsp;</td>
</tr></table>
</td></tr></table></p>
</div>
EOF;
$path_title_array = urldecode($path);
if (get_magic_quotes_gpc()) $path_title_array = stripslashes($path_title_array);
$path_title_array = str_replace("_"," ",$path_title_array);
$path_title_array = explode("/",$path_title_array);
$category_name = ($path)? $path_title_array[count($path_title_array)-1] : "Top";
$category_url = ($path)? "Top/{$path}/" : "";

$sponsor = get_sponsor();

$replace = array("[CATEGORY_NAME]" => encode_utf8($category_name), "[CATEGORY_URL]" => $category_url, "[SPONSOR_URL]" => $sponsor["link"], "[SPONSOR_TEXT]" => $sponsor["text"]);
echo strtr($TEMPLATE["FOOTER"],$replace);
?>