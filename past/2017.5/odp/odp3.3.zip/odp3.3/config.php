<?php
$site_title = "Free PHP ODP Script";
$home_path = "Society"; // Default part of the directory ("" for ODP top category, always without "Top/"). For instance: "World/Espa%c3%b1ol", "Games/Video_Games"...
$use_cache = FALSE; // TRUE or FALSE. If TRUE, remember to chmod "cache" directory to 775 (read and write).
$adult_directory = false; // Include Adult branch of the directory. TRUE or FALSE.
$cache_directory = "cache";
$cache_expiration = 60*60*24*30; // Time in seconds: 60*60*24*30 = 30 days.
?>