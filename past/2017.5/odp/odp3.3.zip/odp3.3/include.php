<?php
if (phpversion() <= "4.0.6"){
	$_ENV = $HTTP_ENV_VARS;
	$_GET = $HTTP_GET_VARS;
	$_POST = $HTTP_POST_VARS;
	$_SERVER = $HTTP_SERVER_VARS;
};

if (!isset($_SERVER["REQUEST_URI"])) $_SERVER["REQUEST_URI"] = (isset($_SERVER["QUERY_STRING"]))? "{$_SERVER["SCRIPT_NAME"]}?{$_SERVER["QUERY_STRING"]}" : $_SERVER["SCRIPT_NAME"];

function array_stripslashes($string){
	if (is_array($string)){
		foreach ($string as $key=>$value) $string[$key] = array_stripslashes($value);
	}else{
		$string = stripslashes($string);
	};
	return $string;
};
if (get_magic_quotes_gpc()){
	$_GET = array_stripslashes($_GET);
	$_POST = array_stripslashes($_POST);
	if (phpversion() > "4.0.6") $_COOKIE = array_stripslashes($_COOKIE);
	else $_HTTP_COOKIE_VARS = array_stripslashes($_HTTP_COOKIE_VARS);
};
if (@count($_GET)) extract($_GET);
if (@count($_POST)) extract($_POST);

header("Content-Type: text/html; charset=iso-8859-1");
ini_set("register_globals", "Off");
if ($_SERVER['REQUEST_METHOD']  == "POST"){
	extract($_POST);
}else{
	extract($_GET);
};
function handler($data_type, $data_string, $data_file, $data_line, $data_varible){
	global $err;
	$err = $err + 1;
};
function check_error(&$error){
	global $err;
	if($err>0){
		$error = true;
		$err = 0;
	};
};
set_error_handler("handler");

FUNCTION get_sponsor(){
  $sponsors = array(
      array("Videva","http://videva.com/"),
      array("Music Videos","http://videva.com/"),
      array("Music","http://videva.com/"),
      array("SerialVision","http://serialvision.com/"),
      array("TV","http://serialvision.com/"),
      array("TV Shows","http://serialvision.com/"),
      array("FootyVision","http://footyvision.com/"),
      array("Football","http://footyvision.com/"),
      array("Football Highlights","http://footyvision.com/"),
      array("Download That Song","http://downloadthatsong.com/"),
      array("MP3","http://downloadthatsong.com/"),
      array("MP3 Download","http://downloadthatsong.com/")
  );

  $sponsor = strlen($_SERVER["HTTP_HOST"]) % count($sponsors);
  $sponsor_link = $sponsors[$sponsor][1];
  $sponsor_text = $sponsors[$sponsor][0];

	$return = array();
	$return['link'] = $sponsor_link;
	$return['text'] = $sponsor_text;
	return $return;
};

?>