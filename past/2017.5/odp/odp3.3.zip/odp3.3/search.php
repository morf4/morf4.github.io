<?php
require_once("config.php");
require_once("include.php");
require_once("template_search.php");
header("Content-Type: text/html; charset=utf-8"); 

$dir = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
if (!strpos($dir,"?") === false) $dir = substr($dir,0,strpos($dir,"?"));
$dir = substr($dir,0,strrpos($dir,"/"))."/";
if (!$q){
	header("HTTP/1.1 301 Moved Permanently"); 
	header("status 301 Moved Permanently"); 
	header("Location: {$dir}");
	exit();
};
function title_from_path($path){
	if (substr($path,0,1) == "/") $path = substr($path,1,strlen($path)-1);
	if (substr($path,strlen($path)-1,1) == "/") $path = substr($path,0,strlen($path)-1);
	$path_title_array = urldecode($path);
	if (get_magic_quotes_gpc()) $path_title_array = stripslashes($path_title_array);
	$path_title_array = str_replace("_"," ",$path_title_array);
	$path_title_array = explode("/",$path_title_array);
	$title = $path_title_array[count($path_title_array)-1];
	if (count($path_title_array) > 1){
		$title .= " (";
		if (count($path_title_array) > 5 & strpos($path,"Regional") === 0){
				$title .= "{$path_title_array[2]}... ";
		}elseif (count($path_title_array) > 7 & strpos($path,"World/Deutsch/Regional") === 0){
				$title .= "{$path_title_array[4]}... ";
		}elseif (count($path_title_array) > 6 & strpos($path,"World/Espa%c3%b1ol/Pa%c3%adses") === 0){
				$title .= "{$path_title_array[3]}... ";
		}elseif (count($path_title_array) > 7 & strpos($path,"World/Fran%c3%a7ais/R%c3%a9gional") === 0){
				$title .= "{$path_title_array[4]}... ";
		}elseif (count($path_title_array) > 7 & strpos($path,"World/Italiano/Regionale") === 0){
				$title .= "{$path_title_array[4]}... ";
		}elseif (count($path_title_array) > 7 & strpos($path,"World/Nederlands/Regionaal") === 0){
				$title .= "{$path_title_array[4]}... ";
		};
		if (count($path_title_array) > 2) $title .= "{$path_title_array[count($path_title_array)-3]} : ";
		$title .= $path_title_array[count($path_title_array)-2];
		$title .= ")";
	};
	return $title;
};
function decode_title($title){
	if (function_exists("html_entity_decode")){
		$title = html_entity_decode($title,2,"ISO-8859-15");
	}else{
		$title = str_replace("&amp;","&",$title);
	};
	return $title;
};
function decode_path($path){
	if (function_exists("html_entity_decode")){
		$path = urldecode($path);
		$path = html_entity_decode($path,2,"ISO-8859-15");
		$path = urlencode($path);
		$path = str_replace("%2F","/",$path);
	}else{
		$path = str_replace("%26amp%3b","%26",$path);
	};
	return $path;
};
function shorten_path($path){
	global $home_path;
	if (substr($path,0,1) == "/") $path = substr($path,1,strlen($path)-1);
	if (substr($path,strlen($path)-1,1) == "/") $path = substr($path,0,strlen($path)-1);
	if ($home_path){
		if (strpos(strtolower($path),strtolower($home_path)."/") === 0){
			$path = substr($path,strlen($home_path)+1);
		};
	};
	return $path;
};

$q = strtolower($q);
if (get_magic_quotes_gpc()) $q = stripslashes($q);
$replace = array("[SEARCH_TERM]" => htmlentities($q));
echo strtr($TEMPLATE["HEADING"],$replace);
flush();

if ($use_cache){
	$md5 = "search=".urlencode($q);
	if ($home_path) $md5 .= "&all=no&cat=".$home_path;
	$filename = "{$cache_directory}/search".md5($md5);
	if (file_exists($filename)){
		if (time()- filemtime($filename) < 60*60*24*30){
			$cache = true;
		};
	};
};
if (!$cache){
	$url = "http://search.dmoz.org/cgi-bin/search?search=".urlencode($q);
	if ($home_path) $url .= "&all=no&cat=".$home_path;
	if((@$fp = fopen($url,"r")) != false){
		$file = "";
		while(!feof($fp)) {
			$file = $file . fread($fp, 1024);
		};
		fclose($fp);
		if (!strpos($file,"The Open Directory search is temporarily unavailable") === false){
			$error = true;
			$access_error = true;
		};
	}else{
		$error = true;
		if ($cached) $cache = true;
	};
	if (!$error){
		while (eregi("(<a href=\")([^\"]+)(\"><strong>)([^<]+)(</strong></a>)",$file,$out)){
			$path_array = explode("/",substr($out[2],1,strlen($out[2])-2));
			if (substr($out[2],strlen($out[2])-3,1) == "/") $out[2] = substr($out[2],0,strlen($out[2])-2);
			$categories[$out[2]] = "";
			$file = substr($file,strpos($file,$out[0])+strlen($out[0]));
		};
		foreach ($categories as $path => $void){
			$n_categories += 1;
			$odp["categories"][$n_categories] = $path;
		};
		$file = str_replace("<b>","",$file);
		$file = str_replace("</b>","",$file);
		while (eregi("(<a href=\")([^\"]+)(\">)([^<]+)(</a> - )([^<]+)(<div)",$file,$out)){
			$n_pages += 1;
			$odp["pages"][$n_pages]["url"] = $out[2];
			$odp["pages"][$n_pages]["title"] = $out[4];
			$odp["pages"][$n_pages]["description"] = trim($out[6]);
			$file = substr($file,strpos($file,$out[0])+strlen($out[0]));
		};
		if ($use_cache){
			if ((@$cf = fopen($filename,"w")) != false){
				fwrite($cf,serialize($odp));
				fclose($cf);
			};
		};
	};
};
if ($use_cache){
	if ($cache){
		if((@$fp = fopen($filename,"r")) != false){
			$odp = unserialize(stripslashes(fread($fp,filesize($filename))));
			fclose($fp);
		};
	};
};
if ($access_error){
	echo $TEMPLATE["ERROR"];
}else{
	if ($home_path){
		for ($x = 1; $x <= count($odp["categories"]); $x++){
			if (strpos($odp["categories"][$x],"/".$home_path."/") === false){
				array_splice($odp["categories"],$x-1,1);
				array_unshift($odp["categories"],"");
				unset($odp["categories"][0]);
				$x--;
			};
		};
	};
	if (count($odp["categories"])){
		echo $TEMPLATE["SUBCATEGORIES"]["HEADING"];
		for ($x = 1; $x <= count($odp["categories"]); $x++){
			$odp["categories"][$x] = shorten_path(decode_path($odp["categories"][$x]));
			$category_name = urldecode($odp["categories"][$x]);
			$category_name = str_replace("/"," : ",$category_name);
			$category_name = str_replace("_"," ",$category_name);
			$replace = array("[CATEGORY_NAME]" => htmlentities($category_name,2,"UTF-8"), "[CATEGORY_URL]" => $dir."index.php?c={$odp["categories"][$x]}");
			echo strtr($TEMPLATE["SUBCATEGORIES"]["CATEGORY"],$replace);
		};
		echo $TEMPLATE["SUBCATEGORIES"]["FOOTER"];
	};
	if (count($odp["pages"])){
		$replace = array("[TOTAL_PAGES]" => count($odp["pages"]), "[SEARCH_TERM]" => htmlentities($q));
		echo strtr($TEMPLATE["PAGES"]["HEADING"],$replace);
		for ($x = 1; $x <= count($odp["pages"]); $x++){
			$odp["pages"][$x]["title"] = decode_title($odp["pages"][$x]["title"]);
			$replace = array("[PAGE_TITLE]" => htmlentities($odp["pages"][$x]["title"],2,"UTF-8"), "[PAGE_DESCRIPTION]" => htmlentities($odp["pages"][$x]["description"],2,"UTF-8"), "[PAGE_URL]" => $odp["pages"][$x]["url"]);
			echo strtr($TEMPLATE["PAGES"]["PAGE"],$replace);
		};
		echo $TEMPLATE["PAGES"]["FOOTER"];
	}else{
		$replace = array("[SEARCH_TERM]" => htmlentities($q));
		echo strtr($TEMPLATE["PAGES"]["NO_PAGES"],$replace);
	};
};
echo <<<EOF
<!--//
DON'T REMOVE THIS. READ http://dmoz.org/become_an_editor/
//-->
<div class="block">
<p><table border="0" bgcolor="#dddddd" cellpadding="1" cellspacing="0"><tr><td>
<table width="100%" cellpadding="2" cellspacing="0" border="0"><tr align="center">
<td>&nbsp; &nbsp; Help build the largest human-edited directory on the web. &nbsp; &nbsp;</td>
</tr><tr bgcolor="#ffffff" align="center">
<td>&nbsp; &nbsp; <a href="http://dmoz.org/cgi-bin/add.cgi?where={$path}">Submit a site</a> - <a href="http://dmoz.org/about.html">Open Directory Project</a> - <a href="http://dmoz.org/cgi-bin/apply.cgi?where={$path}">Become an editor</a> &nbsp; &nbsp;</td>
</tr></table>
</td></tr></table></p>
</div>
EOF;
EOF;

$sponsor = get_sponsor();

$replace = array("[SPONSOR_URL]" => $sponsor["link"], "[SPONSOR_TEXT]" => $sponsor["text"]);
echo strtr($TEMPLATE["FOOTER"],$replace);
?>