<?php
// HEADING LABELS: [SEARCH_TERM]

$TEMPLATE["HEADING"] = <<<EOF
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<title>[SEARCH_TERM] - Search results</title>
	<meta name="description" content="[SEARCH_TERM]" />
	<meta name="keywords" content="[SEARCH_TERM]" />
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<style type="text/css">
	body{color:#666;padding:40px 0 40px;margin:0;text-align:center}
	body,td{font:13px/18px "Lucida Grande","Lucida Sans Unicode",Verdana,Arial,sans-serif}
	input{font-family: "Lucida Grande","Lucida Sans Unicode",Verdana,Arial,sans-serif}
	a{border-bottom:1px solid #ddd;color:#21759b;text-decoration:none}
	a:hover,a:focus{color:#d54e21;border-color:#d54e21}
	h1{color:#000;font:46px/52px Georgia,"Bitstream Vera Serif","Times New Roman",serif;margin:0 120px 12px -2px}
	h2{color:#000;font-size:18px;font-weight:normal;line-height:29px;margin:10px 0 0 0}
	p,form{margin: 10px 0 0 0}
	ul,li{margin:0;padding:0}
	li{list-style: disc inside;padding-left:10px}
	#header{padding:0 12px 10px}
	#main{text-align:left;width:752px;margin:0 auto}
	.add_link{float:right;margin-top:10px}
	.add_link a{background:#488aa8;border:0;color:#fff;display:block;font-weight:bold;margin-left:5px;padding:4px 8px}
	.add_link a:hover,.comments_link a:focus{background:#d54e21;color:#fff}
	.block,.search{border-top:1px solid #ddd;padding:10px 12px 20px}
	.red{color:#f33}
	.search{background:#f6f6f6;padding:5px 12px 15px}
	</style>
	<body>
	<div id="main">
	<div id="header">
	<h1>Search results</h1>
	</div>
	<div class="search">
	<form action="search.php">
	<input type="text" name="q" value="[SEARCH_TERM]" size="50" />
	<input type="submit" value="Search" />
	</form>
	</div>
	<div class="block">
	<h2><a href=".">Index</a> &raquo; Search results</h2>
	</div>
EOF;

// CATEGORIES:CATEGORY LABELS: [CATEGORY_URL] [CATEGORY_NAME]

$TEMPLATE["SUBCATEGORIES"]["HEADING"] = <<<EOF
	<div class="block">
	<p><ul>
EOF;
$TEMPLATE["SUBCATEGORIES"]["CATEGORY"] = <<<EOF
	<li><a href="[CATEGORY_URL]">[CATEGORY_NAME]</a></li>
EOF;
$TEMPLATE["SUBCATEGORIES"]["FOOTER"] = <<<EOF
	</ul></p>
	</div>
EOF;

// PAGES:HEADING LABELS: [TOTAL_PAGES] [SEARCH_TERM]
// PAGES:PAGE LABELS: [PAGE_TITLE] [PAGE_DESCRIPTION] [PAGE_URL]
// PAGES:NO_PAGES LABELS: [SEARCH_TERM]

$TEMPLATE["PAGES"]["HEADING"] = <<<EOF
	<div class="block">
	<p>[TOTAL_PAGES] results found for the search [SEARCH_TERM]:</p>
EOF;
$TEMPLATE["PAGES"]["PAGE"] = <<<EOF
	<p><a href="[PAGE_URL]">[PAGE_TITLE]</a><br/>
	[PAGE_DESCRIPTION]<br/>
	[PAGE_URL]</p>
EOF;
$TEMPLATE["PAGES"]["FOOTER"] = <<<EOF
	</div>
EOF;
$TEMPLATE["PAGES"]["NO_PAGES"] = <<<EOF
	<div class="block">
	<p>No results found for the search [SEARCH_TERM].</p>
	</div>
EOF;

$TEMPLATE["ERROR"] = <<<EOF
	<div class="block">
	<p><i>ODP data temporarily unaccessible.</i></p>
	</div>
EOF;

$TEMPLATE["FOOTER"] = <<<EOF
	<!--//
	####################################################################

	REMOVING THE LINKS BELOW WITHOUT A SITE LICENSE IS AN ILLEGAL ACTION

	####################################################################
	//-->
	<div class="block">
	<p>Powered by the <a href="http://odp.javier-garcia.com/">Free PHP ODP Script</a> by <a href="[SPONSOR_URL]" rel="nofollow">[SPONSOR_TEXT]</a></p>
	</div>
	</div>
	</body>
	</html>
EOF;
?>