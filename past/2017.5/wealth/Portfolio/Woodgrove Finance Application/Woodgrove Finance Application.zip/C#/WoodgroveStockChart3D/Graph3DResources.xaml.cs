using System;
using System.Windows;

namespace WoodgroveFinanceStockChart3D
{
    public partial class Graph3DResources : ResourceDictionary
    {
        public Graph3DResources()
        {
            this.InitializeComponent();
        }
    }
}