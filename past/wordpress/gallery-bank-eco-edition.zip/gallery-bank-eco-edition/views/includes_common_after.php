<script type="text/javascript">
	
	jQuery(function ()
	{
		jQuery(".imgLiquidFill").imgLiquid({fill: true});
		<?php
		if($pagination_setting == 1)
		{
			?>
			jQuery("#holder").jPages({containerID: "gallery_bank_container", perPage:<?php echo $images_per_page ?>});
			<?php
		}
		?>
	});
	<?php
	switch($lightbox_type)
	{
		case "pretty_photo":
			?>
			jQuery(document).ready(function ()
			{
				jQuery("a[rel^=\"prettyPhoto\"]").prettyPhoto
				({
					animation_speed: <?php echo $lightbox_fade_in_time;?>, /* fast/slow/normal */
					slideshow: <?php echo $slide_interval * 1000; ?>, /* false OR interval time in ms */
					autoplay_slideshow: <?php echo $autoplay;?>, /* true/false */
					opacity: 0.80, /* Value between 0 and 1 */
					show_title: false, /* true/false */
					allow_resize: true,
					changepicturecallback: onPictureChanged
				});
			});
			if(typeof(onPictureChanged) != "function")
			{
				function onPictureChanged()
				{
					jQuery('.pp_social').append('<g:plusone data-action="share" href="'+ encodeURIComponent(location.href.replace(location.hash,"")) +'" width="160px" style="margin-left:5px; display:flex !important;"></g:plusone>');
					jQuery('.pp_social').append("<script type='text/javascript'> \
					(function() {\
					var po = document.createElement('script');\
					po.type = 'text/javascript';\
					po.async = true; \
					po.src = 'https://apis.google.com/js/plusone.js';\
					var s = document.getElementsByTagName('script')[0];\
					s.parentNode.insertBefore(po, s);\
					})(); <" + "/" +  "script>");
				}
			}
			<?php
		break;

		case "foo_box":
			?>
			jQuery(document).ready(function ()
			{
				(function (FOOBOX, $, undefined)
				{
					FOOBOX.init = function ()
					{
						$(".foobox").foobox(FOOBOX.o);
					};
				}(window.FOOBOX = window.FOOBOX || {}, jQuery));
				jQuery(function ($)
				{
					FOOBOX.init();
				});
			});
			<?php
		break;
	}
?>
</script>
