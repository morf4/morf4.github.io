<?php if (!defined('W3TC')) die(); ?>
<?php $this->checkbox('minify.css.strip.comments', false, 'css_') ?> <?php w3_e_config_label('minify.css.strip.comments') ?></label><br />
<?php $this->checkbox('minify.css.strip.crlf', false, 'css_') ?> <?php w3_e_config_label('minify.css.strip.crlf') ?></label><br />
