<?php

namespace Aventura\Wprss\Core\Model\Event;

/**
 * @since 4.8.1
 */
class Event extends EventAbstract
{
    
}