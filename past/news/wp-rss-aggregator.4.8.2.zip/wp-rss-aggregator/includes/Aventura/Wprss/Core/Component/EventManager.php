<?php

namespace Aventura\Wprss\Core\Component;

use Aventura\Wprss\Core;

/**
 * @since 4.8.1
 */
class EventManager extends Core\Model\Event\EventManagerAbstract implements Core\Plugin\ComponentInterface
{
    // All functionality is in most cases reusable from the ancestor
}