<?php

namespace Aventura\Wprss\Core\Model;

/**
 * A single command.
 *
 * Possible to instantiate and use right away.
 *
 * @since [*next-version]
 */
class Command extends CommandAbstract
{

}