<?php

namespace Aventura\Wprss\Core\Licensing\Plugin;

use Aventura\Wprss\Core\Licensing;

/**
 * Description of Exception
 *
 * @since 4.8.1
 */
class Exception extends Licensing\Exception
{
    //put your code here
}