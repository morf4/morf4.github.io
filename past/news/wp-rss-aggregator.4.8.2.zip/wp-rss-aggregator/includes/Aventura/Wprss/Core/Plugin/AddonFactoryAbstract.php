<?php

namespace Aventura\Wprss\Core\Plugin;

/**
 * Common functionality for add-on factories.
 *
 * @since 4.8.1
 */
abstract class AddonFactoryAbstract extends FactoryAbstract implements AddonFactoryInterface
{
}